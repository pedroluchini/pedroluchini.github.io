package control;

import java.util.Vector;

public abstract class HistoryManager {
	
	public final static int HISTORY_BUFFER_SIZE = 50;
	
	
	
	
	public static interface Listener {
		public void historyChanged ();
	}
	
	
	
	
	private static Vector<UndoOperation> undoBuffer = new Vector<UndoOperation>();
	private static Vector<UndoOperation> redoBuffer = new Vector<UndoOperation>();
	
	private static Vector<String> undoDescr  = new Vector<String>();
	private static Vector<String> redoDescr  = new Vector<String>();
	
	private static Vector<Listener> listeners = new Vector<Listener>();
	
	
	
	
	public static void addListener ( Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	
	
	
	public static void removeListener ( Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	/**
	 * Enqueues the specified operation in the buffer.
	 * This will clear the "redo" buffer.
	 */
	public static void addUndoOperation ( UndoOperation op, String description ) {
		undoBuffer.add( op );
		undoDescr.add( description );
		
		while ( undoBuffer.size() > HISTORY_BUFFER_SIZE ) {
			undoBuffer.remove( 0 );
			undoDescr.remove( 0 );
		}
		
		redoBuffer.removeAllElements();
		redoDescr.removeAllElements();
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).historyChanged();
	}
	
	
	
	
	/**
	 * Performs the last UndoOperation in the undoBuffer, adding its inverse to
	 * the redoBuffer.
	 */
	public static void undo () {
		UndoOperation op    = undoBuffer.lastElement();
		String        descr = undoDescr.lastElement();
		
		undoBuffer.remove( undoBuffer.size() - 1 );
		undoDescr.remove( undoDescr.size() - 1 );
		
		redoBuffer.add( op.getInverse() );
		redoDescr.add( descr );
		
		op.perform();
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).historyChanged();
	}
	
	/**
	 * Performs the last UndoOperation in the redoBuffer, adding its inverse to
	 * the undoBuffer.
	 */
	public static void redo () {
		UndoOperation op    = (UndoOperation) redoBuffer.lastElement();
		String        descr = (String)        redoDescr.lastElement();
		
		redoBuffer.remove( redoBuffer.size() - 1 );
		redoDescr.remove( redoDescr.size() - 1 );
		
		undoBuffer.add( op.getInverse() );
		undoDescr.add( descr );
		
		op.perform();
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).historyChanged();
	}
	
	
	/**
	 * Returns the description for the next Undo available, or null if there
	 * are no more operations.
	 */
	public static String nextUndoDescription () {
		if ( undoDescr.size() > 0 )
			return undoDescr.lastElement();
		else
			return null;
	}
	
	/**
	 * Returns the description for the next Redo available, or null if there
	 * are no more operations.
	 */
	public static String nextRedoDescription () {
		if ( redoDescr.size() > 0 )
			return redoDescr.lastElement();
		else
			return null;
	}
	
	
	
	
	/**
	 * Clears both buffers (undo and redo), disabling their corresponding menu
	 * items.
	 */
	public static void clear () {
		undoBuffer.removeAllElements();
		undoDescr.removeAllElements();
		redoBuffer.removeAllElements();
		redoDescr.removeAllElements();
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).historyChanged();
	}
	
	
	
	
	/**
	 * DO NOT USE THIS RETURN VALUE TO MODIFY THE ENVIRONMENT.
	 */
	public static UndoOperation getNextUndo () {
		if ( undoBuffer.size() > 0 )
			return undoBuffer.lastElement();
		else
			return null;
	}
	
	
	
	
	/**
	 * DO NOT USE THIS RETURN VALUE TO MODIFY THE ENVIRONMENT.
	 */
	public static UndoOperation getNextRedo () {
		if ( redoBuffer.size() > 0 )
			return redoBuffer.lastElement();
		else
			return null;
	}
	
}
