package control.tool;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.BGLayer;
import model.GlobalEditorModel;
import model.Room;
import model.TileBrushMatrix;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;
import model.selection.SelectionSet;
import control.Main;

public class TileSelectionTool extends ScrollTool {
	
	public final static Color  DRAGBOX_FILL_COLOR     = new Color( 255, 255, 255, 100 );
	public final static Color  DRAGBOX_OUTLINE_COLOR  = new Color( 255, 255, 255 );
	public final static Stroke DRAGBOX_OUTLINE_STROKE = new BasicStroke( 3.0f );
	public final static int    DRAG_IGNORE_AREA       = 3;
	public final static Color  DRAGMOVE_OUTLINE_COLOR  = Color.RED;
	public final static Stroke DRAGMOVE_OUTLINE_STROKE = new BasicStroke( 2.0f );
	
	
	
	
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	private boolean lastPressOnSelection = false;
	
	
	
	
	public TileSelectionTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super( globalEditorModel, toolBar );
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
	}
	
	
	
	
	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getCursor();
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) && getKeyState( KeyEvent.VK_SHIFT ) )
			return Main.wandPlusCursor;
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) && getKeyState( KeyEvent.VK_ALT ) )
			return Main.wandMinusCursor;
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) )
			return Main.wandCursor;
		else
		if ( getKeyState( KeyEvent.VK_SHIFT ) )
			return Main.selectionPlusCursor;
		else
		if ( getKeyState( KeyEvent.VK_ALT ) )
			return Main.selectionMinusCursor;
		else
		if ( (getCurrMouseButton() == MouseEvent.NOBUTTON && mouseOverTileSelection()) || lastPressOnSelection )
			return Cursor.getPredefinedCursor( Cursor.MOVE_CURSOR );
		else
			return Main.selectionCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBar.getTileToolBox();
	}
	
	
	
	
	public String getToolDescription() {
		return "Select, copy, move and delete tiles.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/tileSelection.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Tile selection";
	}
	
	
	
	
	public void paintOverlay(Graphics g) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.paintOverlay( g );
		}
		else
		if ( !getKeyState( KeyEvent.VK_CONTROL ) ) {
			// Paint selection overlay:
			
			// Dragging a new box?
			Point lastPressPoint = getLastPressPoint();
			Point currMousePoint = getCurrMousePoint();
			if ( !lastPressOnSelection && lastPressPoint != null && getCurrMouseButton() == MouseEvent.BUTTON1 ) {
				int layerInx = globalEditorModel.getWorkingLayer();
				
				if ( Math.abs(lastPressPoint.x - currMousePoint.x) < DRAG_IGNORE_AREA ||
				     Math.abs(lastPressPoint.y - currMousePoint.y) < DRAG_IGNORE_AREA )
					return;
				
				int col1 = globalEditorModel.tileColFromPanelX(currMousePoint.x, layerInx);
				int row1 = globalEditorModel.tileRowFromPanelY(currMousePoint.y, layerInx);
				int col2 = globalEditorModel.tileColFromPanelX(lastPressPoint.x, layerInx);
				int row2 = globalEditorModel.tileRowFromPanelY(lastPressPoint.y, layerInx);
				
				if ( row2 < row1 ) {
					int tmp = row1;
					row1 = row2;
					row2 = tmp;
				}
				if ( col2 < col1 ) {
					int tmp = col1;
					col1 = col2;
					col2 = tmp;
				}
				
				row2++; col2++;
				
				// Draw a rectangle covering the area, adjusted to the tiles.
				int x1 = globalEditorModel.panelXFromTileCol( col1, layerInx );
				int y1 = globalEditorModel.panelYFromTileRow( row1, layerInx );
				int x2 = globalEditorModel.panelXFromTileCol( col2, layerInx );
				int y2 = globalEditorModel.panelYFromTileRow( row2, layerInx );
				
				g.setColor( DRAGBOX_FILL_COLOR );
				g.fillRect( x1, y1, (x2 - x1), (y2 - y1) );
				
				g.setColor( DRAGBOX_OUTLINE_COLOR );
				Graphics2D g2D = (Graphics2D) g;
				Stroke oldStroke = g2D.getStroke();
				g2D.setStroke( DRAGBOX_OUTLINE_STROKE );
				
				g2D.drawRect( x1, y1, (x2 - x1), (y2 - y1) );
				
				g2D.setStroke( oldStroke );
			}
			// Dragging objects?
			else
			if ( lastPressOnSelection ) {
				globalEditorModel.roomPtFromPanelPt( lastPressPoint );
				globalEditorModel.roomPtFromPanelPt( currMousePoint );
				
				int dx = currMousePoint.x - lastPressPoint.x;
				int dy = currMousePoint.y - lastPressPoint.y;
				
				int tileW, tileH;
				if ( globalEditorModel.getWorkingLayer() == -1 ) {
					tileW = tileH = globalEditorModel.getLoadedRoom().getBlockSize();
				}
				else {
					int layerInx = globalEditorModel.getWorkingLayer();
					BGLayer bgLayer = globalEditorModel.getLoadedRoom().getBGLayer( layerInx );
					tileW = bgLayer.getTileWidth();
					tileH = bgLayer.getTileHeight();
				}
				
				dx /= tileW;
				dy /= tileH;
				
				// Draw tile outlines:
				Stroke oldStroke = ((Graphics2D) g).getStroke();
				((Graphics2D) g).setStroke( DRAGMOVE_OUTLINE_STROKE );
				g.setColor( DRAGMOVE_OUTLINE_COLOR );
				
				TileBrushMatrix tbm = (TileBrushMatrix) globalEditorModel.getSelectionSet();
				Point tl = new Point();
				Point tr = new Point();
				Point br = new Point();
				Point bl = new Point();
				int layerInx = globalEditorModel.getWorkingLayer();
				
				for ( int i = tbm.getOrigRow(); i <= tbm.getOrigRow() + tbm.getNumOfRows(); i++ ) {
					for ( int j = tbm.getOrigCol(); j <= tbm.getOrigCol() + tbm.getNumOfCols(); j++ ) {
						int tileID = tbm.getTileAtGlobalCoords(i, j);
						
						if ( tileID == TileBrushMatrix.FREE_CELL )
							continue;
						
						tl.x = globalEditorModel.panelXFromTileCol( j + dx,     layerInx );
						tl.y = globalEditorModel.panelYFromTileRow( i + dy,     layerInx );
						tr.x = globalEditorModel.panelXFromTileCol( j + dx + 1, layerInx );
						tr.y = globalEditorModel.panelYFromTileRow( i + dy,     layerInx );
						br.x = globalEditorModel.panelXFromTileCol( j + dx + 1, layerInx );
						br.y = globalEditorModel.panelYFromTileRow( i + dy + 1, layerInx );
						bl.x = globalEditorModel.panelXFromTileCol( j + dx,     layerInx );
						bl.y = globalEditorModel.panelYFromTileRow( i + dy + 1, layerInx );
						
						// Left:
						if ( tbm.getTileAtGlobalCoords(i, j - 1) == TileBrushMatrix.FREE_CELL ) {
							g.drawLine(tl.x, tl.y, bl.x, bl.y);
						}	
						// Right:
						if ( tbm.getTileAtGlobalCoords(i, j + 1) == TileBrushMatrix.FREE_CELL ) {
							g.drawLine(tr.x, tr.y, br.x, br.y);
						}
						// Top:
						if ( tbm.getTileAtGlobalCoords(i - 1, j) == TileBrushMatrix.FREE_CELL ) {
							g.drawLine(tl.x, tl.y, tr.x, tr.y);
						}
						// Bottom:
						if ( tbm.getTileAtGlobalCoords(i + 1, j) == TileBrushMatrix.FREE_CELL ) {
							g.drawLine(bl.x, bl.y, br.x, br.y);
						}
					}
				}
				((Graphics2D) g).setStroke( oldStroke );
			}
		}
	}
	
	
	
	
	public boolean safeDispatchKeyEvent(KeyEvent evt) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else {
			fireCursorChangedEvent();
		}
		
		return false;
	}
	
	
	
	
	public void safeMouseEntered ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseExited ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseExited( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseDragged(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseDragged( evt );
		}
		else {
			fireRepaintEvent();
			fireStatusBarChangedEvent();
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			fireStatusBarChangedEvent();
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMousePressed(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMousePressed( evt );
			fireCursorChangedEvent();
		}
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) ) {
			// Magic wand: Select similar adjacent tiles.
			int layerInx = globalEditorModel.getWorkingLayer();
			
			TileBrushMatrix selectionSet = null;
			if ( globalEditorModel.getSelectionSet() instanceof TileBrushMatrix )
				selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet().clone();
			
			if ( selectionSet == null ) {
				if ( layerInx == -1 )
					selectionSet = new BlockSelectionSet( globalEditorModel.getLoadedRoom().getBlockSize() );
				else {
					BGLayer bgLayer = globalEditorModel.getLoadedRoom().getBGLayer( layerInx );
					Image img = bgLayer.getImage();
					
					selectionSet = new BGTileSelectionSet( img.getWidth(Main.f), img.getHeight(Main.f), bgLayer.getTileWidth(), bgLayer.getTileHeight() );
				}	
			}
			
			Point currMousePoint = getCurrMousePoint();
			int col = globalEditorModel.tileColFromPanelX(currMousePoint.x, layerInx);
			int row = globalEditorModel.tileRowFromPanelY(currMousePoint.y, layerInx);
			
			// Build tile matrix of clicked area:
			Room room = globalEditorModel.getLoadedRoom();
			int tileID;
			if ( layerInx == -1 )
				tileID = room.getBlock( row, col );
			else
				tileID = room.getBGTile( layerInx, row, col );
			TileBrushMatrix clickedArea = makeTileArea( null, row, col, tileID, layerInx );
			int row1 = clickedArea.getOrigRow();
			int row2 = clickedArea.getOrigRow() + clickedArea.getNumOfRows() - 1;
			int col1 = clickedArea.getOrigCol();
			int col2 = clickedArea.getOrigCol() + clickedArea.getNumOfCols() - 1;
			
			// Which modifier key?
			if ( getKeyState( KeyEvent.VK_SHIFT ) ) {
				// Shift: Add tiles to selection.
				for ( int i = row1; i <= row2; i++ )
					for ( int j = col1; j <= col2; j++ )
						if ( clickedArea.getTileAtGlobalCoords( i, j ) != TileBrushMatrix.FREE_CELL )
							selectionSet.setTileAtGlobalCoords( i, j, -1 );
			}
			else
			if ( getKeyState( KeyEvent.VK_ALT ) ) {
				// Alt: Remove tiles from selection.
				for ( int i = row1; i <= row2; i++ )
					for ( int j = col1; j <= col2; j++ )
						if ( clickedArea.getTileAtGlobalCoords( i, j ) != TileBrushMatrix.FREE_CELL )
							selectionSet.unsetTileAtGlobalCoords( i, j );
			}
			else {
				// Start new selection... or clear existing one.
				selectionSet.clearBrush();
				for ( int i = row1; i <= row2; i++ )
					for ( int j = col1; j <= col2; j++ )
						if ( clickedArea.getTileAtGlobalCoords( i, j ) != TileBrushMatrix.FREE_CELL )
							selectionSet.setTileAtGlobalCoords( i, j, -1 );
			}
			
			// Set the new set:
			if ( selectionSet.getNumOfCols() == 0 || selectionSet.getNumOfRows() == 0 )
				Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.TILESELECTION_TOOL_INX, null );
			else
				Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.TILESELECTION_TOOL_INX, (SelectionSet) selectionSet );
			
		}
		else {
			if ( !getKeyState( KeyEvent.VK_ALT ) && !getKeyState( KeyEvent.VK_SHIFT ) )
				lastPressOnSelection = mouseOverTileSelection();
			else
				lastPressOnSelection = false;
			
			safeMouseDragged( evt );
		}
	}
	
	
	
	
	public void safeMouseReleased(MouseEvent evt) {
		Room room = globalEditorModel.getLoadedRoom();
		
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseReleased( evt );
			fireCursorChangedEvent();
		}
		else
		if ( !getKeyState( KeyEvent.VK_CONTROL ) ) {
			if ( evt.getButton() == MouseEvent.BUTTON1 ) {
				// Dragging a new box?
				if ( !lastPressOnSelection ) {
					Point lastPressPoint = getLastPressPoint();
					int layerInx = globalEditorModel.getWorkingLayer();
					
					Point currMousePoint = getCurrMousePoint();
					
					int col1 = globalEditorModel.tileColFromPanelX(currMousePoint.x, layerInx);
					int row1 = globalEditorModel.tileRowFromPanelY(currMousePoint.y, layerInx);
					int col2 = globalEditorModel.tileColFromPanelX(lastPressPoint.x, layerInx);
					int row2 = globalEditorModel.tileRowFromPanelY(lastPressPoint.y, layerInx);
					
					if ( row2 < row1 ) {
						int tmp = row1;
						row1 = row2;
						row2 = tmp;
					}
					if ( col2 < col1 ) {
						int tmp = col1;
						col1 = col2;
						col2 = tmp;
					}
					
					// Constrain to matrix:
					int numRows, numCols;
					if ( layerInx == -1 ) {
						numRows = room.getBlockMatrixRows();
						numCols = room.getBlockMatrixCols();
					}
					else {
						numRows = room.getBGTileMatrixRows( layerInx );
						numCols = room.getBGTileMatrixCols( layerInx );
					}
					if ( col1 < 0 ) col1 = 0;
					if ( row1 < 0 ) row1 = 0;
					if ( col2 >= numCols ) col2 = numCols - 1;
					if ( row2 >= numRows ) row2 = numRows - 1;
					
					TileBrushMatrix selectionSet = null;
					if ( globalEditorModel.getSelectionSet() instanceof TileBrushMatrix )
						selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet().clone();
					
					if ( selectionSet == null ) {
						if ( layerInx == -1 )
							selectionSet = new BlockSelectionSet( room.getBlockSize() );
						else {
							BGLayer bgLayer = room.getBGLayer( layerInx );
							Image img = bgLayer.getImage();
							
							selectionSet = new BGTileSelectionSet( img.getWidth(Main.f), img.getHeight(Main.f), bgLayer.getTileWidth(), bgLayer.getTileHeight() );
						}	
					}
					
					// Which modifier key?
					if ( getKeyState( KeyEvent.VK_SHIFT ) ) {
						// Shift: Add tiles to selection.
						if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
						     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
							for ( int i = row1; i <= row2; i++ )
								for ( int j = col1; j <= col2; j++ ) {
									selectionSet.setTileAtGlobalCoords( i, j, -1 );
								}
						}
					}
					else
					if ( getKeyState( KeyEvent.VK_ALT ) ) {
						// Alt: Remove tiles from selection.
						if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
						     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
							for ( int i = row1; i <= row2; i++ )
								for ( int j = col1; j <= col2; j++ )
									selectionSet.unsetTileAtGlobalCoords( i, j );
						}
					}
					else {
						// Start new selection... or clear existing one.
						selectionSet.clearBrush();
						if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
						     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
							for ( int i = row1; i <= row2; i++ )
								for ( int j = col1; j <= col2; j++ ) {
									selectionSet.setTileAtGlobalCoords( i, j, -1 );
								}
						}
					}
					
					// Set the new set:
					if ( selectionSet.getNumOfCols() == 0 || selectionSet.getNumOfRows() == 0 )
						Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.TILESELECTION_TOOL_INX, null );
					else
						Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.TILESELECTION_TOOL_INX, (SelectionSet) selectionSet );
					
				}
				else {
					// Drag the selected tiles (lastPressOnSelection == true).
					Point lastPressPoint = getLastPressPoint();
					Point currMousePoint = getCurrMousePoint();
					globalEditorModel.roomPtFromPanelPt( lastPressPoint );
					globalEditorModel.roomPtFromPanelPt( currMousePoint );
					
					int dx = currMousePoint.x - lastPressPoint.x;
					int dy = currMousePoint.y - lastPressPoint.y;
					
					int tileW, tileH;
					if ( globalEditorModel.getWorkingLayer() == -1 ) {
						tileW = tileH = globalEditorModel.getLoadedRoom().getBlockSize();
					}
					else {
						int layerInx = globalEditorModel.getWorkingLayer();
						BGLayer bgLayer = globalEditorModel.getLoadedRoom().getBGLayer( layerInx );
						tileW = bgLayer.getTileWidth();
						tileH = bgLayer.getTileHeight();
					}
					
					dx /= tileW;
					dy /= tileH;
					
					// Move tiles:
					Main.moveSelection(
						globalEditorModel,
						toolBar,
						dx, dy );
				}
				
				fireRepaintEvent();
			}
		}
		
		fireCursorChangedEvent();
		lastPressOnSelection = false;
	}
	
	
	
	
	private boolean mouseOverTileSelection () {
		Point currMousePoint = getCurrMousePoint();
		if ( (globalEditorModel.getSelectionSet() instanceof BlockSelectionSet ||
		      globalEditorModel.getSelectionSet() instanceof BGTileSelectionSet) &&
		     currMousePoint != null ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			int mouseRow = globalEditorModel.tileRowFromPanelY( currMousePoint.y, layerInx );
			int mouseCol = globalEditorModel.tileColFromPanelX( currMousePoint.x, layerInx );
			
			TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
			
			if ( selectionSet.getTileAtGlobalCoords( mouseRow, mouseCol ) != TileBrushMatrix.FREE_CELL ) {
				return true;
			}
		}
		
		return false;
	}
	
	
	
	
	public TileBrushMatrix makeTileArea ( TileBrushMatrix tbm, int row, int col, int equalToTileID, int layerInx ) {
		if ( tbm == null )
			tbm = new TileBrushMatrix(null, 0, 0);
		
		Room room = globalEditorModel.getLoadedRoom();
		
		// Current tile outside of matrix?
		if ( layerInx == -1 ) {
			if ( row < 0 || row >= room.getBlockMatrixRows() ||
			     col < 0 || col >= room.getBlockMatrixCols() )
				return tbm;
		}
		else {
			if ( row < 0 || row >= room.getBGTileMatrixRows( layerInx ) ||
			     col < 0 || col >= room.getBGTileMatrixCols( layerInx ) )
				return tbm;
		}
		
		// Current tile is already set?
		if ( tbm.getTileAtGlobalCoords( row, col ) != TileBrushMatrix.FREE_CELL )
			return tbm;
		
		// Start by adding the current tile:
		int tileID;
		if ( layerInx == -1 )
			tileID = room.getBlock( row, col );
		else
			tileID = room.getBGTile( layerInx, row, col );
		
		// Found a different tile?
		if ( tileID != equalToTileID )
			return tbm;
		
		tbm.setTileAtGlobalCoords( row, col, tileID );
		
		// Expand:
		makeTileArea( tbm, row - 1, col,     equalToTileID, layerInx );
		makeTileArea( tbm, row - 1, col + 1, equalToTileID, layerInx );
		makeTileArea( tbm, row,     col + 1, equalToTileID, layerInx );
		makeTileArea( tbm, row + 1, col + 1, equalToTileID, layerInx );
		makeTileArea( tbm, row + 1, col,     equalToTileID, layerInx );
		makeTileArea( tbm, row + 1, col - 1, equalToTileID, layerInx );
		makeTileArea( tbm, row,     col - 1, equalToTileID, layerInx );
		makeTileArea( tbm, row - 1, col - 1, equalToTileID, layerInx );
		
		return tbm;
	}
	
}
