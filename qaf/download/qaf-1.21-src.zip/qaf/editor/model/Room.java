package model;

import java.util.Vector;

import control.Main;

public class Room {
	
	public final static int MAX_BGTILE_ID = Short.MAX_VALUE;
	public final static int PURE_BGTILE_MASK    = 0x0000FFFF;
	public final static int FLIPPED_TILE_X_MASK = 0x80000000;
	public final static int FLIPPED_TILE_Y_MASK = 0x40000000;
	public final static int COLORED_TILE_MASK   = 0x20000000;
	
	
	
	
	public static interface Listener {
		public void blockChanged ( Room src, int row, int col );
		public void bgLayerAdded ( Room src, int newLayerIndex );
		public void bgLayerRemoved ( Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] bgTileColorMatrix );
		public void bgLayerSwapped ( Room src, int bgInx1, int bgInx2 );
		public void bgTileChanged ( Room src, int layerIndex, int row, int col );
		public void bgTileColorChanged ( Room src, int layerIndex, int row, int col );
		public void waterLevelChanged ( Room src );
		public void defaultObjLayerChanged ( Room src );
		public void gameObjAdded ( Room src, int newIndex );
		public void gameObjRemoved ( Room src, int oldIndex, GameObj obj );
		public void gameObjSwapped ( Room src, int i1, int i2 );
	}
	
	
	
	
	private class BGLayerListener implements BGLayer.Listener {
		
		public void translationChanged(BGLayer src) {}
		
		public void imageChanged(BGLayer src) {}

		public void parallaxChanged(BGLayer src) {
			resizeBGTileMatrix( bgLayers.indexOf( src ) );
		}

		public void tileSizeChanged(BGLayer src) {
			resizeBGTileMatrix( bgLayers.indexOf( src ) );
		}

		private void resizeBGTileMatrix(int layerInx) {
			BGLayer bgLayer = bgLayers.get( layerInx );
			int[][] oldBGTileMatrix = bgTileMatrices.get( layerInx );
			ColorTile[][] oldBGTileColorMatrix = bgTileColorMatrices.get( layerInx );
			
			int oldRows = oldBGTileMatrix.length;
			int oldCols = oldBGTileMatrix[0].length;
			
			int newRows = calculateRequiredRows( bgLayer );
			int newCols = calculateRequiredCols( bgLayer );
			
			if ( oldRows == newRows && oldCols == newCols )
				return;
			
			int[][] newBGTileMatrix = new int[newRows][newCols];
			for ( int i = 0; i < newBGTileMatrix.length; i++ )
				for ( int j = 0; j < newBGTileMatrix[i].length; j++ )
					newBGTileMatrix[i][j] = -1;
			ColorTile[][] newBGTileColorMatrix = new ColorTile[newRows][newCols];
			for ( int i = 0; i < newBGTileColorMatrix.length; i++ )
				for ( int j = 0; j < newBGTileColorMatrix[i].length; j++ )
					newBGTileColorMatrix[i][j] = null;
			
			Main.blitMatrix( newBGTileMatrix, oldBGTileMatrix, 0, 0 );
			Main.blitMatrix( newBGTileColorMatrix, oldBGTileColorMatrix, 0, 0 );
			
			bgTileMatrices.set( layerInx, newBGTileMatrix );
			bgTileColorMatrices.set( layerInx, newBGTileColorMatrix );
		}
	}
	
	
	
	
	private int[][] blockMatrix;
	private int blockSize;
	private int screenWidth, screenHeight;
	private int roomWidth, roomHeight;
	private Vector<BGLayer> bgLayers = new Vector<BGLayer>();
	private Vector<int[][]> bgTileMatrices = new Vector<int[][]>();
	private Vector<ColorTile[][]> bgTileColorMatrices = new Vector<ColorTile[][]>();
	private int waterLevel;
	private int defaultObjLayer = 0;
	private Vector<GameObj> gameObjs = new Vector<GameObj>();
	
	private BGLayerListener bgLayerListener = new BGLayerListener();
	
	private Vector<Listener> listeners = new Vector<Listener>();
	
	
	
	
	public void addListener ( Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	
	
	
	public void removeListener ( Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	public Room ( int blockSize,
	              int screenWidth, int screenHeight,
	              int roomWidth, int roomHeight,
	              int waterLevel ) {
		this.blockSize = blockSize;
		this.screenWidth = screenWidth;
		this.screenHeight = screenHeight;
		this.roomWidth = roomWidth;
		this.roomHeight = roomHeight;
		this.waterLevel = waterLevel;
		
		this.blockMatrix = new int[roomHeight * screenHeight][roomWidth * screenWidth];
		for ( int i = 0; i < blockMatrix.length; i++ )
			for ( int j = 0; j < blockMatrix[i].length; j++ )
				blockMatrix[i][j] = -1;
	}
	
	
	
	
	public int getBlockSize () {
		return blockSize;
	}
	
	
	
	
	public int getBlockMatrixRows () {
		return blockMatrix.length;
	}
	
	
	
	
	public int getBlockMatrixCols () {
		return blockMatrix[0].length;
	}
	
	
	
	
	public void setBlock ( int row, int col, int blockID ) {
		blockMatrix[row][col] = blockID;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).blockChanged( this, row, col );
	}
	
	
	
	
	public int getBlock ( int row, int col ) {
		return blockMatrix[row][col];
	}
	
	
	
	
	public int getScreenWidth () {
		return screenWidth;
	}
	
	
	
	
	public int getScreenHeight () {
		return screenHeight;
	}
	
	
	
	
	public int getRoomWidth () {
		return roomWidth;
	}
	
	
	
	
	public int getRoomHeight () {
		return roomHeight;
	}
	
	
	
	
	public void addBGLayer ( int layerIndex, BGLayer bgLayer ) {
		bgLayers.add( layerIndex, bgLayer );
		
		int rows = calculateRequiredRows( bgLayer ); 
		int cols = calculateRequiredCols( bgLayer );

		int[][] newBGData = new int[rows][cols];
		for ( int i = 0; i < newBGData.length; i++ )
			for ( int j = 0; j < newBGData[i].length; j++ )
				newBGData[i][j] = -1;
		
		ColorTile[][] newBGColorData = new ColorTile[rows][cols];
		for ( int i = 0; i < newBGColorData.length; i++ )
			for ( int j = 0; j < newBGColorData[i].length; j++ )
				newBGColorData[i][j] = null;
		
		bgTileMatrices.add( layerIndex, newBGData );
		bgTileColorMatrices.add( layerIndex, newBGColorData );
		
		bgLayer.addListener( bgLayerListener );
		
		// Notify listeners:
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).bgLayerAdded( this, layerIndex );
		
		// Keep def. obj layer consistent:
		if ( defaultObjLayer > layerIndex )
			setDefaultObjLayer( layerIndex + 1 );
	}
	
	
	
	
	public void addBGLayer ( BGLayer bgLayer ) {
		addBGLayer( bgLayers.size(), bgLayer );
	}
	
	
	
	
	public void removeBGLayer ( int layerIndex ) {
		BGLayer bgLayer = bgLayers.get( layerIndex );
		int[][] bgTileMatrix = bgTileMatrices.get( layerIndex );
		ColorTile[][] bgTileColorMatrix = bgTileColorMatrices.get( layerIndex );
		
		bgLayers.remove( layerIndex );
		bgTileMatrices.remove( layerIndex );
		bgTileColorMatrices.remove( layerIndex );
		
		bgLayer.removeListener( bgLayerListener );
		
		// Notify listeners:
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).bgLayerRemoved( this, layerIndex, bgLayer, bgTileMatrix, bgTileColorMatrix );
		
		// Keep def. obj layer consistent:
		if ( defaultObjLayer >= layerIndex )
			setDefaultObjLayer( defaultObjLayer - 1 );
	}
	
	
	
	
	public void swapBGLayers ( int i1, int i2 ) {
		BGLayer bgLayer1 = bgLayers.get( i1 );
		BGLayer bgLayer2 = bgLayers.get( i2 );
		bgLayers.set( i1, bgLayer2 );
		bgLayers.set( i2, bgLayer1 );
		
		int[][] bgMatrix1 = bgTileMatrices.get( i1 );
		int[][] bgMatrix2 = bgTileMatrices.get( i2 );
		bgTileMatrices.set( i1, bgMatrix2 );
		bgTileMatrices.set( i2, bgMatrix1 );
		
		ColorTile[][] bgColorMatrix1 = bgTileColorMatrices.get( i1 );
		ColorTile[][] bgColorMatrix2 = bgTileColorMatrices.get( i2 );
		bgTileColorMatrices.set( i1, bgColorMatrix2 );
		bgTileColorMatrices.set( i2, bgColorMatrix1 );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).bgLayerSwapped( this, i1, i2 );
	}
	
	
	
	
	public int getNumOfBGLayers () {
		return bgLayers.size();
	}
	
	
	
	
	public BGLayer getBGLayer ( int layerIndex ) {
		return bgLayers.get( layerIndex );
	}
	
	
	
	
	public int getBGTileMatrixRows ( int layerInx ) {
		return bgTileMatrices.get( layerInx ).length;
	}
	
	
	
	
	public int getBGTileMatrixCols ( int layerInx ) {
		return bgTileMatrices.get( layerInx )[0].length;
	}
	
	
	
	
	public void setBGTile ( int layerInx, int row, int col, int tileID ) {
		bgTileMatrices.get( layerInx )[row][col] = tileID;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).bgTileChanged( this, layerInx, row, col );
	}
	
	
	
	
	public int getBGTile ( int layerInx, int row, int col ) {
		return bgTileMatrices.get( layerInx )[row][col];
	}
	
	
	
	
	public void setBGTileColor ( int layerInx, int row, int col, ColorTile tileColor ) {
		if ( tileColor == null )
			tileColor = ColorTile.DEFAULT;
		
		bgTileColorMatrices.get( layerInx )[row][col] = tileColor;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).bgTileColorChanged( this, layerInx, row, col );
	}
	
	
	
	
	public ColorTile getBGTileColor ( int layerInx, int row, int col ) {
		ColorTile tileColor = bgTileColorMatrices.get( layerInx )[row][col];
		
		if ( tileColor == null )
			return ColorTile.DEFAULT;
		else
			return tileColor;
	}
	
	
	
	
	public void setWaterLevel ( int waterLevel ) {
		this.waterLevel = waterLevel;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).waterLevelChanged( this );
	}
	
	
	
	
	public int getWaterLevel () {
		return waterLevel;
	}
	
	
	
	
	public void setDefaultObjLayer ( int layerInx ) {
		if ( layerInx >= 0 && layerInx <= bgLayers.size() ) {
			this.defaultObjLayer = layerInx;
			
			for ( int i = 0; i < listeners.size(); i++ )
				listeners.get( i ).defaultObjLayerChanged( this );
		}
	}
	
	
	
	
	public int getDefaultObjLayer () {
		return defaultObjLayer;
	}
	
	
	
	
	public void addGameObj ( int index, GameObj obj ) {
		gameObjs.add( index, obj );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).gameObjAdded( this, index );
	}
	
	
	
	
	public void addGameObj ( GameObj obj ) {
		gameObjs.add( obj );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).gameObjAdded( this, gameObjs.size() - 1 );
	}
	
	
	
	
	public void removeGameObj ( int index ) {
		GameObj obj = gameObjs.get( index );
		gameObjs.remove( index );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).gameObjRemoved( this, index, obj );
	}
	
	
	
	
	public int indexOfGameObj ( GameObj obj ) {
		return gameObjs.indexOf( obj );
	}
	
	
	
	
	public void swapGameObjs ( int i1, int i2 ) {
		GameObj obj1 = gameObjs.get( i1 );
		GameObj obj2 = gameObjs.get( i2 );
		
		gameObjs.set( i1, obj2 );
		gameObjs.set( i2, obj1 );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).gameObjSwapped( this, i1, i2 );
	}
	
	
	
	
	public int getNumOfObjs () {
		return gameObjs.size();
	}
	
	
	
	
	public GameObj getObj ( int index ) {
		return gameObjs.get( index );
	}
	
	
	
	
	public int getPixelWidth () {
		return roomWidth * screenWidth * blockSize;
	}
	
	
	
	
	public int getPixelHeight () {
		return roomHeight * screenHeight * blockSize;
	}
	
	
	
	
	public int getScreenPixelWidth () {
		return screenWidth * blockSize;
	}
	
	
	
	
	public int getScreenPixelHeight () {
		return screenHeight * blockSize;
	}
	
	
	
	
	public int calculateRequiredRows ( BGLayer bgLayer ) {
		int virtualPixelHeight = Math.round(screenHeight * blockSize + (roomHeight - 1) * screenHeight * blockSize * Math.abs(bgLayer.getParallaxY()));
		int rows = (int) Math.round( Math.ceil( (float) virtualPixelHeight / bgLayer.getTileHeight() ) + 1 );
		return rows;
	}
	
	
	
	
	public int calculateRequiredCols ( BGLayer bgLayer ) {
		int virtualPixelWidth  = Math.round( screenWidth  * blockSize + (roomWidth  - 1) * screenWidth  * blockSize * Math.abs(bgLayer.getParallaxX()) );
		int cols = (int) Math.round( Math.ceil( (float) virtualPixelWidth / bgLayer.getTileWidth() ) + 1 );
		return cols;
	}
	
}
