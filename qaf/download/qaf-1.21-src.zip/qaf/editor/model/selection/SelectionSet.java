package model.selection;

import model.GlobalEditorModel;

public interface SelectionSet {
	
	/**
	 * Returns true if the selection can be pasted onto the editor in its
	 * current state.
	 */
	public boolean canPaste ( GlobalEditorModel gem );
	
	/**
	 * Moves the selection by the specified amount.
	 */
	public void move ( int horiz, int vert );
	
	/**
	 * Flips the selection's contents.
	 */
	public void flip ( boolean horizontally, boolean vertically );
	
	/**
	 * Creates an exact copy of this set.
	 */
	public SelectionSet clone ();
	
	/**
	 * This method should make a "back up" of the room's relevant data, so it
	 * can be restored later with restoreState().
	 */
	public Object makeBackUpOfState ( GlobalEditorModel globalEditorModel, int layerInx );
	
	/**
	 * This method should take the argument returned by makeBackUpOfState() and
	 * restore it in the room. 
	 */
	public void restoreState ( GlobalEditorModel globalEditorModel, int layerInx, Object backUp );
	
	/**
	 * This method should try its best to make the selection centered on screen.
	 */
	public void centerOnScreen ( GlobalEditorModel globalEditorModel, int layerInx );
	
	/**
	 * Returns true if the selection must/can be floated to be moved/flipped/pasted.
	 */
	public boolean isFloatable ();
	
	/**
	 * Returns true if the selection can be maintained across this layer transition.
	 */
	public boolean survivesLayerChange ( GlobalEditorModel globalEditorModel, int fromLayerInx, int toLayerInx );
	
	/**
	 * Returns a seelction set that can be pasted. This may or may not mean
	 * that the selection or its contents needs to be cloned.
	 */
	public SelectionSet getPasteableClone ();
	
	/**
	 * Tests two selection sets for equality.
	 */
	public boolean equals ( SelectionSet that );
}
