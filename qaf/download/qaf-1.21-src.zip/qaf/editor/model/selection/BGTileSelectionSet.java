/*
 * Created on Jun 8, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package model.selection;

import java.awt.Image;
import java.awt.Rectangle;

import model.AbstractTileMatrix;
import model.BGLayer;
import model.GlobalEditorModel;
import model.Room;
import model.TileBrushMatrix;
import control.Main;

public class BGTileSelectionSet extends TileBrushMatrix implements SelectionSet, AbstractTileMatrix {
	
	private int imageWidth, imageHeight, tileWidth, tileHeight;
	
	
	
	
	public String toString () {
		return "[BGTileSelectionSet: orig=(" + getOrigRow() + ", " + getOrigCol() + "); size=(" + getNumOfRows() + ", " + getNumOfCols() + ")]";
	}
	
	
	
	
	public BGTileSelectionSet ( int imageWidth, int imageHeight, int tileWidth, int tileHeight ) {
		super( null, 0, 0 );
		this.imageWidth = imageWidth;
		this.imageHeight = imageHeight;
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
	}
	
	
	
	
	public int getImageWidth () {
		return imageWidth;
	}
	
	
	
	
	public int getImageHeight () {
		return imageHeight;
	}
	
	
	
	
	public int getTileWidth () {
		return tileWidth;
	}
	
	
	
	
	public int getTileHeight () {
		return tileHeight;
	}
	
	
	
	
	public boolean canPaste(GlobalEditorModel gem) {
		if ( gem.getWorkingLayer() == -1 )
			return false;
		
		BGLayer bgLayer = gem.getLoadedRoom().getBGLayer( gem.getWorkingLayer() );
		Image img = bgLayer.getImage();
		
		if (img.getWidth(Main.f) != imageWidth)
			return false;
		if (img.getHeight(Main.f) != imageHeight)
			return false;
		if (bgLayer.getTileWidth() != tileWidth)
			return false;
		if (bgLayer.getTileHeight() != tileHeight)
			return false;
		
		return true;
	}
	
	
	
	
	public void move ( int horiz, int vert ) {
		int origCol = getOrigCol();
		int origRow = getOrigRow();
		
		origCol += horiz;
		origRow += vert;
		
		setOrigin( origRow, origCol );
	}
	
	
	
	
	public SelectionSet clone () {
		BGTileSelectionSet that = new BGTileSelectionSet(this.imageWidth, this.imageHeight, this.tileWidth, this.tileHeight);
		for ( int i = this.getOrigRow(); i <= this.getOrigRow() + this.getNumOfRows(); i++ )
			for ( int j = this.getOrigCol(); j <= this.getOrigCol() + this.getNumOfCols(); j++ )
				that.setTileAtGlobalCoords( i, j, this.getTileAtGlobalCoords(i, j) );
		return that;
	}
	
	
	
	
	public Object makeBackUpOfState ( GlobalEditorModel globalEditorModel, int layerInx ) {
		Room room = globalEditorModel.getLoadedRoom();
		int[][] backUp = Main.getLayerTileMatrix( room, layerInx );
		return backUp;
	}




	public void restoreState(GlobalEditorModel globalEditorModel, int layerInx, Object _backUp) {
		Room room = globalEditorModel.getLoadedRoom();
		int[][] backUp = (int[][]) _backUp;
		
		for ( int i = 0; i < room.getBGTileMatrixRows( layerInx ); i++ )
			for ( int j = 0; j < room.getBGTileMatrixCols( layerInx ); j++ )
				room.setBGTile( layerInx, i, j, backUp[i][j] );
	}
	
	
	
	
	public void centerOnScreen ( GlobalEditorModel globalEditorModel, int layerInx ) {
		// Get the viewport's center:
		Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
		int centerPanelX = viewRect.x + viewRect.width/2;
		int centerPanelY = viewRect.y + viewRect.height/2;
		
		// Get the row/column of the screen's center:
		int centerRow = globalEditorModel.tileRowFromPanelY( centerPanelY, layerInx );
		int centerCol = globalEditorModel.tileColFromPanelX( centerPanelX, layerInx );
		
		// Calculate how much the selection needs to be displaced so it will
		// be centered on that row/col:
		int newOrigRow = centerRow - getNumOfRows() + getNumOfRows()/2;
		int newOrigCol = centerCol - getNumOfCols() + getNumOfCols()/2;
		
		// Center it:
		setOrigin( newOrigRow, newOrigCol );
	}
	
	
	
	
	public boolean isFloatable () {
		return true;
	}
	
	
	
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof BGTileSelectionSet ) {
			BGTileSelectionSet that = (BGTileSelectionSet) obj;
			
			if ( this.imageHeight         != that.imageHeight         ||
			     this.imageWidth          != that.imageWidth          ||
			     this.tileHeight          != that.tileHeight          ||
			     this.tileWidth           != that.tileWidth           ||
			     this.getOrigCol()        != that.getOrigCol()        ||
			     this.getOrigRow()        != that.getOrigRow()        ||
			     this.getNumOfCols() != that.getNumOfCols() ||
			     this.getNumOfRows() != that.getNumOfRows() )
				return false;
			
			for ( int i = 0; i < getNumOfRows(); i++ )
				for ( int j = 0; j < getNumOfCols(); j++ )
					if ( this.getTileAtBrushCoords(i, j) != that.getTileAtBrushCoords(i, j) )
						return false;
			
			return true;
		}
		else
			return false;
	}
	
	public boolean equals ( SelectionSet that ) {
		return equals( (Object) that );
	}
	
	
	
	
	public boolean survivesLayerChange ( GlobalEditorModel globalEditorModel, int fromLayerInx, int toLayerInx ) {
		if ( toLayerInx == -1 )
			return false;
		
		BGLayer fromLayer = globalEditorModel.getLoadedRoom().getBGLayer( fromLayerInx );
		BGLayer toLayer   = globalEditorModel.getLoadedRoom().getBGLayer( toLayerInx );
		
		if ( fromLayer.getTranslationX() != toLayer.getTranslationX() )
			return false;
		if ( fromLayer.getTranslationY() != toLayer.getTranslationY() )
			return false;
		if ( fromLayer.getParallaxX() != toLayer.getParallaxX() )
			return false;
		if ( fromLayer.getParallaxY() != toLayer.getParallaxY() )
			return false;
		if ( fromLayer.getTileHeight() != toLayer.getTileHeight() )
			return false;
		if ( fromLayer.getTileWidth() != toLayer.getTileWidth() )
			return false;
		
		return false;
	}
	
	
	
	
	public SelectionSet getPasteableClone () {
		return this.clone();
	}
	
}
