package model;

import java.awt.Point;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JViewport;

import model.selection.BGTileColorSelectionSet;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;
import model.selection.GameObjSelectionSet;
import model.selection.SelectionSet;
import control.Main;

public class GlobalEditorModel {
	
	public static interface Listener {
		public void unsavedChangesChanged (GlobalEditorModel src);
		public void basePathChanged (GlobalEditorModel src);
		public void loadedRoomChanged (GlobalEditorModel src, Room oldRoom, String oldRoomFileName);
		public void scrollChanged (GlobalEditorModel src);
		public void bgLayerVisibilityChanged (GlobalEditorModel src, int layerInx);
		public void blockLayerVisibilityChanged (GlobalEditorModel src);
		public void workingLayerChanged (GlobalEditorModel src);
		public void gridVisibilityChanged (GlobalEditorModel src);
		public void zoomChanged (GlobalEditorModel src);
		public void selectionChanged (GlobalEditorModel src, SelectionSet oldSelection);
		public void clipboardChanged (GlobalEditorModel src, SelectionSet oldClipboard);
	}
	
	
	
	
	private class GameObjListener implements GameObj.Listener {

		public void attributeChanged(GameObj src, String attrKey) {}
		public void idChanged(GameObj src) {}
		
		public void positionChanged(GameObj src) {
			// Constrain to room bounds:
			int x = src.getX();
			x = Math.max( 0, x );
			x = Math.min( loadedRoom.getPixelWidth(), x );
			
			int y = src.getY();
			y = Math.max( 0, y );
			y = Math.min( loadedRoom.getPixelHeight(), y );
			
			if ( x != src.getX() || y != src.getY() )
				src.setPosition( x, y );
		}
	}
	
	
	
	
	private class BGLayerListener implements BGLayer.Listener {

		public void imageChanged(BGLayer src) {}
		public void parallaxChanged(BGLayer src) {}
		public void tileSizeChanged(BGLayer src) {}
		public void translationChanged(BGLayer src) {}
		
	}
	
	
	
	
	private class RoomListener implements Room.Listener {
		
		public void blockChanged(Room src, int row, int col) {}
		public void defaultObjLayerChanged(Room src) {}
		public void gameObjSwapped(Room src, int i1, int i2) {}
		public void waterLevelChanged(Room src) {}
		public void bgTileChanged(Room src, int layerIndex, int row, int col) {}
		public void bgTileColorChanged(Room src, int layerIndex, int row, int col) {}
		
		public void bgLayerAdded(Room src, int newLayerIndex) {
			src.getBGLayer( newLayerIndex ).addListener( bgLayerListener );
			
			// Synchronize visibility array:
			boolean[] newVisibilities = new boolean[src.getNumOfBGLayers()];
			
			for ( int i = 0; i < newVisibilities.length; i++ )
				if ( i < newLayerIndex )
					newVisibilities[i] = bgLayerVisibilities[i];
				else
				if ( i == newLayerIndex )
					newVisibilities[i] = true;
				else
					newVisibilities[i] = bgLayerVisibilities[i - 1];
			
			bgLayerVisibilities = newVisibilities;
		}

		public void bgLayerRemoved(Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] bgTileColorMatrix) {
			bgLayer.removeListener( bgLayerListener );
			
			// Synchronize visibility array:
			boolean[] newVisibilities = new boolean[src.getNumOfBGLayers()];
			
			for ( int i = 0; i < newVisibilities.length; i++ )
				if ( i < oldLayerIndex )
					newVisibilities[i] = bgLayerVisibilities[i];
				else
					newVisibilities[i] = bgLayerVisibilities[i + 1];
			
			bgLayerVisibilities = newVisibilities;
			
			// Check if the workingBGLayerInx hasn't passed the layer vector
			// size:
			if ( workingBGLayerInx >= src.getNumOfBGLayers() )
				setWorkingLayer( src.getNumOfBGLayers() - 1 );
		}

		public void bgLayerSwapped(Room src, int bgInx1, int bgInx2 ) {
			// Synchronize visibility array:
			boolean b1 = bgLayerVisibilities[bgInx1];
			bgLayerVisibilities[bgInx1] = bgLayerVisibilities[bgInx2];
			bgLayerVisibilities[bgInx2] = b1;
		}
		
		public void gameObjAdded(Room src, int newIndex) {
			src.getObj(newIndex).addListener( gameObjListener );
		}
		
		public void gameObjRemoved(Room src, int oldIndex, GameObj obj) {
			obj.removeListener( gameObjListener );
		}
		
	}
	
	
	
	
	private boolean unsavedChanges = false;
	private String basePath;
	private Room loadedRoom;
	private String loadedRoomFileName;
	private int scrollX, scrollY;
	private boolean[] bgLayerVisibilities;
	private boolean blockLayerVisible = true;
	private int workingBGLayerInx = -1;
	private boolean gridVisible = true;
	private float zoom = 1.0f;
	private JViewport viewport;
	private SelectionSet selectionSet;
	private boolean selectionFloating = false;
	private SelectionSet clipboard;
	
	private RoomListener roomListener = new RoomListener();
	private BGLayerListener bgLayerListener = new BGLayerListener();
	private GameObjListener gameObjListener = new GameObjListener();
	
	Vector<Listener> listeners = new Vector<Listener>();
	
	
	
	
	public void addListener ( Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	
	
	
	public void removeListener ( Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	public GlobalEditorModel ( Room loadedRoom, String loadedRoomFileName, String basePath ) {
		this.setLoadedRoom( loadedRoom, loadedRoomFileName );
		this.setBasePath( basePath );
		this.setClipboardContents( null );
	}
	
	
	
	
	public void setUnsavedChanges ( boolean unsavedChanges ) {
		if ( this.unsavedChanges == unsavedChanges )
			return;
		
		this.unsavedChanges = unsavedChanges;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).unsavedChangesChanged( this );
	}
	
	
	
	
	public boolean hasUnsavedChanges () {
		return unsavedChanges;
	}
	
	
	
	
	public void setBasePath ( String basePath ) {
		basePath = Main.getCanonicalPath( basePath );
		
		if ( this.basePath != null && this.basePath.equals( basePath ) )
			return;
		
		
		this.basePath = basePath;
		
		try {
			BufferedWriter fh = new BufferedWriter(
					new OutputStreamWriter(
					new FileOutputStream(Main.qafPath + "basePath.txt") ) );
			
			fh.write( basePath );
			fh.close();
		}
		catch ( IOException exc ) {
			JOptionPane.showMessageDialog(
					Main.f,                      // parent dialog
					"Could not write the base path to \"basePath.txt\".", // message
					"Error",                     // title
					JOptionPane.ERROR_MESSAGE ); // message type
			System.exit( -1 );
		}
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).basePathChanged( this );
	}
	
	
	
	
	public String getBasePath () {
		return basePath;
	}
	
	
	
	
	public void setLoadedRoom ( Room room, String fileName ) {
		if ( this.loadedRoom != null ) {
			this.loadedRoom.removeListener( roomListener );
			for ( int i = 0; i < this.loadedRoom.getNumOfBGLayers(); i++ )
				this.loadedRoom.getBGLayer(i).removeListener(bgLayerListener);
			for ( int i = 0; i < this.loadedRoom.getNumOfObjs(); i++ )
				this.loadedRoom.getObj(i).removeListener(gameObjListener);
		}
		
		Room oldRoom = this.loadedRoom;
		String oldRoomFileName = this.loadedRoomFileName;
		
		this.loadedRoom = room;
		this.loadedRoomFileName = fileName;
		
		loadedRoom.addListener( roomListener );
		for ( int i = 0; i < loadedRoom.getNumOfBGLayers(); i++ )
			loadedRoom.getBGLayer(i).addListener(bgLayerListener);
		for ( int i = 0; i < loadedRoom.getNumOfObjs(); i++ )
			loadedRoom.getObj(i).addListener(gameObjListener);
		
		bgLayerVisibilities = new boolean[room.getNumOfBGLayers()];
		for ( int i = 0; i < bgLayerVisibilities.length; i++ )
			bgLayerVisibilities[i] = true;
		
		// Reset scrolling:
		setScroll( 0, 0 );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).loadedRoomChanged( this, oldRoom, oldRoomFileName );
		
		// Reset selection:
		setSelectionSet( null, false );
	}
	
	
	
	
	public Room getLoadedRoom () {
		return loadedRoom;
	}
	
	
	
	
	public String getLoadedRoomFileName () {
		return loadedRoomFileName;
	}
	
	
	
	
	public void setScroll ( int scrollX, int scrollY ) {
		// Validate:
		int rightLimitX = loadedRoom.getPixelWidth() - loadedRoom.getScreenPixelWidth();
		int bottLimitY = loadedRoom.getPixelHeight() - loadedRoom.getScreenPixelHeight();
		
		if ( scrollX < 0 )
			scrollX = 0;
		else
		if ( scrollX > rightLimitX )
			scrollX = rightLimitX;
		
		if ( scrollY < 0 )
			scrollY = 0;
		else
		if ( scrollY > bottLimitY )
			scrollY = bottLimitY;
		
		// Set if different:
		if ( this.scrollX == scrollX && this.scrollY == scrollY )
			return;
		
		this.scrollX = scrollX;
		this.scrollY = scrollY;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).scrollChanged( this );
	}
	
	
	
	
	public void moveScroll ( int dx, int dy ) {
		setScroll( scrollX + dx, scrollY + dy );
	}
	
	
	
	
	public int getScrollX () {
		return scrollX;
	}
	
	
	
	
	public int getScrollY () {
		return scrollY;
	}
	
	
	
	
	public void setBGLayerVisibility ( int layerInx, boolean visible ) {
		if ( bgLayerVisibilities[layerInx] == visible )
			return;
		
		bgLayerVisibilities[layerInx] = visible;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).bgLayerVisibilityChanged( this, layerInx );
	}
	
	
	
	
	public boolean isBGLayerVisible ( int layerInx ) {
		return bgLayerVisibilities[layerInx];
	}
	
	
	
	
	public void setBlockLayerVisibility ( boolean visible ) {
		if ( this.blockLayerVisible == visible )
			return;
		
		this.blockLayerVisible = visible;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).blockLayerVisibilityChanged( this );
	}
	
	
	
	
	public boolean isBlockLayerVisible () {
		return blockLayerVisible;
	}
	
	
	
	
	public void setWorkingLayer ( int layerIndex ) {
		if ( this.workingBGLayerInx == layerIndex )
			return;
		
		// Change the working layer:
		this.workingBGLayerInx = layerIndex;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).workingLayerChanged( this );
	}
	
	
	
	
	public int getWorkingLayer () {
		return workingBGLayerInx;
	}
	
	
	
	
	public void setGridVisibility ( boolean gridVisible ) {
		if ( this.gridVisible == gridVisible )
			return;
		
		this.gridVisible = gridVisible;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).gridVisibilityChanged( this );
	}
	
	
	
	
	public boolean isGridVisible () {
		return gridVisible;
	}
	
	
	
	
	public void setZoom ( float zoom ) {
		if ( this.zoom == zoom )
			return;
		
		this.zoom = zoom;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).zoomChanged( this );
	}
	
	
	
	
	public float getZoom () {
		return zoom;
	}
	
	
	
	
	public void setViewport ( JViewport viewport ) {
		this.viewport = viewport;
	}
	
	
	
	
	public JViewport getViewport () {
		return viewport;
	}
	
	
	
	
	public void setSelectionSet ( SelectionSet selectionSet, boolean floating ) {
		if ( selectionSet == null && floating )
			throw new IllegalArgumentException( "Can't have a floating null selection." );
		
		SelectionSet oldSelection = this.selectionSet;
		
		if ( selectionSet != null )
			this.selectionSet = selectionSet.clone();
		else
			this.selectionSet = null;
		this.selectionFloating = floating;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).selectionChanged( this, oldSelection );
	}
	
	
	
	
	public SelectionSet getSelectionSet () {
		return selectionSet;
	}
	
	
	
	
	public boolean isSelectionFloating () {
		return selectionFloating;
	}
	
	
	
	
	public void floatSelection () {
		if ( selectionFloating )
			throw new IllegalStateException("Selection is already floating.");
		
		if ( selectionSet == null ) {
			throw new IllegalStateException("Can't float a null selection.");
		}
		else
		if ( !selectionSet.isFloatable() ) {
			throw new IllegalStateException("Selection is not floatable: " + selectionSet);
		}
		else
		if ( selectionSet instanceof BlockSelectionSet ||
		     selectionSet instanceof BGTileSelectionSet ) {
			TileBrushMatrix tileSelectionSet = (TileBrushMatrix) selectionSet;
			
			int row1 = tileSelectionSet.getOrigRow();
			int row2 = tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows();
			int col1 = tileSelectionSet.getOrigCol();
			int col2 = tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols();
			
			// Copy tiles from the selection below:
			for ( int i = row1; i <= row2; i++ ) {
				for ( int j = col1; j <= col2; j++ ) {
					if ( tileSelectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL ) {
						int tileID = -1;
						
						if ( workingBGLayerInx == -1 )
							try {
								tileID = loadedRoom.getBlock(i, j);
							}
							catch (ArrayIndexOutOfBoundsException exc) {}
						else
							try {
								tileID = loadedRoom.getBGTile( workingBGLayerInx, i, j );
							}
							catch (ArrayIndexOutOfBoundsException exc) {}
						
						tileSelectionSet.setTileAtGlobalCoords( i, j, tileID );
					}
				}
			}
			
			// Clear selected tiles:
			for ( int i = tileSelectionSet.getOrigRow(); i <= tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows(); i++ ) {
				for ( int j = tileSelectionSet.getOrigCol(); j <= tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols(); j++ ) {
					if ( tileSelectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL ) {
						if ( workingBGLayerInx == -1 )
							try {
								loadedRoom.setBlock(i, j, -1);
							}
							catch (ArrayIndexOutOfBoundsException exc) {}
						else
							try {
								loadedRoom.setBGTile( workingBGLayerInx, i, j, -1 );
							}
							catch (ArrayIndexOutOfBoundsException exc) {}
					}
				}
			}
		}
		else
		if ( selectionSet instanceof BGTileColorSelectionSet ) {
			BGTileColorSelectionSet tileColorSelectionSet = (BGTileColorSelectionSet) selectionSet;
			
			int row1 = tileColorSelectionSet.getOrigRow();
			int row2 = tileColorSelectionSet.getOrigRow() + tileColorSelectionSet.getNumOfRows();
			int col1 = tileColorSelectionSet.getOrigCol();
			int col2 = tileColorSelectionSet.getOrigCol() + tileColorSelectionSet.getNumOfCols();
			
			// Copy tiles from the selection below:
			for ( int i = row1; i <= row2; i++ ) {
				for ( int j = col1; j <= col2; j++ ) {
					if ( tileColorSelectionSet.getTileAtGlobalCoords(i, j) != null ) {
						if ( workingBGLayerInx == -1 )
							throw new IllegalStateException("Can't have color selections in the obstacle layer.");
						
						ColorTile tileColor = ColorTile.DEFAULT;
						try {
							tileColor = loadedRoom.getBGTileColor( workingBGLayerInx, i, j );
						}
						catch (ArrayIndexOutOfBoundsException exc) {}
						
						tileColorSelectionSet.setTileAtGlobalCoords( i, j, tileColor );
					}
				}
			}
			
			// Clear selected tiles:
			for ( int i = tileColorSelectionSet.getOrigRow(); i <= tileColorSelectionSet.getOrigRow() + tileColorSelectionSet.getNumOfRows(); i++ ) {
				for ( int j = tileColorSelectionSet.getOrigCol(); j <= tileColorSelectionSet.getOrigCol() + tileColorSelectionSet.getNumOfCols(); j++ ) {
					if ( tileColorSelectionSet.getTileAtGlobalCoords(i, j) != null ) {
						try {
							loadedRoom.setBGTileColor( workingBGLayerInx, i, j, null );
						}
						catch (ArrayIndexOutOfBoundsException exc) {}
					}
				}
			}
		}
		else
		if ( selectionSet instanceof GameObjSelectionSet ) {}
		else {
			throw new IllegalStateException("Unknown selection set type.");
		}
		
		selectionFloating = true;
	}
	
	
	
	
	public void defloatSelection () {
		if ( !selectionFloating )
			throw new IllegalStateException("Selection is already defloated.");
		
		if ( selectionSet == null ) {
			throw new IllegalStateException("Can't defloat a null selection.");
		}
		else
		if ( selectionSet instanceof BlockSelectionSet ||
		     selectionSet instanceof BGTileSelectionSet ) {
			TileBrushMatrix tileSelectionSet = (TileBrushMatrix) selectionSet;
			
			// Set tiles in the selection below:
			for ( int i = tileSelectionSet.getOrigRow(); i <= tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows(); i++ )
				for ( int j = tileSelectionSet.getOrigCol(); j <= tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols(); j++ )
					if ( tileSelectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL ) {
						int tileID = tileSelectionSet.getTileAtGlobalCoords(i, j);
						
						try {
							if ( workingBGLayerInx == -1 )
								loadedRoom.setBlock(i, j, tileID);
							else
								loadedRoom.setBGTile( workingBGLayerInx, i, j, tileID );
						}
						catch (ArrayIndexOutOfBoundsException exc) {}
					}
			
			// Crop to matrix:
			int numRows = (workingBGLayerInx == -1 ? loadedRoom.getBlockMatrixRows() : loadedRoom.getBGTileMatrixRows(workingBGLayerInx));
			int numCols = (workingBGLayerInx == -1 ? loadedRoom.getBlockMatrixCols() : loadedRoom.getBGTileMatrixCols(workingBGLayerInx));
			while ( tileSelectionSet.getOrigCol() < 0 ) {
				int j = tileSelectionSet.getOrigCol();
				int row1 = tileSelectionSet.getOrigRow();
				int row2 = row1 + tileSelectionSet.getNumOfRows() - 1;
				for ( int i = row1; i <= row2; i++ )
					tileSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			while ( tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols() > numCols ) {
				int j = tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols() - 1;
				int row1 = tileSelectionSet.getOrigRow();
				int row2 = row1 + tileSelectionSet.getNumOfRows() - 1;
				for ( int i = row1; i <= row2; i++ )
					tileSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			while ( tileSelectionSet.getOrigRow() < 0 ) {
				int i = tileSelectionSet.getOrigRow();
				int col1 = tileSelectionSet.getOrigCol();
				int col2 = col1 + tileSelectionSet.getNumOfCols() - 1;
				for ( int j = col1; j <= col2; j++ )
					tileSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			while ( tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows() > numRows ) {
				int i = tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows() - 1;
				int col1 = tileSelectionSet.getOrigCol();
				int col2 = col1 + tileSelectionSet.getNumOfCols() - 1;
				for ( int j = col1; j <= col2; j++ )
					tileSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			
		}
		else
		if ( selectionSet instanceof BGTileColorSelectionSet ) {
			BGTileColorSelectionSet tileColorSelectionSet = (BGTileColorSelectionSet) selectionSet;
			
			// Set tiles in the selection below:
			for ( int i = tileColorSelectionSet.getOrigRow(); i <= tileColorSelectionSet.getOrigRow() + tileColorSelectionSet.getNumOfRows(); i++ )
				for ( int j = tileColorSelectionSet.getOrigCol(); j <= tileColorSelectionSet.getOrigCol() + tileColorSelectionSet.getNumOfCols(); j++ )
					if ( tileColorSelectionSet.getTileAtGlobalCoords(i, j) != null ) {
						ColorTile tileColor = tileColorSelectionSet.getTileAtGlobalCoords(i, j);
						
						try {
							loadedRoom.setBGTileColor( workingBGLayerInx, i, j, tileColor );
						}
						catch (ArrayIndexOutOfBoundsException exc) {}
					}
			
			// Crop to matrix:
			int numRows = (workingBGLayerInx == -1 ? loadedRoom.getBlockMatrixRows() : loadedRoom.getBGTileMatrixRows(workingBGLayerInx));
			int numCols = (workingBGLayerInx == -1 ? loadedRoom.getBlockMatrixCols() : loadedRoom.getBGTileMatrixCols(workingBGLayerInx));
			while ( tileColorSelectionSet.getOrigCol() < 0 ) {
				int j = tileColorSelectionSet.getOrigCol();
				int row1 = tileColorSelectionSet.getOrigRow();
				int row2 = row1 + tileColorSelectionSet.getNumOfRows() - 1;
				for ( int i = row1; i <= row2; i++ )
					tileColorSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			while ( tileColorSelectionSet.getOrigCol() + tileColorSelectionSet.getNumOfCols() > numCols ) {
				int j = tileColorSelectionSet.getOrigCol() + tileColorSelectionSet.getNumOfCols() - 1;
				int row1 = tileColorSelectionSet.getOrigRow();
				int row2 = row1 + tileColorSelectionSet.getNumOfRows() - 1;
				for ( int i = row1; i <= row2; i++ )
					tileColorSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			while ( tileColorSelectionSet.getOrigRow() < 0 ) {
				int i = tileColorSelectionSet.getOrigRow();
				int col1 = tileColorSelectionSet.getOrigCol();
				int col2 = col1 + tileColorSelectionSet.getNumOfCols() - 1;
				for ( int j = col1; j <= col2; j++ )
					tileColorSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
			while ( tileColorSelectionSet.getOrigRow() + tileColorSelectionSet.getNumOfRows() > numRows ) {
				int i = tileColorSelectionSet.getOrigRow() + tileColorSelectionSet.getNumOfRows() - 1;
				int col1 = tileColorSelectionSet.getOrigCol();
				int col2 = col1 + tileColorSelectionSet.getNumOfCols() - 1;
				for ( int j = col1; j <= col2; j++ )
					tileColorSelectionSet.unsetTileAtGlobalCoords( i, j );
			}
		}
		else
		if ( selectionSet instanceof GameObjSelectionSet ) {}
		else {
			throw new IllegalStateException("Unknown selection set type.");
		}
		
		selectionFloating = false;
	}
	
	
	
	
	public void setClipboardContents ( SelectionSet contents ) {
		if ( this.clipboard == contents )
			return;
		
		SelectionSet oldClipboard = this.clipboard;
		this.clipboard = contents;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).clipboardChanged( this, oldClipboard );
	}
	
	
	
	
	public SelectionSet getClipboardContents () {
		return clipboard;
	}
	
	
	
	
	/**
	 * Given a path, tests whether it is contained in the base path or one of
	 * its subdirectories. The path will be converted to its canonicalPath
	 * before being tested automatically.
	 */
	public boolean isInBasePath ( String path ) {
		path = Main.getCanonicalPath( path );
		
		// The path must "begin" with the base path:
		return (path.indexOf( basePath ) == 0);
	}
	
	
	
	
	/**
	 * Given a path, removes the basePath from its beginning, leaving only the
	 * relative path.
	 * 
	 * The canonical path can be obtained again with prependBasePath().
	 * 
	 * If the specified path is not "valid" (i.e., isInsideBasePath(path)
	 * returns false), the method returns null.
	 */
	public String stripBasePath ( String path ) {
		if ( !isInBasePath( path ) )
			return null;
		
		// Remove trailing slash from the base path, if it is there:
		String cleanBasePath = basePath;
		if ( cleanBasePath.endsWith( File.separator ) )
			cleanBasePath = cleanBasePath.substring( 0, cleanBasePath.length() - File.separator.length() );
		
		return path.substring( cleanBasePath.length() + File.separator.length() );
	}
	
	
	
	
	/**
	 * Prepends the base path to a relative path, so that it is once again a
	 * canonical path.
	 */
	public String prependBasePath ( String relativePath ) {
		// Remove trailing slash from the base path, if it is there:
		String cleanBasePath = basePath;
		if ( cleanBasePath.endsWith( File.separator ) )
			cleanBasePath = cleanBasePath.substring( 0, cleanBasePath.length() - File.separator.length() );
		
		// Remove slash from the beginning of the relative path:
		if ( relativePath.startsWith( File.separator ) )
			relativePath = relativePath.substring( File.separator.length() );
		
		return cleanBasePath + File.separator + relativePath;
	}
	
	
	
	
	public int roomXFromPanelX ( int x ) {
		return Math.round((x / zoom) + scrollX);
	}
	
	public int roomYFromPanelY ( int y ) {
		return Math.round((y / zoom) + scrollY);
	}
	
	public int panelXFromRoomX ( int x ) {
		return Math.round(zoom * (-scrollX + x));
	}
	
	public int panelYFromRoomY ( int y ) {
		return Math.round(zoom * (-scrollY + y));
	}
	
	public void roomPtFromPanelPt ( Point p ) {
		p.x = roomXFromPanelX(p.x);
		p.y = roomYFromPanelY(p.y);
	}
	
	public void panelPtFromRoomPt ( Point p ) {
		p.x = panelXFromRoomX(p.x);
		p.y = panelYFromRoomY(p.y);
	}
	
	
	
	
	public int tileColFromPanelX ( int x, int layerInx ) {
		float parallaxX;
		int translateX;
		int tileWidth;
		
		if ( layerInx == -1 ) {
			parallaxX = 1;
			translateX = 0;
			tileWidth = loadedRoom.getBlockSize();
		}
		else {
			BGLayer bgLayer = loadedRoom.getBGLayer( layerInx );
			parallaxX = bgLayer.getParallaxX();
			translateX = bgLayer.getTranslationX();
			tileWidth = bgLayer.getTileWidth();
		}
		
		x = Math.round(((x / zoom) + scrollX * parallaxX) - translateX);
		return x / tileWidth;
	}
	
	public int tileRowFromPanelY ( int y, int layerInx ) {
		float parallaxY;
		int translateY;
		int tileHeight;
		
		if ( layerInx == -1 ) {
			parallaxY = 1;
			translateY = 0;
			tileHeight = loadedRoom.getBlockSize();
		}
		else {
			BGLayer bgLayer = loadedRoom.getBGLayer( layerInx );
			parallaxY = bgLayer.getParallaxY();
			translateY = bgLayer.getTranslationY();
			tileHeight = bgLayer.getTileHeight();
		}
		
		y = Math.round(((y / zoom) + scrollY * parallaxY) - translateY);
		return y / tileHeight;
	}
	
	public int panelXFromTileCol ( int col, int layerInx ) {
		float parallaxX;
		int translateX;
		int tileWidth;
		
		if ( layerInx == -1 ) {
			parallaxX = 1;
			translateX = 0;
			tileWidth = loadedRoom.getBlockSize();
		}
		else {
			BGLayer bgLayer = loadedRoom.getBGLayer( layerInx );
			parallaxX = bgLayer.getParallaxX();
			translateX = bgLayer.getTranslationX();
			tileWidth = bgLayer.getTileWidth();
		}
		
		return Math.round(zoom * ((col * tileWidth + translateX) - (scrollX * parallaxX)));
	}
	
	public int panelYFromTileRow ( int row, int layerInx ) {
		float parallaxY;
		int translateY;
		int tileHeight;
		
		if ( layerInx == -1 ) {
			parallaxY = 1;
			translateY = 0;
			tileHeight = loadedRoom.getBlockSize();
		}
		else {
			BGLayer bgLayer = loadedRoom.getBGLayer( layerInx );
			parallaxY = bgLayer.getParallaxY();
			translateY = bgLayer.getTranslationY();
			tileHeight = bgLayer.getTileHeight();
		}
		
		return Math.round(zoom * ((row * tileHeight + translateY) - (scrollY * parallaxY)));
	}
	
	public int tileRowFromRoomY ( int y, int layerInx ) {
		return tileRowFromPanelY( panelYFromRoomY( y ), layerInx );
	}
	
	public int tileColFromRoomX ( int x, int layerInx ) {
		return tileColFromPanelX( panelXFromRoomX( x ), layerInx );
	}
	
	public int roomYFromTileRow ( int row, int layerInx ) {
		return roomYFromPanelY( panelYFromTileRow( row, layerInx ) );
	}
	
	public int roomXFromTileCol ( int col, int layerInx ) {
		return roomXFromPanelX( panelXFromTileCol( col, layerInx ) );
	}
	
}
