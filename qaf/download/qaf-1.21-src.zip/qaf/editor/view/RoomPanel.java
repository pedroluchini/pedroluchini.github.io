package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.HierarchyBoundsAdapter;
import java.awt.event.HierarchyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Hashtable;

import javax.swing.JPanel;
import javax.swing.Timer;

import model.AbstractTileMatrix;
import model.BGLayer;
import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.ObstacleBlockTypes;
import model.Room;
import model.TileBrushMatrix;
import model.selection.BGTileColorSelectionSet;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;
import model.selection.GameObjSelectionSet;
import model.selection.SelectionSet;
import control.Main;
import control.tool.Tool;

class CachedColoredTileInfo {
	private Image image;
	private int sx1, sy1, sx2, sy2;
	private ColorTile colorTile;
	
	public CachedColoredTileInfo (
			Image image,
			int sx1, int sy1,
			int sx2, int sy2,
			ColorTile colorTile ) {
		this.image = image;
		this.sx1 = sx1;
		this.sy1 = sy1;
		this.sx2 = sx2;
		this.sy2 = sy2;
		this.colorTile = colorTile;
	}
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof CachedColoredTileInfo ) {
			CachedColoredTileInfo that = (CachedColoredTileInfo) obj;
			
			if ( !this.image.equals(image) )
				return false;
			if ( this.sx1 != that.sx1 )
				return false;
			if ( this.sy1 != that.sy1 )
				return false;
			if ( this.sx2 != that.sx2 )
				return false;
			if ( this.sy2 != that.sy2 )
				return false;
			if ( !this.colorTile.equals(that.colorTile) )
				return false;
			
			return true;
		}
		else
			return false;
	}
	
	public int hashCode () {
		int hashCode = 0;
		hashCode ^= image.hashCode();
		hashCode ^= sx1;
		hashCode ^= sy1;
		hashCode ^= sx2;
		hashCode ^= sy2;
		hashCode ^= colorTile.hashCode();
		return hashCode;
	}
}




public class RoomPanel extends JPanel {
	static final long serialVersionUID = 0;
	
	public static final Color  BACKGROUND_COLOR             = new Color(0, 0, 100);
	public static final Color  TILE_GRID_COLOR              = new Color(130, 0, 0);
	public static final Color  SCREEN_GRID_COLOR            = new Color(255, 255, 200);
	public static final Font   GAMEOBJ_LABEL_FONT           = new Font( "Courier New", Font.PLAIN, 11 );
	public static final Color  GAMEOBJ_LABEL_COLOR          = Color.WHITE;
	public static final Color  GAMEOBJ_LABEL_OUTLINE_COLOR  = Color.BLACK;
	public static final int    GAMEOBJ_MARKER_SIZE          = 9;
	public static final Color  GAMEOBJ_MARKER_COLOR         = Color.RED;
	public static final Color  GAMEOBJ_MARKER_OUTLINE_COLOR = Color.BLACK;
	public static final Stroke GAMEOBJ_MARKER_STROKE        = new BasicStroke( 2.0f );
	public static final Color  SELECTION_MARQUEE_COLOR_A    = Color.WHITE;
	public static final Color  SELECTION_MARQUEE_COLOR_B    = Color.BLACK;
	public static final int    CACHE_SIZE                   = 5000;
	
	
	
	
	private class StrokeTimer {
		private Stroke[] strokes = { null, null, null, null };
		private int currStroke = 0;
		private Timer t = new Timer(
			250,
			new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					currStroke++;
					if ( currStroke >= strokes.length )
						currStroke = 0;
					
					// Repaint:
					repaint();
				}
			} );
		
		public StrokeTimer () {
			float dash[] = {4.0f, 4.0f};
			strokes[0] = new BasicStroke( 2.0f, 0, 0, 1.0f, dash, 0.0f );
			strokes[1] = new BasicStroke( 2.0f, 0, 0, 1.0f, dash, 2.0f );
			strokes[2] = new BasicStroke( 2.0f, 0, 0, 1.0f, dash, 4.0f );
			strokes[3] = new BasicStroke( 2.0f, 0, 0, 1.0f, dash, 6.0f );
		}
		
		public Stroke getCurrentA() {
			return strokes[currStroke];
		}
		
		public Stroke getCurrentB() {
			return strokes[(currStroke + strokes.length/2) % strokes.length];
		}
		
		public void start () {
			t.start();
		}
		
		public void stop () {
			t.stop();
		}
	}
	
	
	
	
	private class GameObjListener implements GameObj.Listener {

		public void attributeChanged(GameObj src, String attrKey) {
			repaint();
		}

		public void idChanged(GameObj src) {
			repaint();
		}

		public void positionChanged(GameObj src) {
			repaint();
		}
		
	}
	
	
	
	
	private class BGLayerListener implements BGLayer.Listener {
		
		public void imageChanged(BGLayer src) {
			enforceTileCacheSize();
			repaint();
		}

		public void parallaxChanged(BGLayer src) {
			repaint();
		}

		public void tileSizeChanged(BGLayer src) {
			enforceTileCacheSize();
			repaint();
		}

		public void translationChanged(BGLayer src) {
			repaint();
		}
		
	}
	
	
	
	
	private class RoomListener implements Room.Listener {
		
		public void bgLayerAdded(Room src, int newLayerIndex) {
			src.getBGLayer(newLayerIndex).addListener(bgLayerListener);
			enforceTileCacheSize();
			repaint();
		}

		public void bgLayerRemoved(Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] bgTileColorMatrix) {
			bgLayer.removeListener(bgLayerListener);
			enforceTileCacheSize();
			repaint();
		}

		public void bgLayerSwapped(Room src, int bgInx1, int bgInx2) {
			enforceTileCacheSize();
			repaint();
		}

		public void blockChanged(Room src, int row, int col) {
			repaint();
		}

		public void defaultObjLayerChanged(Room src) {
			repaint();
		}

		public void gameObjAdded(Room src, int newIndex) {
			src.getObj(newIndex).addListener(gameObjListener);
			repaint();
		}

		public void gameObjRemoved(Room src, int oldIndex, GameObj obj) {
			obj.removeListener(gameObjListener);
			repaint();
		}

		public void gameObjSwapped(Room src, int i1, int i2) {
			repaint();
		}

		public void waterLevelChanged(Room src) {
			repaint();
		}

		public void bgTileChanged(Room src, int layerIndex, int row, int col) {
			enforceTileCacheSize();
			repaint();
		}
		
		public void bgTileColorChanged(Room src, int layerIndex, int row, int col) {
			enforceTileCacheSize();
			repaint();
		}
	}
	
	
	
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {
		
		public void basePathChanged(GlobalEditorModel src) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
		
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {
			if (oldRoom != null) {
				oldRoom.removeListener(roomListener);
				for ( int i = 0; i < oldRoom.getNumOfBGLayers(); i++ )
					oldRoom.getBGLayer( i ).removeListener( bgLayerListener );
			}
			
			Room room = src.getLoadedRoom();
			room.addListener(roomListener);
			
			for ( int i = 0; i < room.getNumOfBGLayers(); i++ )
				room.getBGLayer( i ).addListener( bgLayerListener );
			
			cachedColoredTiles.clear();
			
			setPreferredSize(
				new Dimension(
					Math.round(room.getScreenPixelWidth() * src.getZoom()),
					Math.round(room.getScreenPixelHeight() * src.getZoom())) );
			revalidate();
			backBuffer = null;
			
			repaint();
		}
		
		public void scrollChanged (GlobalEditorModel src) {
			repaint();
		}

		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {
			repaint();
		}
		
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {
			repaint();
		}
		
		public void workingLayerChanged (GlobalEditorModel src) {
			repaint();
		}
		
		public void gridVisibilityChanged (GlobalEditorModel src) {
			repaint();
		}
		
		public void zoomChanged (GlobalEditorModel src) {
			setPreferredSize(
				new Dimension(
					Math.round(src.getLoadedRoom().getScreenPixelWidth() * src.getZoom()),
					Math.round(src.getLoadedRoom().getScreenPixelHeight() * src.getZoom())) );
			revalidate();
			backBuffer = null;
			
			repaint();
		}
		
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {
			if ( src.getSelectionSet() == null )
				strokeTimer.stop();
			else
				strokeTimer.start();
			
			repaint();
		}
		
	}
	
	
	
	
	private GameObjListener     gameObjListener     = new GameObjListener();
	private BGLayerListener     bgLayerListener     = new BGLayerListener();
	private RoomListener        roomListener        = new RoomListener();
	private GlobalEditorModelListener editorModelListener = new GlobalEditorModelListener();
	private Tool currentTool;
	private StrokeTimer strokeTimer = new StrokeTimer();
	private Image backBuffer;
	private GlobalEditorModel globalEditorModel;
	private Hashtable<CachedColoredTileInfo, RenderableColoredTile> cachedColoredTiles = new Hashtable<CachedColoredTileInfo, RenderableColoredTile>();
	
	
	
	
	public RoomPanel(GlobalEditorModel editorModel) {
		this.globalEditorModel = editorModel;
		
		addHierarchyBoundsListener(
			new HierarchyBoundsAdapter() {
				public void ancestorResized ( HierarchyEvent evt ) {
					backBuffer = null;
				}
			} );
		
		editorModel.addListener(editorModelListener);
		
		if ( editorModel.getLoadedRoom() != null ) {
			Room room = editorModel.getLoadedRoom();
			room.addListener(roomListener);
			setPreferredSize(
				new Dimension(
					room.getScreenPixelWidth(),
					room.getScreenPixelHeight()) );
		}
		
		setMinimumSize( new Dimension(0, 0) );
		setFocusable( true );
		addMouseListener(
			new MouseAdapter() {
				public void mouseEntered ( MouseEvent evt ) {
					requestFocusInWindow();
				}
			} );
	}
	
	
	
	
	public void setCurrentTool ( Tool tool ) {
		this.currentTool = tool;
	}
	
	
	
	
	public void update ( Graphics g ) {
		paint( g );
	}
	
	
	
	
	public void paint ( Graphics g ) {
		Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
		
		if ( backBuffer == null )
			backBuffer = createImage( viewRect.width, viewRect.height );
		
		Graphics bufferGraphics = backBuffer.getGraphics();
		bufferGraphics.translate( -viewRect.x, -viewRect.y );
		
		display( bufferGraphics );
		
		g.drawImage( backBuffer, viewRect.x, viewRect.y, this );
	}
	
	
	
	
	private void display ( Graphics g ) {
		// Clear background:
		g.setColor( BACKGROUND_COLOR );
		g.fillRect( 0, 0, getWidth(), getHeight() );
		
		float zoom = globalEditorModel.getZoom();
		
		// Draw the loaded room:
		Room room = globalEditorModel.getLoadedRoom();
		if ( room != null ) {
			int x = -globalEditorModel.getScrollX();
			int y = -globalEditorModel.getScrollY();
			
			// Clear the room with a black background:
			g.setColor( Color.BLACK );
			g.fillRect( Math.round(x * zoom),
			            Math.round(y * zoom),
			            Math.round(room.getPixelWidth() * zoom),
			            Math.round(room.getPixelHeight() * zoom) );
			
			// Iterate over this room's BGLayers (in reverse order; higher-index
			// layers must appear behind lower-index layers):
			boolean defaultObjLayerDrawn = false;
			for ( int bgInx = room.getNumOfBGLayers() - 1; bgInx >= 0; bgInx-- ) {
				// Insertion point for "object layer"
				if ( bgInx < room.getDefaultObjLayer() && !defaultObjLayerDrawn ) {
					drawObjectLayer( (Graphics2D) g, x, y );
					defaultObjLayerDrawn = true;
				}
				
				// Draw BGLayer:
				BGLayer bgLayer = room.getBGLayer( bgInx );
				if ( globalEditorModel.isBGLayerVisible( bgInx ) ) {
					Image image = bgLayer.getImage();
					int imageWidth = image.getWidth(this);
					int tileWidth = bgLayer.getTileWidth();
					int tileHeight = bgLayer.getTileHeight();
					int translateX = bgLayer.getTranslationX();
					int translateY = bgLayer.getTranslationY();
					float parallaxX = bgLayer.getParallaxX();
					float parallaxY = bgLayer.getParallaxY();
					
					for ( int i = 0; i < room.getBGTileMatrixRows( bgInx ); i++ ) {
						for ( int j = 0; j < room.getBGTileMatrixCols( bgInx ); j++ ) {
							// Draw tile at (i, j):
							int tileID = room.getBGTile( bgInx, i, j );
							ColorTile tileColor = room.getBGTileColor( bgInx, i, j );
							
							// Override if selection set is a tile matrix in this layer.
							if ( globalEditorModel.getWorkingLayer() == bgInx &&
							     globalEditorModel.getSelectionSet() instanceof BGTileSelectionSet &&
							     globalEditorModel.isSelectionFloating() ) {
								TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
								
								if ( selectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL )
									tileID = selectionSet.getTileAtGlobalCoords(i, j);
							}
							if ( globalEditorModel.getWorkingLayer() == bgInx &&
							     globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet &&
							     globalEditorModel.isSelectionFloating() ) {
								BGTileColorSelectionSet selectionSet = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
								
								if ( selectionSet.getTileAtGlobalCoords(i, j) != null )
									tileColor = selectionSet.getTileAtGlobalCoords(i, j);
							}
							
							// ID -1 is a blank tile:
							if ( tileID == -1 )
								continue;
							
							// Calculate the tile's texture coordinates:
							int texX = (tileID * tileWidth) % imageWidth;
							int texY = tileHeight * ((tileID * tileWidth) / imageWidth);
							int texW = tileWidth;
							int texH = tileHeight;
							
							// Tile is flipped?
							if ( (tileID & Room.FLIPPED_TILE_X_MASK) != 0 ) {
								texX += tileWidth;
								texW *= -1;
							}
							if ( (tileID & Room.FLIPPED_TILE_Y_MASK) != 0 ) {
								texY += tileHeight;
								texH *= -1;
							}
							
							int baseX = Math.round(parallaxX * x + j * tileWidth  + translateX);
							int baseY = Math.round(parallaxY * y + i * tileHeight + translateY);
							
							drawTile(
								g,
								image,
								Math.round(zoom * baseX), Math.round(zoom * baseY), Math.round(zoom * (baseX + tileWidth)), Math.round(zoom * (baseY + tileHeight)), // Destination coordinates
								texX,                     texY,                     texX + texW,                            texY + texH,                             // Source coordinates
								tileColor );
						}
					} 
				}
			}
			
			if ( !defaultObjLayerDrawn )
				drawObjectLayer( (Graphics2D) g, x, y );
			
			// Water level:
			g.setColor( Color.CYAN );
			g.drawLine( Math.round(zoom * x),                          Math.round(zoom * (y + room.getWaterLevel())),
						Math.round(zoom * (x + room.getPixelWidth())), Math.round(zoom * (y + room.getWaterLevel())) );
			g.drawLine( Math.round(zoom * x),                          Math.round(zoom * (y + room.getWaterLevel())) - 1,
						Math.round(zoom * (x + room.getPixelWidth())), Math.round(zoom * (y + room.getWaterLevel())) - 1 );
			
			// Grid?
			if ( globalEditorModel.isGridVisible() ) {
				// Tile grid:
				int bgGridRows, bgGridCols, bgGridWidth, bgGridHeight;
				int translateX = 0, translateY = 0;
				float parallaxX = 1, parallaxY = 1;
				int workingLayerInx = globalEditorModel.getWorkingLayer();
				if ( workingLayerInx >= 0 ) {
					BGLayer bgLayer = room.getBGLayer( workingLayerInx );
					
					bgGridRows = room.getBGTileMatrixRows( workingLayerInx );
					bgGridCols = room.getBGTileMatrixCols( workingLayerInx );
					bgGridWidth = bgLayer.getTileWidth();
					bgGridHeight = bgLayer.getTileHeight();
					translateX = bgLayer.getTranslationX();
					translateY = bgLayer.getTranslationY();
					parallaxX = bgLayer.getParallaxX();
					parallaxY = bgLayer.getParallaxY();
				}
				else {
					bgGridRows = room.getBlockMatrixRows();
					bgGridCols = room.getBlockMatrixCols();
					bgGridWidth = bgGridHeight = room.getBlockSize();
				}
				
				Main.drawGrid(
					g,
					Math.round(zoom * (translateX + Math.round(parallaxX * x))),
					Math.round(zoom * (translateY + Math.round(parallaxY * y))),
					bgGridRows, bgGridCols,
					zoom * bgGridWidth,
					zoom * bgGridHeight,
					Integer.MAX_VALUE,
					TILE_GRID_COLOR );
	
				// Screen grid:
				Main.drawGrid(
					g,
					zoom * x,
					zoom * y,
					room.getRoomHeight(),
					room.getRoomWidth(),
					zoom * room.getScreenPixelWidth(),
					zoom * room.getScreenPixelHeight(),
					Integer.MAX_VALUE,
					SCREEN_GRID_COLOR );
			}
			
			// Selection overlay:
			SelectionSet selectionSet = globalEditorModel.getSelectionSet();
			Graphics2D g2D = (Graphics2D) g;
			
			Stroke marqueeStrokeA = strokeTimer.getCurrentA();
			Stroke marqueeStrokeB = strokeTimer.getCurrentB();
			Color marqueeColorA = (globalEditorModel.isSelectionFloating() ? Color.YELLOW : SELECTION_MARQUEE_COLOR_A);
			Color marqueeColorB = SELECTION_MARQUEE_COLOR_B;
			
			Stroke oldStroke = g2D.getStroke();
			
			if ( selectionSet == null ) {}
			else
			if ( selectionSet instanceof AbstractTileMatrix )  {
				AbstractTileMatrix atm = (AbstractTileMatrix) selectionSet;
				
				Point tl = new Point();
				Point tr = new Point();
				Point br = new Point();
				Point bl = new Point();
				int layerInx = globalEditorModel.getWorkingLayer();
				
				for ( int i = atm.getOrigRow(); i <= atm.getOrigRow() + atm.getNumOfRows(); i++ ) {
					for ( int j = atm.getOrigCol(); j <= atm.getOrigCol() + atm.getNumOfCols(); j++ ) {
						if ( !atm.isTileAtGlobalCoordsSet( i, j ) )
							continue;
						
						tl.x = globalEditorModel.panelXFromTileCol( j,     layerInx );
						tl.y = globalEditorModel.panelYFromTileRow( i,     layerInx );
						tr.x = globalEditorModel.panelXFromTileCol( j + 1, layerInx );
						tr.y = globalEditorModel.panelYFromTileRow( i,     layerInx );
						br.x = globalEditorModel.panelXFromTileCol( j + 1, layerInx );
						br.y = globalEditorModel.panelYFromTileRow( i + 1, layerInx );
						bl.x = globalEditorModel.panelXFromTileCol( j,     layerInx );
						bl.y = globalEditorModel.panelYFromTileRow( i + 1, layerInx );
						
						// Left:
						if ( !atm.isTileAtGlobalCoordsSet(i, j - 1) ) {
							g2D.setStroke( marqueeStrokeA );
							g2D.setColor( marqueeColorA );
							g.drawLine(tl.x, tl.y, bl.x, bl.y);
							g2D.setStroke( marqueeStrokeB );
							g2D.setColor( marqueeColorB );
							g.drawLine(tl.x, tl.y, bl.x, bl.y);
						}	
						// Right:
						if ( !atm.isTileAtGlobalCoordsSet(i, j + 1) ) {
							g2D.setStroke( marqueeStrokeA );
							g2D.setColor( marqueeColorA );
							g.drawLine(tr.x, tr.y, br.x, br.y);
							g2D.setStroke( marqueeStrokeB );
							g2D.setColor( marqueeColorB );
							g.drawLine(tr.x, tr.y, br.x, br.y);
						}
						// Top:
						if ( !atm.isTileAtGlobalCoordsSet(i - 1, j) ) {
							g2D.setStroke( marqueeStrokeA );
							g2D.setColor( marqueeColorA );
							g.drawLine(tl.x, tl.y, tr.x, tr.y);
							g2D.setStroke( marqueeStrokeB );
							g2D.setColor( marqueeColorB );
							g.drawLine(tl.x, tl.y, tr.x, tr.y);
						}
						// Bottom:
						if ( !atm.isTileAtGlobalCoordsSet(i + 1, j) ) {
							g2D.setStroke( marqueeStrokeA );
							g2D.setColor( marqueeColorA );
							g.drawLine(bl.x, bl.y, br.x, br.y);
							g2D.setStroke( marqueeStrokeB );
							g2D.setColor( marqueeColorB );
							g.drawLine(bl.x, bl.y, br.x, br.y);
						}
					}
				}
			}
			else
			if ( selectionSet instanceof GameObjSelectionSet )  {
				GameObjSelectionSet goss = (GameObjSelectionSet) selectionSet;
				
				for ( int i = 0; i < goss.getNumOfObjs(); i++ ) {
					GameObj obj = goss.getObj(i);
					int objX = globalEditorModel.panelXFromRoomX( obj.getX() );
					int objY = globalEditorModel.panelYFromRoomY( obj.getY() );
					
					g2D.setStroke( marqueeStrokeA );
					g2D.setColor( marqueeColorA );
					g.drawRect(
						objX - GAMEOBJ_MARKER_SIZE/2 - 3,
						objY - GAMEOBJ_MARKER_SIZE/2 - 3,
						GAMEOBJ_MARKER_SIZE + 6,
						GAMEOBJ_MARKER_SIZE + 6 );
					g2D.setStroke( marqueeStrokeB );
					g2D.setColor( marqueeColorB );
					g.drawRect(
						objX - GAMEOBJ_MARKER_SIZE/2 - 3,
						objY - GAMEOBJ_MARKER_SIZE/2 - 3,
						GAMEOBJ_MARKER_SIZE + 6,
						GAMEOBJ_MARKER_SIZE + 6 );
				}
			}
			else {
				throw new IllegalStateException("Unknown selection set type.");
			}
			
			g2D.setStroke( oldStroke );
			
			// Tool overlay:
			if ( currentTool != null )
				currentTool.paintOverlay( g );
		}
		
	}
	
	
	
	
	private void drawObjectLayer ( Graphics2D g, int scrollX, int scrollY ) {
		float zoom = globalEditorModel.getZoom();
		
		// Draw obstacle layer and game object markers.
		// Is the obstacle layer visible?
		if ( globalEditorModel.isBlockLayerVisible() ) {
			Room room = globalEditorModel.getLoadedRoom();
			
			for ( int i = 0; i < room.getBlockMatrixRows(); i++ ) {
				for ( int j = 0; j < room.getBlockMatrixCols(); j++ ) {
					int tileID = room.getBlock( i, j );
					
					// Override if selection set is a tile matrix in the obstacle layer.
					if ( globalEditorModel.getWorkingLayer() == -1 &&
					     globalEditorModel.getSelectionSet() instanceof BlockSelectionSet &&
					     globalEditorModel.isSelectionFloating() ) {
						TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
						
						if ( selectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL )
							tileID = selectionSet.getTileAtGlobalCoords(i, j);
					}
					
					ObstacleBlockTypes.drawBlock(
						tileID,
						Math.round(zoom * (scrollX + j * room.getBlockSize())), Math.round(zoom * (scrollY + i * room.getBlockSize())),
						Math.round(zoom * room.getBlockSize()),
						g );
				}
			}
		
			// Draw GameObj instances:
			for ( int i = room.getNumOfObjs() - 1; i >= 0; i-- ) {
				GameObj obj = room.getObj( i );
				
				int objOnScreenX = Math.round(zoom * (scrollX + obj.getX()));
				int objOnScreenY = Math.round(zoom * (scrollY + obj.getY()));
				
				// Marker:
				// First the outline...
				g.setColor( GAMEOBJ_MARKER_OUTLINE_COLOR );
				g.drawRect(
					objOnScreenX - GAMEOBJ_MARKER_SIZE/2 - 2, objOnScreenY - GAMEOBJ_MARKER_SIZE/2 - 2, 
					GAMEOBJ_MARKER_SIZE + 3, GAMEOBJ_MARKER_SIZE + 3 );
				
				g.setColor( GAMEOBJ_MARKER_COLOR );
				// Place a dot on the object's location...
				g.drawLine( objOnScreenX, objOnScreenY, objOnScreenX, objOnScreenY );
				
				// Draw a rectangle around the object:
				Stroke previousStroke = g.getStroke();
				g.setStroke( GAMEOBJ_MARKER_STROKE );
				g.drawRect(
					objOnScreenX - GAMEOBJ_MARKER_SIZE/2, objOnScreenY - GAMEOBJ_MARKER_SIZE/2, 
					GAMEOBJ_MARKER_SIZE, GAMEOBJ_MARKER_SIZE );
				g.setStroke( previousStroke );
				
				// Draw label:
				g.setFont( GAMEOBJ_LABEL_FONT );
				// First its outline...
				g.setColor( GAMEOBJ_LABEL_OUTLINE_COLOR );
				g.drawString( obj.getID(), objOnScreenX + GAMEOBJ_MARKER_SIZE/2 - 1, objOnScreenY - GAMEOBJ_MARKER_SIZE/2     );
				g.drawString( obj.getID(), objOnScreenX + GAMEOBJ_MARKER_SIZE/2    , objOnScreenY - GAMEOBJ_MARKER_SIZE/2 - 1 );
				g.drawString( obj.getID(), objOnScreenX + GAMEOBJ_MARKER_SIZE/2 + 1, objOnScreenY - GAMEOBJ_MARKER_SIZE/2     );
				g.drawString( obj.getID(), objOnScreenX + GAMEOBJ_MARKER_SIZE/2    , objOnScreenY - GAMEOBJ_MARKER_SIZE/2 + 1 );
				
				// Then the string itself:
				g.setColor( GAMEOBJ_LABEL_COLOR );
				g.drawString( obj.getID(), objOnScreenX + GAMEOBJ_MARKER_SIZE/2, objOnScreenY - GAMEOBJ_MARKER_SIZE/2 );
			}
		}
	}
	
	
	
	
	public void stopMarqueeStrokeTimer () {
		strokeTimer.stop();
	}
	
	
	
	
	private void drawTile(
			Graphics g,
			Image image,
			int dx1, int dy1,
			int dx2, int dy2,
			int sx1, int sy1,
			int sx2, int sy2,
			ColorTile tileColor ) {
		// Plain tile?
		if ( tileColor == null || tileColor.equals( ColorTile.DEFAULT ) ) {
			g.drawImage( image, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, this );
		}
		// Colored tile:
		else {
			CachedColoredTileInfo key =
				new CachedColoredTileInfo(
					image, sx1, sy1, sx2, sy2, tileColor );
			
			RenderableColoredTile rct = cachedColoredTiles.get( key );
			
			if ( rct == null ) {
				// Set hourglass cursor:
				Cursor oldCursor = getCursor();
				setCursor( Cursor.getPredefinedCursor( Cursor.WAIT_CURSOR ) );
				Main.f.setCursor( Cursor.getPredefinedCursor( Cursor.WAIT_CURSOR ) );
				
				// Create renderable tile:
				rct = new RenderableColoredTile( image, sx1, sx2, sy1, sy2, tileColor );
				cachedColoredTiles.put( key, rct );
				
				// Restore cursor:
				setCursor( oldCursor );
				Main.f.setCursor( Cursor.getDefaultCursor() );
			}
			
			rct.render( g, dx1, dy1, dx2, dy2 );
		}
	}
	
	
	
	
	private void enforceTileCacheSize () {
		while ( cachedColoredTiles.size() > CACHE_SIZE ) {
			CachedColoredTileInfo key = cachedColoredTiles.keys().nextElement();
			cachedColoredTiles.remove( key );
		}
	}
	
}
