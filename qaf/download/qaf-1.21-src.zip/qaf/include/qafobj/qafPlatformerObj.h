/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_OBJ_PLATFORMEROBJ_H
#define QAF_OBJ_PLATFORMEROBJ_H

#include "../qafCollisionStruct.h"
#include "../qafGameObj.h"
#include "../qafEnvironment.h"
#include "../qafutil/qafVector2D.h"


namespace qaf {
	
	/**
	 * This is a ready-made game object which controls like a platformer.
	 * You may control the character's parameters (speed, jump height, etc.)
	 * through its public fields (marked in ALL CAPS).
	 * 
	 * The <tt>render()</tt> method simply displays a set of lines,
	 * illustrating the boundaries used for contact testing against the
	 * obstacle layer (in blue/red) and the collision structure (in yellow).
	 * You may override it in a subclass to display your own sprites.
	 * 
	 * The platformer is represented by a rectangle with dimensions
	 * <tt>WIDTH</tt>x<tt>HEIGHT</tt>. Its position (the "hot spot," if you
	 * will), is placed at the center of the rectangle's bottom segment.
	 * Visually, the strucure looks like this:
	 * @code
	 *           ___
	 * topLeft  |   | topRight
	 *          |   |
	 *          |   |
	 *  botLeft |___| botRight
	 *            ^
	 *           pos
	 * 
	 * @endcode
	 */
	class PlatformerObj : public GameObj {
	public:
		
		/**
		 * Represents input for a platformer player.
		 * 
		 * When a <tt>PlatformerObj</tt> is created, it must receive a pointer
		 * to one of these structures. Its state will be read in the
		 * <tt>PlatformerObj::update()</tt> method, and the key states will be
		 * used to update the character's position and direction.
		 */
		class PlatformerInput {
		public:
			/** Directional input: Set to true when the LEFT/RIGHT/DOWN buttons
			* are pressed. */
			bool left, right, down;
			
			/** This should be set to true in the frame when the JUMP button is
			* pressed, and set to false in the next frame. */
			bool jumpPress;
			
			/** This should be set to true as long as JUMP is kept pressed. */
			bool jump;
			
			/**
			 * The constructor sets all key states to false.
			 */
			PlatformerInput ();
			virtual ~PlatformerInput() {}
		};
		
		
		
		/**
		 * Input structure for this platformer character. If the pointer is set
		 * to <tt>NULL</tt>, the character will stop receiving input, but will
		 * still update its state (falling, floating in the water, etc.).
		 */
		PlatformerInput * platformerInput;
		
		
		/** The character's width, in pixels.
		 * @see HEIGHT */
		float WIDTH;
		
		/** The character's height, in pixels.
		 * @see WIDTH */
		float HEIGHT;
		
		/** The point where the camera will focus. This is a displacement
		 * relative to the character's base point.
		 * 
		 * @see CAMERA_DY */
		float CAMERA_DX;
		
		/** The point where the camera will focus. This is a displacement
		 * relative to the character's base point.
		 * 
		 * @see CAMERA_DY */
		float CAMERA_DY;
		
		/** The camera does not "stick" to the character, but rather is
		 * attracted to it. This parameter controls how fast it will follow
		 * the player's movements. Specify a value in the [0, 1] range.
		 *
		 * To make the camera "stick" to the character (i.e., it will always be
		 * at the player's position), you may set
		 * @code
		 * CAMERA_STICKINESS = 1;
		 * @endcode
		 * 
		 * @see CENTER_SCROLLING_ON_SELF
		 */
		float CAMERA_STICKINESS;
		
		/** If this flag is set to false, the object will not change the
		 * scrolling point in its <tt>update()</tt> method.
		 * 
		 * @see CAMERA_STICKINESS
		 */
		bool CENTER_SCROLLING_ON_SELF;
		
		/** The character's maximum walk speed, in pixels/second. 
		 * (Specify a number greater than zero; the object will adjust the sign
		 * as needed.) */
		float WALK_SPEED;
		
		/** This factor is used to slow down the character when he is walking
		 * up a slope with 26-degree inclination. Specify a number in the range
		 * [0, 1].
		 * @code
		 * CLIMB_26_SLOPE_SLOWDOWN = 1.0; // Walks at normal speed when climbing 26-degree slopes
		 * @endcode
		 * 
		 * @see CLIMB_45_SLOPE_SLOWDOWN
		 */
		float CLIMB_26_SLOPE_SLOWDOWN;
		
		/** This factor is used to slow down the character when he is walking
		 * up a slope with 45-degree inclination. Specify a number in the range
		 * [0, 1].
		 * @code
		 * CLIMB_45_SLOPE_SLOWDOWN = 0.5; // Walks at half speed when climbing 45-degree slopes
		 * @endcode
		 * 
		 * @see CLIMB_26_SLOPE_SLOWDOWN
		 */
		float CLIMB_45_SLOPE_SLOWDOWN;
		
		/** The acceleration applied to the X speed as the player keeps
		 * pressing the walk keys, in pixels/second<sup>2</sup>. (Specify
		 * numbers greater than zero; the object will adjust the sign as
		 * needed.)
		 *
		 * @see WALK_DECELERATION */
		float WALK_ACCELERATION;
		
		/** The deceleration applied to the X speed as the player releases
		 * walk keys, in pixels/second<sup>2</sup>. (Specify numbers greater
		 * than zero; the object will adjust the sign as needed.)
		 *
		 * @see WALK_ACCELERATION */
		float WALK_DECELERATION;
		
		/** The Y speed applied when the player jumps on the ground, in
		 * pixels/second. (Specify a number greater than zero; the object will
		 * adjust the sign as needed.)
		 * 
		 * @see WATER_JUMP_STRENGTH */
		float JUMP_STRENGTH;
		
		/** The Y speed applied when the player jumps on the water's surface,
		 * in pixels/second. (Specify a number greater than zero; the object
		 * will adjust the sign as needed.)
		 * 
		 * @see JUMP_STRENGTH */
		float WATER_JUMP_STRENGTH;
		
		/** The acceleration applied to the Y speed when the player is falling,
		 * in pixels/second<sup>2</sup>. */
		float GRAVITY;
		
		/** When falling, the Y speed will be clamped to this value. */
		float MAX_FALL_SPEED;
		
		/** This indicates how much of the character will be submerged when
		 * floating on the water's surface.
		 *
		 * @code
		 *      ____
		 *     |    |
		 * ~~~~~~~~~~~~~~~~ /
		 *     |    |       |
		 *     |    |       | Subm. height
		 *     |    |       |
		 *     |____|       /
		 * 
		 * @endcode
		 */
		float SUBMERSION_HEIGHT;
		
		/** "Reverse gravity" applied to the character when underwater, in
		 * pixels/second<sup>2</sup>.
		 * (Specify a number greater than zero; the object will adjust the
		 * sign as needed.) */
		float BUOYANCY;
		
		/** When floating upwards the Y speed will be clamped to this value.
		 * (Specify a number greater than zero; the object will adjust the
		 * sign as needed.)
		 * 
		 * @see MAX_SINK_SPEED */
		float MAX_FLOAT_SPEED;
		
		/** When sinking downwards the Y speed will be clamped to this value.
		 * (Specify a number greater than zero; the object will adjust the
		 * sign as needed.)
		 * 
		 * @see MAX_FLOAT_SPEED */
		float MAX_SINK_SPEED;
		
		/** The character's maximum swimming X speed, in pixels/second.
		 * (Specify a number greater than zero; the object will adjust the
		 * sign as needed.)
		 */
		float SWIM_SPEED;
		
		/** The acceleration applied to the X speed as the player keeps
		 * pressing the walk keys while underwater, in
		 * pixels/second<sup>2</sup>. (Specify numbers greater than zero; the
		 * object will adjust the signs as needed.)
		 * 
		 * @see SWIM_DECELERATION */
		float SWIM_ACCELERATION;
		
		/** The deceleration applied to the X speed as the player releases
		 * walk keys while underwater, in pixels/second<sup>2</sup>. (Specify
		 * numbers greater than zero; the object will adjust the signs as
		 * needed.)
		 * 
		 * @see SWIM_ACCELERATION */
		float SWIM_DECELERATION;
		
		/** You may turn off the underwater mechanics by setting this flag to
		 * false. The character will behave as though there were no water at
		 * all. */
		bool FLOAT_ON_WATER_SURFACE;
		
		/**
		 * Constructor:
		 * If an attribute table is supplied, the constructor will use its keys
		 * to initialize the platformer's parameters (the members in ALL CAPS).
		 * The keys must have the same name as their corresponding members, and
		 * the values must be convertible to floating-point numbers. (The boolean
		 * parameters must be the strings "true" or "false.")
		 * 
		 * Any parameter that cannot be initialized will receive a default value:
		 * @code
		 * HEIGHT                   =  55;
		 * WIDTH                    =  10;
		 * 
		 * CAMERA_DX                =   0;
		 * CAMERA_DY                = -45;
		 * 
		 * CAMERA_STICKINESS        =   0.7f;
		 * 
		 * CENTER_SCROLLING_ON_SELF = false;
		 * 
		 * WALK_SPEED               = 120.0f;
		 * 
		 * CLIMB_26_SLOPE_SLOWDOWN  =   1.0f;
		 * CLIMB_45_SLOPE_SLOWDOWN  =   0.5f;
		 * 
		 * WALK_ACCELERATION        = 900.0f;
		 * WALK_DECELERATION        = 900.0f;
		 * 
		 * JUMP_STRENGTH            = 240.0f;
		 * WATER_JUMP_STRENGTH      = 195.0f;
		 * GRAVITY                  = 390.5f;
		 * MAX_FALL_SPEED           = 330.0f;
		 * 
		 * SUBMERSION_HEIGHT        =  35.0f;
		 * BUOYANCY                 = 450.0f;
		 * MAX_FLOAT_SPEED          =  60.0f;
		 * MAX_SINK_SPEED           = 150.0f;
		 * SWIM_SPEED               =  90.0f;
		 * SWIM_ACCELERATION        = 225.0f;
		 * SWIM_DECELERATION        = 225.0f;
		 * @endcode
		 */
		PlatformerObj ( float x, float y, PlatformerInput * platformerInput, AttributeTable & attributes = AttributeTable() );
		virtual ~PlatformerObj ();
		
		
		/**
		 * Centers the scrolling point on the character.
		 */
		void initialize ();
		
		/**
		 * Updates the character's position, velocity, and sets the contact
		 * status. It will also center the scrolling point on the character and
		 * update the collision structure.
		 */
		void update ( int objLayer, float dt );
		
		/**
		 * Draws a rectangle displaying the character's bounds, contact status,
		 * and direction. Intended for debug purposes.
		 */
		void render ( int objLayer, float scrollX, float scrollY );
		
		/**
		 * Returns a collision structure delimited by the platformerObj's
		 * position, width and height.
		 */
		CollisionStruct * getCollisionStruct ();
		
		/** This flag is set by the <tt>update()</tt> method, indicating which
		 * way the character should be facing when its sprites are rendered. */
		bool isFacingLeft;
		
		/// @{
		/** These flags are set by the <tt>update()</tt> method, and indicate
		 * which segments are touching walls, floors and ceilings.
		 * 
		 * @see rightContact, leftContact, topContact, bottomContact */
		bool rightContact, leftContact, topContact, bottomContact;
		/// @}
		
		
		/**
		 * Returns the current position of the platformer character. This is a
		 * const reference, so you can call this method as much as you like
		 * without performance penalties.
		 */
		inline const Vector2D & getPos() {
			return pos;
		}
		
		/**
		 * Sets the platformer's position.
		 */
		inline void setPos ( float x, float y ) {
			float dx = x - pos.x;
			float dy = y - pos.y;
			
			translate( dx, dy );
		}
		
		/**
		 * Modifies the platformer's position.
		 */
		inline void translate ( float dx, float dy ) {
			pos.x += dx;
			pos.y += dy;
			
			platformerCollisionStruct.setX(
				platformerCollisionStruct.getX() + dx );
			platformerCollisionStruct.setY(
				platformerCollisionStruct.getY() + dy );
		}
		
		/**
		 * Returns the current velocity of the platformer character. This is a
		 * const reference, so you can call this method as much as you like
		 * without performance penalties.
		 */
		inline const Vector2D & getVel() {
			return vel;
		}
		
		/**
		 * Sets the platformer's velocity.
		 */
		inline void setVel ( float x, float y ) {
			float dx = x - vel.x;
			float dy = y - vel.y;
			
			vel.x += dx;
			vel.y += dy;
		}
		
	private:
		void * pHGE;
		float accDX, accDT;
		Vector2D pos, vel;
		Vector2D prevCamPos, nextCamPos;
		CollisionStruct::Box platformerCollisionStruct;
		
		inline float botRightX () { return pos.x + WIDTH/2; }
		inline float botRightY () { return pos.y; }
		inline float topRightX () { return pos.x + WIDTH/2; }
		inline float topRightY () { return pos.y - HEIGHT; }
		inline float topLeftX  () { return pos.x - WIDTH/2; }
		inline float topLeftY  () { return pos.y - HEIGHT; }
		inline float botLeftX  () { return pos.x - WIDTH/2; }
		inline float botLeftY  () { return pos.y; }
		
		inline bool isUnderwater () {
			return (pos.y > Environment::getLoadedRoom()->waterLevel + SUBMERSION_HEIGHT);
		}
		
		inline bool rightCollision () {
			return Environment::getLoadedRoom()->segmentCollision(
					topRightX(), topRightY(),
					botRightX(), botRightY(),
					false ); 
		}
		inline bool leftCollision () {
			return Environment::getLoadedRoom()->segmentCollision(
					topLeftX(), topLeftY(),
					botLeftX(), botLeftY(),
					false );
		}
		inline bool topCollision () {
			return Environment::getLoadedRoom()->segmentCollision(
					topLeftX(),  topLeftY(),
					topRightX(), topRightY(),
					false );
		}
		inline bool botCollision () {
			return Environment::getLoadedRoom()->segmentCollision(
					botLeftX(),  botLeftY(),
					botRightX(), botRightY(),
					false );
		}
		
		// Encapsulate input access here. These methods return false if the
		// input object is NULL.
		inline bool inputLeft() {
			return (platformerInput != NULL && platformerInput->left);
		}
		inline bool inputRight() {
			return (platformerInput != NULL && platformerInput->right);
		}
		inline bool inputDown() {
			return (platformerInput != NULL && platformerInput->down);
		}
		inline bool inputJumpPress() {
			return (platformerInput != NULL && platformerInput->jumpPress);
		}
		inline bool inputJump() {
			return (platformerInput != NULL && platformerInput->jump);
		}
		
	};
	
}



#endif