/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

/**
 * @file qafJoystickSystem.h
 */

#ifndef QAF_JOYSTICKSYSTEM_H
#define QAF_JOYSTICKSYSTEM_H

#include "qafutil/qafContainer.h"

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>


namespace qaf {
	
	/** 
	 * Types of objects present in a joystick. The names are derived from
	 * DirectInput's nomenclature. See the header file qafJoystickSystem.h for
	 * a list of useful macros that can be applied to these values.
	 */
	enum JoystickObject {
		QAF_JOY_NONE = 0,        /**< Represents an invalid code. */ /// @{
		QAF_JOY_X_AXIS,          /**< Axis that might provide analog input. */
		QAF_JOY_Y_AXIS,          
		QAF_JOY_Z_AXIS,          
		QAF_JOY_X_AXIS_ROTATION, 
		QAF_JOY_Y_AXIS_ROTATION,
		QAF_JOY_Z_AXIS_ROTATION,
		QAF_JOY_SLIDER_0,
		QAF_JOY_SLIDER_1,        /** @} */ /// @{
		QAF_JOY_POV_0,           /**< Point-of-view hat, representing directional input. */
		QAF_JOY_POV_1,
		QAF_JOY_POV_2,
		QAF_JOY_POV_3,           /** @} */ /// @{
		QAF_JOY_BUTTON_0,        /**< Button that can only receive digital input. */
		QAF_JOY_BUTTON_1,
		QAF_JOY_BUTTON_2,
		QAF_JOY_BUTTON_3,
		QAF_JOY_BUTTON_4,
		QAF_JOY_BUTTON_5,
		QAF_JOY_BUTTON_6,
		QAF_JOY_BUTTON_7,
		QAF_JOY_BUTTON_8,
		QAF_JOY_BUTTON_9,
		QAF_JOY_BUTTON_10,
		QAF_JOY_BUTTON_11,
		QAF_JOY_BUTTON_12,
		QAF_JOY_BUTTON_13,
		QAF_JOY_BUTTON_14,
		QAF_JOY_BUTTON_15,
		QAF_JOY_BUTTON_16,
		QAF_JOY_BUTTON_17,
		QAF_JOY_BUTTON_18,
		QAF_JOY_BUTTON_19,
		QAF_JOY_BUTTON_20,
		QAF_JOY_BUTTON_21,
		QAF_JOY_BUTTON_22,
		QAF_JOY_BUTTON_23,
		QAF_JOY_BUTTON_24,
		QAF_JOY_BUTTON_25,
		QAF_JOY_BUTTON_26,
		QAF_JOY_BUTTON_27,
		QAF_JOY_BUTTON_28,
		QAF_JOY_BUTTON_29,
		QAF_JOY_BUTTON_30,
		QAF_JOY_BUTTON_31,
		QAF_JOY_BUTTON_32,
		QAF_JOY_BUTTON_33,
		QAF_JOY_BUTTON_34,
		QAF_JOY_BUTTON_35,
		QAF_JOY_BUTTON_36,
		QAF_JOY_BUTTON_37,
		QAF_JOY_BUTTON_38,
		QAF_JOY_BUTTON_39,
		QAF_JOY_BUTTON_40,
		QAF_JOY_BUTTON_41,
		QAF_JOY_BUTTON_42,
		QAF_JOY_BUTTON_43,
		QAF_JOY_BUTTON_44,
		QAF_JOY_BUTTON_45,
		QAF_JOY_BUTTON_46,
		QAF_JOY_BUTTON_47,
		QAF_JOY_BUTTON_48,
		QAF_JOY_BUTTON_49,
		QAF_JOY_BUTTON_50,
		QAF_JOY_BUTTON_51,
		QAF_JOY_BUTTON_52,
		QAF_JOY_BUTTON_53,
		QAF_JOY_BUTTON_54,
		QAF_JOY_BUTTON_55,
		QAF_JOY_BUTTON_56,
		QAF_JOY_BUTTON_57,
		QAF_JOY_BUTTON_58,
		QAF_JOY_BUTTON_59,
		QAF_JOY_BUTTON_60,
		QAF_JOY_BUTTON_61,
		QAF_JOY_BUTTON_62,
		QAF_JOY_BUTTON_63,
		QAF_JOY_BUTTON_64,
		QAF_JOY_BUTTON_65,
		QAF_JOY_BUTTON_66,
		QAF_JOY_BUTTON_67,
		QAF_JOY_BUTTON_68,
		QAF_JOY_BUTTON_69,
		QAF_JOY_BUTTON_70,
		QAF_JOY_BUTTON_71,
		QAF_JOY_BUTTON_72,
		QAF_JOY_BUTTON_73,
		QAF_JOY_BUTTON_74,
		QAF_JOY_BUTTON_75,
		QAF_JOY_BUTTON_76,
		QAF_JOY_BUTTON_77,
		QAF_JOY_BUTTON_78,
		QAF_JOY_BUTTON_79,
		QAF_JOY_BUTTON_80,
		QAF_JOY_BUTTON_81,
		QAF_JOY_BUTTON_82,
		QAF_JOY_BUTTON_83,
		QAF_JOY_BUTTON_84,
		QAF_JOY_BUTTON_85,
		QAF_JOY_BUTTON_86,
		QAF_JOY_BUTTON_87,
		QAF_JOY_BUTTON_88,
		QAF_JOY_BUTTON_89,
		QAF_JOY_BUTTON_90,
		QAF_JOY_BUTTON_91,
		QAF_JOY_BUTTON_92,
		QAF_JOY_BUTTON_93,
		QAF_JOY_BUTTON_94,
		QAF_JOY_BUTTON_95,
		QAF_JOY_BUTTON_96,
		QAF_JOY_BUTTON_97,
		QAF_JOY_BUTTON_98,
		QAF_JOY_BUTTON_99,
		QAF_JOY_BUTTON_100,
		QAF_JOY_BUTTON_101,
		QAF_JOY_BUTTON_102,
		QAF_JOY_BUTTON_103,
		QAF_JOY_BUTTON_104,
		QAF_JOY_BUTTON_105,
		QAF_JOY_BUTTON_106,
		QAF_JOY_BUTTON_107,
		QAF_JOY_BUTTON_108,
		QAF_JOY_BUTTON_109,
		QAF_JOY_BUTTON_110,
		QAF_JOY_BUTTON_111,
		QAF_JOY_BUTTON_112,
		QAF_JOY_BUTTON_113,
		QAF_JOY_BUTTON_114,
		QAF_JOY_BUTTON_115,
		QAF_JOY_BUTTON_116,
		QAF_JOY_BUTTON_117,
		QAF_JOY_BUTTON_118,
		QAF_JOY_BUTTON_119,
		QAF_JOY_BUTTON_120,
		QAF_JOY_BUTTON_121,
		QAF_JOY_BUTTON_122,
		QAF_JOY_BUTTON_123,
		QAF_JOY_BUTTON_124,
		QAF_JOY_BUTTON_125,
		QAF_JOY_BUTTON_126,      
		QAF_JOY_BUTTON_127       
	};
	/** @} */
	
	/** The number of items in the JoystickObject enumeration. */
	#define QAF_JOY_MAX_OBJECTS   (QAF_JOY_BUTTON_127 - QAF_JOY_X_AXIS + 1)
	
	/** Determines if an object code represents an axis or slider. */
	#define QAF_JOY_ISAXIS(obj)   (obj >= QAF_JOY_X_AXIS   && obj <= QAF_JOY_SLIDER_1  )
	
	/** Determines if an object code represents a POV hat. */
	#define QAF_JOY_ISPOV(obj)    (obj >= QAF_JOY_POV_0    && obj <= QAF_JOY_POV_3     )
	
	/** Determines if an object code represents a button. */
	#define QAF_JOY_ISBUTTON(obj) (obj >= QAF_JOY_BUTTON_0 && obj <= QAF_JOY_BUTTON_127)
	
	/** Returns the object code of a button. E.g., <tt>QAF_JOY_BUTTON(5)</tt>
	* will evaluate to <tt>QAF_JOY_BUTTON_5</tt>. */
	#define QAF_JOY_BUTTON(n)     ((JoystickObject) (QAF_JOY_BUTTON_0 + n))
	
	/**
	 * This class represents an instance of an active joystick device.
	 * 
	 * Most methods expect a <tt>JoystickObject</tt> code as a parameter. See
	 * the enumerated type definition in qafJoystickSystem.h for its possible
	 * values.
	 * 
	 * If any errors are encountered during the execution of this class's
	 * methods, they will be reported in the HGE log file.
	 */
	class Joystick {
		public:
			/**
			 * @internal
			 * @param pJoystick A pointer to the joystick interface.
			 * @param hWindow   The window handle to which this device will be 
			 *                  attached.
			 */
			Joystick ( LPDIRECTINPUTDEVICE8 pJoystick, HWND hWindow );
			virtual ~Joystick ();
			
			/**
			 * @internal
			 * @return true if the device was successfully initialized.
			 */
			bool isInitialized ();
			
			/**
			 * @internal
			 * This method must be called every frame to update the joystick's
			 * state. This is the <tt>Environment</tt>'s task; users need not
			 * and should not invoke this method directly.
			 * 
			 * @return false if the device could not be read. This could happen
			 * if the window has lost focus, or the joystick was disconnected.
			 */
			bool poll ();
			
			/**
			 * Returns a number representing the specified object's state. The
			 * semantics of that value depend on the type of object read:
			 *  - Axes and sliders: An integer number between the axis' minimum
			 *    and maximum values. (See the <tt>setAxesParameters()</tt>
			 *    method).
			 *  - POV hats: The position is indicated in hundredths of a degree
			 *    clockwise from north (away from the user). The center
			 *    position is reported as -1. For indicators that have only
			 *    five positions, the value for a controller is -1 (center),
			 *    0 (north), 9000 (east), 18000 (south), or 27000 (west).
			 *    <em><b>Warning:</b> This differs slightly from DirectInput's
			 *    default.</em>
			 *  - Buttons: A non-zero value is returned if the button is
			 *    pressed (usually 128); otherwise, zero is returned.
			 */
			int getObjectState ( JoystickObject obj );
			
			/**
			 * Returns a pointer to an internal string, containing the object's
			 * description.
			 * 
			 * @return <tt>NULL</tt> if the object does not exist on the
			 *         joystick.
			 */
			const char * getObjectName ( JoystickObject obj );
			
			/**
			 * @return This joystick's name. The string is statically allocated
			 *         and should not be changed or freed.
			 */
			const char * getDeviceName ();
			
			/**
			 * @internal
			 * Changes this joystick's target window.
			 * 
			 * @return false if the change was not successful.
			 */
			bool setHWND ( HWND hWindow );
			
			/**
			 * Sets the axes' parameters.
			 * @param absolute   If set to false, the axes' data will be
			 *                   returned in relation to the last frame.
			 *                   Default: true
			 * @param minValue   The axes' minimum value (e.g., the number
			 *                   returned when the X-axis is all the way to the
			 *                   left). Default: -1000
			 * @param maxValue   The axes' maximum value (e.g., the number
			 *                   returned when the X-axis is all the way to the
			 *                   right). Default: +1000
			 * @param deadZone   A percentage value (range [0, 1]), indicating
			 *                   the area at the axes' center where movement
			 *                   should be considered zero. Default: 0.1
			 * @param saturation A percentage value (range [0, 1]), indicating
			 *                   the area at the axes' outer edge where
			 *                   movement should be considered at its maximum.
			 *                   Default: 1.0
			 * 
			 * @return false if the change was not successful. Note that
			 *         <em>some</em> of the axes might have been changed if
			 *         that occurs.
			 */
			bool setAxesParameters ( bool absolute, int minValue, int maxValue, float deadZone, float saturation );
			
			/**
			 * Creates a periodic force-feedback effect if the device supports
			 * it.
			 * 
			 * @param magnitude A number contained in the interval [0, 1],
			 *                  where 0 represents no force and 1 represents
			 *                  the device's maximum force.
			 * @param duration  Duration of the vibration, in seconds.
			 * @param period    This parameter specifies the period of the effect's
			 *                  vibration.
			 * 
			 * @return The effect ID, which can be used for playback later, or
			 *         -1 if the effect could not be created.
			 * 
			 * @see playEffect(), changeVibrationMagnitude(), deleteEffect()
			 */
			int createVibrationEffect ( float magnitude, float duration, float period );
			
			/**
			 * Changes the vibration's magnitude of the effect specified by
			 * <tt>effectID</tt>. It may be possible to change the effect's
			 * parameters as it is playing, depending on the device.
			 * 
			 * @return false if the operation was not successful.
			 * 
			 * @see createVibrationEffect(), playEffect()
			 */
			bool changeVibrationMagnitude ( int effectID, float newMagnitude, float newPeriod );
			
			/**
			 * Unloads and deletes the effect specified by <tt>effectID</tt>.
			 * 
			 * @return false if the operation was not successful.
			 * 
			 * @see createVibrationEffect()
			 */
			bool deleteEffect ( int effectID );
			
			/**
			 * Starts the effect specified by <tt>effectID</tt>.
			 * 
			 * @return false if the operation was not successful.
			 * 
			 * @see createVibrationEffect(), changeVibrationMagnitude()
			 */
			bool playEffect ( int effectID, int repetitions );
			
		private:
			void * pHGE;
			
			bool initialized;
			LPDIRECTINPUTDEVICE8 pJoystick; // Pointer to the joystick interface
			HWND hWindow; // Window handle used to set cooperative levels
			
			DIJOYSTATE2 state; // Joystick state
			
			Container<GUID> effectGUIDs; // Supported force-feedback effects
			Container<DWORD> effectAxesOfs; // Axes that support force-feedback, initialized in the constructor
			Container<IDirectInputEffect *> createdEffects;
			
			char deviceName[MAX_PATH];
			char * objNames[QAF_JOY_MAX_OBJECTS]; // Joystick object names
			void resetStates ();
			
			// Callback used to enumerate joystick axes:
			static BOOL CALLBACK enumAxesCallback ( const DIDEVICEOBJECTINSTANCE * pdidoi, void * pContext );
			
			// Callback used to enumerate joystick axes that support
			// force-feedback:
			static BOOL CALLBACK enumFFAxesCallback ( const DIDEVICEOBJECTINSTANCE * pdidoi, void * pContext );
			
			// Callback used to enumerate force-feedback effects and store
			// their GUIDs:
			static BOOL CALLBACK enumEffectsCallback ( LPCDIEFFECTINFO pei, void * pContext );
	};
	
	
	
	/**
	 * @internal
	 * This class manages the system's available joysticks. The
	 * <tt>Environment</tt> will take care of everything joystick-related,
	 * and users shouldn't directly use a <tt>JoystickSystem</tt> object.
	 */
	class JoystickSystem {
		public:
			JoystickSystem ();
			virtual ~JoystickSystem ();
			
			/**
			 * @internal
			 * Reads the system's available joysticks and prepares their
			 * interfaces.
			 * @param hWindow The window handle to which the joysticks will be
			 *                attached.
			 * @return false if initialization was not successful.
			 */
			bool initialize ( HWND hWindow );
			
			/**
			 * @internal
			 * Releases all resources.
			 */
			void shutdown ();
			
			/**
			 * @internal
			 * @return the number of joysticks available.
			 */
			int getNumberOfJoysticks ();
			
			/**
			 * @internal
			 * @return a pointer to the <tt>i</tt>th joystick device available, or
			 *         <tt>NULL</tt> if an invalid index is specified.
			 */
			Joystick * getJoystick ( int i );
			
		private:
			void * pHGE;
			
			LPDIRECTINPUT8 pDI; // Pointer to the DirectInput object
			
			Container<Joystick *> joysticks; // Available joysticks
			
			// Callback used to enumerate available joysticks:
			static BOOL CALLBACK enumJoysticksCallback ( const DIDEVICEINSTANCE * pdidInstance, void * pContext);
			
	};
	
	
}


#endif