/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_ENVIRONMENT_H
#define QAF_ENVIRONMENT_H

#include "qafDef.h"
#include "qafGameObjFactory.h"
#include "qafJoystickSystem.h"
#include "qafRoom.h"
#include "qafutil/qafBigTexture.h"
#include "qafutil/qafVector2D.h"
#include "qafutil/qafVector3D.h"



namespace qaf {
	
	/**
	 * Used to iterate over the <tt>Environment</tt>'s list of active
	 * game objects. Instances of this class are returned by
	 * <tt>Environment::makeObjIterator()</tt>.
	 * 
	 * Note that there is no guarantee as to the order objects are returned
	 * by the iterator.
	 * 
	 * If you need to iterate over a specific class of object, use the
	 * template form:
	 * 
	 * @code
	 *	ObjIterator<YourClass> i = Environment::makeObjIterator<YourClass>();
	 *	while ( i.hasNext() ) {
	 *		YourClass * obj = i.next();
	 *		// Do something with the object...
	 *	}
	 * @endcode
	 * 
	 * @warning
	 * All active <tt>ObjIterator</tt>s are invalidated at the end of a
	 * frame cycle; you must get a new <tt>ObjIterator</tt> every frame.
	 * \par
	 * It is safe to use an <tt>ObjIterator</tt> along with the object
	 * manipulation methods (<tt>Environment::addGameObj()</tt>,
	 * <tt>Environment::removeGameObj()</tt>,
	 * <tt>Environment::moveGameObj()</tt>) and room management
	 * (<tt>Environment::loadRoom()</tt>,
	 * <tt>Environment::unloadRoom()</tt>), since those are buffered.
	 */
	template <typename T>
	class ObjIterator {
		public:
			/**
			 * @return false if the end of the <tt>GameObj</tt> list has
			 * been reached.
			 */
			bool hasNext () {
				return (currObjInx >= 0);
			};
			
			/** 
			 * Retrieves the next object in the list and advances the
			 * pointer to the next object.
			 * 
			 * If the end of the object list has been reached, returns NULL.
			 */
			T * next () {
				if ( currObjInx < 0 )
					return NULL;
				else {
					currObjInx--;
					return objects->elem( currObjInx + 1 );
				}
			}
			
			/**
			 * @return The total number of objects in this iterator.
			 */
			int getCount () {
				return objects->getCount();
			}
			
		private:
			friend class Environment;
			
			int currObjInx;
			const Container<T *> * objects;
			
			inline ObjIterator ( const Container<T *> * _objects ) : objects(_objects) {
				currObjInx = _objects->getCount() - 1;
			}
	};
	
	
	
	
	/**
	 * This class is used to generate a visualization of vectors for debug
	 * purposes. The extremities are represented in room coordinates, not
	 * screen coordinates. In other words, you don't need to worry about
	 * scrolling.
	 * 
	 * The vector will be rendered as an arrow pointing from <tt>p1</tt> to
	 * <tt>p2</tt>, in the specified <tt>color</tt>.
	 * 
	 * @see Environment::debugVectors
	 * 
	 * @note    <tt>DebugVector</tt>s are only available if you initialize
	 *          the <tt>Environment</tt> with <tt>useDebug</tt> set to
	 *          true.
	 */
	class DebugVector {
	public:
		DebugVector () {}
		
		DebugVector ( Vector2D & _p1, Vector2D & _p2, DWORD _color );
		
		void render ();
		
	private:
		Vector2D p1, p2;
		DWORD color;
	};
	
	
	
	
	/**
	 * The <tt>Environment</tt> manages the game's state -- both static
	 * (window, loaded room, background layers), and dynamic (<tt>GameObj</tt>s).
	 *
	 * Setting up the Qaf environment involves the following steps:
	 * - Invoking the <tt>initialize()</tt> method to prepare the environment
	 *   resources;
	 * - Defining a <tt>GameObjFactory</tt> by invoking the
	 *   <tt>setGameObjFactory()</tt> method;
	 * - Defining prologue and epilogue callbacks with
	 *   <tt>setPrologueCallback()</tt> and <tt>setEpilogueCallback()</tt>;
	 * - Loading a starting room with <tt>loadRoom()</tt>;
	 * - Invoking the <tt>update()</tt> method in HGE's frame function.
	 * 
	 * Before shutting down HGE, you should invoke
	 * <tt>Environment::shutdown()</tt> to ensure everything is cleaned up
	 * before the application exits.
	 */
	class Environment {
	public:

		/**
		 * A "clock" used by the <tt>Environment</tt> to update the water
		 * level's undulation, current, and refraction.
		 * 
		 * This value is kept consistent with the <tt>dt</tt> parameter
		 * supplied to <tt>update()</tt>.
		 * 
		 * This field may be modified at will; for instance, you could reset
		 * the <tt>Environment</tt> time by setting <tt>time = 0</tt>.
		 */
		static float time;
		
		/**
		 * Similar to <tt>time</tt>, this will keep track of how many frames
		 * were rendered.
		 */
		static int frames;
		

		/**
		 * This must be called before any other method, as it prepares the
		 * <tt>Environment</tt>'s internal variables.
		 *
		 * @param useBackBuffer Whether the game should use a buffer before
		 *                      flushing to the screen. See
		 *                      <tt>enableBackBuffer()</tt> for details.
		 * @param useDebug      Passing true here will enable the
		 *                      <tt>DebugConsole</tt> and <tt>DebugVector</tt>s.
		 *                      The debug resources incur a slight overhead, so
		 *                      you might want to disable them for the game's
		 *                      final version.
		 * 
		 * @return false if there was a problem during initialization. Use 
		 *         <tt>hge->System_GetErrorMessage()</tt> to get a
		 *         description of the error.
		 */
		static bool initialize ( bool useBackBuffer, bool useDebug );
		
		/**
		 * Call this once per frame to perform Qaf's game loop. This will check
		 * collisions, update the <tt>GameObj</tt>s, perform all rendering
		 * operations, and call the prologue/epilogue functions.
		 * 
		 * Usually, you will place this in HGE's frame function.
		 */
		static void update ( float dt );
		
		/**
		 * This method is a quick shortcut to turn on or off the execution of
		 * all <tt>GameObj</tt>s' <tt>%update()</tt> method and collision
		 * detection.
		 *
		 * @see GameObj::update()
		 */
		static void enableObjUpdate ( bool flag );
		
		/**
		 * @return true if object updating is enabled.
		 * @see enableObjUpdate()
		 */
		static bool isObjUpdateEnabled ();
		
		/**
		 * This method is a quick shortcut to turn on or off the execution of
		 * the <tt>render()</tt> method.
		 * 
		 * In short, setting this flag to false will halt <em>all</em> rendering
		 * operations (both <tt>GameObj</tt>- and <tt>BGLayer</tt>-related),
		 * and the only rendering that could possibly take place would be in
		 * the prologue/epilogue callbacks.
		 *
		 * @see GameObj::render()
		 */
		static void enableRender ( bool flag );
		
		/**
		 * @return true if rendering is enabled.
		 * @see enableRender()
		 */
		static bool isRenderEnabled ();
		
		
		/**
		 * Releases all resources used by the <tt>Environment</tt>.
		 * 
		 * This method unloads textures, the loaded room, and <tt>delete</tt>s
		 * any <tt>GameObj</tt>s still active.
		 * 
		 * This method should only be invoked after stopping HGE's game loop
		 * (i.e., when <tt>System_Start()</tt> returns), and not during game
		 * execution.
		 * 
		 * @see initialize(), update()
		 */
		static void shutdown ();
		
		/**
		 * The back buffer is a render target used to store all rendered data
		 * before it is flushed to the screen.
		 * 
		 * This buffer is necessary for the underwater distortion effect, and
		 * may be used by the developer to create sophisticated visual effects.
		 * 
		 * The back buffer's dimensions are limited by the video card's maximum
		 * texture size; also, transferring data from this buffer to the screen
		 * may incur a heavy performance penalty. Thus, it is possible to
		 * disable the back buffer if performance or compatibility issues
		 * require it.
		 * 
		 * @see isBackBufferEnabled(), getBackBuffer()
		 */
		static void enableBackBuffer ( bool flag );
		
		/**
		 * @return true if the back buffer has been enabled (that does not mean
		 * that is has been successfully created, however).
		 * 
		 * @see enableBackBuffer(), getBackBuffer()
		 */
		static bool isBackBufferEnabled ();
		
		/**
		 * @return The back buffer's texture handle (HTEXTURE). This texture
		 *         stores the <tt>Environment</tt>'s rendered data (background
		 *         layers and <tt>GameObj</tt>s). If the back buffer has been
		 *         disabled or could not be created, returns <tt>NULL</tt>.
		 * 
		 * @see enableBackBuffer(), isBackBufferEnabled()
		 */
		static unsigned long getBackBuffer ();
		
		
		/**
		 * When a room is loaded, the game object factory is queried by the
		 * <tt>Environment</tt> to create its objects.
		 * 
		 * Setting this pointer to <tt>NULL</tt> will turn off object creation.
		 */
		static void setGameObjFactory ( GameObjFactory * _gameObjFactory );
		
		/**
		 * @return The game object factory currently in use by the
		 *         <tt>Environment</tt>.
		 * @see setGameObjFactory()
		 */
		static GameObjFactory * getGameObjFactory ();
		
		/**
		 * The prologue callback is called at the beginning of every frame
		 * cycle. Its prototype must be:
		 * 
		 * @code
		 * void prologueCB ();
		 * @endcode
		 * 
		 * It will be called each frame, <em>after</em> rendering starts
		 * (i.e., after <tt>hge->Gfx_BeginScene()</tt>). Anything rendered here
		 * will appear beneath all BG layers and game objects. If you need to
		 * clear the screen or apply scene-wide transformations, do those in
		 * the prologue function.
		 * 
		 * @see setEpilogueCallback()
		 */
		static void setPrologueCallback ( void (*cb) () );
		
		/**
		 * The epilogue callback is called at the end of every frame cycle. Its
		 * prototype must be:
		 * 
		 * @code
		 * void epilogueCB ();
		 * @endcode
		 * 
		 * It will be called after all rendering has been performed in each
		 * frame, but before <tt>hge->Gfx_EndScene()</tt>. Thus, it is safe to
		 * perform rendering operations here. They will appear in front of
		 * everything else; this is a good place to render on-screen status
		 * bars, menus, etc.
		 * 
		 * @see setPrologueCallback()
		 */
		static void setEpilogueCallback ( void (*cb) () );
		
		
		/**
		 * Changes the game's loaded <tt>Room</tt>, unloading what was loaded
		 * before.
		 * 
		 * The file must be a valid encoded room file, created with Qaf's %Room
		 * Editor. If an error is found, the method returns false and the
		 * environment is left unchanged.
		 * 
		 * Loading a room will automatically trigger the <tt>unloadRoom()</tt>
		 * method; thus, all volatile <tt>GameObj</tt>s will be
		 * <tt>delete</tt>d. The new room's objects are extracted from the room
		 * file, and their data is forwarded to the current
		 * <tt>GameObjFactory</tt>.
		 * 
		 * @return false if the file could not be loaded or it is not a valid
		 *         Qaf room file.
		 * 
		 * @note
		 * This operation is not executed immediately. It will be kept in a
		 * buffer, and the actual loading will only take place at the end of
		 * the frame cycle.
		 * 
		 * @see unloadRoom(), setGameObjFactory()
		 */
		static bool loadRoom ( std::string filename );
		
		/**
		 * @return A pointer to the currently loaded <tt>Room</tt>, or
		 * <tt>NULL</tt> if no room has been loaded.
		 */
		static Room * getLoadedRoom ();

		/**
		 * Unloads the currently loaded room, deleting all volatile
		 * <tt>GameObj</tt>s.
		 * 
		 * At the end of the operation, the <tt>Environment</tt> will contain
		 * a single empty object layer.
		 * 
		 * @note
		 * This operation is not executed immediately. It will be kept in a
		 * buffer, and the actual unloading will only take place in the next
		 * frame.
		 * 
		 * @see loadRoom(), GameObj::isVolatile()
		 */
		static void unloadRoom ();
		
		
		/**
		 * This changes the "scrolling point," which represents the screen's
		 * displacement relative to the room's top-left corner.
		 *
		 * The method will automatically clamp the coordinates, preventing the
		 * screen from "exiting" the loaded room's area.
		 *
		 * @see moveScrollingPoint(), centerScrollingPoint(), getScrollingX(),
		 *      getScrollingY()
		 */
		static void setScrollingPoint ( int x, int y );
		
		/**
		 * @param dx How many pixels the screen should be "nudged" horizontally
		 * @param dy How many pixels the screen should be "nudged" vertically
		 * 
		 * @see setScrollingPoint(), centerScrollingPoint()
		 */
		static void moveScrollingPoint ( int dx, int dy );
		
		/**
		 * Centers the screen at coordinates (<tt>x</tt>, <tt>y</tt>). This is
		 * the same as calling
		 * 
		 * @code
		 * setScrollingPoint( x - screenWidth/2, y - screenHeight/2 );
		 * @endcode
		 * 
		 * where <tt>screenWidth</tt> and <tt>screenHeight</tt> are extracted
		 * from the currently loaded room.
		 * 
		 * This method does nothing if there is no loaded room.
		 * 
		 * @see setScrollingPoint(), moveScrollingPoint()
		 */
		static void centerScrollingPoint ( int x, int y );
		
		/**
		 * @return The scrolling point's X coordinate.
		 * @see setScrollingPoint(), getScrollingY()
		 */
		static int getScrollingX ();
		
		/**
		 * @return The scrolling point's Y coordinate.
		 * @see setScrollingPoint(), getScrollingX()
		 */
		static int getScrollingY ();
		
		
		/**
		 * Returns the current screen width.
		 * If there is a loaded room, the room's screen width (in pixels) is
		 * returned. Otherwise, the window's screen width is returned by
		 * consulting the HGE_SCREENWIDTH system state.
		 */
		static int getScreenWidth ();
		
		/**
		 * Returns the current screen height.
		 * If there is a loaded room, the room's screen height (in pixels) is
		 * returned. Otherwise, the window's screen height is returned by
		 * consulting the HGE_SCREENHEIGHT system state.
		 */
		static int getScreenHeight ();
		
		
		/**
		 * Inserts an object into the <tt>Environment</tt>. If no layer is
		 * specified, the loaded room's default layer is used.
		 * 
		 * If <tt>onTop</tt> is true, the object will be inserted at the
		 * frontmost position in the layer.
		 * 
		 * This operation is buffered, and its effects will only be visible in
		 * the next frame.
		 * 
		 * The object's <tt>%initialize()</tt> method will <em>not</em> be
		 * called.
		 * 
		 * @see Room::defaultObjLayer, removeGameObj(), moveGameObj()
		 */
		static void addGameObj ( GameObj * obj, int layer = -1, bool onTop = true );
		
		/**
		 * Searches the <tt>Environment</tt> for the specified object.
		 * If it is found, this method returns its layer, and stores the
		 * object's index in the <tt>index</tt> pointer. (Keep in mind that
		 * each layer is a list of objects; objects that are at the front of
		 * the layer will have lower indices, and objects that are at the back
		 * will have higher indices.)
		 * 
		 * If the object is not found, the method returns -1, and the
		 * <tt>index</tt> pointer is left unchanged.
		 * 
		 * If you don't care about the object's intra-layer position, use
		 * <tt>index = NULL</tt>.
		 * 
		 * @return The layer where the object currently resides, or -1 if the
		 *         object is not found.
		 */
		static int findGameObj ( GameObj * obj, int * index = NULL );
		
		/**
		 * Searches the <tt>Environment</tt> for the specified <tt>GameObj</tt>
		 * and removes it from its current layer. If the <tt>deleteIt</tt>
		 * parameter is true, the object will also be <tt>delete</tt>d.
		 * 
		 * If a valid source layer is specified, it is used to trim down the
		 * search. (If you already know which layer the object is in, you can
		 * get a performance boost by telling the <tt>Environment</tt> where to
		 * look. Rather than inspecting <em>all</em> the layers, only
		 * <tt>srcLayer</tt> is searched.)
		 * 
		 * This operation is buffered, and its effects will only be "visible" in
		 * the next frame. (This includes the object's <tt>delet</tt>ion.)
		 * 
		 * @see addGameObj(), moveGameObj()
		 */
		static void removeGameObj ( GameObj * obj, bool deleteIt, int srcLayer = -1 );
		
		/**
		 * Searches the <tt>Environment</tt> for the specified
		 * <tt>GameObj</tt>, removes it from its current layer and places it
		 * into the destination layer. The object will be at the frontmost
		 * position in that layer.
		 * 
		 * If a valid source layer is specified, it is used to trim down the
		 * search. (If you already know which layer the object is in, you can
		 * get a performance boost by telling the <tt>Environment</tt> where to
		 * look. Rather than inspecting <em>all</em> the layers, only
		 * <tt>srcLayer</tt> is searched.)
		 * 
		 * If <tt>destLayer</tt> is not a valid layer index, the object will be
		 * inserted in the loaded room's default object layer.
		 * 
		 * This operation is buffered, and its effects will only be "visible" in
		 * the next frame.
		 * 
		 * @see addGameObj(), removeGameObj()
		 */
		static void moveGameObj ( GameObj * obj, int destLayer, int srcLayer = -1 );
		
		/**
		 * Brings the object to the front of its layer.
		 * 
		 * The object will be updated and rendered after all others in its
		 * layer. Thus, it will appear "on top" of everything.
		 * 
		 * This does <em>not</em> move the object to another layer. It simply
		 * changes its position in-layer.
		 * 
		 * This operation is buffered, and its effects are not immediately
		 * visible.
		 * 
		 * @see sendGameObjToBack(), moveGameObj()
		 */
		static void bringGameObjToFront ( GameObj * obj, int srcLayer = -1 );
		
		/**
		 * Sends the object to the back of its layer.
		 * 
		 * The object will be updated and rendered before all others in its
		 * layer. Thus, it will appear "below" everything.
		 * 
		 * This does <em>not</em> move the object to another layer. It simply
		 * changes its position in-layer.
		 * 
		 * This operation is buffered, and its effects are not immediately
		 * visible.
		 * 
		 * @see bringGameObjToFront(), moveGameObj()
		 */
		static void sendGameObjToBack ( GameObj * obj, int srcLayer = -1 );
		
		
		
		/**
		 * @return The number of joysticks that are currently available.
		 * @see getJoystick()
		 */
		static int getNumberOfJoysticks ();
		
		/**
		 * @return A pointer to the <tt>Joystick</tt> device available at index
		 *         <tt>i</tt>, or <tt>NULL</tt> if an invalid index is
		 *         specified.
		 * @see getNumberOfJoysticks()
		 */
		static Joystick * getJoystick ( int i );
		
		
		/**
		 * Loads a <tt>BigTexture</tt> from a file on the disk.
		 * 
		 * The <tt>Environment</tt> maintains a cache of loaded textures, so
		 * as to avoid the duplication of these objects. If the texture has
		 * already been loaded, a pointer to it will be returned instead of
		 * creating a new texture.
		 * 
		 * Do not <tt>delete</tt> this pointer. When you no longer need the
		 * texture, release it by calling
		 * <tt>Environment::freeBigTexture()</tt>.
		 * 
		 * @see Environment::freeBigTexture(),
		 *      Environment::setBigTextureCacheSize()
		 */
		static const BigTexture * loadBigTexture ( const char * filename );
		
		/**
		 * Releases an allocated <tt>BigTexture</tt>.
		 * 
		 * The texture must have been loaded with the
		 * <tt>Environment::loadBigTexture()</tt> method. The texture's
		 * reference counter will be decremented, but it will not be removed
		 * immediately.
		 * 
		 * @see Environment::loadBigTexture(),
		 *      Environment::setBigTextureCacheSize()
		 */
		static void freeBigTexture ( const BigTexture * tex );
		
		/**
		 * Coordinates the <tt>BigTexture</tt> cache management.
		 * 
		 * When a <tt>BigTexture</tt>'s reference counter reaches zero, it is
		 * not deleted immediately, but is kept in the cache until all slots
		 * have been filled.
		 * 
		 * When a new texture is requested with <tt>loadBigTexture()</tt>, the
		 * least-recently-freed texture will be <tt>deleted</tt> to make room for
		 * the new object.
		 * 
		 * You can control how many slots are available in the cache with this
		 * method. The default initial value is 7.
		 * 
		 * If <tt>size</tt> is less or equal to zero, the method does nothing.
		 */
		static void setBigTextureCacheSize ( int size );
		
		
	private:
		
		// A Container of pointers to Containers of pointers to GameObjs.
		// This stores all currently active GameObjs.
		static Container<Container<GameObj *> *> gameObjLayers;
		
		// A generic object discriminator:
		class AbstractObjDiscriminator {
			public:
				virtual void addGameObj ( GameObj * obj ) = 0;
				virtual void removeGameObj ( GameObj * obj ) = 0;
				virtual void removeAll () = 0;
				virtual ~AbstractObjDiscriminator () {}
		};
		
		// A type-specific object discriminator:
		template <typename T>
		class ObjDiscriminator : public AbstractObjDiscriminator {
			public:
				// The constructor looks through the current object list for
				// objects that match its target class:
				ObjDiscriminator () {
					for ( int layerInx = 0; layerInx < gameObjLayers.getCount(); layerInx++ ) {
						for ( int objInx = 0; objInx < gameObjLayers[layerInx]->getCount(); objInx++ ) {
							// Try to cast this pointer to the correct type:
							T * t_obj = dynamic_cast<T *> ( gameObjLayers[layerInx]->elem( objInx ) );
							if ( t_obj ) {
								// Add it:
								objects.add( t_obj );
							}
						}
					}
				}
				
				// Adds the object to the object list if it's of the correct
				// type.
				void addGameObj ( GameObj * obj ) {
					// Try to cast this pointer to the correct type:
					T * t_obj = dynamic_cast<T *> ( obj );
					if ( t_obj ) {
						// Add it:
						objects.add( t_obj );
					}
				}
				
				// Removes the object if it was added to a list:
				void removeGameObj ( GameObj * obj ) {
					// The dynamic cast is not needed here.
					// If the object is of the correct type, it will be found
					// by its address; otherwise, the comparison will simply
					// fail and the object will not be found.
					// However, a static cast is necessary to prevent compiler
					// errors.
					objects.removeFirst( (T *) obj );
				}
				
				// Removes all objects:
				void removeAll () {
					objects.removeAll();
				}
				
				// This is public so the ObjIterator class can see the objects
				// contained in the discriminator.
				Container<T *> objects;
		};
		
		// A Container of object discriminators:
		static Container<AbstractObjDiscriminator *> objDiscriminators;
		
	public:
		
		/**
		 * Allows clients to traverse the active object list.
		 * 
		 * @warning
		 * If you need to iterate over the object list, get a new iterator
		 * every frame.
		 * 
		 * @see ObjIterator
		 */
		template <typename T>
		static ObjIterator<T> makeObjIterator () {
			// Keep a reference to the discriminator for this class.
			static ObjDiscriminator<T> myDiscriminator;
			
			// This will only be run once:
			static bool once = true;
			if ( once ) {
				// Add the discriminator to the Environment's discriminator
				// list:
				Environment::objDiscriminators.add( &myDiscriminator );
				
				once = false;
			}
			
			// Create and return an object iterator:
			return ObjIterator<T>( &(myDiscriminator.objects) );
		}
		
		
	private:
		// A generic collision handler:
		class AbstractCollisionHandler {
			public:
				virtual void checkCollisions () = 0;
				virtual ~AbstractCollisionHandler () {}
		};
		
		// A type-specific collision handler:
		template <typename T1, typename T2>
		class CollisionHandler : public AbstractCollisionHandler {
			public:
				// The constructor receives a pointer to the handler function:
				CollisionHandler ( void (*_pfHandler) (T1 *, T2 *) ) {
					pfHandler = _pfHandler;
				}
				
				// Checks collisions between the objects:
				// From back to front, so objects that were added later are
				// checked first...
				void checkCollisions () {
					ObjIterator<T1> objects1 = makeObjIterator<T1>();
					while ( objects1.hasNext() ) {
						// Get first object:
						T1 * obj1 = objects1.next();
						
						ObjIterator<T2> objects2 = makeObjIterator<T2>();
						while ( objects2.hasNext() ) {
							// Get second object:
							T2 * obj2 = objects2.next();
							
							// Both objects have collision structures?
							CollisionStruct * cs1 = obj1->getCollisionStruct();
							CollisionStruct * cs2 = obj2->getCollisionStruct();
							
							if ( cs1 && cs2 ) {
								// The structures collide?
								if ( cs1->collidesWith( cs2 ) ) {
									// Invoke the handler:
									pfHandler( obj1, obj2 );
								}
							}
						}
					}
				}
				
			private:
				void (*pfHandler) (T1 *, T2 *);
		};
		
		// A Container of collision handlers:
		static Container<AbstractCollisionHandler *> collisionHandlers;
		
	public:
		
		/**
		 * Registers a collision handler between classes of objects.
		 * 
		 * In the template's two typenames, you specify two subclasses of
		 * <tt>GameObj</tt> to test for collisions. Every frame, all active
		 * instances of these two classes will be tested against each other for
		 * collisions, and the handler function will be invoked.
		 * 
		 * For instance, let's say you have created the classes
		 * <tt>PlayerObj</tt> and <tt>EnemyObj</tt>, both subclasses of
		 * <tt>GameObj</tt>:
		 * 
		 * @code
		 *	// This is the collision handler. It will be called every time the
		 *	// player touches an enemy.
		 *	void handler_PlayerEnemy ( PlayerObj * p, EnemyObj * e ) {
		 *		// Get the enemy's damage strength:
		 *		int enemyDamage = e->getDamageStrength();
		 *		
		 *		// "Hurt" the player:
		 *		p->decreaseHP( enemyDamage );
		 *	};
		 *	@endcode
		 *	@code
		 *	// Now, somewhere in main()...
		 *	// Tell the environment that collisions between PlayerObj and
		 *	// EnemyObj are handled by the handler_PlayerEnemy function:
		 *	Environment::registerCollisionHandler<PlayerObj, EnemyObj> ( handler_PlayerEnemy );
		 *		
		 * @endcode
		 * 
		 * @param pfHandler The handler function to be invoked when a collision
		 *                  occurs. It will receive the two colliding objects
		 *                  as its two parameters.
		 */
		template <typename T1, typename T2>
		static void registerCollisionHandler ( void (*pfHandler) (T1 *, T2 *) ) {
			// Create the collision handler:
			AbstractCollisionHandler * newHandler = new CollisionHandler<T1, T2>( pfHandler );
			
			// Add the handler:
			collisionHandlers.add( newHandler );
		}
		
		
		/**
		 * The debug console is useful for outputting data to the screen.
		 * Its contents will be cleared every frame.
		 * 
		 * You can use it just like the standard output:
		 * 
		 * @code
		 * qaf::Environment::cout << "Variable x = " << value << '\n';
		 * @endcode
		 * 
		 * The console will use a <tt>hgeFont</tt> to render the text at the
		 * screen's top-left corner.
		 * 
		 * The text is kept in a buffer, and displayed at the end of every
		 * frame. The buffer will then be cleared, preventing it from flooding
		 * the screen with text.
		 * 
		 * @note    The <tt>DebugConsole</tt> is only available if you
		 *          initialize the <tt>Environment</tt> with <tt>useDebug</tt>
		 *          set to true.
		 */
		class DebugConsole {
		public:
			inline DebugConsole & operator << ( char c ) {
				data += c;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( const char * str ) {
				data += str;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( const std::string & str ) {
				data += str;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( int val ) {
				sprintf( temp, "%d", val );
				data += temp;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( float val ) {
				sprintf( temp, "%f", val );
				data += temp;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( bool b ) {
				data += ( b ? "true" : "false" );
				
				return *this;
			}
			
			inline DebugConsole & operator << ( const Vector2D & v2D ) {
				sprintf( temp, "(%f, %f)", v2D.x, v2D.y );
				data += temp;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( const Vector3D & v3D ) {
				sprintf( temp, "(%f, %f, %f)", v3D.x, v3D.y, v3D.z );
				data += temp;
				
				return *this;
			}
			
			inline DebugConsole & operator << ( const void * ptr ) {
				sprintf( temp, "%p", ptr );
				data += temp;
				
				return *this;
			}
			
			inline const char * getData () {
				return data.c_str();
			}
			
			inline void clear () {
				data = "";
			}
			
		private:
			char temp[500];
			std::string data;
		};
		
		static DebugConsole cout;
		
		
		/**
		 * Add <tt>DebugVector</tt>s here. This container will be checked at
		 * the end of every frame, and its contents will be rendered as
		 * described in the <tt>DebugVector</tt> class.
		 * 
		 * Once that's done, the container will be automatically emptied in
		 * preparation for the next frame.
		 * 
		 * @see DebugVector
		 * 
		 * @note
		 * <tt>DebugVector</tt>s are only available if you initialize the
		 * <tt>Environment</tt> with <tt>useDebug</tt> set to true.
		 */
		static Container<DebugVector> debugVectors;
		
		
	private:
		
		// Draws the entire environment -- room, game objs, water, etc.
		static void render ();
		
		// Performs pending operations in operation buffer.
		static void doOpBuffer ();
		
		// Performs the actual room loading/unloading:
		static void doLoadRoom ( Room * newRoom, void * objInfo );
		static void doUnloadRoom ();
		
		// Frees "dead" textures from the BigTexture cache.
		static void enforceBigTexCacheSize ();
		
		
	};
	
}

#endif
