/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_OBJ_ANIMPARTICLEOBJ_H
#define QAF_OBJ_ANIMPARTICLEOBJ_H

#include "../qafGameObj.h"
#include <hgeanim.h>

namespace qaf {
	
	/**
	 * This is an object that renders itself as an animation, with optional
	 * linear/angular speeds.
	 * 
	 * The <tt>size</tt> parameter is used to scale the animation when
	 * rendered. If you want the animation at its original size, use 1.0.
	 * 
	 * When the animation has finished playing, the object will remove itself
	 * from the <tt>Environment</tt>. If you create an <tt>AnimParticleObj</tt>
	 * from an <tt>hgeAnimation</tt> that has the <tt>HGEANIM_LOOP</tt> flag
	 * set, the object will never delete itself and you are responsible for
	 * removing/deleting it.
	 * 
	 * The <tt>anim</tt> object will be copied internally by
	 * <tt>AnimParticleObj</tt>'s constructor. The animation will be played
	 * from its first frame, as per the <tt>hgeAnimation::Play()</tt> method.
	 * 
	 * @see qaf::SpriteParticleObj
	 */
	class AnimParticleObj : public GameObj {
		public:
			
			/**
			 * @param anim         The animation used to render this particle.
			 * @param x            The object's initial X position.
			 * @param y            The object's initial Y position.
			 * @param angle        The object's initial rotation.
			 * @param vx           The object's X speed (pixels/second).
			 * @param vy           The object's Y speed (pixels/second).
			 * @param vr           The object's angular speed (radians/second).
			 * @param ax           The object's X acceleration (pixels/second<sup>2</sup>).
			 * @param ay           The object's Y acceleration (pixels/second<sup>2</sup>).
			 * @param sizeX        The animation's horiz. scale.
			 * @param sizeY        The animation's vert. scale.
			 * @param color        The animation's color.
			 * @param blendMode    The blend mode used to render the animation.
			 */
			AnimParticleObj (
				const hgeAnimation * anim,
				float x, float y,
				float angle,
				float vx, float vy,
				float vr,
				float ax, float ay,
				float sizeX = 1.0f, float sizeY = 1.0f,
				DWORD color = 0xFFFFFFFF,
				DWORD blendMode = BLEND_DEFAULT );
			
			
			
			/**
			 * Returns a reference to the particle's animation.
			 */
			inline hgeAnimation * getAnimation () {
				return &anim;
			}
			
			/**
			 * Returns true if the particle's lifetime has expired.
			 */
			inline bool isDead () {
				return !anim.IsPlaying();
			}
			
			/**
			 * Returns the particle's current position. Any of the parameters
			 * may be NULL, indicating that they shouldn't be returned.
			 */
			void getPos ( float * _x, float * _y, float * _angle ) {
				if ( _x )
					*_x = x;
				if ( _y )
					*_y = y;
				if ( _angle )
					*_angle = angle;
			}
			
			/**
			 * Returns the particle's current velocity. Any of the parameters
			 * may be NULL, indicating that they shouldn't be returned.
			 */
			inline void getVel ( float * _vx, float * _vy, float * _vr ) {
				if ( _vx )
					*_vx = vx;
				if ( _vy )
					*_vy = vy;
				if ( _vr )
					*_vr = vr;
			}
			
			/**
			 * Returns the particle's size.
			 */
			inline void getSize ( float * xScale, float * yScale ) {
				if ( xScale )
					*xScale = sizeX;
				if ( yScale )
					*yScale = sizeY;
			}
			
			
			
			void update ( int objLayer, float dt );
			void render ( int objLayer, float scrollX, float scrollY );
			
		protected:
			hgeAnimation anim;
			float x, y, angle, vx, vy, vr, ax, ay, sizeX, sizeY;
	};
	
}



#endif

