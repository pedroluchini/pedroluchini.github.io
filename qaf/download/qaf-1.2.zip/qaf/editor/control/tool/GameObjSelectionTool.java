package control.tool;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.HashSet;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.GameObjSelectionSet;
import model.selection.SelectionSet;
import view.RoomPanel;
import control.HistoryManager;
import control.Main;
import control.UndoImpl;

public class GameObjSelectionTool extends ScrollTool {
	
	public final static Color  DRAGBOX_FILL_COLOR      = new Color( 255, 255, 255, 100 );
	public final static Color  DRAGBOX_OUTLINE_COLOR   = Color.WHITE;
	public final static Stroke DRAGBOX_OUTLINE_STROKE  = new BasicStroke( 3.0f );
	public final static int    DRAG_IGNORE_AREA        = 0;
	public final static Color  DRAGMOVE_OUTLINE_COLOR  = Color.RED;
	public final static Stroke DRAGMOVE_OUTLINE_STROKE = new BasicStroke( 2.0f );
	public final static int    GRIDSNAP_THRESHOLD      = 8;
	
	
	
	
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	private boolean lastPressOnSelection = false;
	private GameObj dragFocusObj = null;
	private GameObjSelectionToolBox toolBox;
	
	
	
	
	public GameObjSelectionTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super(globalEditorModel, toolBar);
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
		this.toolBox = new GameObjSelectionToolBox( globalEditorModel );
	}
	
	
	

	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getCursor();
		else
		if ( getKeyState( KeyEvent.VK_SHIFT ) )
			return Main.selectionPlusCursor;
		else
		if ( getKeyState( KeyEvent.VK_ALT ) )
			return Main.selectionMinusCursor;
		else
		if ( mouseOverGameObjSelection() || lastPressOnSelection )
			return Cursor.getPredefinedCursor( Cursor.MOVE_CURSOR );
		else
			return Main.selectionCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBox;
	}
	
	
	
	
	public String getToolDescription() {
		return "Select, copy, move, delete, and edit game objects.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/objectSelection.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Game object selection";
	}
	
	
	
	
	public void paintOverlay(Graphics g) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.paintOverlay( g );
		}
		else {
			// Paint selection overlay:
			Point lastPressPoint = getLastPressPoint();
			Point currMousePoint = getCurrMousePoint();
			
			// Dragging a new box?
			if ( !lastPressOnSelection && lastPressPoint != null && getCurrMouseButton() == MouseEvent.BUTTON1 ) {
				if ( Math.abs(lastPressPoint.x - currMousePoint.x) < DRAG_IGNORE_AREA ||
				     Math.abs(lastPressPoint.y - currMousePoint.y) < DRAG_IGNORE_AREA )
					return;
				
				int x1 = currMousePoint.x;
				int y1 = currMousePoint.y;
				int x2 = lastPressPoint.x;
				int y2 = lastPressPoint.y;
				
				if ( x2 < x1 ) {
					int tmp = x1;
					x1 = x2;
					x2 = tmp;
				}
				if ( y2 < y1 ) {
					int tmp = y1;
					y1 = y2;
					y2 = tmp;
				}
				
				// Draw a rectangle covering the area, adjusted to the tiles.
				g.setColor( DRAGBOX_FILL_COLOR );
				g.fillRect( x1, y1, (x2 - x1), (y2 - y1) );
				
				g.setColor( DRAGBOX_OUTLINE_COLOR );
				Graphics2D g2D = (Graphics2D) g;
				Stroke oldStroke = g2D.getStroke();
				g2D.setStroke( DRAGBOX_OUTLINE_STROKE );
				
				g2D.drawRect( x1, y1, (x2 - x1), (y2 - y1) );
				
				g2D.setStroke( oldStroke );
			}
			// Dragging objects?
			else
			if ( lastPressOnSelection ) {
				globalEditorModel.roomPtFromPanelPt( lastPressPoint );
				globalEditorModel.roomPtFromPanelPt( currMousePoint );
				
				int dx = currMousePoint.x - lastPressPoint.x;
				int dy = currMousePoint.y - lastPressPoint.y;
				
				// Adjust for grid snap:
				if ( toolBox.isSnapToGridEnabled() ) {
					int layerInx = globalEditorModel.getWorkingLayer();
					int dragFocusX = dragFocusObj.getX() + dx;
					int dragFocusY = dragFocusObj.getY() + dy;
					
					int gridSnappedX = getGridSnappedRoomX( dragFocusX, layerInx );
					int gridSnappedY = getGridSnappedRoomY( dragFocusY, layerInx );
					
					dx += gridSnappedX - dragFocusX;
					dy += gridSnappedY - dragFocusY;
				}
				
				// Draw object outlines:
				Stroke oldStroke = ((Graphics2D) g).getStroke();
				((Graphics2D) g).setStroke( DRAGMOVE_OUTLINE_STROKE );
				g.setColor( DRAGMOVE_OUTLINE_COLOR );
				GameObjSelectionSet selectionSet = (GameObjSelectionSet) globalEditorModel.getSelectionSet();
				for ( int i = 0; i < selectionSet.getNumOfObjs(); i++ ) {
					int objScreenX = globalEditorModel.panelXFromRoomX( selectionSet.getObj(i).getX() + dx );
					int objScreenY = globalEditorModel.panelYFromRoomY( selectionSet.getObj(i).getY() + dy );
					
					g.drawRect(
						objScreenX - RoomPanel.GAMEOBJ_MARKER_SIZE/2,
						objScreenY - RoomPanel.GAMEOBJ_MARKER_SIZE/2,
						RoomPanel.GAMEOBJ_MARKER_SIZE,
						RoomPanel.GAMEOBJ_MARKER_SIZE );
				}
				((Graphics2D) g).setStroke( oldStroke );
			}
		}
	}
	
	
	
	
	public boolean safeDispatchKeyEvent ( KeyEvent evt ) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else {
			fireCursorChangedEvent();
		}
		
		return false;
	}
	
	
	
	
	public void safeMouseDragged(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseDragged( evt );
		}
		else {
			fireRepaintEvent();
			fireStatusBarChangedEvent();
		}
	}




	public void safeMouseEntered(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}




	public void safeMouseExited(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseExited( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}




	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			fireCursorChangedEvent();
			fireStatusBarChangedEvent();
		}
	}




	public void safeMousePressed(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMousePressed( evt );
			fireCursorChangedEvent();
		}
		else if ( getCurrMouseButton() == MouseEvent.BUTTON1 ) {
			dragFocusObj = whichObjectMouseOver();
			if ( dragFocusObj != null && !mouseOverGameObjSelection() ) {
				// Add/remove/set the object as the current selection set:
				handleSelectionBoxDrag();
				fireCursorChangedEvent();
			}
			
			if ( !getKeyState( KeyEvent.VK_ALT ) && !getKeyState( KeyEvent.VK_SHIFT ) )
				lastPressOnSelection = mouseOverGameObjSelection();
			else
				lastPressOnSelection = false;
		}
	}




	public void safeMouseReleased(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseReleased( evt );
			fireCursorChangedEvent();
		}
		else {
			if ( evt.getButton() == MouseEvent.BUTTON1 ) {
				// Dragging a new box?
				if ( !lastPressOnSelection ) {
					handleSelectionBoxDrag();
				}
				else {
					// Drag the selected objects (lastPressOnSelection == true).
					Point lastPressPoint = getLastPressPoint();
					Point currMousePoint = getCurrMousePoint();
					globalEditorModel.roomPtFromPanelPt( lastPressPoint );
					globalEditorModel.roomPtFromPanelPt( currMousePoint );
					
					int dx = currMousePoint.x - lastPressPoint.x;
					int dy = currMousePoint.y - lastPressPoint.y;
					
					// Adjust for grid snap:
					if ( toolBox.isSnapToGridEnabled() ) {
						int layerInx = globalEditorModel.getWorkingLayer();
						int dragFocusX = dragFocusObj.getX() + dx;
						int dragFocusY = dragFocusObj.getY() + dy;
						
						int gridSnappedX = getGridSnappedRoomX( dragFocusX, layerInx );
						int gridSnappedY = getGridSnappedRoomY( dragFocusY, layerInx );
						
						dx += gridSnappedX - dragFocusX;
						dy += gridSnappedY - dragFocusY;
					}
					
					// Move objects:
					Main.moveSelection(
						globalEditorModel,
						toolBar,
						dx, dy );
				}
				
				fireRepaintEvent();
				fireCursorChangedEvent();
			}
		}
		
		lastPressOnSelection = false;
		dragFocusObj = null;
	}




	private GameObj whichObjectMouseOver () {
		Point currMousePoint = getCurrMousePoint();
		if ( currMousePoint == null )
			return null;
		else {
			globalEditorModel.roomPtFromPanelPt( currMousePoint );
			Room room = globalEditorModel.getLoadedRoom();
			for ( int i = 0; i < room.getNumOfObjs(); i++ ) {
				GameObj obj = room.getObj( i );
				if ( gameObjHasPoint( obj, currMousePoint.x, currMousePoint.y ) )
					return obj;
			}
			
			return null;
		}
	}
	
	
	
	
	private boolean mouseOverGameObjSelection () {
		Point currMousePoint = getCurrMousePoint();
		if ( globalEditorModel.getSelectionSet() instanceof GameObjSelectionSet &&
		     currMousePoint != null ) {
			globalEditorModel.roomPtFromPanelPt( currMousePoint );
			
			GameObjSelectionSet selectionSet = (GameObjSelectionSet) globalEditorModel.getSelectionSet();
			
			for ( int i = 0; i < selectionSet.getNumOfObjs(); i++ ) {
				GameObj obj = selectionSet.getObj( i );
				if ( gameObjHasPoint( obj, currMousePoint.x, currMousePoint.y ) ) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	
	
	
	private boolean gameObjHasPoint ( GameObj obj, int x, int y ) {
		if ( x > obj.getX() - RoomPanel.GAMEOBJ_MARKER_SIZE / globalEditorModel.getZoom() && 
		     x < obj.getX() + RoomPanel.GAMEOBJ_MARKER_SIZE / globalEditorModel.getZoom() &&
		     y > obj.getY() - RoomPanel.GAMEOBJ_MARKER_SIZE / globalEditorModel.getZoom() &&
		     y < obj.getY() + RoomPanel.GAMEOBJ_MARKER_SIZE / globalEditorModel.getZoom() )
			return true;
		else
			return false;
	}
	
	
	
	
	private void handleSelectionBoxDrag () {
		Point lastPressPoint = getLastPressPoint();
		Room room = globalEditorModel.getLoadedRoom();
		
		UndoImpl.Composite undoOp = new UndoImpl.Composite();
		
		// Defloat current selection:
		if ( globalEditorModel.isSelectionFloating() ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.defloatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			undoOp.add(
				new UndoImpl.DefloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.GAMEOBJSELECTION_TOOL_INX,
					layerInx,
					oldState,
					newState,
					selection ) );
		}
		
		// Store old state:
		SelectionSet oldSelectionSet = globalEditorModel.getSelectionSet();
		boolean oldFloating = globalEditorModel.isSelectionFloating();
		if (oldSelectionSet != null)
			oldSelectionSet = oldSelectionSet.clone();
		
		// Translate mouse points to room coords.:
		Point currMousePoint = getCurrMousePoint();
		globalEditorModel.roomPtFromPanelPt( currMousePoint );
		globalEditorModel.roomPtFromPanelPt( lastPressPoint );
		
		int x1 = lastPressPoint.x;
		int x2 = currMousePoint.x;
		int y1 = lastPressPoint.y;
		int y2 = currMousePoint.y;
		
		if ( x2 < x1 ) {
			int tmp = x1;
			x1 = x2;
			x2 = tmp;
		}
		if ( y2 < y1 ) {
			int tmp = y1;
			y1 = y2;
			y2 = tmp;
		}
		
		Rectangle selectionArea = new Rectangle( x1, y1, (x2 - x1), (y2 - y1) );
		
		HashSet<GameObj> resultingObjs = new HashSet<GameObj>();
		if ( globalEditorModel.getSelectionSet() instanceof GameObjSelectionSet ) {
			GameObjSelectionSet selectionSet = (GameObjSelectionSet) globalEditorModel.getSelectionSet();
			for ( int i = 0; i < selectionSet.getNumOfObjs(); i++ )
				resultingObjs.add( selectionSet.getObj( i ) );
		}
		
		// Which modifier key?
		if ( getKeyState( KeyEvent.VK_SHIFT ) ) {
			// Shift: Add objects to selection.
			if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
			     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
				for ( int i = 0; i < room.getNumOfObjs(); i++ ) {
					GameObj obj = room.getObj( i );
					if ( gameObjInSelectionArea( obj, selectionArea ) ) {
						resultingObjs.add( obj );
					}
				}
			}
		}
		else
		if ( getKeyState( KeyEvent.VK_ALT ) ) {
			// Alt: Remove tiles from selection.
			if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
			     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
				HashSet<GameObj> toBeRemovedObjs = new HashSet<GameObj>();
				for ( int i = 0; i < room.getNumOfObjs(); i++ ) {
					GameObj obj = room.getObj( i );
					if ( gameObjInSelectionArea( obj, selectionArea ) ) {
						toBeRemovedObjs.add( obj );
					}
				}
				
				resultingObjs.removeAll( toBeRemovedObjs );
			}
		}
		else {
			// Start new selection... or clear existing one.
			resultingObjs.clear();
			if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
			     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
				for ( int i = 0; i < room.getNumOfObjs(); i++ ) {
					GameObj obj = room.getObj( i );
					if ( gameObjInSelectionArea( obj, selectionArea ) ) {
						resultingObjs.add( obj );
					}
				}
			}
		}
		
		// Set the new set:
		if ( resultingObjs.size() == 0 )
			globalEditorModel.setSelectionSet( null, false );
		else
			globalEditorModel.setSelectionSet( new GameObjSelectionSet( resultingObjs ), false );
		
		// Commit undo operation, if the selection changed:
		SelectionSet newSelectionSet = globalEditorModel.getSelectionSet();
		if ( (oldSelectionSet != null && !oldSelectionSet.equals(newSelectionSet)) ||
		     (newSelectionSet != null && !newSelectionSet.equals(oldSelectionSet)) )
			undoOp.add(
				new UndoImpl.SelectionSetChanged(
					globalEditorModel,
					toolBar,
					ToolBar.GAMEOBJSELECTION_TOOL_INX,
					globalEditorModel.getWorkingLayer(),
					oldSelectionSet,
					globalEditorModel.getSelectionSet(),
					oldFloating,
					globalEditorModel.isSelectionFloating() ) );
		
		if ( undoOp.getCount() > 0 )
			HistoryManager.addUndoOperation(
				undoOp,
				(globalEditorModel.getSelectionSet() == null ? "select none" : "game obj. selection") );
		
	}
	
	
	
	
	private boolean gameObjInSelectionArea ( GameObj gameObj, Rectangle selectionArea ) {
		int objX = gameObj.getX();
		int objY = gameObj.getY();
		
		if ( selectionArea.width == 0 || selectionArea.height == 0 ) {
			selectionArea = new Rectangle( selectionArea );
			selectionArea.width++;
			selectionArea.height++;
		}
		
		return selectionArea.intersects(
			objX - RoomPanel.GAMEOBJ_MARKER_SIZE / globalEditorModel.getZoom(),
			objY - RoomPanel.GAMEOBJ_MARKER_SIZE / globalEditorModel.getZoom(),
			RoomPanel.GAMEOBJ_MARKER_SIZE * 2 / globalEditorModel.getZoom(),
			RoomPanel.GAMEOBJ_MARKER_SIZE * 2 / globalEditorModel.getZoom() );
	}
	
	
	
	
	public void gainedToolBarFocus () {
		// Force obstacle layer to be displayed:
		globalEditorModel.setBlockLayerVisibility( true );
	}
	
	
	
	
	private int getGridSnappedRoomX ( int roomX, int layerInx ) {
		Room room = globalEditorModel.getLoadedRoom();
		float zoom = globalEditorModel.getZoom();
		int gridW;
		if ( layerInx == -1 )
			gridW = room.getBlockSize();
		else
			gridW = room.getBGLayer(layerInx).getTileWidth();
		
		int threshold = (int) (Math.min(GRIDSNAP_THRESHOLD / zoom, gridW/2));
		
		// Get closest vertical grid lines:
		int xLeft = globalEditorModel.roomXFromTileCol( globalEditorModel.tileColFromRoomX( roomX, layerInx ), layerInx );
		int xRight = xLeft + gridW;
		
		if ( (roomX - xLeft) <= threshold )
			return xLeft;
		else
		if ( (xRight - roomX) <= threshold )
			return xRight - 1;
		else
			return roomX;
	}
	
	
	
	
	private int getGridSnappedRoomY ( int roomY, int layerInx ) {
		Room room = globalEditorModel.getLoadedRoom();
		float zoom = globalEditorModel.getZoom();
		int gridH;
		if ( layerInx == -1 )
			gridH = room.getBlockSize();
		else
			gridH = room.getBGLayer(layerInx).getTileHeight();
		
		int threshold = (int) (Math.min(GRIDSNAP_THRESHOLD / zoom, gridH/2));
		
		// Get closest vertical grid lines:
		int yTop = globalEditorModel.roomYFromTileRow( globalEditorModel.tileRowFromRoomY( roomY, layerInx ), layerInx );
		int yBot = yTop + gridH;
		
		if ( (roomY - yTop) <= threshold )
			return yTop;
		else
		if ( (yBot - roomY) <= threshold )
			return yBot - 1;
		else
			return roomY;
	}
	
}
