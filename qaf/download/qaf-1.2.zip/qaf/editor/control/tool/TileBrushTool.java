package control.tool;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.BGLayer;
import model.GlobalEditorModel;
import model.Room;
import model.TileBrushMatrix;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;
import control.HistoryManager;
import control.Main;
import control.UndoImpl;

public class TileBrushTool extends ScrollTool {
	
	public final static Color BRUSH_FILL_OVERLAY_COLOR = new Color( 255, 255, 0, 100 );
	
	
	
	
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	private Point lastRowAndCol = null;
	private int[][] oldTileMatrix = null;
	
	
	
	
	public TileBrushTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super( globalEditorModel, toolBar );
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
	}
	
	

	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getCursor();
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) )
			return Main.eyedropCursor;
		else
		if ( getCurrMouseButton() == MouseEvent.BUTTON3 )
			return Main.eraserCursor;
		else
			return Main.brushCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBar.getTileToolBox();
	}
	
	
	
	
	public String getToolDescription() {
		return "Set tiles in the current layer.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/tileBrush.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Tile brush";
	}
	
	

	
	public void paintOverlay(Graphics g) {
		Point mousePos = getCurrMousePoint();
		if ( mousePos == null )
			return;
		
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.paintOverlay( g );
		}
		else
		if ( (getKeyState( KeyEvent.VK_CONTROL ) || getCurrMouseButton() == MouseEvent.BUTTON3) ) {
			// Render single tile overlay:
			int layerInx = globalEditorModel.getWorkingLayer();
			
			int tileWidth, tileHeight;
			Room room = globalEditorModel.getLoadedRoom();
			if ( layerInx == -1 ) {
				tileWidth = tileHeight = room.getBlockSize();
			}
			else {
				BGLayer bgLayer = room.getBGLayer( layerInx );
				tileWidth = bgLayer.getTileWidth();
				tileHeight = bgLayer.getTileHeight();
			}
			tileWidth *= globalEditorModel.getZoom();
			tileHeight *= globalEditorModel.getZoom();
			
			// Calculate top-left:
			int x = globalEditorModel.panelXFromTileCol(
				globalEditorModel.tileColFromPanelX(
					mousePos.x,
					layerInx),
				layerInx );
			int y = globalEditorModel.panelYFromTileRow(
				globalEditorModel.tileRowFromPanelY(
					mousePos.y,
					layerInx),
				layerInx );
			
			g.setColor( BRUSH_FILL_OVERLAY_COLOR );
			g.fillRect( x, y, tileWidth, tileHeight );
		}
		else {
			// Render brush overlay:
			int layerInx = globalEditorModel.getWorkingLayer();
			
			int tileWidth, tileHeight;
			Room room = globalEditorModel.getLoadedRoom();
			if ( layerInx == -1 ) {
				tileWidth = tileHeight = room.getBlockSize();
			}
			else {
				BGLayer bgLayer = room.getBGLayer( layerInx );
				tileWidth = bgLayer.getTileWidth();
				tileHeight = bgLayer.getTileHeight();
			}
			tileWidth *= globalEditorModel.getZoom();
			tileHeight *= globalEditorModel.getZoom();
			
			// Adjust to center on the brush:
			TileBrushMatrix tileBrushMatrix;
			if ( layerInx == -1 )
				tileBrushMatrix = toolBar.getBlockPicker().tileBrushMatrix;
			else
				tileBrushMatrix = toolBar.getBGTilePicker( layerInx ).tileBrushMatrix;
			mousePos.x -= (tileBrushMatrix.getNumOfCols() / 2) * tileWidth;
			mousePos.y -= (tileBrushMatrix.getNumOfRows() / 2) * tileHeight;
			
			// Calculate top-left:
			int x = globalEditorModel.panelXFromTileCol(
				globalEditorModel.tileColFromPanelX(
					mousePos.x,
					layerInx),
				layerInx );
			int y = globalEditorModel.panelYFromTileRow(
				globalEditorModel.tileRowFromPanelY(
					mousePos.y,
					layerInx),
				layerInx );
			
			g.setColor( BRUSH_FILL_OVERLAY_COLOR );
			for ( int i = 0; i < tileBrushMatrix.getNumOfRows(); i++ ) {
				for ( int j = 0; j < tileBrushMatrix.getNumOfCols(); j++ ) {
					int tileID = tileBrushMatrix.getTileAtBrushCoords( i, j );
					if ( tileID != TileBrushMatrix.FREE_CELL )
						g.fillRect(
							x + j * tileWidth,
							y + i * tileHeight,
							tileWidth, tileHeight );
				}
			}
		}
	}
	
	
	
	
	public void safeMouseEntered(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseExited(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseExited( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			// Calculate cursor's row and column:
			Point currRowAndCol = getCurrMousePoint();
			if ( currRowAndCol != null ) {
				currRowAndCol.x = globalEditorModel.tileColFromPanelX( currRowAndCol.x, globalEditorModel.getWorkingLayer() );
				currRowAndCol.y = globalEditorModel.tileRowFromPanelY( currRowAndCol.y, globalEditorModel.getWorkingLayer() );
			}
			
			// Repaint if the row or column changed since the last movement:
			if ( lastRowAndCol == null && currRowAndCol != null ) {
				fireRepaintEvent();
			}
			else
			if ( lastRowAndCol != null && currRowAndCol == null ) {
				fireRepaintEvent();
			}
			else
			if ( !lastRowAndCol.equals( currRowAndCol ) ) {
				fireRepaintEvent();
			}
			
			lastRowAndCol = currRowAndCol;
			
			fireStatusBarChangedEvent();
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMousePressed ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMousePressed( evt );
			fireCursorChangedEvent();
		}
		else
		if ( getCurrMouseButton() == MouseEvent.BUTTON1 || getCurrMouseButton() == MouseEvent.BUTTON3 ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			Room room = globalEditorModel.getLoadedRoom();
			
			// Store old tile matrix:
			oldTileMatrix = Main.getLayerTileMatrix( room, layerInx );
			
			// Let mousedragged handle this:
			safeMouseDragged( evt );
		}
	}
	
	
	
	
	public void safeMouseReleased ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseReleased( evt );
			fireCursorChangedEvent();
		}
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) ) {
			final Point currRowAndCol = new Point();
			int layerInx = globalEditorModel.getWorkingLayer();
			Room room = globalEditorModel.getLoadedRoom();
			
			// Calculate current row and column:
			currRowAndCol.x = globalEditorModel.tileColFromPanelX( evt.getX(), globalEditorModel.getWorkingLayer() );
			currRowAndCol.y = globalEditorModel.tileRowFromPanelY( evt.getY(), globalEditorModel.getWorkingLayer() );
			
			// "Picked" a blank tile?
			try {
				int tileID = -1;
				if ( layerInx == -1 )
					tileID = room.getBlock( currRowAndCol.y, currRowAndCol.x );
				else
					tileID = room.getBGTile( layerInx, currRowAndCol.y, currRowAndCol.x );
				
				if ( tileID == -1 ) {
					// Switch to eraser tool:
					toolBar.setCurrentTool( ToolBar.TILEERASER_TOOL_INX );
				}
			}
			catch ( ArrayIndexOutOfBoundsException exc ) {}
		}
		else
		if ( (evt.getButton() == MouseEvent.BUTTON1 || evt.getButton() == MouseEvent.BUTTON3) ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			Room room = globalEditorModel.getLoadedRoom();
			int[][] newTileMatrix = Main.getLayerTileMatrix( room, layerInx );
			
			// Commit undo operation:
			HistoryManager.addUndoOperation(
				new UndoImpl.TileDrawing(
					globalEditorModel,
					room,
					layerInx,
					oldTileMatrix,
					newTileMatrix ),
				"tile brush" );
			
			globalEditorModel.setUnsavedChanges( true );
		}
		
		// Restore cursor:
		fireCursorChangedEvent();
	}
	
	
	
	
	public void safeMouseDragged ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseDragged( evt );
		}
		else
		if ( (getCurrMouseButton() == MouseEvent.BUTTON1 || getCurrMouseButton() == MouseEvent.BUTTON3) ) {
			final Point currRowAndCol = new Point();
			int layerInx = globalEditorModel.getWorkingLayer();
			Room room = globalEditorModel.getLoadedRoom();
			
			// Calculate current row and column:
			currRowAndCol.x = globalEditorModel.tileColFromPanelX( evt.getX(), globalEditorModel.getWorkingLayer() );
			currRowAndCol.y = globalEditorModel.tileRowFromPanelY( evt.getY(), globalEditorModel.getWorkingLayer() );
			
			TileBrushMatrix tileBrushMatrix;
			if ( layerInx == -1 )
				tileBrushMatrix = toolBar.getBlockPicker().tileBrushMatrix;
			else
				tileBrushMatrix = toolBar.getBGTilePicker( layerInx ).tileBrushMatrix;
			
			// Left click:
			if ( getCurrMouseButton() == MouseEvent.BUTTON1 ) {
				// Ctrl?
				if ( getKeyState( KeyEvent.VK_CONTROL ) ) {
					// Pick tile:
					if ( layerInx == -1 ) {
						try {
							int tileID = room.getBlock( currRowAndCol.y, currRowAndCol.x );
							if ( tileID != -1 )
								toolBar.getBlockPicker().setSelectedBlock( tileID );
						}
						catch ( ArrayIndexOutOfBoundsException exc ) {}
					}
					else {
						try {
							int tileID = room.getBGTile( layerInx, currRowAndCol.y, currRowAndCol.x );
							if ( tileID != -1 )
								toolBar.getBGTilePicker( layerInx ).setSelectedTile( tileID );
						}
						catch ( ArrayIndexOutOfBoundsException exc ) {}
					}
				}
				// No modifiers:
				else {
					// Interpolate:
					Point[] interpolation = Main.createInterpolationSequence( lastRowAndCol, currRowAndCol );
					
					// For each point in the sequence...
					for ( int iPoint = 0; iPoint < interpolation.length; iPoint++ ) {
						// Adjust to center on the brush:
						int leftCol = interpolation[iPoint].x - (tileBrushMatrix.getNumOfCols() / 2);
						int topRow  = interpolation[iPoint].y - (tileBrushMatrix.getNumOfRows() / 2);
						
						for ( int i = 0; i < tileBrushMatrix.getNumOfRows(); i++ ) {
							for ( int j = 0; j < tileBrushMatrix.getNumOfCols(); j++ ) {
								// If there's a tile selection, restrict drawn
								// tiles to the selected tiles.
								if ( globalEditorModel.getSelectionSet() instanceof BlockSelectionSet ||
								     globalEditorModel.getSelectionSet() instanceof BGTileSelectionSet ) {
									TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
									if ( selectionSet.getTileAtGlobalCoords(topRow + i, leftCol + j) == TileBrushMatrix.FREE_CELL )
										continue;
								}
								
								int tileID = tileBrushMatrix.getTileAtBrushCoords( i, j );
								if ( tileID != TileBrushMatrix.FREE_CELL ) {
									try {
										if ( layerInx == -1 )
											room.setBlock( topRow + i, leftCol + j, tileID );
										else
											room.setBGTile( layerInx, topRow + i, leftCol + j, tileID );
									}
									catch ( ArrayIndexOutOfBoundsException exc ) {}
								}
							}
						}
					}
				}
			}
			else
			// Right click:
			if ( getCurrMouseButton() == MouseEvent.BUTTON3 ) {
				// No modifiers?
				if ( !getKeyState( KeyEvent.VK_CONTROL ) ) {
				// Interpolate:
					Point[] interpolation = Main.createInterpolationSequence( lastRowAndCol, currRowAndCol );
					
					// For each point in the sequence...
					for ( int iPoint = 0; iPoint < interpolation.length; iPoint++ ) {
						// If there's a tile selection, restrict drawn
						// tiles to the selected tiles.
						if ( globalEditorModel.getSelectionSet() instanceof BlockSelectionSet ||
						     globalEditorModel.getSelectionSet() instanceof BGTileSelectionSet ) {
							TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
							if ( selectionSet.getTileAtGlobalCoords(interpolation[iPoint].y, interpolation[iPoint].x) == TileBrushMatrix.FREE_CELL )
								continue;
						}
						
						try {
							if ( layerInx == -1 )
								room.setBlock( interpolation[iPoint].y, interpolation[iPoint].x, -1 );
							else
								room.setBGTile( layerInx, interpolation[iPoint].y, interpolation[iPoint].x, -1 );
						}
						catch ( ArrayIndexOutOfBoundsException exc ) {}
					}
				}
			}
		}
		
		// Update lastRowAndCol and repaint if necessary.
		safeMouseMoved(evt);
	}
	
	
	
	
	public boolean safeDispatchKeyEvent ( KeyEvent evt ) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else {
			fireRepaintEvent();
			fireCursorChangedEvent();
		}
		
		return false;
	}
	
	
	
	
	public void setSelectedTile ( int tileID ) {
		int layerInx = globalEditorModel.getWorkingLayer();

		if ( layerInx == -1 ) {
			if ( tileID != -1 ) {
				toolBar.getBlockPicker().setSelectedBlock( tileID );
			}
		}
		else {
			if ( tileID != -1 ) {
				toolBar.getBGTilePicker( layerInx ).setSelectedTile( tileID );
			}
		}
	}
	
	
}
