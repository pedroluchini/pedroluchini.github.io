/*
 * Created on Jun 16, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package model;

import java.awt.Color;

public class ColorTile {
	
	public final static int BLEND_COLORMUL = 0x00000000;
	public final static int BLEND_COLORADD = 0x00000001;
	public final static ColorTile DEFAULT = new ColorTile();
	
	
	
	
	private int blend = 0;
	private Color[] colors = {
		Color.WHITE,
		Color.WHITE,
		Color.WHITE,
		Color.WHITE
	};
	
	
	
	
	public ColorTile () {}
	
	
	
	
	public ColorTile ( int blend, Color color0, Color color1, Color color2, Color color3 ) {
		this.blend = blend;
		this.colors[0] = color0;
		this.colors[1] = color1;
		this.colors[2] = color2;
		this.colors[3] = color3;
	}
	
	
	
	
	public ColorTile ( int blend, Color[] colors ) {
		this.blend = blend;
		this.colors[0] = colors[0];
		this.colors[1] = colors[1];
		this.colors[2] = colors[2];
		this.colors[3] = colors[3];
	}
	
	
	
	
	public ColorTile ( ColorTile that ) {
		if ( that != null ) {
			this.blend = that.blend;
			this.colors[0] = that.colors[0];
			this.colors[1] = that.colors[1];
			this.colors[2] = that.colors[2];
			this.colors[3] = that.colors[3];
		}
	}
	
	
	
	
	public int getBlend () {
		return this.blend;
	}
	
	
	
	
	public Color getColor ( int vertex ) {
		return colors[vertex];
	}
	
	
	
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof ColorTile ) {
			ColorTile that = (ColorTile) obj;
			
			if ( this.blend != that.blend )
				return false;
			if ( !this.colors[0].equals( that.colors[0]) )
				return false;
			if ( !this.colors[1].equals( that.colors[1]) )
				return false;
			if ( !this.colors[2].equals( that.colors[2]) )
				return false;
			if ( !this.colors[3].equals( that.colors[3]) )
				return false;
			
			return true;
		}
		else
			return false;
	}
	
	
	
	
	public int hashCode () {
		int hashCode = 0;
		hashCode ^= blend;
		hashCode ^= colors[0].hashCode();
		hashCode ^= colors[1].hashCode();
		hashCode ^= colors[2].hashCode();
		hashCode ^= colors[3].hashCode();
		return hashCode;
	}
	
	
	
	
	public ColorTile makeFlippedClone ( boolean horizontally, boolean vertically ) {
		ColorTile clone = new ColorTile( this.blend, this.colors );
		
		if ( horizontally ) {
			clone.colors[0] = this.colors[1];
			clone.colors[1] = this.colors[0];
			clone.colors[2] = this.colors[3];
			clone.colors[3] = this.colors[2];
		}
		if ( vertically ) {
			clone.colors[0] = this.colors[3];
			clone.colors[1] = this.colors[2];
			clone.colors[2] = this.colors[1];
			clone.colors[3] = this.colors[0];
		}
		
		return clone;
	}
	
	
	
	
	public static boolean isBlendColorAdd ( int blend ) {
		return (blend & BLEND_COLORADD ) != 0;
	}
	
	public static boolean isBlendColorMul ( int blend ) {
		return (blend & BLEND_COLORADD ) == 0;
	}
	
	
	
	
	public static boolean testEquality ( ColorTile ct1, ColorTile ct2 ) {
		if ( ct1 != null )
			return ct1.equals( ct2 );
		else
		if ( ct2 != null )
			return ct2.equals( ct1 );
		else
			return true;
	}
	
}