/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafBGLayer.h>

#include <qafEnvironment.h>


using namespace qaf;
using namespace std;

BGLayer::BGLayer ( string _sourceImagePath, int _tileWidth, int _tileHeight, float _parallaxFactorX, float _parallaxFactorY, int _translateX, int _translateY, int _rows, int _columns )
	: bgData( _rows, _columns ),
	  bgColorData( _rows, _columns ),
	  tileWidth( _tileWidth ),
	  tileHeight( _tileHeight ),
	  parallaxFactorX( _parallaxFactorX ),
	  parallaxFactorY( _parallaxFactorY )
{	
	translateX     = _translateX;
	translateY     = _translateY;
	
	// Load the tile library texture from disk:
	libTexture = Environment::loadBigTexture( _sourceImagePath.c_str() );
	
} // End of method: BGLayer::BGLayer





BGLayer::~BGLayer () {
	// Release the tile library:
	Environment::freeBigTexture( libTexture );
	
	// Delete color tile matrix:
	for ( int i = 0; i < bgColorData.rows; i++ )
		for ( int j = 0; j < bgColorData.columns; j++ )
			if ( bgColorData.cell( i, j ) )
				delete bgColorData.cell( i, j );
}



DWORD avgColor ( DWORD c1, DWORD c2 ) {
	return ARGB(
		(GETA(c1) + GETA(c2))/2,
		(GETR(c1) + GETR(c2))/2,
		(GETG(c1) + GETG(c2))/2,
		(GETB(c1) + GETB(c2))/2 );
}

void BGLayer::render ( int x, int y ) {
	// Clip hidden tiles:
	// Calculate which portions of the tile matrix are visible:
	int startRow = MAX( 0,              (int) ((-y * parallaxFactorY - translateY) / tileHeight));
	int startCol = MAX( 0,              (int) ((-x * parallaxFactorX - translateX) / tileWidth) );
	int endRow   = MIN( bgData.rows,    (int) ((-y * parallaxFactorY + Environment::getScreenHeight() - translateY) / tileHeight) + 1); // startRow + (Environment::getScreenHeight() / tileHeight) + 2 );
	int endCol   = MIN( bgData.columns, (int) ((-x * parallaxFactorX + Environment::getScreenWidth()  - translateX) / tileWidth)  + 1); // startCol + (Environment::getScreenWidth()  / tileWidth ) + 2 );
	
	// Iterate over the bgData matrix:
	for ( int i = startRow; i < endRow; i++ ) {
		for ( int j = startCol; j < endCol; j++ ) {
			int tileID = bgData.cell(i, j);
			
			// Ignore "blank tiles":
			if ( tileID != -1 ) {
				// Special masks:
				bool flipX = (tileID & QAF_TILE_FLIPPED_X_MASK ? true : false);
				bool flipY = (tileID & QAF_TILE_FLIPPED_Y_MASK ? true : false);
				bool colored = (tileID & QAF_TILE_COLORED_MASK ? true : false);
				tileID &= QAF_TILE_PURE_ID_MASK;
				
				// Calculate this tile's position in the tile library:
				int tileRow = (tileID * tileWidth) / libTexture->getImageWidth();
				int tileCol = tileID % (libTexture->getImageWidth() / tileWidth);
				
				// Calculate the four vertices' coordinates:
				int left  = (translateX + (int) (parallaxFactorX * x) + j * tileWidth);
				int top   = (translateY + (int) (parallaxFactorY * y) + i * tileHeight);
				int right = left + tileWidth;
				int bott  = top + tileHeight;
				
				// Render the tile:
				if ( colored ) {
					float texLeft  = (float) (tileCol * tileWidth)  / libTexture->getImageWidth();
					float texTop   = (float) (tileRow * tileHeight) / libTexture->getImageHeight();
					float texRight = texLeft + (float) tileWidth  / libTexture->getImageWidth();
					float texBott  = texTop  + (float) tileHeight / libTexture->getImageHeight();
					
					if ( flipX ) {
						int tmp = left;
						left = right;
						right = tmp;
					}
					if ( flipY ) {
						int tmp = top;
						top = bott;
						bott = tmp;
					}
					
					float _left  = (float) left;
					float _right = (float) right;
					float _top   = (float) top;
					float _bott  = (float) bott;
					
					// Render it as four triples:
					// +--+
					// |\/|
					// |/\|
					// +--+
					// 
					static hgeTriple t;
					t.blend = bgColorData.cell(i,j)->blend;
					t.v[0].z = t.v[1].z = t.v[2].z = t.v[3].z = 0;
					
					// Use center vertex for all four triples:
					t.v[2].col = avgColor(
									avgColor(bgColorData.cell(i,j)->colors[0], bgColorData.cell(i,j)->colors[1]),
									avgColor(bgColorData.cell(i,j)->colors[2], bgColorData.cell(i,j)->colors[3]));
					t.v[2].tx  = (texLeft + texRight)/2;
					t.v[2].ty  = (texTop + texBott)/2;
					t.v[2].x   = (_left + _right)/2;
					t.v[2].y   = (_top + _bott)/2;
					t.v[2].z   = 0;
					
					// Top:
					t.v[0].col = bgColorData.cell(i,j)->colors[0];
					t.v[0].tx  = texLeft;
					t.v[0].ty  = texTop;
					t.v[0].x   = _left;
					t.v[0].y   = _top;
					
					t.v[1].col = bgColorData.cell(i,j)->colors[1];
					t.v[1].tx  = texRight;
					t.v[1].ty  = texTop;
					t.v[1].x   = _right;
					t.v[1].y   = _top;
					
					libTexture->renderTriple( &t );
					
					// Left:
					t.v[1].col = bgColorData.cell(i,j)->colors[3];
					t.v[1].tx  = texLeft;
					t.v[1].ty  = texBott;
					t.v[1].x   = _left;
					t.v[1].y   = _bott;
					
					libTexture->renderTriple( &t );
					
					// Bottom:
					t.v[0].col = bgColorData.cell(i,j)->colors[2];
					t.v[0].tx  = texRight;
					t.v[0].ty  = texBott;
					t.v[0].x   = _right;
					t.v[0].y   = _bott;
					
					libTexture->renderTriple( &t );
					
					// Right:
					t.v[1].col = bgColorData.cell(i,j)->colors[1];
					t.v[1].tx  = texRight;
					t.v[1].ty  = texTop;
					t.v[1].x   = _right;
					t.v[1].y   = _top;
					
					libTexture->renderTriple( &t );
				}
				else {
					libTexture->renderRectangle(
						left, top,
						tileCol * tileWidth, tileRow * tileHeight,
						tileWidth, tileHeight,
						0xFFFFFFFF,
						2,
						flipX, flipY );
				}
			}
		}
	}
	
} // End of method: BGLayer::render
