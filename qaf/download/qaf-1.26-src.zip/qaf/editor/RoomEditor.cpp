#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <windows.h>

int main ( int argc, char ** argv ) {
	char szPath[512];
	GetModuleFileName( NULL, szPath, 512 );
	while ( szPath[strlen(szPath) - 1] != '\\' )
		szPath[strlen(szPath) - 1] = 0;
	
	if ( szPath[strlen(szPath) - 1] == '\\' )
		szPath[strlen(szPath) - 1] = 0;
	
	char szRoomFileName[512];
	if ( argc >= 2 )
		sprintf( szRoomFileName, "\"%s\"", argv[1] );
	else
		sprintf( szRoomFileName, " " );
	
	char cmd[1024];
	sprintf( cmd, "java -cp \"%s\" control.Main \"%s\" %s", szPath, szPath, szRoomFileName );
	
	system( cmd );
	
	return 0;
}
