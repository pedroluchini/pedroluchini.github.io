package control;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

import model.BGLayer;
import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.SelectionSet;
import control.tool.BlockPicker;

public class RoomInfoBox extends Box {
	static final long serialVersionUID = 0;
	
	
	
	
	private class RoomListener implements Room.Listener {

		public void bgTileChanged(Room src, int layerIndex, int row, int col) {}
		public void bgTileColorChanged(Room src, int layerIndex, int row, int col) {}
		public void blockChanged(Room src, int row, int col) {}
		public void gameObjSwapped(Room src, int i1, int i2) {}
		
		public void defaultObjLayerChanged(Room src) {
			ButtonModel selectedModel = defLayerBtnGroup.getSelection();
			ButtonModel defLayerModel = defLayerRadioBtns.get(src.getDefaultObjLayer()).getModel();
			
			if ( selectedModel != defLayerModel )
				defLayerBtnGroup.setSelected( defLayerModel, true );
		}
		
		public void bgLayerSwapped(Room src, int bgInx1, int bgInx2) {
			defaultObjLayerChanged(src);
		}
		
		public void bgLayerAdded(Room src, int newLayerIndex) {
			recreateDefLayerButtons();
		}
		
		public void bgLayerRemoved(Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] colorTileMatrix) {
			recreateDefLayerButtons();
		}
		
		public void waterLevelChanged(Room src) {
			validateWaterButtons();
		}
		
		public void gameObjAdded(Room src, int newIndex) {
			objCountLabel.setText( makeObjCountLabelText() );
		}
		
		public void gameObjRemoved(Room src, int oldIndex, GameObj obj) {
			objCountLabel.setText( makeObjCountLabelText() );
		}
		
	}
	
	
	
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {

		public void basePathChanged(GlobalEditorModel src) {}
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
		public void gridVisibilityChanged(GlobalEditorModel src) {}
		public void scrollChanged(GlobalEditorModel src) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		public void workingLayerChanged(GlobalEditorModel src) {}
		public void zoomChanged(GlobalEditorModel src) {}
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
		
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {
			if (oldRoom != null)
				oldRoom.removeListener(roomListener);
			
			src.getLoadedRoom().addListener( roomListener );
			
			sizeLabel.setText( makeSizeLabelText() );
			objCountLabel.setText( makeObjCountLabelText() );
			
			recreateDefLayerButtons();
			validateWaterButtons();
		}
		
	}
	
	
	
	
	private GlobalEditorModel globalEditorModel;
	private JLabel sizeLabel = new JLabel(),
	               objCountLabel = new JLabel();
	private JButton waterMinusBtn = new JButton("-"),
			        waterPlusBtn = new JButton("+");
	private Vector<JRadioButton> defLayerRadioBtns = new Vector<JRadioButton>();
	private ButtonGroup defLayerBtnGroup = new ButtonGroup();
	private Box defLayerBtnBox = Box.createHorizontalBox();
	
	private RoomListener roomListener = new RoomListener();
	private GlobalEditorModelListener globalEditorModelListener = new GlobalEditorModelListener();
	
	
	
	
	public RoomInfoBox ( GlobalEditorModel _globalEditorModel ) {
		super( BoxLayout.X_AXIS );
		
		this.globalEditorModel = _globalEditorModel;
		
		globalEditorModel.addListener( globalEditorModelListener );
		globalEditorModel.getLoadedRoom().addListener( roomListener );
		
		sizeLabel.setText( makeSizeLabelText() );
		objCountLabel.setText( makeObjCountLabelText() );
		
		waterMinusBtn.setToolTipText( "Lower water level" );
		waterMinusBtn.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				Room room = globalEditorModel.getLoadedRoom();
				
				int oldWaterLevel = room.getWaterLevel();
				room.setWaterLevel( room.getWaterLevel() + room.getBlockSize()/2 );
				int newWaterLevel = room.getWaterLevel();
				
				globalEditorModel.setUnsavedChanges( true );
				
				// Commit undo operation... or check if a water level op is
				// already in the buffer:
				if ( HistoryManager.getNextUndo() instanceof UndoImpl.WaterLevelChanged ) {
					UndoImpl.WaterLevelChanged op = (UndoImpl.WaterLevelChanged) HistoryManager.getNextUndo();
					op.setNewWaterLevel( newWaterLevel );
				}
				else {
					HistoryManager.addUndoOperation(
						new UndoImpl.WaterLevelChanged(
							globalEditorModel,
							room,
							oldWaterLevel, newWaterLevel ),
						"raise/lower water level" );
				}
			}
		} );
		
		waterPlusBtn.setToolTipText( "Raise water level" );
		waterPlusBtn.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				Room room = globalEditorModel.getLoadedRoom();
				
				int oldWaterLevel = room.getWaterLevel();
				room.setWaterLevel( room.getWaterLevel() - room.getBlockSize()/2 );
				int newWaterLevel = room.getWaterLevel();
				
				globalEditorModel.setUnsavedChanges( true );
				
				// Commit undo operation... or check if a water level op is
				// already in the buffer:
				if ( HistoryManager.getNextUndo() instanceof UndoImpl.WaterLevelChanged ) {
					UndoImpl.WaterLevelChanged op = (UndoImpl.WaterLevelChanged) HistoryManager.getNextUndo();
					op.setNewWaterLevel( newWaterLevel );
				}
				else {
					HistoryManager.addUndoOperation(
						new UndoImpl.WaterLevelChanged(
							globalEditorModel,
							room,
							oldWaterLevel, newWaterLevel ),
						"raise/lower water level" );
				}
			}
		} );
		
		recreateDefLayerButtons();
		validateWaterButtons();
		
		// Info box layout:
		//
		// +------------------------------------+
		// | Size: 1x1 screens (16x12 tiles)    |
		// | # game objects                     |
		// | Water level:        | [-] [+]      |
		// | Default Obj. layer:                |
		// | (*) 0 ( ) 1 ( ) 2                  |
		// +------------------------------------+
		//
		setAlignmentX( 0 );
		setAlignmentY( 0 );
		
		add( Box.createRigidArea( new Dimension(5, 0) ) );
		
		Box vBox = Box.createVerticalBox();
		vBox.setAlignmentX( 0 );
		vBox.setAlignmentY( 0 );
		{
			vBox.add( Box.createVerticalStrut( 5 ) );
			
			Box hBox = Box.createHorizontalBox();
			hBox.setAlignmentX( 0 );
			hBox.setAlignmentY( 0 );
			{
				hBox.add( sizeLabel );
				sizeLabel.setAlignmentX( 0 );
				sizeLabel.setAlignmentY( 0 );
			}
			vBox.add( hBox );
			
			vBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
			
			hBox = Box.createHorizontalBox();
			hBox.setAlignmentX( 0 );
			hBox.setAlignmentY( 0 );
			{
				hBox.add( objCountLabel );
				objCountLabel.setAlignmentX( 0 );
				objCountLabel.setAlignmentY( 0 );
			}
			vBox.add( hBox );
			
			vBox.add( Box.createRigidArea( new Dimension(0, 20) ) );
			
			hBox = Box.createHorizontalBox();
			hBox.setAlignmentX( 0 );
			hBox.setAlignmentY( 0 );
			{
				JLabel wlLabel = new JLabel("Water level:");
				wlLabel.setAlignmentX( 0 );
				wlLabel.setAlignmentY( 0.5f );
				hBox.add( wlLabel );
				
				hBox.add( Box.createRigidArea( new Dimension(5, 0) ) );
				
				waterMinusBtn.setAlignmentX( 0 );
				waterMinusBtn.setAlignmentY( 0.5f );
				hBox.add( waterMinusBtn );
				
				hBox.add( Box.createRigidArea( new Dimension(5, 0) ) );
				
				waterPlusBtn.setAlignmentX( 0 );
				waterPlusBtn.setAlignmentY( 0.5f );
				hBox.add( waterPlusBtn );
				
				hBox.add( Box.createRigidArea( new Dimension(5, 0) ) );
			}
			vBox.add( hBox );
			
			vBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
			JLabel dolLabel = new JLabel( "Default obj. layer:" );
			dolLabel.setAlignmentX( 0 );
			dolLabel.setAlignmentY( 0 );
			vBox.add( dolLabel );
			
			vBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
			
			defLayerBtnBox.setAlignmentX( 0 );
			defLayerBtnBox.setAlignmentY( 0 );
			vBox.add( defLayerBtnBox );
			
			vBox.add( Box.createVerticalStrut( 10 ) );
		}
		add( vBox );
		
		add( Box.createHorizontalStrut( 5 ) );
	}
	
	
	
	
	public Dimension getPreferredSize () {
		return new Dimension(
			BlockPicker.BLOCKS_PER_ROW * 32 + 1,
			super.getPreferredSize().height );
	}
	
	
	
	
	private void validateWaterButtons () {
		Room room = globalEditorModel.getLoadedRoom();
		
		if ( room.getWaterLevel() < 0 )
			waterPlusBtn.setEnabled( false );
		else
			waterPlusBtn.setEnabled( true );
		
		if ( room.getWaterLevel() > room.getPixelHeight() + 1 )
			waterMinusBtn.setEnabled( false );
		else
			waterMinusBtn.setEnabled( true );
	}
	
	
	
	
	private void recreateDefLayerButtons () {
		// Remove all buttons:
		while ( defLayerRadioBtns.size() > 0 ) {
			defLayerBtnBox.remove( defLayerRadioBtns.get(0) );
			defLayerBtnGroup.remove( defLayerRadioBtns.get(0) );
			defLayerRadioBtns.remove( 0 );
		}
		
		// Create them:
		for ( int i = 0; i <= globalEditorModel.getLoadedRoom().getNumOfBGLayers(); i++ ) {
			JRadioButton defLayerBtn = new JRadioButton( Integer.toString(i) );
			
			defLayerBtn.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					int layerInx = Integer.parseInt( evt.getActionCommand() );
					if ( layerInx != globalEditorModel.getLoadedRoom().getDefaultObjLayer() ) {
						HistoryManager.addUndoOperation(
							new UndoImpl.DefObjLayerChanged(
								globalEditorModel,
								globalEditorModel.getLoadedRoom(),
								globalEditorModel.getLoadedRoom().getDefaultObjLayer(),
								layerInx ),
							"change def. obj. layer to " + layerInx );
						
						globalEditorModel.getLoadedRoom().setDefaultObjLayer( layerInx );
						
						globalEditorModel.setUnsavedChanges( true );
					}
				}
			} );
			
			defLayerBtn.setActionCommand( Integer.toString(i) );
			
			if ( i == 0 || i < globalEditorModel.getLoadedRoom().getNumOfBGLayers() )
				defLayerBtn.setToolTipText( "Default obj. layer in front of BG layer " + i );
			else
				defLayerBtn.setToolTipText( "Default obj. layer behind BG layer " + (i - 1) );
			
			defLayerBtnBox.add( defLayerBtn );
			defLayerBtnGroup.add( defLayerBtn );
			defLayerRadioBtns.add( defLayerBtn );
			
			if ( globalEditorModel.getLoadedRoom().getDefaultObjLayer() == i )
				defLayerBtnGroup.setSelected( defLayerBtn.getModel(), true );
		}
		
		defLayerBtnBox.revalidate();
	}
	
	
	
	
	private String makeSizeLabelText () {
		Room room = globalEditorModel.getLoadedRoom();
		
		return "Room size: " + room.getRoomWidth() + "x" + room.getRoomHeight() + " screens (" + room.getPixelWidth() + "x" + room.getPixelHeight() + " pixels)";
	}
	
	
	
	
	private String makeObjCountLabelText () {
		Room room = globalEditorModel.getLoadedRoom();
		
		if ( room.getNumOfObjs() == 0 )
			return "No game objects.";
		else
		if ( room.getNumOfObjs() == 1 )
			return "1 game object.";
		else
			return room.getNumOfObjs() + " game objects";
	}

}
