package control;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class RoomFileFilter extends FileFilter {
	public String getDescription () {
		return "Qaf room files (*.QR)";
	}
	public boolean accept ( File f ) {
		if ( !f.isFile() )
			return true; // Show directories, drives, etc.
		else
			return f.getName().toLowerCase().endsWith( ".qr" );
	}
}
