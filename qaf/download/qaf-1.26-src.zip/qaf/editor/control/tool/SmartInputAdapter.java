package control.tool;

import java.awt.Component;
import java.awt.KeyEventDispatcher;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

/**
 * This is a mouse and keyboard wrapper. It serves two main purposes:
 * - Simplify the task of determing whether a key is pressed (a.k.a., the key
 *   state);
 * - Avoid overlapping mouse events (such as the user pressing two mouse
 *   buttons at the same time).
 */
public class SmartInputAdapter implements MouseListener, MouseMotionListener, KeyEventDispatcher {
	
	private class SafeEvent {
		public final static int TYPE_MOUSE_PRESSED  = 0;
		public final static int TYPE_MOUSE_RELEASED = 1;
		public final static int TYPE_KEY_PRESSED    = 2;
		public final static int TYPE_KEY_RELEASED   = 3;
		public final static int TYPE_MOUSE_ENTERED  = 4;
		public final static int TYPE_MOUSE_EXITED   = 5;
		
		private int type, param;
		private Object originator;
		
		public SafeEvent ( int type, int param, Object originator ) {
			this.type = type;
			this.param = param;
			this.originator = originator;
		}
		
		public boolean equals ( Object obj ) {
			if ( obj instanceof SafeEvent ) {
				SafeEvent evt = (SafeEvent) obj;
				return (this.type == evt.type && this.param == evt.param);
			}
			else
				return false;
		}
		
		public boolean mirrors ( Object obj ) {
			if ( obj instanceof SafeEvent ) {
				SafeEvent evt = (SafeEvent) obj;
				
				if ( this.param != evt.param )
					return false;
				else {
					switch ( this.type )  {
					case TYPE_MOUSE_PRESSED:
						return (evt.type == TYPE_MOUSE_RELEASED);
					case TYPE_MOUSE_RELEASED:
						return (evt.type == TYPE_MOUSE_PRESSED);
					case TYPE_MOUSE_ENTERED:
						return (evt.type == TYPE_MOUSE_EXITED);
					case TYPE_MOUSE_EXITED:
						return (evt.type == TYPE_MOUSE_ENTERED);
					case TYPE_KEY_PRESSED:
						return (evt.type == TYPE_KEY_RELEASED);
					case TYPE_KEY_RELEASED:
						return (evt.type == TYPE_KEY_PRESSED);
					default:
						return false;
					}
				}
			}
			else
				return false;
		}
		
		public String toString () {
			String typeStr;
			switch ( type ) {
			case TYPE_MOUSE_PRESSED:
				typeStr = "MOUSE_PRESSED";
				break;
			case TYPE_MOUSE_RELEASED:
				typeStr = "MOUSE_RELEASED";
				break;
			case TYPE_MOUSE_ENTERED:
				typeStr = "MOUSE_ENTERED";
				break;
			case TYPE_MOUSE_EXITED:
				typeStr = "MOUSE_EXITED";
				break;
			case TYPE_KEY_PRESSED:
				typeStr = "KEY_PRESSED";
				break;
			case TYPE_KEY_RELEASED:
				typeStr = "KEY_RELEASED";
				break;
			default:
				typeStr = "UNKNOWN";
				break;
			}
			return "[SafeEvent: type=" + typeStr + "; param=" + param + "]";
		}
	}
	
	
	
	
	public boolean debug = false;
	
	private Vector<SafeEvent> unprocessedEventQueue = new Vector<SafeEvent>();
	private Stack<SafeEvent> processedEventStack = new Stack<SafeEvent>();
	
	private Set<Integer> keyStates = new HashSet<Integer>();
	private Set<Integer> dummyKeyStates = new HashSet<Integer>();
	private Point lastPressPoint = null, currMousePoint = null;
	private int currMouseButton = MouseEvent.NOBUTTON;
	
	
	
	
	private boolean processEvent ( SafeEvent evt ) {
		switch ( evt.type ) {
		case SafeEvent.TYPE_KEY_PRESSED:
			// It is not allowed to press a key while holding down a mouse
			// button.
			if ( currMouseButton != MouseEvent.NOBUTTON ) {
				if (debug) System.out.println("Queued event: " + evt);
				return false;
			}
			else {
				// Multiple keypresses are allowed.
				// OK!
				processedEventStack.push( evt );
				keyStates.add( new Integer( evt.param ) );
				safeDispatchKeyEvent( (KeyEvent) evt.originator );
				if (debug) System.out.println("Processed event: " + evt);
				return true;
			}
			
		case SafeEvent.TYPE_KEY_RELEASED:
			// It is not allowed to release a key unless that key was pressed
			// last.
			if ( processedEventStack.empty() || !processedEventStack.peek().mirrors( evt ) ) {
				if (debug) System.out.println("Queued event: " + evt);
				return false;
			}
			else {
				// OK!
				processedEventStack.pop();
				keyStates.remove( new Integer( evt.param ) );
				safeDispatchKeyEvent( (KeyEvent) evt.originator );
				if (debug) System.out.println("Processed event: " + evt);
				return true;
			}
			
		case SafeEvent.TYPE_MOUSE_PRESSED:
			// It is not allowed to press a mouse button while another mouse
			// button is down.
			if ( currMouseButton != MouseEvent.NOBUTTON ) {
				if (debug) System.out.println("Queued event: " + evt);
				return false;
			}
			else {
				// OK!
				processedEventStack.push( evt );
				currMouseButton = evt.param;
				lastPressPoint = new Point( ((MouseEvent) evt.originator).getX(), ((MouseEvent) evt.originator).getY() );
				safeMousePressed( (MouseEvent) evt.originator );
				if (debug) System.out.println("Processed event: " + evt);
				return true;
			}
			
		case SafeEvent.TYPE_MOUSE_RELEASED:
			// It is not allowed to release a mouse button unless that button
			// was pressed last.
			if ( processedEventStack.empty() || !processedEventStack.peek().mirrors( evt ) ) {
				if (debug) System.out.println("Queued event: " + evt);
				return false;
			}
			else {
				// OK!
				processedEventStack.pop();
				currMouseButton = MouseEvent.NOBUTTON;
				safeMouseReleased( (MouseEvent) evt.originator );
				lastPressPoint = null;
				if (debug) System.out.println("Processed event: " + evt);
				return true;
			}
			
		case SafeEvent.TYPE_MOUSE_ENTERED:
			// It is not allowed to leave/enter when a mouse button is held
			// down.
			if ( currMouseButton != MouseEvent.NOBUTTON ) {
				if (debug) System.out.println("Queued event: " + evt);
				return false;
			}
			else {
				// OK!
				currMousePoint = new Point( ((MouseEvent) evt.originator).getX(), ((MouseEvent) evt.originator).getY() );
				safeMouseEntered( (MouseEvent) evt.originator );
				if (debug) System.out.println("Processed event: " + evt);
				return true;
			}
		
		case SafeEvent.TYPE_MOUSE_EXITED:
			// It is not allowed to leave/enter when a mouse button is held
			// down.
			if ( currMouseButton != MouseEvent.NOBUTTON ) {
				if (debug) System.out.println("Queued event: " + evt);
				return false;
			}
			else {
				// OK!
				currMousePoint = null;
				safeMouseExited( (MouseEvent) evt.originator );
				if (debug) System.out.println("Processed event: " + evt);
				return true;
			}
			
		default:
			if (debug) System.out.println("Queued event: " + evt);
			return false;
		}
	}
	
	
	
	
	private void cleanUpUnprocessedBuffer () {
		while ( !processedEventStack.empty() ) {
			// Get the top of the stack, and look for its mirror in the
			// unprocessed buffer:
			SafeEvent evt = processedEventStack.peek();
			
			boolean foundMirror = false;
			for ( int i = 0; i < unprocessedEventQueue.size(); i++ ) {
				if ( evt.mirrors( unprocessedEventQueue.get(i) ) ) { // TODO: Mouse Exited/Entered are leaving elements in the unproc. buffer 
					// Found the mirror! Process it:
					SafeEvent mirrorEvt = unprocessedEventQueue.get(i);
					if ( processEvent(mirrorEvt) )
						unprocessedEventQueue.remove( mirrorEvt );
					else
						System.out.println( "Wtf? Top of the stack's mirror couldn't be processed?" );
					
					foundMirror = true;
					break;
				}
			}
			
			// Couldn't find the mirror?
			if ( !foundMirror )
				// Nothing we can do.
				break;
		}
		
		// Unprocessed events can be processed now?
		while ( unprocessedEventQueue.size() > 0 ) {
			if ( processEvent( unprocessedEventQueue.get( 0 ) ) )
				unprocessedEventQueue.remove( 0 );
			else
				break;
		}
		
	}
	
	
	
	
	private void dispatchEvent ( SafeEvent evt ) {
		if ( processEvent( evt ) )
			cleanUpUnprocessedBuffer();
		else
			unprocessedEventQueue.add( evt );
		
		if (debug) System.out.println("proc: " + processedEventStack.size() + "; unproc: " + unprocessedEventQueue.size());
	}
	
	
	
	
	final public boolean dispatchKeyEvent(KeyEvent evt) {
		// Ignore key repeat events:
		if ( evt.getID() == KeyEvent.KEY_PRESSED && dummyKeyStates.contains( evt.getKeyCode() ) )
			return false;
		
		// Set dummy key state here, to prevent repeated key presses later:
		if ( evt.getID() == KeyEvent.KEY_PRESSED )
			dummyKeyStates.add( evt.getKeyCode() );
		else
		if ( evt.getID() == KeyEvent.KEY_RELEASED )
			dummyKeyStates.remove( evt.getKeyCode() );
		
		// Process the key event:
		int type;
		if ( evt.getID() == KeyEvent.KEY_PRESSED )
			type = SafeEvent.TYPE_KEY_PRESSED;
		else
		if ( evt.getID() == KeyEvent.KEY_RELEASED )
			type = SafeEvent.TYPE_KEY_RELEASED;
		else
			// Don't care about other types of events.
			return false;
		
		dispatchEvent( new SafeEvent( type, evt.getKeyCode(), evt ) );
		return false;
	}
	
	final public void mouseClicked(MouseEvent evt) {}
	
	final public void mouseEntered(MouseEvent evt) {
		dispatchEvent( new SafeEvent( SafeEvent.TYPE_MOUSE_ENTERED, 0, evt ) );
	}
	
	final public void mouseExited(MouseEvent evt) {
		dispatchEvent( new SafeEvent( SafeEvent.TYPE_MOUSE_EXITED, 0, evt ) );
	}
	
	final public void mousePressed(MouseEvent evt) {
		dispatchEvent( new SafeEvent( SafeEvent.TYPE_MOUSE_PRESSED, evt.getButton(), evt ) );
	}
	
	final public void mouseReleased(MouseEvent evt) {
		dispatchEvent( new SafeEvent( SafeEvent.TYPE_MOUSE_RELEASED, evt.getButton(), evt ) );
	}
	
	final public void mouseDragged(MouseEvent evt) {
		if ( currMousePoint == null )
			currMousePoint = new Point();
		currMousePoint.x = evt.getX();
		currMousePoint.y = evt.getY();
		
		safeMouseDragged(evt);
	}
	
	final public void mouseMoved(MouseEvent evt) {
		if ( currMousePoint == null )
			currMousePoint = new Point();
		currMousePoint.x = evt.getX();
		currMousePoint.y = evt.getY();
		
		safeMouseMoved(evt);
	}
	
	
	
	
	/**
	 * Returns true if the key is pressed.
	 */
	public boolean getKeyState ( int keyCode ) {
		return keyStates.contains( new Integer(keyCode) );
	}
	
	/**
	 * Returns the point where the mouse was pressed at the beginning of the
	 * drag gesture, or null if the user is not currently dragging. 
	 */
	public Point getLastPressPoint () {
		if ( lastPressPoint == null )
			return null;
		else
			return new Point(lastPressPoint);
	}
	
	/**
	 * Returns the current mouse position, or null if the cursor has left the
	 * component.
	 */
	public Point getCurrMousePoint () {
		if ( currMousePoint == null )
			return null;
		else
			return new Point(currMousePoint);
	}
	
	/**
	 * Returns the mouse button that's currently pressed.
	 */
	public int getCurrMouseButton () {
		return currMouseButton;
	}
	
	
	
	
	static public void transfer ( SmartInputAdapter from, SmartInputAdapter to, Component eventSource ) {
		if ( from == to )
			return;
		
		// Transfer the event stack:
		for ( int i = 0; i < from.processedEventStack.size(); i++ ) {
			SafeEvent evt = from.processedEventStack.firstElement();
			
			switch ( evt.type ) {
			case SafeEvent.TYPE_KEY_PRESSED:
			case SafeEvent.TYPE_KEY_RELEASED:
				to.dispatchKeyEvent( (KeyEvent) evt.originator );
				break;
				
			case SafeEvent.TYPE_MOUSE_ENTERED:
				to.mouseEntered( (MouseEvent) evt.originator );
				break;
			
			case SafeEvent.TYPE_MOUSE_EXITED:
				to.mouseExited( (MouseEvent) evt.originator );
				break;
			
			case SafeEvent.TYPE_MOUSE_PRESSED:
				to.mousePressed( (MouseEvent) evt.originator );
				break;
			
			case SafeEvent.TYPE_MOUSE_RELEASED:
				to.mouseReleased( (MouseEvent) evt.originator );
				break;
			}
		}
		
		// Transfer the unprocessed queue:
		for ( int i = 0; i < from.unprocessedEventQueue.size(); i++ ) {
			to.unprocessedEventQueue.add( from.unprocessedEventQueue.get( i ) );
		}
		
		// Keep state consistent:
		if ( to.currMousePoint == null && from.currMousePoint != null ) {
			to.mouseEntered(
				new MouseEvent(
					eventSource,
					MouseEvent.MOUSE_ENTERED,
					System.currentTimeMillis(),
					0,
					from.currMousePoint.x, from.currMousePoint.y,
					0,
					false ) );
		}
		else
		if ( to.currMousePoint != null && from.currMousePoint == null ) {
			to.mouseExited(
				new MouseEvent(
					eventSource,
					MouseEvent.MOUSE_EXITED,
					System.currentTimeMillis(),
					0,
					-1, -1,
					0,
					false ) );
		}
		else
		if ( to.currMousePoint != null && from.currMousePoint != null ) {
			to.mouseMoved(
				new MouseEvent(
					eventSource,
					MouseEvent.MOUSE_MOVED,
					System.currentTimeMillis(),
					0,
					from.currMousePoint.x, from.currMousePoint.y,
					0,
					false ) );
		}
		
		
		// Clear the "from" adapter:
		while ( !from.processedEventStack.empty() ) {
			SafeEvent evt = from.processedEventStack.peek();
			
			switch ( evt.type ) {
			case SafeEvent.TYPE_KEY_PRESSED:
				KeyEvent releasedEvent = new KeyEvent(eventSource, KeyEvent.KEY_RELEASED, System.currentTimeMillis(), 0, evt.param, (char) evt.param );
				from.dispatchKeyEvent( releasedEvent );
				break;
				
			case SafeEvent.TYPE_MOUSE_ENTERED:
				from.mouseExited( (MouseEvent) evt.originator );
				break;
			
			case SafeEvent.TYPE_MOUSE_PRESSED:
				from.mouseReleased( (MouseEvent) evt.originator );
				break;
			
			}
		}
		
		from.unprocessedEventQueue.removeAllElements();
		
		if ( from.currMousePoint != null )
			from.mouseExited(
				new MouseEvent(
					eventSource,
					MouseEvent.MOUSE_EXITED,
					System.currentTimeMillis(),
					0,
					-1, -1,
					0,
					false ) );
	}
	
	
	
	
	public boolean safeDispatchKeyEvent(KeyEvent evt) { return false; }
	public void safeMouseEntered(MouseEvent evt) {}
	public void safeMouseExited(MouseEvent evt) {}
	public void safeMousePressed(MouseEvent evt) {}
	public void safeMouseReleased(MouseEvent evt) {}
	public void safeMouseDragged(MouseEvent evt) {}
	public void safeMouseMoved(MouseEvent evt) {}
	
}
