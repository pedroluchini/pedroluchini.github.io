package control.tool;

import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.GlobalEditorModel;
import control.Main;

public class ScrollTool extends Tool {
	
	private Point lastPressPointScroll = null;
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	
	
	
	
	public ScrollTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
	}
	
	
	
	
	public void paintOverlay(Graphics g) {}
	
	
	

	public Cursor getCursor() {
		if ( getCurrMouseButton() == MouseEvent.BUTTON1 )
			return Main.dragPressCursor;
		else
			return Main.dragCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, false );
	}
	
	
	
	
	public Component getToolBox() {
		return new Container();
	}
	
	
	
	
	public String getToolDescription() {
		return "Change the room's scrolling point.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/drag.gif" );
	}
	
	
	
	
	public String getToolName() {
		return "Scroll";
	}
	
	
	
	
	public void safeMouseDragged(MouseEvent evt) {
		if ( getCurrMouseButton() == MouseEvent.BUTTON1 ) {
			Point pressPt = getLastPressPoint();
			Point currPt = getCurrMousePoint();
			
			// Convert to room coordinates:
			pressPt.x = globalEditorModel.roomXFromPanelX( pressPt.x );
			pressPt.y = globalEditorModel.roomYFromPanelY( pressPt.y );
			currPt.x = globalEditorModel.roomXFromPanelX( currPt.x );
			currPt.y = globalEditorModel.roomYFromPanelY( currPt.y );
			
			// Calculate mouse displacement relative to original scrolling:
			int dx = pressPt.x - currPt.x;
			int dy = pressPt.y - currPt.y;
			
			// Set scrolling:
			globalEditorModel.setScroll(
				lastPressPointScroll.x + dx,
				lastPressPointScroll.y + dy );
		}
		
		fireStatusBarChangedEvent();
	}
	
	
	
	
	public void safeMouseEntered(MouseEvent evt) {
		safeMouseMoved(evt);
	}
	
	
	
	
	public void safeMouseExited(MouseEvent evt) {
		fireStatusBarChangedEvent();
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		fireStatusBarChangedEvent();
	}
	
	
	
	
	public void safeMousePressed(MouseEvent evt) {
		if ( evt.getButton() == MouseEvent.BUTTON1 ) {
			if ( lastPressPointScroll == null )
				lastPressPointScroll = new Point();
			
			lastPressPointScroll.x = globalEditorModel.getScrollX();
			lastPressPointScroll.y = globalEditorModel.getScrollY();
			
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMouseReleased(MouseEvent evt) {
		lastPressPointScroll = null;
		
		fireCursorChangedEvent();
	}
	
	
	
	
	public boolean safeDispatchKeyEvent ( KeyEvent evt ) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		
		return false;
	}
	
	
	
	public void gainedToolBarFocus () {}
	
	
	
	
	public void lostToolBarFocus () {}
	
}
