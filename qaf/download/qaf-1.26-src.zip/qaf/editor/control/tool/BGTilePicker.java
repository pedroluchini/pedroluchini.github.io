package control.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.BGLayer;
import model.Room;
import model.TileBrushMatrix;
import view.RoomPanel;
import control.Main;

public class BGTilePicker extends Box implements BGLayer.Listener {
	final static long serialVersionUID = 0;
	
	public final static Color TILE_GRID_COLOR = Color.RED;
	
	
	
	
	private class TilePickerArea extends JPanel {
		static final long serialVersionUID = 0;
		
		SmartInputAdapter inputAdapter = new SmartInputAdapter() {
			public void safeMousePressed(MouseEvent evt) {
				// Calculate row, column, and tileID:
				int x = evt.getX();
				int y = evt.getY();
				
				// Flip as needed:
				if (flipXCheckBox.isSelected())
					x = bgLayer.getImage().getWidth(Main.f) - x;
				if (flipYCheckBox.isSelected() && y > 0)
					y = bgLayer.getImage().getHeight(Main.f) - y;
				
				// Ignore if click was outside the image:
				if (x > bgLayer.getImage().getWidth(Main.f) || y > bgLayer.getImage().getHeight(Main.f))
					return;
		
				// Get which tile was clicked on:
				int tileID;
				
				// Row and column clicked:
				int row = (y - 1) / bgLayer.getTileHeight();
				int col = (x - 1) / bgLayer.getTileWidth();
	
				// Rows/columns in the layer's image:
				int nColsInImg = bgLayer.getNumOfCols();
				int nRowsInImg = bgLayer.getNumOfRows();
				
				tileID = nColsInImg * row + col;
				
				// Ignore click if the selected tile is an invalid
				// value:
				if (tileID > Room.MAX_BGTILE_ID)
					return;
				
				// Flip row and/or column:
				if ( flipXCheckBox.isSelected() )
					col = nColsInImg - col - 1;
				if ( flipYCheckBox.isSelected() )
					row = nRowsInImg - row - 1;
				
				// Flip tile:
				if ( flipXCheckBox.isSelected() )
					tileID |= Room.FLIPPED_TILE_X_MASK;
				if ( flipYCheckBox.isSelected() )
					tileID |= Room.FLIPPED_TILE_Y_MASK;
				
				if ( getKeyState( KeyEvent.VK_SHIFT ) )
					// Shift: Add tiles to selection
					tileBrushMatrix.setTileAtGlobalCoords( row, col, tileID );
				else
				if ( getKeyState( KeyEvent.VK_ALT ) ) {
					// Alt: Remove tiles from selection, if the brush won't
					// become empty as a result.
					if ( tileBrushMatrix.getNumOfCols() > 1 || tileBrushMatrix.getNumOfRows() > 1 )
						tileBrushMatrix.unsetTileAtGlobalCoords( row, col );
				}
				else {
					// No modifiers: Set new brush
					tileBrushMatrix.clearBrush();
					tileBrushMatrix.setTileAtGlobalCoords( row, col, tileID );
				}
				
				// Display changes:
				repaint();
			}
			
			public void safeMouseDragged(MouseEvent evt) {
				safeMousePressed(evt);
			}
	
			public boolean safeDispatchKeyEvent(KeyEvent evt) {
				if ( getKeyState( KeyEvent.VK_SHIFT ) )
					setCursor( Main.eyedropPlusCursor );
				else
				if ( getKeyState( KeyEvent.VK_ALT ) )
					setCursor( Main.eyedropMinusCursor );
				else
					setCursor( Main.eyedropCursor );
				
				return false;
			}
		};
		
		public TilePickerArea () {
			super();
			setCursor( Main.eyedropCursor );
			
			addMouseListener( inputAdapter );
			addMouseMotionListener( inputAdapter );
			KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher( inputAdapter );
			// TODO: Remove the inputAdapter when the tilepicker is deleted. finalize?
		}
		
		public Dimension getPreferredSize () {
			Image bgImage = bgLayer.getImage();
			return new Dimension( bgImage.getWidth(Main.f) + 1, bgImage.getHeight(Main.f) + 1 );
		}
		
		public Dimension getMinimumSize () {
			return getPreferredSize();
		}
		
		public void paint ( Graphics g ) {
			int tileWidth = bgLayer.getTileWidth();
			int tileHeight = bgLayer.getTileHeight();
			
			Main.clearBGWithHatches( g, getWidth(), getHeight() );
			
			Image bgImage = bgLayer.getImage();
			int sx1 = 0, sy1 = 0, sx2 = bgImage.getWidth(this), sy2 = bgImage.getHeight(this);
			int dx1 = 0, dy1 = 0, dx2 = bgImage.getWidth(this), dy2 = bgImage.getHeight(this);
			if ( flipXCheckBox.isSelected() ) {
				int tmp = dx1;
				dx1 = dx2;
				dx2 = tmp;
			}
			if ( flipYCheckBox.isSelected() ) {
				int tmp = dy1;
				dy1 = dy2;
				dy2 = tmp;
			}
			g.drawImage( bgImage, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, this );
			
			
			Main.drawGrid(
				g,
				0, 0,
				bgLayer.getNumOfRows(), bgLayer.getNumOfCols(),
				tileWidth, tileHeight,
				Room.MAX_BGTILE_ID,
				RoomPanel.TILE_GRID_COLOR );
			
			// Tile brush overlay:
			int topRow   = tileBrushMatrix.getOrigRow();
			int bottRow  = tileBrushMatrix.getOrigRow() + tileBrushMatrix.getNumOfRows() - 1;
			int leftCol  = tileBrushMatrix.getOrigCol();
			int rightCol = tileBrushMatrix.getOrigCol() + tileBrushMatrix.getNumOfCols() - 1;
			
			g.setColor( TILE_GRID_COLOR );
			for ( int row = topRow; row <= bottRow; row++ ) {
				for ( int col = leftCol; col <= rightCol; col++ ) {
					// Ignore if a free cell is set at these coords.:
					if ( tileBrushMatrix.getTileAtGlobalCoords( row, col ) != TileBrushMatrix.FREE_CELL ) {
						// Left line, if no cell on the left:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row, col - 1 ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( tileWidth * col - 1, tileHeight * row - 1, 3, tileHeight + 2 );
						// Right line, if no cell on the right:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row, col + 1 ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( tileWidth * (col + 1) - 1, tileHeight * row - 1, 3, tileHeight + 2 );
						// Top line, if no cell above:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row - 1, col ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( tileWidth * col - 1, tileHeight * row - 1, tileWidth + 2, 3 );
						// Bottom line, if no cell below:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row + 1, col ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( tileWidth * col - 1, tileHeight * (row + 1) - 1, tileWidth + 2, 3 );
						
					}
				}
			}
		}
		
	}
	
	
	
	
	private BGLayer bgLayer;
	private TilePickerArea tilePickerArea = new TilePickerArea();
	private JCheckBox flipXCheckBox, flipYCheckBox;
	public TileBrushMatrix tileBrushMatrix;
	
	
	
	
	public BGTilePicker ( BGLayer _bgLayer ) {
		super( BoxLayout.Y_AXIS );
		setAlignmentX( 0.5f );
		setAlignmentY( 0.5f );
		
		this.bgLayer = _bgLayer;
		
		bgLayer.addListener( this );
		// TODO: Remove BGTilePicker from BGLayer listeners
		
		int[][] brushMatrix = { { 0 } };
		this.tileBrushMatrix = new TileBrushMatrix( brushMatrix, 0, 0 );
		
		// +-----------------------------+
		// |+---------------------------+|
		// ||                           ||
		// ||     TilePickerArea        ||
		// ||                           ||
		// |+---------------------------+|
		// | [ ] Flip X    [ ] Flip Y    |
		// +-----------------------------+
		
		tilePickerArea.setAlignmentX( 0.5f );
		tilePickerArea.setAlignmentY( 0.5f );
		add( new JScrollPane( tilePickerArea ) );
		
		add( Box.createVerticalStrut( 5 ) );
		
		Box hBox = Box.createHorizontalBox();
		hBox.setAlignmentX( 0.5f );
		hBox.setAlignmentY( 0.5f );
		{
			hBox.add( Box.createHorizontalStrut( 5 ) );
			
			flipXCheckBox = new JCheckBox( "Flip X" );
			flipXCheckBox.setAlignmentX( 0.5f );
			flipXCheckBox.setAlignmentY( 0.5f );
			hBox.add( flipXCheckBox );
			flipXCheckBox.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					tileBrushMatrix.flip( true, false );
					tileBrushMatrix.setOrigCol( bgLayer.getNumOfCols() - (tileBrushMatrix.getOrigCol() + tileBrushMatrix.getNumOfCols()) );
					tilePickerArea.repaint();
				}
			} );
			
			hBox.add( Box.createHorizontalStrut( 5 ) );
			
			flipYCheckBox = new JCheckBox( "Flip Y" );
			flipYCheckBox.setAlignmentX( 0.5f );
			flipYCheckBox.setAlignmentY( 0.5f );
			hBox.add( flipYCheckBox );
			flipYCheckBox.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					tileBrushMatrix.flip( false, true );
					tileBrushMatrix.setOrigRow( bgLayer.getNumOfRows() - (tileBrushMatrix.getOrigRow() + tileBrushMatrix.getNumOfRows()) );
					tilePickerArea.repaint();
				}
			} );
			
			hBox.add( Box.createHorizontalStrut( 5 ) );
		}
		hBox.setMaximumSize( new Dimension( Integer.MAX_VALUE, hBox.getPreferredSize().height ) );
		add( hBox );
		
		add( Box.createVerticalStrut( 5 ) );
	}




	public void imageChanged(BGLayer src) {
		// Reset brush
		setSelectedTile( 0 );
	}




	public void parallaxChanged(BGLayer src) {}




	public void tileSizeChanged(BGLayer src) {
		// Reset brush
		setSelectedTile( 0 );
	}




	public void translationChanged(BGLayer src) {}
	
	
	
	
	public void setSelectedTile ( int tileID ) {
		int pureTileID = tileID & Room.PURE_BGTILE_MASK;
		
		// Reset brush
		flipXCheckBox.setSelected( false );
		flipYCheckBox.setSelected( false );
		int[][] brushMatrix = { { pureTileID } };
		this.tileBrushMatrix =
			new TileBrushMatrix(
				brushMatrix,
				pureTileID / bgLayer.getNumOfCols(),
				pureTileID % bgLayer.getNumOfCols() );
		
		// Tile is flipped?
		if ( (tileID & Room.FLIPPED_TILE_X_MASK) != 0 )
			flipXCheckBox.doClick();
		if ( (tileID & Room.FLIPPED_TILE_Y_MASK) != 0 )
			flipYCheckBox.doClick();
		tilePickerArea.repaint();
	}
	
}
