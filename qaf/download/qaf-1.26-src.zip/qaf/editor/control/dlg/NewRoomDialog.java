package control.dlg;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;

import control.Main;

import model.BGLayer;
import model.GlobalEditorModel;
import model.PositiveIntegerSpinnerModel;
import model.Room;

/**
 * This is a JDialog created specifically for editing a new room's parameters.
 * The recommended strategy is to use the static method createRoom() rather
 * than creating the dialog directly. 
 */
public class NewRoomDialog extends JDialog {
	static final long serialVersionUID = 0;
	
	/** The room being created. This pointer will be set by the "OK" button's
	 * callback. */
	Room newRoom = null;
	
	Room originalRoom;
	
	// Keeping the GUI elements here lets me use them later for callbacks:
	JSpinner  blockSizeSpinner,
	          screenWidthSpinner,
	          screenHeightSpinner,
	          roomWidthSpinner,
	          roomHeightSpinner;
	JCheckBox keepBGCheckBox = new JCheckBox( "Keep background layers" );
	JButton   okButton       = new JButton( "OK" ),
	          cancelButton   = new JButton( "Cancel" );
	
	
	/**
	 * Constructor: Receives the parent Frame and the initial room parameters.
	 */
	private NewRoomDialog ( Frame parent, Room _originalRoom ) {
		// Bind the JDialog to the parent and define it as modal.
		super( parent, true );
		setResizable( false );
		
		this.originalRoom = _originalRoom;
		
		// Create spinners:
		blockSizeSpinner    = new JSpinner( new PositiveIntegerSpinnerModel( originalRoom.getBlockSize() ) );
		screenWidthSpinner  = new JSpinner( new PositiveIntegerSpinnerModel( originalRoom.getScreenWidth() ) );
		screenHeightSpinner = new JSpinner( new PositiveIntegerSpinnerModel( originalRoom.getScreenHeight() ) );
		roomWidthSpinner    = new JSpinner( new PositiveIntegerSpinnerModel( originalRoom.getRoomWidth() ) );
		roomHeightSpinner   = new JSpinner( new PositiveIntegerSpinnerModel( originalRoom.getRoomHeight() ) );
		
		// Make all spinners editable:
		((JSpinner.DefaultEditor) blockSizeSpinner.getEditor()).getTextField().setEditable( true );
		((JSpinner.DefaultEditor) screenWidthSpinner.getEditor()).getTextField().setEditable( true );
		((JSpinner.DefaultEditor) screenHeightSpinner.getEditor()).getTextField().setEditable( true );
		((JSpinner.DefaultEditor) blockSizeSpinner.getEditor()).getTextField().setEditable( true );
		((JSpinner.DefaultEditor) roomWidthSpinner.getEditor()).getTextField().setEditable( true );
		((JSpinner.DefaultEditor) roomHeightSpinner.getEditor()).getTextField().setEditable( true );
		
		// Build layout:
		//
		// +==========================================+
		// | Set the new room's dimensions. Rooms are |
		// | measured in "screens", which is the area |
		// | visible in the game's window. A screen   |
		// | is divided into "blocks," which are the  |
		// | basic elements that make up the room's   |
		// | obstacle layer.                          |
		// |                                          |
		// | Block size:    [______] pixels           |
		// | Screen width:  [______] blocks           |
		// | Screen height: [______] blocks           |
		// | Room width:    [______] screens          |
		// | Room height:   [______] screens          |
		// |                                          |
		// | [x] Keep BG layers                       |
		// |                                          |
		// |           [ OK ] [ Cancel ]              |
		// +------------------------------------------+
		//
		
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentX( 0.0f );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		theBox.add( new JLabel( "Set the new room's dimensions below. Rooms are" ) );
		theBox.add( new JLabel( "measured in \"screens,\" which is the area visible" ) );
		theBox.add( new JLabel( "in the game's window. A screen is divided into" ) );
		theBox.add( new JLabel( "\"blocks,\" which are the basic elements that make" ) );
		theBox.add( new JLabel( "up the room's obstacle layer." ) );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// DIMENSION BOX:
		Container dimensionGrid = new Container() {
			static final long serialVersionUID = 0;
			public float getAlignmentX() {
				return 0.0f;
			} };
		dimensionGrid.setLayout( new GridLayout(5, 3, 15, 5) );
		
		dimensionGrid.add( new JLabel( "Block size:" ) );
		dimensionGrid.add( blockSizeSpinner );
		dimensionGrid.add( new JLabel( "pixels" ) );
		
		dimensionGrid.add( new JLabel( "Screen width:" ) );
		dimensionGrid.add( screenWidthSpinner );
		dimensionGrid.add( new JLabel( "blocks" ) );
		
		dimensionGrid.add( new JLabel( "Screen height:" ) );
		dimensionGrid.add( screenHeightSpinner );
		dimensionGrid.add( new JLabel( "blocks" ) );
		
		dimensionGrid.add( new JLabel( "Room width:" ) );
		dimensionGrid.add( roomWidthSpinner );
		dimensionGrid.add( new JLabel( "screens" ) );
		
		dimensionGrid.add( new JLabel( "Room height:" ) );
		dimensionGrid.add( roomHeightSpinner );
		dimensionGrid.add( new JLabel( "screens" ) );
		
		theBox.add( dimensionGrid );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		keepBGCheckBox.setSelected( true );
		theBox.add( keepBGCheckBox );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		theBox.add( new JSeparator() );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// Buttons:
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.0f );
		buttonBox.add( Box.createHorizontalGlue() );
		
		okButton.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				// Create new room:
				int blockSize    = ((Integer) blockSizeSpinner.getValue()).intValue();
				int screenWidth  = ((Integer) screenWidthSpinner.getValue()).intValue();
				int screenHeight = ((Integer) screenHeightSpinner.getValue()).intValue();
				int roomWidth    = ((Integer) roomWidthSpinner.getValue()).intValue();
				int roomHeight   = ((Integer) roomHeightSpinner.getValue()).intValue();
				newRoom =
					new Room(
						blockSize,
						screenWidth,
						screenHeight,
						roomWidth,
						roomHeight,
						roomHeight * screenHeight * blockSize + blockSize/2 );
				
				// Copy BG layers from currently loaded room?
				if ( keepBGCheckBox.isSelected() ) {
					for ( int i = 0; i < originalRoom.getNumOfBGLayers(); i++ ) {
						BGLayer oldBGLayer = originalRoom.getBGLayer( i );
						BGLayer newBGLayer = 
							new BGLayer(
								oldBGLayer.getImage(),
								oldBGLayer.getImageFileName(),
								oldBGLayer.getTileWidth(),
								oldBGLayer.getTileHeight(),
								oldBGLayer.getParallaxX(),
								oldBGLayer.getParallaxY(),
								oldBGLayer.getTranslationX(),
								oldBGLayer.getTranslationY() );
						newRoom.addBGLayer( newBGLayer );
					}
				}
				
				// Keep def. obj layer:
				newRoom.setDefaultObjLayer( originalRoom.getDefaultObjLayer() );
				
				// Close the dialog:
				dispose();
			} } );
		buttonBox.add( okButton );
		
		buttonBox.add( Box.createRigidArea( new Dimension(20, 0) ) );
		
		cancelButton.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				newRoom = null;
				dispose();
			} } );
		buttonBox.add( cancelButton );
		
		buttonBox.add( Box.createHorizontalGlue() );
		
		theBox.add( buttonBox );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		Box fillerBox = Box.createHorizontalBox();
		fillerBox.setAlignmentY( 0.0f );
		fillerBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		fillerBox.add( theBox );
		fillerBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		
		getContentPane().add( fillerBox );
		
		// Layout done!
		
		// Set "OK" as the default button:
		getRootPane().setDefaultButton( okButton );
				
		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
		Action escapeAction = new AbstractAction() {
			static final long serialVersionUID = 0;
			public void actionPerformed(ActionEvent e) {
				cancelButton.doClick();
			} };
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", escapeAction);
	}
	
	
	
	/**
	 * Pops up a dialog, asking the user to enter the parameters for a new
	 * room. Returns false if, for whatever reason, the operation ddn't conclude.
	 */
	public static boolean newRoom ( GlobalEditorModel globalEditorModel ) {
		// Dialog:
		NewRoomDialog dlg = new NewRoomDialog(
			Main.f,
			globalEditorModel.getLoadedRoom() );
		dlg.setTitle( "New room" );
		dlg.setLocationRelativeTo( null ); // Center on screen
		dlg.pack();
		dlg.setVisible( true );
		
		// If the user canceled, the "newRoom" field will be set to null. 
		if ( dlg.newRoom != null ) {
			globalEditorModel.setLoadedRoom( dlg.newRoom, null );
			globalEditorModel.setWorkingLayer( -1 );
			
			return true;
		}
		else
			return false;
	}
	
}
