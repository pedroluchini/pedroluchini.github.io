/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafutil/qafHgeInputStream.h>

#include <hge.h>

using namespace qaf;


HgeInputStream::HgeInputStream ( const char * filename ) {
	data = NULL;
	size = 0;
	filePointer = 0;
	
	// Load the data using HGE:
	HGE * hge = hgeCreate( HGE_VERSION );
	DWORD resourceSize;
	data = (unsigned char *) hge->Resource_Load( (char *) filename, &resourceSize );
	size = resourceSize;
	hge->Release();
}




HgeInputStream::~HgeInputStream () {
	// Free the resource data if it was loaded:
	if ( data ) {
		HGE * hge = hgeCreate( HGE_VERSION );
		hge->Resource_Free( data );
		hge->Release();
	}
}




bool HgeInputStream::canRead () {
	return (data != NULL && filePointer < size );
}




int HgeInputStream::getSize () {
	return size;
}




long HgeInputStream::tell () {
	return filePointer;
}




int HgeInputStream::seek ( long offset, int whence ) {
	if ( whence == SEEK_SET ) {
		if ( offset < 0 || offset > size )
			return -1;
		
		filePointer = offset;
		return 0;
	}
	else if ( whence == SEEK_END ) {
		if ( offset > 0 || offset < -size )
			return -1;
		
		filePointer = size + offset;
		return 0;
	}
	else if ( whence == SEEK_CUR ) {
		long newPos = filePointer + offset;
		if ( newPos < 0 || newPos > size )
			return -1;
		
		filePointer = newPos;
		return 0;
	}
	else
		return -1;
}




int HgeInputStream::getC () {
	// End of file?
	if ( filePointer >= size )
		return -1;
	else {
		int nextC = data[filePointer];
		
		// Increment file pointer:
		filePointer++;
		
		return nextC;
	}
}




int HgeInputStream::read ( void * buffer, long itemSize, long itemCount ) {
	int itemsRead = 0;
	
	while ( itemsRead < itemCount ) {
		// Not enough bytes in the stream to read?
		if ( (size - filePointer) < itemSize ) {
			break;
		}
		
		// Read 'em:
		for ( int i = 0; i < itemSize; i++ ) {
			((unsigned char *) buffer)[itemsRead*itemSize + i] = (unsigned char) getC();
		}
		
		itemsRead++;
	}
	
	return itemsRead;
}




int HgeInputStream::skipWhiteSpace () {
	int iBytesSkipped = 0;
	
	while ( filePointer < size && 
	        (data[filePointer] == ' '  ||
	         data[filePointer] == '\t' ||
	         data[filePointer] == '\n' ||
	         data[filePointer] == '\r') ) {
		iBytesSkipped++;
		filePointer++;
	}
	
	return iBytesSkipped;
}
