package control;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.RoomIO;
import model.TileBrushMatrix;
import model.selection.BGTileColorSelectionSet;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;
import model.selection.GameObjSelectionSet;
import model.selection.SelectionSet;
import view.MainFrame;
import control.dlg.OpenRoomDialog;
import control.tool.ToolBar;

public class Main {
	
	public static float QAF_VERSION = 1.2f;
	
	public static JFrame f = new JFrame("Room Editor");
	public static Cursor brushCursor, dragCursor, dragPressCursor, eraserCursor, eyedropCursor, eyedropPlusCursor, eyedropMinusCursor, fillCursor, selectionCursor, selectionMinusCursor, selectionPlusCursor, wandCursor, wandMinusCursor, wandPlusCursor;
	public static String qafPath;
	
	
	
	
	public static void main ( String[] args ) {
		// I need this to create images and such.
		f.pack();
		f.setVisible( true );
		
		if ( args.length == 0 )
			qafPath = "." + File.separator;
		else
			qafPath = args[0] + File.separator;
		
		// Enable dynamic layout (prevents Swing's "grey fog" during window
		// resizing):
		Toolkit.getDefaultToolkit().setDynamicLayout( true );
		
		// Set default platform look and feel:
		try {
			UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName() );
		}
		catch ( UnsupportedLookAndFeelException exc ) {}
		catch ( ClassNotFoundException exc ) {}
		catch ( IllegalAccessException exc ) {}
		catch ( InstantiationException exc ) {}
		
		// Create cursors:
		Image brushCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/brush.gif");
		if ( brushCursorImg != null )
			brushCursor = Toolkit.getDefaultToolkit().createCustomCursor( brushCursorImg, new Point(16, 16), "brush cursor" );
		if ( brushCursor == null )
			brushCursor = Cursor.getDefaultCursor();
		
		Image dragCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/drag.gif");
		if ( dragCursorImg != null )
			dragCursor = Toolkit.getDefaultToolkit().createCustomCursor( dragCursorImg, new Point(10, 10), "drag cursor" );
		if ( dragCursor == null )
			dragCursor = Cursor.getDefaultCursor();
		
		Image dragPressCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/dragPress.gif");
		if ( dragPressCursorImg != null )
			dragPressCursor = Toolkit.getDefaultToolkit().createCustomCursor( dragPressCursorImg, new Point(10, 10), "drag press cursor" );
		if ( dragPressCursor == null )
			dragPressCursor = Cursor.getDefaultCursor();
		
		Image eraserCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eraser.gif");
		if ( eraserCursorImg != null )
			eraserCursor = Toolkit.getDefaultToolkit().createCustomCursor( eraserCursorImg, new Point(16, 16), "erasercursor" );
		if ( eraserCursor == null )
			eraserCursor = Cursor.getDefaultCursor();
		
		Image eyedropCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eyedrop.gif");
		if ( eyedropCursorImg != null )
			eyedropCursor = Toolkit.getDefaultToolkit().createCustomCursor( eyedropCursorImg, new Point(8, 22), "eyedrop cursor" );
		if ( eyedropCursor == null )
			eyedropCursor = Cursor.getDefaultCursor();
		
		Image eyedropPlusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eyedropPlus.gif");
		if ( eyedropPlusCursorImg != null )
			eyedropPlusCursor = Toolkit.getDefaultToolkit().createCustomCursor( eyedropPlusCursorImg, new Point(8, 22), "eyedropPlus cursor" );
		if ( eyedropPlusCursor == null )
			eyedropPlusCursor = Cursor.getDefaultCursor();
		
		Image eyedropMinusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eyedropMinus.gif");
		if ( eyedropMinusCursorImg != null )
			eyedropMinusCursor = Toolkit.getDefaultToolkit().createCustomCursor( eyedropMinusCursorImg, new Point(8, 22), "eyedropMinus cursor" );
		if ( eyedropMinusCursor == null )
			eyedropMinusCursor = Cursor.getDefaultCursor();
		
		Image fillCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/fill.gif");
		if ( fillCursorImg != null )
			fillCursor = Toolkit.getDefaultToolkit().createCustomCursor( fillCursorImg, new Point(6, 24), "fill cursor" );
		if ( fillCursor == null )
			fillCursor = Cursor.getDefaultCursor();
		
		Image selectionCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/selection.gif");
		if ( selectionCursorImg != null )
			selectionCursor = Toolkit.getDefaultToolkit().createCustomCursor( selectionCursorImg, new Point(15, 15), "selection cursor" );
		if ( selectionCursor == null )
			selectionCursor = Cursor.getDefaultCursor();
		
		Image selectionMinusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/selectionMinus.gif");
		if ( selectionMinusCursorImg != null )
			selectionMinusCursor = Toolkit.getDefaultToolkit().createCustomCursor( selectionMinusCursorImg, new Point(15, 15), "selectionMinus cursor" );
		if ( selectionMinusCursor == null )
			selectionMinusCursor = Cursor.getDefaultCursor();
		
		Image selectionPlusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/selectionPlus.gif");
		if ( selectionPlusCursorImg != null )
			selectionPlusCursor = Toolkit.getDefaultToolkit().createCustomCursor( selectionPlusCursorImg, new Point(15, 15), "selectionPlus cursor" );
		if ( selectionPlusCursor == null )
			selectionPlusCursor = Cursor.getDefaultCursor();
		
		Image wandCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/wand.gif");
		if ( wandCursorImg != null )
			wandCursor = Toolkit.getDefaultToolkit().createCustomCursor( wandCursorImg, new Point(15, 14), "wand cursor" );
		if ( wandCursor == null )
			wandCursor = Cursor.getDefaultCursor();
		
		Image wandMinusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/wandMinus.gif");
		if ( wandMinusCursorImg != null )
			wandMinusCursor = Toolkit.getDefaultToolkit().createCustomCursor( wandMinusCursorImg, new Point(15, 14), "wandMinus cursor" );
		if ( wandMinusCursor == null )
			wandMinusCursor = Cursor.getDefaultCursor();
		
		Image wandPlusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/wandPlus.gif");
		if ( wandPlusCursorImg != null )
			wandPlusCursor = Toolkit.getDefaultToolkit().createCustomCursor( wandPlusCursorImg, new Point(15, 14), "wandPlus cursor" );
		if ( wandPlusCursor == null )
			wandPlusCursor = Cursor.getDefaultCursor();
		
		// The basePath is important for determining relative paths. It will be
		// kept in a file and read every time the application starts.
		String basePath = null;
		try {
			BufferedReader fh = new BufferedReader(
				new InputStreamReader(
					new FileInputStream(qafPath + "basePath.txt") ) );
			
			basePath = fh.readLine();
			fh.close();
			
			if ( ! new File( basePath ).isDirectory() )
				throw new FileNotFoundException();			
		}
		catch ( FileNotFoundException exc ) {
			// Could not open file! That must mean the basePath has not been
			// set yet.
			// Canceling is not an option!
			basePath = promptForBasePath( null, false );
		}
		catch ( IOException exc ) {
			JOptionPane.showMessageDialog(
					f,                        // parent dialog
					"Could not read the base path from \"basePath.txt\".", // message
					"Error",                  // title
					JOptionPane.ERROR_MESSAGE // message type
				);
			System.exit( -1 );
		}
		
		// Create the frame:
		GlobalEditorModel globalEditorModel =
			new GlobalEditorModel(
				new Room( 32, 20, 15, 1, 1, 480 + 16 ),
				null,
				basePath );
		MainFrame mf =
			new MainFrame(
				globalEditorModel );
		mf.pack();
		mf.setVisible( true );
		
		// Don't need the dummy frame anymore:
		f.dispose();
		f = mf;
		
		// Load a room from command line:
		if ( args.length > 1 )
			OpenRoomDialog.openRoom( globalEditorModel, new File(args[1]) );
	}
	
	
	
	
	/**
	 * Tests the unsavedChanges variable. If it is true, performs the usual
	 * routine of "Do you want to save" before unloading the room. If the user 
	 * cancels at any point, the method will return false; otherwise it will
	 * save the room and return true.
	 */
	public static boolean checkUnsavedChanges ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		if ( globalEditorModel.hasUnsavedChanges() ) {
			// Ask the user if he wants to save
			String[] message = {
				"You have made changes to this room since",
				"the last time you saved. Would you like to",
				"save now?" }; 
			int option = JOptionPane.showConfirmDialog(
				Main.f,                           // parent dialog
				message,                          // message
				"Unsaved changes",                // title
				JOptionPane.YES_NO_CANCEL_OPTION, // option type
				JOptionPane.WARNING_MESSAGE );    // message type
	
			if ( option == JOptionPane.CANCEL_OPTION )
				//User canceled: Bail out
				return false;
			else if ( option == JOptionPane.YES_OPTION ) {
				// User chose to save:
				// he may still cancel if the loaded room had no filename.
				return saveRoom( globalEditorModel, toolBar );
			}
			else
				// User chose not to save:
				return true;
		}
		else
			return true;
	}
	
	
	
	
	/**
	 * Saves the currently loaded room to the path specified in
	 * loadedRoomFilename, or redirects to saveAs if the filename is null.
	 * 
	 * Returns false if the user canceled, or true if the room was saved.
	 */
	public static boolean saveRoom ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		// Defloat selection:
		if ( globalEditorModel.isSelectionFloating() ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.defloatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			HistoryManager.addUndoOperation(
				new UndoImpl.DefloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
					layerInx,
					oldState,
					newState,
					selection ),
				"defloat selection");
		}
		
		if ( globalEditorModel.getLoadedRoomFileName() == null )
			return saveRoomAs( globalEditorModel, toolBar );
		else {
			try {
				RoomIO.writeRoom(
					globalEditorModel.getLoadedRoom(),
					globalEditorModel.getLoadedRoomFileName() );
				
				globalEditorModel.setUnsavedChanges( false );
				return true;
			}
			catch ( IOException exc ) {
				String[] message = {
					"Could not write to file:",
					globalEditorModel.getLoadedRoomFileName() };
					
				JOptionPane.showMessageDialog(
					f,                           // parent dialog
					message,                    // message
					"Error",                     // title
					JOptionPane.ERROR_MESSAGE ); // message type
				
				return false;
			}
		}
	}
	
	
	
	
	/**
	 * Prompts the user for a filename, and writes the room data to it.
	 * 
	 * Returns false if the user canceled, or true if the room was saved.
	 */
	public static boolean saveRoomAs ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		// Defloat selection:
		if ( globalEditorModel.isSelectionFloating() ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.defloatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			HistoryManager.addUndoOperation(
				new UndoImpl.DefloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
					layerInx,
					oldState,
					newState,
					selection ),
				"defloat selection");
		}
		
		while ( true ) {
			JFileChooser fDlg = new JFileChooser();
			fDlg.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fDlg.setFileFilter( new RoomFileFilter() );
			if ( globalEditorModel.getLoadedRoomFileName() != null )
				fDlg.setCurrentDirectory( new File( globalEditorModel.getLoadedRoomFileName() ).getParentFile() );
			else
				fDlg.setCurrentDirectory( new File( globalEditorModel.getBasePath() ) );
			
			// Show dialog and test whether the user has canceled
			if ( fDlg.showSaveDialog( f ) != JFileChooser.APPROVE_OPTION )
				return false;
			else {
				String filename = Main.getCanonicalPath( fDlg.getSelectedFile() );
				
				// Is this a valid path?
				if ( !globalEditorModel.isInBasePath( filename ) ) {
					String[] message = {
						"The file path you chose is not contained in the base path",
						"or one of its subdirectories. The base path is",
						" ",
						globalEditorModel.getBasePath() };
					JOptionPane.showMessageDialog(
						f,                           // parent dialog
						message,                     // message
						"Error",                     // title
						JOptionPane.ERROR_MESSAGE ); // message type
				}
				else {
					// Append "qr" extension?
					if ( !filename.endsWith( ".qr" ) )
						filename += ".qr";
					
					// If the selected file already exists, ask for
					// confirmation:
					if ( new File( filename ).exists() ) {
						String[] message = {
							"The selected file already exists.",
							"Overwrite it?" };
						
						int option = JOptionPane.showConfirmDialog(
							Main.f,                         // parent dialog
							message,                        // message
							"Saved room",                   // title
							JOptionPane.YES_NO_OPTION,      // option type
							JOptionPane.QUESTION_MESSAGE ); // message type
						
						if ( option == JOptionPane.NO_OPTION )
							// Show the file chooser again!
							continue;
					}
					
					Room loadedRoom = globalEditorModel.getLoadedRoom();
					String loadedRoomFileName = globalEditorModel.getLoadedRoomFileName();
					try {
						RoomIO.writeRoom( loadedRoom, loadedRoomFileName );
				
						globalEditorModel.setLoadedRoom( loadedRoom, loadedRoomFileName );
						
						globalEditorModel.setUnsavedChanges( false );
						
						return true;
					}
					catch ( IOException exc ) {
						JOptionPane.showMessageDialog(
							f,                           // parent dialog
							"Could not write to file: " + loadedRoomFileName , // message
							"Error",                     // title
							JOptionPane.ERROR_MESSAGE ); // message type
						
						return false;
					}
				}
			}
		}
	}
	
	
	
	
	
	/**
	 * Auxiliary method: Opens an image and waits for it to load using a
	 * MediaTracker.
	 * 
	 * Filename is NOT relative to the base path.
	 */
	public static Image createImage ( String filename ) {
		Image data = Toolkit.getDefaultToolkit().createImage( filename );
		
		// Wait for image to load:
		MediaTracker mediaTracker = new MediaTracker( f );
		mediaTracker.addImage( data, 0 );
		try {
			mediaTracker.waitForID( 0 );
		}
		catch ( InterruptedException ie ) {
			ie.printStackTrace();
		}
		
		return data;
	}
	
	
	
	
	/**
	 * This is an auxiliary method to get the canonical path without going
	 * through all the hassle of handling IOExceptions. It will return the 
	 * absolute pathname if the canonical query fails.
	 */
	public static String getCanonicalPath ( File file ) {
		try {
			return file.getCanonicalPath();
		}
		catch ( IOException exc ) {
			return file.getAbsolutePath();
		}
	}
	
	public static String getCanonicalPath ( String file ) {
		return getCanonicalPath( new File( file ) );
	}
	
	
	
	
	/**
	 * Pops up a warning to explain what the base path is and asks the user to
	 * input a path. The "cancelOption" flag indicates whether the dialog will
	 * contain a "Cancel" button.
	 * 
	 * This will return the path in its canonical form.
	 */
	public static String promptForBasePath ( String oldBasePath, boolean cancelOption) {
		String[] message = {
			"The \"base path\" is equivalent to the game's working directory.",
			"This editor uses it to determine relative paths between rooms",
			"and the image files that compose their background layers.",
			" ",
			"Every room you create and every BG image you use will",
			"be required to be inside the base path or its subdirectories." };
		
		final JDialog dlg = new JDialog( f, "Base path", true ); // modal dialog
		dlg.setDefaultCloseOperation( JDialog.DO_NOTHING_ON_CLOSE );
				
		final JTextField txtField = new JTextField( 30 );
		final String[] oldBasePathA = { oldBasePath };
		oldBasePathA[0] = oldBasePath;
		
		if ( oldBasePath != null )
			txtField.setText( oldBasePath );
		else
			txtField.setText( "Choose a directory" );
		
		txtField.select( 0, txtField.getText().length() );
		
		JButton browseButton = new JButton( "Browse..." );
		browseButton.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					JFileChooser fDlg = new JFileChooser();
					fDlg.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					if ( oldBasePathA[0] != null ) 
						fDlg.setCurrentDirectory( new File( oldBasePathA[0] ) );
					
					// Show dialog and test whether the user has canceled
					if ( fDlg.showOpenDialog( f ) == JFileChooser.APPROVE_OPTION &&
					     fDlg.getSelectedFile()   != null )
						txtField.setText( getCanonicalPath( fDlg.getSelectedFile() ) );
				}
			} );
		
		Box txtBrowseBox = Box.createHorizontalBox();
		txtBrowseBox.setAlignmentX( 0.5f );
		txtBrowseBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		txtBrowseBox.add( txtField );
		txtBrowseBox.add( browseButton );
		txtBrowseBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		
		final JButton okButton = new JButton( "OK" );
		okButton.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					// Must be a valid directory!
					if ( new File( txtField.getText() ).isDirectory() ) 
						dlg.dispose();
					else {
						JOptionPane.showMessageDialog(
							dlg,                                   // parent dialog
							"You must specify a valid directory.", // message
							"Error",                               // title
							JOptionPane.ERROR_MESSAGE              // message type
						);
					}
			} } );
		
		final JButton cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				txtField.setText( "" );
				dlg.dispose();
			} } );
		
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.5f );
		buttonBox.add( okButton );
		if ( cancelOption ) {
			buttonBox.add( Box.createRigidArea( new Dimension(15, 0) ) );
			buttonBox.add( cancelButton );
			
			// Handle escape key to close the dialog
			KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
			Action escapeAction = new AbstractAction() {
				static final long serialVersionUID = 0;
				public void actionPerformed(ActionEvent e) {
					cancelButton.doClick();
				} };
			dlg.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
			dlg.getRootPane().getActionMap().put("ESCAPE", escapeAction);
		}
		
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY( 0.0f );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		for ( int i = 0; i < message.length; i++ ) {
			Box b = Box.createHorizontalBox();
			b.setAlignmentX( 0.5f );
			b.add( new JLabel( message[i] ) );
			theBox.add( b );
		}
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		theBox.add( txtBrowseBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		theBox.add( buttonBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		dlg.getContentPane().add( theBox );
		dlg.getRootPane().setDefaultButton( okButton );
		dlg.setResizable( false );
		dlg.pack();
		dlg.setLocationRelativeTo( null ); // Center on screen
		
		// Show the dialog and wait for user input:
		dlg.setVisible( true );
		
		// User canceled?
		if ( txtField.getText().equals("") )
			return null;
		else
			return getCanonicalPath( txtField.getText() );
	}
	
	
	
	
	/**
	 * Shows a dialog with the message "The path you chose is not contained in
	 * the base path".
	 */
	public static void showNotInBasePathDialog ( Component parent, String basePath ) {
		String[] message = {
			"The file you chose is not contained in the base path",
			"or one of its subdirectories. The base path is",
			" ",
			basePath };
		JOptionPane.showMessageDialog(
			parent,                      // parent dialog
			message,                     // message
			"Error",                     // title
			JOptionPane.ERROR_MESSAGE ); // message type
	}
	
	
	
	
	/**
	 * Auxiliary method: Copies a section of a matrix onto another.
	 */
	public static void blitMatrix ( int[][] dest, int[][] src, int destRow, int destCol ) {
		for ( int i = 0; i < src.length; i++ )
			for ( int j = 0; j < src[i].length; j++ )
				try {
					dest[i + destRow][j + destCol] = src[i][j];
				}
				catch ( ArrayIndexOutOfBoundsException exc ) {}
	}
	
	public static void blitMatrix ( ColorTile[][] dest, ColorTile[][] src, int destRow, int destCol ) {
		for ( int i = 0; i < src.length; i++ )
			for ( int j = 0; j < src[i].length; j++ )
				try {
					dest[i + destRow][j + destCol] = src[i][j];
				}
				catch ( ArrayIndexOutOfBoundsException exc ) {}
	}
	
	
	
	
	/**
	 * Fills a Graphics area with black-on-gray hatches.
	 */
	public static void clearBGWithHatches ( Graphics g, int width, int height ) {
		g.setColor( Color.GRAY );
		g.fillRect( 0, 0, width, height );
		
		g.setColor( Color.BLACK );
		for ( int i = 0; i < Math.max(width, height); i += 3 ) {
			g.drawLine( i, 0, i + height, height );
			g.drawLine( -i, 0, -i + height, height );
		}
	}
	
	
	
	
	/**
	 * Fills a Graphics area with grey checkered patterns.
	 */
	public static void clearBGWithCheckers ( Graphics g, int width, int height ) {
		g.setColor( Color.GRAY );
		g.fillRect( 0, 0, width, height );
		
		final int CHECKERED_SIZE = 10;
		
		g.setColor( Color.DARK_GRAY );
		for ( int x = 0; x < width; x += CHECKERED_SIZE ) {
			int y = 0;
			if ( x % (CHECKERED_SIZE*2) != 0 )
				y += CHECKERED_SIZE;
			for ( ; y < height; y += CHECKERED_SIZE*2 )
				g.fillRect( x, y, CHECKERED_SIZE, CHECKERED_SIZE );
		}
	}
	
	
	
	
	/**
	 * Draws a grid with up to maxCount blocks onto the specified Graphics
	 * object, with its top-left corner at coordinates (x, y).
	 */
	public static void drawGrid ( Graphics g, float x, float y, int rows, int cols, float gridWidth, float gridHeight, int maxCount, Color c ) {
		g.setColor( c );
		int count = 0;
		int i = 0, j = 0;
		
		ROW_LOOP: for ( i = 0; i < rows; i++ ) {
			for ( j = 0; j < cols; j++ ) {
				count++;
				if ( count > maxCount )
					break ROW_LOOP;
				
				float left   = x + j * gridWidth,
				      right  = left + gridWidth,
				      top    = y + i * gridHeight,
				      bottom = top + gridHeight;
				// Draw lines below and on the right of the tile:
				g.drawLine( Math.round(left) + 1, Math.round(bottom),  Math.round(right), Math.round(bottom) );
				g.drawLine( Math.round(right),    Math.round(top) + 1, Math.round(right), Math.round(bottom) - 1 );
			}
		}
		
		// Finish the grid with lines above and on the left of the whole grid:
		int colsDrawn = (i > 0         ? cols : j);
		int rowsDrawn = ((cols != 0 ? j % cols : 0) == 0 ? i    : i + 1);
		float left   = x,
		      right  = left + gridWidth * colsDrawn,
		      top    = y,
		      bottom = top + gridHeight * rowsDrawn; 
		g.drawLine( Math.round(left), Math.round(top),     Math.round(right), Math.round(top) );
		g.drawLine( Math.round(left), Math.round(top) + 1, Math.round(left),  Math.round(bottom) );
	}
	
	
	
	
	/**
	 * Copies the tile matrix from the room's background layer.
	 */
	public static int[][] getLayerTileMatrix ( Room room, int layerInx ) {
		int[][] tileMatrix;
		if ( layerInx == -1 )
			tileMatrix = new int[room.getBlockMatrixRows()][room.getBlockMatrixCols()];
		else
			tileMatrix = new int[room.getBGTileMatrixRows(layerInx)][room.getBGTileMatrixCols(layerInx)];
		
		for ( int i = 0; i < tileMatrix.length; i++ )
			for ( int j = 0; j < tileMatrix[i].length; j++ )
				if ( layerInx == -1 )
					tileMatrix[i][j] = room.getBlock( i, j );
				else
					tileMatrix[i][j] = room.getBGTile( layerInx, i, j );
		
		return tileMatrix;
	}
	
	
	
	
	/**
	 * Copies the color matrix from the room's background layer.
	 */
	public static ColorTile[][] getLayerTileColorMatrix ( Room room, int layerInx ) {
		ColorTile[][] tileColorMatrix;
		tileColorMatrix = new ColorTile[room.getBGTileMatrixRows(layerInx)][room.getBGTileMatrixCols(layerInx)];
		
		for ( int i = 0; i < tileColorMatrix.length; i++ )
			for ( int j = 0; j < tileColorMatrix[i].length; j++ )
				tileColorMatrix[i][j] = room.getBGTileColor( layerInx, i, j );
		
		return tileColorMatrix;
	}
	
	
	
	
	public static void fillMatrix ( int[][] matrix, int value ) {
		for ( int i = 0; i < matrix.length; i++ )
			for ( int j = 0; j < matrix[i].length; j++ )
				matrix[i][j] = value;
	}
	
	
	
	
	public static void fillMatrix ( ColorTile[][] matrix, ColorTile value ) {
		for ( int i = 0; i < matrix.length; i++ )
			for ( int j = 0; j < matrix[i].length; j++ )
				matrix[i][j] = value;
	}
	
	
	
	
	public static Point[] createInterpolationSequence ( Point from, Point to ) {
		final Vector<Point> resultVector = new Vector<Point>();
		resultVector.removeAllElements();
		
		int deltaX = to.x - from.x;
		int deltaY = to.y - from.y;
		
		// Categorize the line (from->to) based on its predominant axis:
		// Vertical:
		if ( Math.abs(deltaX) > Math.abs(deltaY) ) {
			// Swap "from" and "to" if the line goes from right to left
			// (simplifies things a lot):
			if ( deltaX < 0 ) {
				deltaX *= -1;
				deltaY *= -1;
				
				int tmp = from.x;
				from.x = to.x;
				to.x = tmp;
				
				tmp = from.y;
				from.y = to.y;
				to.y = tmp;
			}
			
			// Steps:
			// dy = a * dx
			// a = deltaY / deltaX
			float stepX = 1;
			float stepY = ((float) deltaY / deltaX) * stepX;
			
			float x = from.x, y = from.y;
			while ( x <= to.x ) {
				resultVector.add( new Point( Math.round(x), Math.round(y) ) );
				
				// "Step" to the next tile
				x += stepX;
				y += stepY;
			}
		}
		// Horizontal:
		else {
			// Swap "from" and "to" if the line goes from bottom to top
			// (simplifies things a lot):
			if ( deltaY < 0 ) {
				deltaX *= -1;
				deltaY *= -1;
	 			
				int tmp = from.x;
				from.x = to.x;
				to.x = tmp;
	 			
				tmp = from.y;
				from.y = to.y;
				to.y = tmp;
			}
			
			// Steps:
			// dx = dy / a
			// a = deltaY / deltaX
			float stepY = 1;
			float stepX = ((float) deltaX / deltaY) * stepY;
	 		
			float x = from.x, y = from.y;
			while ( y <= to.y ) {
				resultVector.add( new Point( Math.round(x), Math.round(y) ) );
				
				// "Step" to the next tile
				x += stepX;
				y += stepY;
			}
		}
		
		// Create result array:
		Point[] resultArray = new Point[resultVector.size()];
		for ( int i = 0; i < resultArray.length; i++ )
			resultArray[i] = resultVector.get( i );
		
		return resultArray;
	}
	
	
	
	
	public static String makeStatusBarText ( GlobalEditorModel globalEditorModel, Point currMousePoint, boolean appendRowAndCol ) {
		if ( currMousePoint == null )
			return " ";
		
		String resultStr = "Cursor: ";
		
		if ( currMousePoint != null ) {
			resultStr += "(" +
				globalEditorModel.roomXFromPanelX(currMousePoint.x) +
				" px, " +
				globalEditorModel.roomYFromPanelY(currMousePoint.y) +
				" px)";
		
			if ( appendRowAndCol )
				resultStr += "; (" + 
			       globalEditorModel.tileRowFromPanelY(currMousePoint.y, globalEditorModel.getWorkingLayer()) +
			       " row, " + 
			       globalEditorModel.tileColFromPanelX(currMousePoint.x, globalEditorModel.getWorkingLayer()) +
			       " col)";
		}
		
		return resultStr;
	}
	
	
	
	
	/**
	 * Returns true if the key event is related to selection operations.
	 */
	public static boolean processSelectionKeyEvent ( GlobalEditorModel globalEditorModel, ToolBar toolBar, KeyEvent evt ) {
		if ( globalEditorModel.getSelectionSet() == null )
			return false;
		
		if ( evt.getID() == KeyEvent.KEY_PRESSED &&
		     evt.getKeyCode() == KeyEvent.VK_DELETE &&
		     Main.f.isActive() ) {
			Main.deleteSelection( globalEditorModel, toolBar );
			
			globalEditorModel.setUnsavedChanges( true );
			return true;
		}
		else
		if ( evt.getID() == KeyEvent.KEY_PRESSED &&
		     evt.getKeyCode() == KeyEvent.VK_LEFT &&
		     evt.isShiftDown() &&
		     Main.f.isActive() ) {
			// Set appropriate selection tool:
			toolBar.setCurrentTool( ToolBar.getSelectionToolIndex( globalEditorModel.getSelectionSet() ) );
			
			if ( evt.isControlDown() )
				Main.moveSelection( globalEditorModel, toolBar, -10, 0 );
			else
				Main.moveSelection( globalEditorModel, toolBar, -1, 0 );
			
			globalEditorModel.setUnsavedChanges( true );
			return true;
		}
		else
		if ( evt.getID() == KeyEvent.KEY_PRESSED &&
		     evt.getKeyCode() == KeyEvent.VK_RIGHT &&
		     evt.isShiftDown() &&
		     Main.f.isActive() ) {
			// Set appropriate selection tool:
			toolBar.setCurrentTool( ToolBar.getSelectionToolIndex( globalEditorModel.getSelectionSet() ) );
			
			if ( evt.isControlDown() )
				Main.moveSelection( globalEditorModel, toolBar, 10, 0 );
			else
				Main.moveSelection( globalEditorModel, toolBar, 1, 0 );
			
			globalEditorModel.setUnsavedChanges( true );
			return true;
		}
		else
		if ( evt.getID() == KeyEvent.KEY_PRESSED &&
		     evt.getKeyCode() == KeyEvent.VK_UP &&
		     evt.isShiftDown() &&
		     Main.f.isActive() ) {
			// Set appropriate selection tool:
			toolBar.setCurrentTool( ToolBar.getSelectionToolIndex( globalEditorModel.getSelectionSet() ) );
			
			if ( evt.isControlDown() )
				Main.moveSelection( globalEditorModel, toolBar, 0, -10 );
			else
				Main.moveSelection( globalEditorModel, toolBar, 0, -1 );
			
			globalEditorModel.setUnsavedChanges( true );
			return true;
		}
		else
		if ( evt.getID() == KeyEvent.KEY_PRESSED &&
		     evt.getKeyCode() == KeyEvent.VK_DOWN &&
		     evt.isShiftDown() &&
		     Main.f.isActive() ) {
			// Set appropriate selection tool:
			toolBar.setCurrentTool( ToolBar.getSelectionToolIndex( globalEditorModel.getSelectionSet() ) );
			
			if ( evt.isControlDown() )
				Main.moveSelection( globalEditorModel, toolBar, 0, 10 );
			else
				Main.moveSelection( globalEditorModel, toolBar, 0, 1 );
			
			globalEditorModel.setUnsavedChanges( true );
			return true;
		}
		else
			return false;
	}
	
	
	
	
	/**
	 * Clears the selection and commits an undo operation.
	 */
	public static void deleteSelection ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		// If the selection is floating, just get rid of it.
		if ( globalEditorModel.isSelectionFloating() ) {
			int selectionToolInx = ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet());
			
			SelectionSet oldSelection = globalEditorModel.getSelectionSet();
			boolean oldFloating = globalEditorModel.isSelectionFloating();
			
			globalEditorModel.setSelectionSet( null, false );
			
			HistoryManager.addUndoOperation(
				new UndoImpl.SelectionSetChanged(
					globalEditorModel,
					toolBar, 
					selectionToolInx,
					globalEditorModel.getWorkingLayer(), 
					oldSelection,
					globalEditorModel.getSelectionSet(),
					oldFloating,
					globalEditorModel.isSelectionFloating() ),
				"delete selection" );
		}
		else {
			if ( globalEditorModel.getSelectionSet() == null ) {}
			else
			if ( globalEditorModel.getSelectionSet() instanceof BlockSelectionSet ||
			     globalEditorModel.getSelectionSet() instanceof BGTileSelectionSet ) {
				// Clear tiles in the selection.
				int layerInx = globalEditorModel.getWorkingLayer();
				TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
				Room room = globalEditorModel.getLoadedRoom();
				
				int[][] oldTileMatrix = Main.getLayerTileMatrix(room, layerInx);
				
				for ( int i = selectionSet.getOrigRow(); i <= selectionSet.getOrigRow() + selectionSet.getNumOfRows(); i++ )
					for ( int j = selectionSet.getOrigCol(); j <= selectionSet.getOrigCol() + selectionSet.getNumOfCols(); j++ )
						if ( selectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL ) {
							if ( layerInx == -1 )
								room.setBlock(i, j, -1);
							else
								room.setBGTile(layerInx, i, j, -1);
						}
				
				int[][] newTileMatrix = Main.getLayerTileMatrix(room, layerInx);
				
				// Commit undo operation:
				HistoryManager.addUndoOperation(
					new UndoImpl.TileDrawing(
						globalEditorModel,
						room,
						layerInx,
						oldTileMatrix,
						newTileMatrix ),
					"delete tile selection" );
			}
			else
			if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet ) {
				// Clear tiles in the selection.
				int layerInx = globalEditorModel.getWorkingLayer();
				BGTileColorSelectionSet selectionSet = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
				Room room = globalEditorModel.getLoadedRoom();
				
				ColorTile[][] oldTileColorMatrix = Main.getLayerTileColorMatrix(room, layerInx);
				
				for ( int i = selectionSet.getOrigRow(); i <= selectionSet.getOrigRow() + selectionSet.getNumOfRows(); i++ )
					for ( int j = selectionSet.getOrigCol(); j <= selectionSet.getOrigCol() + selectionSet.getNumOfCols(); j++ )
						if ( selectionSet.getTileAtGlobalCoords(i, j) != null ) {
							room.setBGTileColor(layerInx, i, j, null);
						}
				
				ColorTile[][] newTileColorMatrix = Main.getLayerTileColorMatrix(room, layerInx);
				
				// Commit undo operation:
				HistoryManager.addUndoOperation(
					new UndoImpl.TileColorDrawing(
						globalEditorModel,
						room,
						layerInx,
						oldTileColorMatrix,
						newTileColorMatrix ),
					"delete color selection" );
			}
			else
			if ( globalEditorModel.getSelectionSet() instanceof GameObjSelectionSet ) {
				UndoImpl.Composite undoOp = new UndoImpl.Composite();
				
				// Remove objects in selection:
				Room room = globalEditorModel.getLoadedRoom();
				GameObjSelectionSet selectionSet = (GameObjSelectionSet) globalEditorModel.getSelectionSet();
				for ( int i = 0; i < selectionSet.getNumOfObjs(); i++ ) {
					GameObj obj = selectionSet.getObj( i );
					int objInx = room.indexOfGameObj( obj );
					if ( objInx != -1 ) {
						room.removeGameObj( objInx );
						
						undoOp.add(
							new UndoImpl.DeleteObject(
								globalEditorModel,
								room,
								objInx,
								obj ) );
					}
				}
				
				// No more selection:
				boolean oldFloating = globalEditorModel.isSelectionFloating();
				globalEditorModel.setSelectionSet( null, false );
				
				undoOp.add(
					new UndoImpl.SelectionSetChanged(
						globalEditorModel,
						toolBar,
						ToolBar.getSelectionToolIndex( selectionSet ),
						globalEditorModel.getWorkingLayer(),
						selectionSet,
						globalEditorModel.getSelectionSet(),
						oldFloating,
						globalEditorModel.isSelectionFloating() ) );
				
				// Commit undo operation:
				HistoryManager.addUndoOperation( undoOp, "delete game objects" );
			}
			else {
				throw new IllegalStateException("Unknown selection set type: " + globalEditorModel.getSelectionSet().getClass().getSimpleName());
			}
		}
	}
	
	
	
	
	/**
	 * Floats the selection, if necessary, and moves it.
	 */
	public static void moveSelection ( GlobalEditorModel globalEditorModel, ToolBar toolBar, int horiz, int vert ) {
		if ( horiz == 0 && vert == 0 )
			return;
		
		UndoImpl.Composite undoOp = new UndoImpl.Composite();
		int layerInx = globalEditorModel.getWorkingLayer();
		
		// Float selection:
		if ( !globalEditorModel.isSelectionFloating() && globalEditorModel.getSelectionSet().isFloatable() ) {
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.floatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			undoOp.add(
				new UndoImpl.FloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
					globalEditorModel.getWorkingLayer(),
					oldState,
					newState,
					selection ) );
		}
		
		// Move it:
		globalEditorModel.getSelectionSet().move( horiz, vert );
		
		undoOp.add(
			new UndoImpl.MoveSelection( 
				globalEditorModel,
				layerInx,
				horiz,
				vert ) );
		
		globalEditorModel.setUnsavedChanges( true );
		
		// Commit undo operation:
		HistoryManager.addUndoOperation(
			undoOp,
			"move selection" );
	}
	
	
	
	
	/**
	 * Floats the selection, if necessary, and flips it.
	 */
	public static void flipSelection ( GlobalEditorModel globalEditorModel, ToolBar toolBar, boolean horiz, boolean vert ) {
		UndoImpl.Composite undoOp = new UndoImpl.Composite();
		int layerInx = globalEditorModel.getWorkingLayer();
		
		// Float selection:
		if ( !globalEditorModel.isSelectionFloating() && globalEditorModel.getSelectionSet().isFloatable() ) {
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.floatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			undoOp.add(
				new UndoImpl.FloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
					globalEditorModel.getWorkingLayer(),
					oldState,
					newState,
					selection ) );
		}
		
		// Flip it:
		globalEditorModel.getSelectionSet().flip( horiz, vert );
		
		undoOp.add(
			new UndoImpl.FlipSelection( 
				globalEditorModel,
				layerInx,
				horiz,
				vert ) );
		
		globalEditorModel.setUnsavedChanges( true );
		
		// Commit undo operation:
		HistoryManager.addUndoOperation(
			undoOp,
			"flip selection" );
	}
	
	
	
	
	public static void copy ( GlobalEditorModel globalEditorModel ) {
		SelectionSet selectionSet = globalEditorModel.getSelectionSet().clone();
		
		// If the selection wasn't floating...
		if ( !globalEditorModel.isSelectionFloating() ) {
			// It may be necessary to copy stuff from the underlying layer.
			if ( selectionSet == null ) {
				throw new IllegalStateException("Can't float a null selection.");
			}
			else
			if ( selectionSet instanceof BlockSelectionSet ||
			     selectionSet instanceof BGTileSelectionSet ) {
				TileBrushMatrix tileSelectionSet = (TileBrushMatrix) selectionSet;
				int workingBGLayerInx = globalEditorModel.getWorkingLayer();
				Room loadedRoom = globalEditorModel.getLoadedRoom();
				
				int row1 = tileSelectionSet.getOrigRow();
				int row2 = tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows();
				int col1 = tileSelectionSet.getOrigCol();
				int col2 = tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols();
				
				// Copy tiles from the selection below:
				for ( int i = row1; i <= row2; i++ ) {
					for ( int j = col1; j <= col2; j++ ) {
						if ( tileSelectionSet.getTileAtGlobalCoords(i, j) != TileBrushMatrix.FREE_CELL ) {
							int tileID = -1;
							
							if ( workingBGLayerInx == -1 )
								try {
									tileID = loadedRoom.getBlock(i, j);
								}
								catch (ArrayIndexOutOfBoundsException exc) {}
							else
								try {
									tileID = loadedRoom.getBGTile( workingBGLayerInx, i, j );
								}
								catch (ArrayIndexOutOfBoundsException exc) {}
							
							tileSelectionSet.setTileAtGlobalCoords( i, j, tileID );
						}
					}
				}
			}
			else
			if ( selectionSet instanceof BGTileColorSelectionSet ) {
				BGTileColorSelectionSet tileSelectionSet = (BGTileColorSelectionSet) selectionSet;
				int workingBGLayerInx = globalEditorModel.getWorkingLayer();
				Room loadedRoom = globalEditorModel.getLoadedRoom();
				
				int row1 = tileSelectionSet.getOrigRow();
				int row2 = tileSelectionSet.getOrigRow() + tileSelectionSet.getNumOfRows();
				int col1 = tileSelectionSet.getOrigCol();
				int col2 = tileSelectionSet.getOrigCol() + tileSelectionSet.getNumOfCols();
				
				// Copy tiles from the selection below:
				for ( int i = row1; i <= row2; i++ ) {
					for ( int j = col1; j <= col2; j++ ) {
						if ( tileSelectionSet.getTileAtGlobalCoords(i, j) != null ) {
							ColorTile tileColor = ColorTile.DEFAULT;
							
							try {
								tileColor = loadedRoom.getBGTileColor( workingBGLayerInx, i, j );
							}
							catch (ArrayIndexOutOfBoundsException exc) {}
							
							tileSelectionSet.setTileAtGlobalCoords( i, j, tileColor );
						}
					}
				}
			}
			else
			if ( selectionSet instanceof GameObjSelectionSet ) {
				//Clone objects, in the same order as they are in the room:
				GameObjSelectionSet objSelectionSet = (GameObjSelectionSet) selectionSet;
				Vector<GameObj> copiedObjs = new Vector<GameObj>();
				
				// Keep object ordering within the room
				Room room = globalEditorModel.getLoadedRoom();
				for ( int i = 0; i < room.getNumOfObjs(); i++ )
					if ( objSelectionSet.indexOfObj( room.getObj(i) ) != -1 )
						copiedObjs.add( room.getObj(i).clone() );
				
				selectionSet = new GameObjSelectionSet( copiedObjs );
			}
			else {
				throw new IllegalStateException("Unknown selection set type: " + selectionSet.getClass().getSimpleName());
			}
		}
		
		globalEditorModel.setClipboardContents( selectionSet );
	}
	
	
	
	
	public static void paste ( GlobalEditorModel globalEditorModel, ToolBar toolBar, boolean centerOnScreen ) {
		UndoImpl.Composite undoOp = new UndoImpl.Composite();
		
		// Defloat current selection:
		if ( globalEditorModel.isSelectionFloating() ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.defloatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			undoOp.add(
				new UndoImpl.DefloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
					layerInx,
					oldState,
					newState,
					selection ) );
		}
		
		SelectionSet pastedSelection = globalEditorModel.getClipboardContents().getPasteableClone();
		int selectionToolInx = ToolBar.getSelectionToolIndex( pastedSelection );
		int layerInx = globalEditorModel.getWorkingLayer();
		
		toolBar.setCurrentTool( selectionToolInx );
		
		// Paste it as floating selection.
		SelectionSet oldSelection = globalEditorModel.getSelectionSet();
		boolean oldFloating = globalEditorModel.isSelectionFloating();
		
		// Center on screen:
		if ( centerOnScreen )
			pastedSelection.centerOnScreen( globalEditorModel, layerInx );
		
		globalEditorModel.setSelectionSet( pastedSelection, pastedSelection.isFloatable() );
		
		undoOp.add(
			new UndoImpl.SelectionSetChanged(
				globalEditorModel,
				toolBar,
				selectionToolInx,
				layerInx,
				oldSelection,
				globalEditorModel.getSelectionSet(),
				oldFloating,
				globalEditorModel.isSelectionFloating() ) );
		
		// Special actions depending on selection type:
		if ( pastedSelection instanceof GameObjSelectionSet ) {
			GameObjSelectionSet objSelectionSet = (GameObjSelectionSet) pastedSelection;
			Room room = globalEditorModel.getLoadedRoom();
			for ( int i = objSelectionSet.getNumOfObjs() - 1; i >= 0; i-- ) {
				room.addGameObj( 0, objSelectionSet.getObj( i ) );
				undoOp.add(
					new UndoImpl.CreateObject(
						globalEditorModel,
						room,
						0,
						objSelectionSet.getObj( i ) ) );
			}
		}
		
		// Commit undo operation:
		HistoryManager.addUndoOperation( undoOp, "paste selection" );
		
		globalEditorModel.setUnsavedChanges( true );
	}
	
	
	
	
	/**
	 * Sets a defloated selection set, committing undo operations as necessary.
	 */
	public static void setSelectionSet ( GlobalEditorModel globalEditorModel, ToolBar toolBar, int selectionToolIndex, SelectionSet newSelectionSet ) {
		UndoImpl.Composite undoOp = new UndoImpl.Composite();
		int layerInx = globalEditorModel.getWorkingLayer();
		
		// Defloat current selection:
		if ( globalEditorModel.isSelectionFloating() ) {
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.defloatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			undoOp.add(
				new UndoImpl.DefloatSelection(
					globalEditorModel,
					toolBar,
					ToolBar.getSelectionToolIndex( selection ),
					layerInx,
					oldState,
					newState,
					selection ) );
		}
		
		// Store old state:
		SelectionSet oldSelectionSet = globalEditorModel.getSelectionSet();
		boolean oldFloating = globalEditorModel.isSelectionFloating();
		if (oldSelectionSet != null)
			oldSelectionSet = oldSelectionSet.clone();
		
		// Set the new set:
		globalEditorModel.setSelectionSet( newSelectionSet, false );
		
		// Commit undo operation, if the selection changed:
		if ( (oldSelectionSet != null && !oldSelectionSet.equals(newSelectionSet)) ||
		     (newSelectionSet != null && !newSelectionSet.equals(oldSelectionSet)) )
			undoOp.add(
				new UndoImpl.SelectionSetChanged(
					globalEditorModel,
					toolBar,
					selectionToolIndex,
					globalEditorModel.getWorkingLayer(),
					oldSelectionSet,
					globalEditorModel.getSelectionSet(),
					oldFloating,
					globalEditorModel.isSelectionFloating() ) );
		
		if ( undoOp.getCount() > 0 )
			HistoryManager.addUndoOperation(
				undoOp,
				(globalEditorModel.getSelectionSet() == null ? "select none" : "color selection") );
	}
	
}
