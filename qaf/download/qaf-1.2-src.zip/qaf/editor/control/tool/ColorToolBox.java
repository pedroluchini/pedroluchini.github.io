/*
 * Created on Jun 16, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package control.tool;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;

import model.ColorTile;
import control.Main;
import control.dlg.ColorChooserDialog;

public class ColorToolBox extends Box {
	final static long serialVersionUID = 0;
	
	
	
	
	private JButton       flipXBtn          = new JButton( "Flip horiz." );
	private JButton       flipYBtn          = new JButton( "Flip vert." );
	private JRadioButton  colorMulRadioBtn  = new JRadioButton( "BLEND_COLORMUL", true );
	private JRadioButton  colorAddRadioBtn  = new JRadioButton( "BLEND_COLORADD" );
	private ButtonGroup   colorBtnGroup     = new ButtonGroup();
	private JButton       colorBtn0         = new JButton(" "),
	                      colorBtn1         = new JButton(" "),
	                      colorBtn2         = new JButton(" "),
	                      colorBtn3         = new JButton(" ");
	private JToggleButton stretchFillBtn    = new JToggleButton( new ImageIcon( Main.qafPath + "img/colorFillStretch.png" ), true ),
	                      repeatFillBtn     = new JToggleButton( new ImageIcon( Main.qafPath + "img/colorFillRepeat.png" ), false );
	private JPanel        colorTileDisplay  =
		new JPanel() {
		final static long serialVersionUID = 0;
			public void paint ( Graphics g ) {
				int w = getWidth();
				int h = getHeight();
				
				// Clear BG with checkered pattern:
				Main.clearBGWithCheckers( g, w, h );
				
				int a0 = resultTile.getColor(0).getAlpha();
				int r0 = resultTile.getColor(0).getRed();
				int g0 = resultTile.getColor(0).getGreen();
				int b0 = resultTile.getColor(0).getBlue();
				int a1 = resultTile.getColor(1).getAlpha();
				int r1 = resultTile.getColor(1).getRed();
				int g1 = resultTile.getColor(1).getGreen();
				int b1 = resultTile.getColor(1).getBlue();
				int a2 = resultTile.getColor(2).getAlpha();
				int r2 = resultTile.getColor(2).getRed();
				int g2 = resultTile.getColor(2).getGreen();
				int b2 = resultTile.getColor(2).getBlue();
				int a3 = resultTile.getColor(3).getAlpha();
				int r3 = resultTile.getColor(3).getRed();
				int g3 = resultTile.getColor(3).getGreen();
				int b3 = resultTile.getColor(3).getBlue();
				
				for ( int x = 0; x < w; x += 4 )
					for ( int y = 0; y < h; y += 4 ) {
						Color c =
							new Color(
								interpolate(x, w, y, h, r0, r1, r2, r3),
								interpolate(x, w, y, h, g0, g1, g2, g3),
								interpolate(x, w, y, h, b0, b1, b2, b3),
								interpolate(x, w, y, h, a0, a1, a2, a3) );
						
						g.setColor( c );
						g.fillRect( x, y, 4, 4 );
					}
			}
		};
	
	private ColorTile resultTile = new ColorTile();
	
	
	
	
	public ColorToolBox () {
		super( BoxLayout.Y_AXIS );
		setAlignmentX( 0 );
		setAlignmentY( 0 );
		
		colorBtnGroup.add( colorAddRadioBtn );
		colorBtnGroup.add( colorMulRadioBtn );
		
		
		// +------------------------------+
		// |[ Flip X ]      [ ]+-----+[ ] |
		// |[ Flip Y ]         |     |    |
		// |(*) COLORMUL       |     |    |
		// |( ) COLORADD    [ ]+-----+[ ] |
		// |                              |
		// |    [Stretch]    [Repeat]     |
		// |                              |
		// +------------------------------+
		
		Box hBox = Box.createHorizontalBox();
		hBox.setAlignmentX( 0 );
		hBox.setAlignmentY( 0 );
		{
			hBox.add( Box.createHorizontalStrut( 5 ) );
			
			Box vBox = Box.createVerticalBox();
			vBox.setAlignmentX( 0 );
			vBox.setAlignmentY( 0 );
			{
				vBox.add( Box.createVerticalStrut( 5 ) );
				
				flipXBtn.setAlignmentX( 0 );
				flipXBtn.setAlignmentY( 0 );
				flipXBtn.setMinimumSize( new Dimension( 150, flipXBtn.getPreferredSize().height ) );
				flipXBtn.setPreferredSize(flipXBtn.getMinimumSize());
				flipXBtn.setMaximumSize(flipXBtn.getMinimumSize());
				flipXBtn.addActionListener( new ActionListener() {
					public void actionPerformed ( ActionEvent evt ) {
						setSelectedTileColor(
							new ColorTile(
								resultTile.getBlend(),
								resultTile.getColor(1),
								resultTile.getColor(0),
								resultTile.getColor(3),
								resultTile.getColor(2) ) );
					}
				} );
				vBox.add( flipXBtn );
				
				vBox.add( Box.createVerticalStrut( 5 ) );
				
				flipYBtn.setAlignmentX( 0 );
				flipYBtn.setAlignmentY( 0 );
				flipYBtn.setMinimumSize( new Dimension( 150, flipYBtn.getPreferredSize().height ) );
				flipYBtn.setPreferredSize(flipYBtn.getMinimumSize());
				flipYBtn.setMaximumSize(flipYBtn.getMinimumSize());
				flipYBtn.addActionListener( new ActionListener() {
					public void actionPerformed ( ActionEvent evt ) {
						setSelectedTileColor(
							new ColorTile(
								resultTile.getBlend(),
								resultTile.getColor(3),
								resultTile.getColor(2),
								resultTile.getColor(1),
								resultTile.getColor(0) ) );
					}
				} );
				vBox.add( flipYBtn );
				
				vBox.add( Box.createVerticalStrut( 15 ) );
				
				colorMulRadioBtn.setAlignmentX( 0 );
				colorMulRadioBtn.setAlignmentY( 0 );
				colorMulRadioBtn.addActionListener(
					new ActionListener() {
						public void actionPerformed ( ActionEvent evt ) {
							setSelectedTileColor(
								new ColorTile(
									ColorTile.BLEND_COLORMUL,
									resultTile.getColor(0),
									resultTile.getColor(1), 
									resultTile.getColor(2), 
									resultTile.getColor(3) ) );
						}
					} );
				vBox.add( colorMulRadioBtn );
				
				colorAddRadioBtn.setAlignmentX( 0 );
				colorAddRadioBtn.setAlignmentY( 0 );
				colorAddRadioBtn.addActionListener(
					new ActionListener() {
						public void actionPerformed ( ActionEvent evt ) {
							setSelectedTileColor(
								new ColorTile(
									ColorTile.BLEND_COLORADD,
									resultTile.getColor(0),
									resultTile.getColor(1), 
									resultTile.getColor(2), 
									resultTile.getColor(3) ) );
						}
					} );
				vBox.add( colorAddRadioBtn );
				
				vBox.add( Box.createVerticalStrut( 5 ) );
			}
			hBox.add( vBox );
			
			hBox.add( Box.createHorizontalStrut( 5 ) );
			
			vBox = Box.createVerticalBox();
			vBox.setAlignmentX( 0 );
			vBox.setAlignmentY( 0 );
			{
				vBox.add( Box.createVerticalStrut( 5 ) );
				
				Container c = new Container();
				c.setLayout( new GridBagLayout() );
				{
					// Top-left
					colorBtn0.setAlignmentX( 0 );
					colorBtn0.setAlignmentY( 0 );
					colorBtn0.addActionListener(
						new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								Color newColor = ColorChooserDialog.getColor( resultTile.getColor(0) );
								if ( newColor != null ) {
									Color[] colors = { newColor, resultTile.getColor(1), resultTile.getColor(2), resultTile.getColor(3)};
									setSelectedTileColor( new ColorTile( resultTile.getBlend(), colors ) );
								}
							}
						} );
					c.add( colorBtn0, new GridBagConstraints(0, 0, 1, 1, 1, 0, GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0) );
					
					// Top-right:
					colorBtn1.setAlignmentX( 0 );
					colorBtn1.setAlignmentY( 0 );
					colorBtn1.addActionListener(
						new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								Color newColor = ColorChooserDialog.getColor( resultTile.getColor(1) );
								if ( newColor != null ) {
									Color[] colors = { resultTile.getColor(0), newColor, resultTile.getColor(2), resultTile.getColor(3)};
									setSelectedTileColor( new ColorTile( resultTile.getBlend(), colors ) );
								}
							}
						} );
					c.add( colorBtn1, new GridBagConstraints(2, 0, 1, 1, 0, 0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0) );
					
					// Center:
					colorTileDisplay.setAlignmentX( 0 );
					colorTileDisplay.setAlignmentY( 0 );
					colorTileDisplay.setMinimumSize( new Dimension( 70, 70 ) );
					colorTileDisplay.setPreferredSize( colorTileDisplay.getMinimumSize() );
					colorTileDisplay.setMaximumSize( colorTileDisplay.getMinimumSize() );
					c.add( colorTileDisplay, new GridBagConstraints(1, 1, 1, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0) );
					
					// Bottom-left:
					colorBtn3.setAlignmentX( 0 );
					colorBtn3.setAlignmentY( 0 );
					colorBtn3.addActionListener(
						new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								Color newColor = ColorChooserDialog.getColor( resultTile.getColor(3) );
								if ( newColor != null ) {
									Color[] colors = { resultTile.getColor(0), resultTile.getColor(1), resultTile.getColor(2), newColor};
									setSelectedTileColor( new ColorTile( resultTile.getBlend(), colors ) );
								}
							}
						} );
					c.add( colorBtn3, new GridBagConstraints(0, 2, 1, 1, 1, 1, GridBagConstraints.NORTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0) );
					
					// Bottom-right:
					colorBtn2.setAlignmentX( 0 );
					colorBtn2.setAlignmentY( 0 );
					colorBtn2.addActionListener(
						new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								Color newColor = ColorChooserDialog.getColor( resultTile.getColor(2) );
								if ( newColor != null ) {
									Color[] colors = { resultTile.getColor(0), resultTile.getColor(1), newColor, resultTile.getColor(3)};
									setSelectedTileColor( new ColorTile( resultTile.getBlend(), colors ) );
								}
							}
						} );
					c.add( colorBtn2, new GridBagConstraints(2, 2, 1, 1, 0, 1, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0) );
					
				}
				vBox.add( c );
				
				vBox.add( Box.createVerticalStrut( 5 ) );
			}
			hBox.add( vBox );
			
			hBox.add( Box.createHorizontalStrut( 5 ) );
		}
		add( hBox );
		
		add( Box.createVerticalStrut( 10 ) );
		
		hBox = Box.createHorizontalBox();
		hBox.setAlignmentX( 0 );
		hBox.setAlignmentY( 0 );
		{
			hBox.add( Box.createHorizontalGlue() );
			
			stretchFillBtn.setMargin( new Insets(3,3,3,3) );
			stretchFillBtn.setAlignmentX( 0 );
			stretchFillBtn.setAlignmentY( 0 );
			stretchFillBtn.setToolTipText( "Stretch gradient to fill selection" );
			hBox.add( stretchFillBtn );
			
			hBox.add( Box.createHorizontalStrut( 15 ) );
			
			repeatFillBtn.setMargin( new Insets(3,3,3,3) );
			repeatFillBtn.setAlignmentX( 0 );
			repeatFillBtn.setAlignmentY( 0 );
			repeatFillBtn.setToolTipText( "Repeat gradient on each selected tile" );
			hBox.add( repeatFillBtn );
			
			hBox.add( Box.createHorizontalGlue() );
		}
		add( hBox );
		
		add( Box.createVerticalStrut( 15 ) );
		
		// Create button group:
		ButtonGroup btnGroup = new ButtonGroup();
		btnGroup.add( stretchFillBtn );
		btnGroup.add( repeatFillBtn );
		
		// Update fields:
		setSelectedTileColor( ColorTile.DEFAULT );
		
	}
	
	
	
	
	public void setEnabled ( boolean b ) {
		super.setEnabled( b );
		
		flipXBtn.setEnabled( b );
		flipYBtn.setEnabled( b );
		colorMulRadioBtn.setEnabled( b );
		colorAddRadioBtn.setEnabled( b );
		
		colorBtn0.setEnabled( b );
		colorBtn1.setEnabled( b );
		colorBtn2.setEnabled( b );
		colorBtn3.setEnabled( b );
		
		stretchFillBtn.setEnabled( b );
		repeatFillBtn.setEnabled( b );
	}
	
	
	
	
	public void setSelectedTileColor ( ColorTile colorTile ) {
		this.resultTile = colorTile;
		
		if ( ColorTile.isBlendColorAdd( colorTile.getBlend() ) )
			colorBtnGroup.setSelected( colorAddRadioBtn.getModel(), true );
		else
			colorBtnGroup.setSelected( colorMulRadioBtn.getModel(), true );
		
		colorBtn0.setBackground( removeAlpha(colorTile.getColor(0)) );
		colorBtn0.setToolTipText( formatHexColor(colorTile.getColor(0) ) );
		
		colorBtn1.setBackground( removeAlpha(colorTile.getColor(1)) );
		colorBtn1.setToolTipText( formatHexColor(colorTile.getColor(1) ) );
		
		colorBtn2.setBackground( removeAlpha(colorTile.getColor(2)) );
		colorBtn2.setToolTipText( formatHexColor(colorTile.getColor(2) ) );
		
		colorBtn3.setBackground( removeAlpha(colorTile.getColor(3)) );
		colorBtn3.setToolTipText( formatHexColor(colorTile.getColor(3) ) );
		
		colorTileDisplay.repaint();
	}
	
	
	
	
	public ColorTile getSelectedTileColor () {
		return resultTile;
	}
	
	
	
	
	public boolean isStretchFillChecked () {
		return stretchFillBtn.isSelected();
	}
	
	
	
	
	private static int interpolate ( int x, int w, int y, int h, int c0, int c1, int c2, int c3 ) {
		float horiz = (float) x / (float) w;
		float vert  = (float) y / (float) h;
		
		return (int) ((1 - vert) * ((1 - horiz) * c0 + horiz * c1) + vert * ((1 - horiz) * c3 + horiz * c2));
	}
	
	
	
	
	private static String formatHexColor ( Color c ) {
		String str = Integer.toHexString( c.getRGB() );
		while ( str.length() < 8 )
			str = "0" + str;
		str = str.toUpperCase();
		return str;
	}
	
	
	
	
	private Color removeAlpha ( Color c ) {
		return new Color( c.getRed(), c.getGreen(), c.getBlue(), 255 );
	}

}
