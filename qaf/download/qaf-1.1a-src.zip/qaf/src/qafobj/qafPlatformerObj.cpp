/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafobj/qafPlatformerObj.h>

#include <hge.h>

using namespace qaf;
using namespace std;


#define hge ((HGE *) pHGE)




PlatformerObj::PlatformerInput::PlatformerInput () {
	left = right = down = jumpPress = jump = false;
}




PlatformerObj::PlatformerObj ( float _x, float _y, PlatformerInput * _platformerInput, AttributeTable & attributes ) {
	pHGE = hgeCreate( HGE_VERSION );
	
	pos.x = _x;
	pos.y = _y;
	
	platformerInput = _platformerInput;
	
	vel.x = vel.y = 0;
	
	isFacingLeft = false;
	
	cameraVelocity.x = cameraVelocity.y = 0;
	cameraPosition.x = cameraPosition.y = 0;
	
	rightContact = leftContact = topContact = bottomContact = false;
	
	accDX = 0;
	
	// A few deault values:
	HEIGHT                   =  55;
	WIDTH                    =  10;
	
	CAMERA_DX                =   0;
	CAMERA_DY                = -45;
	
	CAMERA_INV_DRAG          =   0.3f;
	CAMERA_ACCELERATION      =   0.1f;
	
	CENTER_SCROLLING_ON_SELF = false;
	
	WALK_SPEED               = 120.0f;
	
	CLIMB_26_SLOPE_SLOWDOWN  =   1.0f;
	CLIMB_45_SLOPE_SLOWDOWN  =   0.5f;
	
	WALK_ACCELERATION        = 900.0f;
	WALK_DECELERATION        = 900.0f;
	
	JUMP_STRENGTH            = 240.0f;
	WATER_JUMP_STRENGTH      = 195.0f;
	GRAVITY                  = 390.5f;
	MAX_FALL_SPEED           = 330.0f;
	
	SUBMERSION_HEIGHT        =  35.0f;
	BUOYANCY                 = 450.0f;
	MAX_FLOAT_SPEED          =  60.0f;
	MAX_SINK_SPEED           = 150.0f;
	SWIM_SPEED               =  90.0f;
	SWIM_ACCELERATION        = 225.0f;
	SWIM_DECELERATION        = 225.0f;
	
	FLOAT_ON_WATER_SURFACE   = true;
	
	// Read parameters from the attribute table:
	
	float parm;
	
	if ( sscanf( attributes["HEIGHT"].c_str(), "%f", &parm ) == 1 )
		HEIGHT = parm;
	
	if ( sscanf( attributes["WIDTH"].c_str(), "%f", &parm ) == 1 )
		WIDTH = parm;
	
	if ( sscanf( attributes["CAMERA_DX"].c_str(), "%f", &parm ) == 1 )
		CAMERA_DX = parm;
	
	if ( sscanf( attributes["CAMERA_DY"].c_str(), "%f", &parm ) == 1 )
		CAMERA_DY = parm;
	
	if ( sscanf( attributes["CAMERA_INV_DRAG"].c_str(), "%f", &parm ) == 1 )
		CAMERA_INV_DRAG = parm;
	
	if ( sscanf( attributes["CAMERA_ACCELERATION"].c_str(), "%f", &parm ) == 1 )
		CAMERA_ACCELERATION = parm;
	
	if ( attributes["CENTER_SCROLLING_ON_SELF"] == "true" )
		CENTER_SCROLLING_ON_SELF = true;
	
	if ( sscanf( attributes["WALK_SPEED"].c_str(), "%f", &parm ) == 1 )
		WALK_SPEED = parm;
	
	if ( sscanf( attributes["CLIMB_26_SLOPE_SLOWDOWN"].c_str(), "%f", &parm ) == 1 )
		CLIMB_26_SLOPE_SLOWDOWN = parm;
	
	if ( sscanf( attributes["CLIMB_45_SLOPE_SLOWDOWN"].c_str(), "%f", &parm ) == 1 )
		CLIMB_45_SLOPE_SLOWDOWN = parm;
	
	if ( sscanf( attributes["WALK_ACCELERATION"].c_str(), "%f", &parm ) == 1 )
		WALK_ACCELERATION = parm;
	
	if ( sscanf( attributes["WALK_DECELERATION"].c_str(), "%f", &parm ) == 1 )
		WALK_DECELERATION = parm;
	
	if ( sscanf( attributes["JUMP_STRENGTH"].c_str(), "%f", &parm ) == 1 )
		JUMP_STRENGTH = parm;
	
	if ( sscanf( attributes["WATER_JUMP_STRENGTH"].c_str(), "%f", &parm ) == 1 )
		WATER_JUMP_STRENGTH = parm;
	
	if ( sscanf( attributes["GRAVITY"].c_str(), "%f", &parm ) == 1 )
		GRAVITY = parm;
	
	if ( sscanf( attributes["MAX_FALL_SPEED"].c_str(), "%f", &parm ) == 1 )
		MAX_FALL_SPEED = parm;
	
	if ( sscanf( attributes["SUBMERSION_HEIGHT"].c_str(), "%f", &parm ) == 1 )
		SUBMERSION_HEIGHT = parm;
	
	if ( sscanf( attributes["BUOYANCY"].c_str(), "%f", &parm ) == 1 )
		BUOYANCY = parm;
	
	if ( sscanf( attributes["MAX_FLOAT_SPEED"].c_str(), "%f", &parm ) == 1 )
		MAX_FLOAT_SPEED = parm;
	
	if ( sscanf( attributes["MAX_SINK_SPEED"].c_str(), "%f", &parm ) == 1 )
		MAX_SINK_SPEED = parm;
	
	if ( sscanf( attributes["SWIM_SPEED"].c_str(), "%f", &parm ) == 1 )
		SWIM_SPEED = parm;
	
	if ( sscanf( attributes["SWIM_ACCELERATION"].c_str(), "%f", &parm ) == 1 )
		SWIM_ACCELERATION = parm;
	
	if ( sscanf( attributes["SWIM_DECELERATION"].c_str(), "%f", &parm ) == 1 )
		SWIM_DECELERATION = parm;
	
	if ( attributes["FLOAT_ON_WATER_SURFACE"] == "false" )
		FLOAT_ON_WATER_SURFACE = false;
	
	
	// Now that all the parameters have been read... initialize the collision
	// structure:
	platformerCollisionStruct.setX( pos.x - WIDTH/2 );
	platformerCollisionStruct.setY( pos.y - HEIGHT );
	platformerCollisionStruct.setWidth( WIDTH );
	platformerCollisionStruct.setHeight( HEIGHT );
}




PlatformerObj::~PlatformerObj () {
	hge->Release();
}




void PlatformerObj::initialize () {
	if ( CENTER_SCROLLING_ON_SELF ) {
		// Center camera on character:
		Environment::centerScrollingPoint(
			(int) (pos.x + CAMERA_DX),
			(int) (pos.y + CAMERA_DY) );
		
		cameraPosition.x = pos.x + CAMERA_DX;
		cameraPosition.y = pos.y + CAMERA_DY;
	}
}



void PlatformerObj::update ( int objLayer, float dt ) {
	// Store last frame's position. I'll need it later...
	Vector2D lastPos = pos;
	
	// 
	// Horizontal controls:
	// 
	// Walk left?
	if ( inputLeft() && !inputRight() ) {
		isFacingLeft = true;
		
		// Abovewater?
		if ( !isUnderwater() || !FLOAT_ON_WATER_SURFACE ) {
			// Make xSpeed tend to the walk speed:
			if ( vel.x < -WALK_SPEED ) {
				vel.x += WALK_DECELERATION * dt;
				
				if ( vel.x > -WALK_SPEED )
					vel.x = -WALK_SPEED;
			}
			else if ( vel.x > -WALK_SPEED ) {
				vel.x -= WALK_ACCELERATION * dt;
				
				if ( vel.x < -WALK_SPEED )
					vel.x = -WALK_SPEED;
			}
		}
		// Underwater?
		else {
			// Make xSpeed tend to the swim speed:
			if ( vel.x < -SWIM_SPEED ) {
				vel.x += SWIM_DECELERATION * dt;
				
				if ( vel.x > -SWIM_SPEED )
					vel.x = -SWIM_SPEED;
			}
			else if ( vel.x > -SWIM_SPEED ) {
				vel.x -= SWIM_ACCELERATION * dt;
				
				if ( vel.x < -SWIM_SPEED )
					vel.x = -SWIM_SPEED;
			}
		}
	}
	// Walk right?
	else if ( inputRight() && !inputLeft() ) {
		isFacingLeft = false;
		
		// Abovewater?
		if ( !isUnderwater() || !FLOAT_ON_WATER_SURFACE ) {
			// Make xSpeed tend to the walk speed:
			if ( vel.x > WALK_SPEED ) {
				vel.x -= WALK_DECELERATION * dt;
				
				if ( vel.x < WALK_SPEED )
					vel.x = WALK_SPEED;
			}
			else if ( vel.x < WALK_SPEED ) {
				vel.x += WALK_ACCELERATION * dt;
				
				if ( vel.x > WALK_SPEED )
					vel.x = WALK_SPEED;
			}
		}
		// Underwater?
		else {
			// Make xSpeed tend to the swim speed:
			if ( vel.x > SWIM_SPEED ) {
				vel.x -= SWIM_DECELERATION * dt;
				
				if ( vel.x < SWIM_SPEED )
					vel.x = SWIM_SPEED;
			}
			else if ( vel.x < SWIM_SPEED ) {
				vel.x += SWIM_ACCELERATION * dt;
				
				if ( vel.x > SWIM_SPEED )
					vel.x = SWIM_SPEED;
			}
		}
	}
	// Neither left nor right.
	else {
		// Slow to a stop:
		// Abovewater?
		if ( !isUnderwater() || !FLOAT_ON_WATER_SURFACE ) {
			if ( vel.x > 0 ) {
				vel.x -= WALK_DECELERATION * dt;
				
				if ( vel.x < 0 )
					vel.x = 0;
			}
			else if ( vel.x < 0 ) {
				vel.x += WALK_DECELERATION * dt;
				
				if ( vel.x > 0 )
					vel.x = 0;
			}
		}
		// Underwater?
		else {
			if ( vel.x > 0 ) {
				vel.x -= SWIM_DECELERATION * dt;
				
				if ( vel.x < 0 )
					vel.x = 0;
			}
			else if ( vel.x < 0 ) {
				vel.x += SWIM_DECELERATION * dt;
				
				if ( vel.x > 0 )
					vel.x = 0;
			}
		}
	}
	
	// 
	// Horizontal movement:
	// 
	accDX += vel.x * dt;
	float x1, y1, x2, y2;
	
	if ( accDX > 0 ) {
		// Look for collisions on the right side:
		x1 = topRightX();
		y1 = topRightY() + QAF_GEOM_EPSILON;
		x2 = botRightX();
		y2 = botRightY() - QAF_GEOM_EPSILON;
	}
	else {
		// Look for collisions on the left side:
		x1 = topLeftX();
		y1 = topLeftY() + QAF_GEOM_EPSILON;
		x2 = botLeftX();
		y2 = botLeftY() - QAF_GEOM_EPSILON;
	}
	
	float dx = (accDX < 0 ? -1.0f : 1.0f);
	while ( ABS(accDX) > 1.0f ) {
		// Flat floor?
		if ( !Environment::getLoadedRoom()->segmentCollision(
				x1 + dx, y1,
				x2 + dx, y2,
				false ) ) {
			// Just move it:
			pos.x += dx;
			x1 += dx;
			x2 += dx;
			
			accDX -= dx;
		}
		// 26-degree slope?
		else if ( !Environment::getLoadedRoom()->segmentCollision(
						x1 + dx, y1 - 0.5f,
						x2 + dx, y2 - 0.5f,
						false ) ) {
			// Move sideways and upwards, taking into account the climb factor:
			float scaledDX = dx * CLIMB_26_SLOPE_SLOWDOWN;
			pos.x += scaledDX;
			x1 += scaledDX;
			x2 += scaledDX;
			
			float scaledDY = -CLIMB_26_SLOPE_SLOWDOWN/2;
			pos.y += scaledDY;
			y1 += scaledDY;
			y2 += scaledDY;
			
			accDX -= dx;
		}
		// 45-degree slope?
		else if ( !Environment::getLoadedRoom()->segmentCollision(
						x1 + dx, y1 - 1.0f,
						x2 + dx, y2 - 1.0f,
						false ) ) {
			// Move sideways and upwards, taking into account the climb factor:
			float scaledDX = dx * CLIMB_45_SLOPE_SLOWDOWN;
			pos.x += scaledDX;
			x1 += scaledDX;
			x2 += scaledDX;
			
			float scaledDY = -CLIMB_45_SLOPE_SLOWDOWN;
			pos.y += scaledDY;
			y1 += scaledDY;
			y2 += scaledDY;
			
			accDX -= dx;
		}
		// Wall.
		else {
			vel.x = 0;
			accDX = 0;
			break;
		}
	}
	
	
	// 
	// Gravity/buoyancy:
	// 
	// Abovewater?
	if ( !isUnderwater() || !FLOAT_ON_WATER_SURFACE ) {
		// Increase speed downwards if the character is not standing on the floor.
		if ( !bottomContact )
			vel.y += GRAVITY * dt;
		
		// Keep speed within the allowed limit:
		if ( vel.y > MAX_FALL_SPEED )
			vel.y = MAX_FALL_SPEED;
		
		// 
		// Jumping:
		// 
		if ( inputJumpPress() && bottomContact ) {
			// If the player presses DOWN + JUMP on a thin-floor, fall through.
			// Here, I'm going to use a trick to detect thin-floors: Since they
			// won't trigger segment collisions if I tell the Room not to detect
			// them, the collision will return false if the player is standing on a
			// thin-floor.
			if ( inputDown() &&
				!Environment::getLoadedRoom()->segmentCollision(
					botLeftX(), botLeftY() + 1, botRightX(), botRightY() + 1, false ) ) {
				pos.y += 2;
				vel.y += 2;
			}
			else {
				// Jump!
				// Set the Y speed to the configured jump strength.
				// This will cause the character to start moving upwards.
				vel.y = -JUMP_STRENGTH;
			}
		}
		
		// When the player stops pressing the jump button, stop the jump:
		if ( !inputJump() && vel.y < 0 )
			vel.y = 0;
	}
	// Underwater?
	else {
		// Increase speed upwards if the character is not touching the ceiling.
		if ( !topContact )
			vel.y -= BUOYANCY * dt;
		
		// Keep speed within the allowed limit:
		if ( vel.y < -MAX_FLOAT_SPEED )
			vel.y = -MAX_FLOAT_SPEED;
		
		if ( vel.y > MAX_SINK_SPEED )
			vel.y = MAX_SINK_SPEED;
		
		// Prevent the player from "bouncing" on the water's surface:
		// If nothing is done, the player will surpass the water's surface and
		// exit the water, then Gravity will kick in and make him fall in
		// again, and so on. This looks horrible; it's better to leave the
		// "floating" effect to the character's animation, not the game logic.
		// So, here's what I'm going to do: If the player is *about* to leave the
		// water (i.e., at the current speed and height, he'll be out of the
		// water by the next frame)...
		if ( pos.y + vel.y * dt <= Environment::getLoadedRoom()->waterLevel + SUBMERSION_HEIGHT ) {
			// Set the player's position on the water's surface, and set the
			// speed to zero so he'll stop bouncing.
			pos.y = Environment::getLoadedRoom()->waterLevel + SUBMERSION_HEIGHT + QAF_GEOM_EPSILON;
			vel.y = 0;
			
			// Now, that last change on the player's position might have
			// caused the bottom segment to collide against the floor...
			while ( botCollision() && !topCollision() ) {
				pos.y -= QAF_GEOM_EPSILON;
			}
			
			// 
			// Water-jumping:
			// 
			// So, the player is on the water's surface. Check for a water-jump
			// here.
			if ( inputJumpPress() ) {
				// Jump!
				vel.y = -WATER_JUMP_STRENGTH;
			}
			
		}
	}
	
	// 
	// Vertical movement:
	// 
	if ( vel.y > 0 ) {
		// Fall, and check for a floor collision on the way.
		static Container<Vector2D> contacts;
		if ( Environment::getLoadedRoom()->segmentCollision(
				botLeftX(), botLeftY(),
				botRightX(), botRightY(),
				0, vel.y * dt, 
				true,
				&contacts, NULL, NULL ) ) {
			// A collision was found!
			// Set the Y coordinate to that point, and reset the Y speed.
			pos.y = contacts[0].y;
			vel.y = 0;
		}
		else {
			// No collision was found. Move!
			pos.y += vel.y * dt;
		}
	}
	else if ( vel.y < 0 ) {
		// Go up, and check for a ceiling collision on the way.
		static Container<Vector2D> contacts;
		if ( Environment::getLoadedRoom()->segmentCollision(
				topLeftX(), topLeftY(),
				topRightX(), topRightY(),
				0, vel.y * dt,
				false,
				&contacts, NULL, NULL ) ) {
			// A collision was found!
			// Set the Y coordinate to that point, and reverse the Y speed.
			pos.y = contacts[0].y + HEIGHT;
			vel.y = -vel.y / 3;
		}
		else {
			// No collision was found. Move!
			pos.y += vel.y * dt;
		}
	}
	
	
	// 
	// Stick to floor:
	// 
	// If the player was on the floor up until the last frame, and suddenly
	// found himself in the air...
	// Also, there will be no sticking to the floor when the player is
	// underwater, or he just jumped!
	if ( bottomContact && vel.y >= 0 && (!isUnderwater() || !FLOAT_ON_WATER_SURFACE) ) {
		// Maybe he's walking down a slope.
		// Look for the floor downwards, at least as far as the X speed (thus
		// taking into account slopes of 45 degrees).
		static Container<Vector2D> contacts;
		if ( Environment::getLoadedRoom()->segmentCollision(
				botLeftX(),  botLeftY(),
				botRightX(), botRightY(),
				0, ABS(vel.x * dt) + 1,
				true,
				&contacts, NULL, NULL ) ) {
			// Floor found! Move the player there:
			pos.y = contacts[0].y;
		}
	}
	
	
	// 
	// Set contact status:
	// 
	topContact = Environment::getLoadedRoom()->segmentCollision(
		topLeftX() , topLeftY()  - 1,
		topRightX(), topRightY() - 1,
		false );
	bottomContact = Environment::getLoadedRoom()->segmentCollision(
		botLeftX() , botLeftY()  + 1,
		botRightX(), botRightY() + 1,
		false );
	leftContact = Environment::getLoadedRoom()->segmentCollision(
		topLeftX()  - 1, topLeftY() + 1,
		botLeftX()  - 1, botLeftY() - 2,
		false );
	rightContact = Environment::getLoadedRoom()->segmentCollision(
		topRightX() + 1, topRightY() + 1,
		botRightX() + 1, botRightY() - 2,
		false );
	
	// Perform a "thin-floor test" now, using the bottom segment.
	// Also, allow the player to fall through the thin-floor if DOWN + JUMP was
	// pressed in this frame.
	if ( !inputJumpPress() &&
	     !bottomContact &&
		 vel.y >= 0 &&
	     Environment::getLoadedRoom()->segmentCollision(
			botLeftX() , botLeftY() - 1,
			botRightX(), botRightY() - 1,
			0, 2, true, NULL, NULL, NULL ) ) {
		bottomContact = true;
		vel.y = 0;
	}
	
	
	// Update the Y speed to keep it consistent.
	// However, it should only be updated if it is positive (downwards) and the
	// player isn't underwater. This will ensure the player won't be "flying
	// off" slopes when he gets to their top, while still preventing the "snap"
	// that always takes place when the player walks off a ledge.
	if ( pos.y > lastPos.y && (!isUnderwater() || !FLOAT_ON_WATER_SURFACE) ) {
		vel.y = (pos.y - lastPos.y) / dt;
	}
	
	// 
	// Collision structure:
	// 
	// Now that all the parameters have been calculated... update the collision
	// structure:
	platformerCollisionStruct.setX( pos.x - WIDTH/2 );
	platformerCollisionStruct.setY( pos.y - HEIGHT );
	platformerCollisionStruct.setWidth( WIDTH );
	platformerCollisionStruct.setHeight( HEIGHT );
	
	
	// 
	// Center screen on player:
	// 
	if ( CENTER_SCROLLING_ON_SELF ) {
		Vector2D oldScrolling = cameraPosition;
		Vector2D newScrolling = Vector2D(
			pos.x + CAMERA_DX,
			pos.y + CAMERA_DY );
		
		cameraVelocity *= CAMERA_INV_DRAG;
		cameraVelocity += ((newScrolling - oldScrolling) * CAMERA_ACCELERATION) / dt;
		
		cameraPosition += cameraVelocity * dt;
		
		Environment::centerScrollingPoint(
			(int) cameraPosition.x,
			(int) cameraPosition.y );
	}
}




void PlatformerObj::render ( int objLayer, float scrollX, float scrollY ) {
	// 
	// Placeholder:
	// 
	
	// Draw collision structure:
	platformerCollisionStruct.render( scrollX, scrollY, 0xFFFFFF00 );	
	
	
	// Draw contact bounds:
	hge->Gfx_RenderLine( botLeftX()  - scrollX, botLeftY()  - scrollY, botRightX() - scrollX, botRightY() - scrollY, (bottomContact ? 0xFFFF0000 : 0xFF00FFFF) );
	hge->Gfx_RenderLine( botRightX() - scrollX, botRightY() - scrollY, topRightX() - scrollX, topRightY() - scrollY, (rightContact  ? 0xFFFF0000 : 0xFF00FFFF) );
	hge->Gfx_RenderLine( topRightX() - scrollX, topRightY() - scrollY, topLeftX()  - scrollX, topLeftY()  - scrollY, (topContact    ? 0xFFFF0000 : 0xFF00FFFF) );
	hge->Gfx_RenderLine( topLeftX()  - scrollX, topLeftY()  - scrollY, botLeftX()  - scrollX, botLeftY()  - scrollY, (leftContact   ? 0xFFFF0000 : 0xFF00FFFF) );
	
	// Arrow in the direction the player is facing:
	if ( isFacingLeft ) {
		hge->Gfx_RenderLine(
			pos.x - WIDTH/2 + 4 - scrollX, pos.y - HEIGHT/2 - 4 - scrollY,
			pos.x - WIDTH/2     - scrollX, pos.y - HEIGHT/2     - scrollY,
			0xFF00FFFF );
		hge->Gfx_RenderLine(
			pos.x - WIDTH/2     - scrollX, pos.y - HEIGHT/2     - scrollY,
			pos.x - WIDTH/2 + 4 - scrollX, pos.y - HEIGHT/2 + 4 - scrollY,
			0xFF00FFFF );
	}
	else {
		hge->Gfx_RenderLine(
			pos.x + WIDTH/2 - 4 - scrollX, pos.y - HEIGHT/2 - 4 - scrollY,
			pos.x + WIDTH/2     - scrollX, pos.y - HEIGHT/2     - scrollY,
			0xFF00FFFF );
		hge->Gfx_RenderLine(
			pos.x + WIDTH/2     - scrollX, pos.y - HEIGHT/2     - scrollY,
			pos.x + WIDTH/2 - 4 - scrollX, pos.y - HEIGHT/2 + 4 - scrollY,
			0xFF00FFFF );
	}
}




CollisionStruct * PlatformerObj::getCollisionStruct () {
	return &platformerCollisionStruct;
}
