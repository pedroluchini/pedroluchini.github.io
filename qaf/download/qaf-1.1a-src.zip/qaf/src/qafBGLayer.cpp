/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafBGLayer.h>

#include <qafEnvironment.h>


using namespace qaf;
using namespace std;

BGLayer::BGLayer ( string _sourceImagePath, int _tileWidth, int _tileHeight, float _parallaxFactorX, float _parallaxFactorY, int _translateX, int _translateY, int _rows, int _columns )
	: bgData( _rows, _columns ),
	  tileWidth( _tileWidth ),
	  tileHeight( _tileHeight ),
	  parallaxFactorX( _parallaxFactorX ),
	  parallaxFactorY( _parallaxFactorY )
{	
	translateX     = _translateX;
	translateY     = _translateY;
	
	// Load the tile library texture from disk:
	libTexture = Environment::loadBigTexture( _sourceImagePath.c_str() );
	
} // End of method: BGLayer::BGLayer





BGLayer::~BGLayer () {
	// Release the tile library:
	Environment::freeBigTexture( libTexture );
}




void BGLayer::render ( int x, int y ) {
	// Clip hidden tiles:
	// Calculate which portions of the tile matrix are visible:
	int startRow = MAX( 0,              (int) ((-y * parallaxFactorY - translateY) / tileHeight));
	int startCol = MAX( 0,              (int) ((-x * parallaxFactorX - translateX) / tileWidth) );
	int endRow   = MIN( bgData.rows,    (int) ((-y * parallaxFactorY + Environment::getScreenHeight() - translateY) / tileHeight) + 1); // startRow + (Environment::getScreenHeight() / tileHeight) + 2 );
	int endCol   = MIN( bgData.columns, (int) ((-x * parallaxFactorX + Environment::getScreenWidth()  - translateX) / tileWidth)  + 1); // startCol + (Environment::getScreenWidth()  / tileWidth ) + 2 );
	
	// Iterate over the bgData matrix:
	for ( int i = startRow; i < endRow; i++ ) {
		for ( int j = startCol; j < endCol; j++ ) {
			int tileID = bgData.cell(i, j);
			
			// Ignore "blank tiles":
			if ( tileID != -1 ) {
				// Flip status:
				bool flipX = (tileID & QAF_TILE_FLIPPED_X_MASK ? true : false);
				bool flipY = (tileID & QAF_TILE_FLIPPED_Y_MASK ? true : false);
				tileID &= (~QAF_TILE_FLIPPED_X_MASK);
				tileID &= (~QAF_TILE_FLIPPED_Y_MASK);
				
				// Calculate this tile's position in the tile library:
				int tileRow = (tileID * tileWidth) / libTexture->getImageWidth();
				int tileCol = tileID % (libTexture->getImageWidth() / tileWidth);
				
				// Calculate the four vertices' coordinates:
				int left = (translateX + (int) (parallaxFactorX * x) + j * tileWidth);
				int top  = (translateY + (int) (parallaxFactorY * y) + i * tileHeight);
				
				// Render the tile:
				libTexture->renderRectangle(
					left, top,
					tileCol * tileWidth, tileRow * tileHeight,
					tileWidth, tileHeight,
					0xFFFFFFFF,
					2,
					flipX, flipY );
				
			}
		}
	}
	
} // End of method: BGLayer::render
