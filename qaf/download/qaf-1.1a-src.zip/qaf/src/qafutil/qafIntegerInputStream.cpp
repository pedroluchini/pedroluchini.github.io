/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafutil/qafIntegerInputStream.h>

using namespace qaf;
using namespace std;


#define B_00000001 0x01u
#define B_00000011 0x03u
#define B_00000111 0x07u
#define B_00001111 0x0Fu
#define B_00011111 0x1Fu
#define B_00111111 0x3Fu
#define B_10000000 0x80u
#define B_11000000 0xC0u
#define B_11100000 0xE0u
#define B_11110000 0xF0u
#define B_11111000 0xF8u
#define B_11111100 0xFCu
#define B_11111110 0xFEu
#define B_11111111 0xFFu



IntegerInputStream::IntegerInputStream ( const char * filename )
: HgeInputStream( filename )
{
	// Nothing to do here.
}




bool IntegerInputStream::canRead () {
	return HgeInputStream::canRead();
}




int IntegerInputStream::readInt () {
	// Get the "header" byte:
	int b = nextByte();
	
	// 11111111?
	if ( b == B_11111111 ) {
		// The next integer is a negative number:
		return -readInt();
	}
	// 0xxxxxxx?
	if ( (b & B_10000000) == 0 ) {
		// ASCII:
		return b;
	}
	// 10xxxxxx?
	else if ( (b & B_11000000) == B_10000000 ) {
		// Error! Encoded integers cannot start with "10xxxxxx"!
		throw EncodingException();
	}
	// 110xxxxx?
	else if ( (b & B_11100000) == B_11000000 ) {
		// Two-byte sequence:
		int result = 0;
		
		// 110xxxxx 10xxxxxx
		result += (b & B_00011111) << 6;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 0;
		
		return result;
	}
	// 1110xxxx?
	else if ( (b & B_11110000) == B_11100000 ) {
		// Three-byte sequence:
		int result = 0;
		
		// 1110xxxx 10xxxxxx 10xxxxxx
		result += (b & B_00001111) << 12;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 6;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 0;
		
		return result;
	}
	// 11110xxx?
	else if ( (b & B_11111000) == B_11110000 ) {
		// Four-byte sequence:
		int result = 0;
		
		// 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx 
		result += (b & B_00000111) << 18;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 12;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 6;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 0;
		
		return result;
	}
	// 111110xx?
	else if ( (b & B_11111100) == B_11111000 ) {
		// Five-byte sequence:
		int result = 0;
		
		// 111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 
		result += (b & B_00000011) << 24;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 18;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 12;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 6;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 0;
		
		return result;
	}
	// 1111110x?
	else if ( (b & B_11111110) == B_11111100 ) {
		// Six-byte sequence:
		int result = 0;
		
		// 1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 
		result += (b & B_00000001) << 30;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 24;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 18;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 12;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 6;
		
		b = nextByte();
		if ( (b & B_11000000) != B_10000000 ) throw EncodingException();
		else result += (b & B_00111111) << 0;
		
		return result;
	}
	else
		throw EncodingException();
} // End of function: readInt




string IntegerInputStream::readNullTerminatedString () {
	string str = "";
	int b;
	
	while ( true ) {
		b = readInt();
		if ( b == 0 )
			break;
		else
			str += (char) b;
	}
	
	return str;
} // End of function: readNullTerminatedString




IntegerInputStream::~IntegerInputStream () {}
	


int IntegerInputStream::nextByte () {
	int b = HgeInputStream::getC();
	
	if ( b == -1 )
		throw EndOfFileException();
	else
		return b;
}
