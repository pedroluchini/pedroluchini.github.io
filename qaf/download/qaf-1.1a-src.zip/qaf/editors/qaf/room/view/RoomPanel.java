package qaf.room.view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.HierarchyBoundsAdapter;
import java.awt.event.HierarchyEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

import qaf.room.control.HistoryManager;
import qaf.room.control.Main;
import qaf.room.control.UndoImpl;
import qaf.room.control.UndoOperation;
import qaf.room.model.BGLayer;
import qaf.room.model.GameObj;
import qaf.room.model.Room;

/**
 * "Canvas coordinates" refers to the actual canvas coordinates, ignoring
 * the scroll and zoom factors.
 * 
 * "Room coordinates" refers to the virtual pixels in the Room (relative to
 * its top-left corner) and considers zooming. 
 */
public class RoomPanel extends JPanel {
	
	/**
	 * The color that is painted onto the edges of the canvas that are not
	 * covered by the displayed room.
	 */
	public static final Color BG_COLOR = new Color( 0, 0, 60 );
	
	/**
	 * The color used to render the current brush outline around the mouse.
	 */
	public static final Color BRUSH_CURSOR_COLOR = new Color( 255, 255, 0, 127 );
	
	/** "Scrolling arrows" are painted on all sides where scrolling is
	 * possible. */
	public static final int   SCROLL_ARROW_SIZE  = 10;
	public static final Color SCROLL_ARROW_COLOR = Color.BLUE;
	
	/** - "Normal" state: Click to set or get tiles from the layer.
	 *  - "Object insertion" state: User is positioning a newly-created object
	 *      in the room. 
	 *  - "Object drag" state: User is dragging an object across the room.
	 *  - "Menu" state: A pop-up menu has been displayed on the canvas. Ignore
	 *      all events until it is gone. */
	public static final int   STATE_NORMAL     = 0,
	                          STATE_OBJ_INSERT = 1,
	                          STATE_OBJ_DRAG   = 2,
	                          STATE_MENU       = 3;
	
	/** The limit of the zoom: */
	public static final float ZOOM_IN_LIMIT = 2, ZOOM_OUT_LIMIT = .5f;
	
	/** Scaling applied to the room before it is drawn: */
	float zoomFactor = 1;
	
	/**
	 * The "scrolling point" indicates where the room's top-left corner
	 * will be drawn, relative to the canvas' top-left corner.
	 * (Canvas coordinates)
	 */
	int scrollX = 0, scrollY = 0;
	
	/**
	 * The "scrolling boundary" is the space where the scrolling point is
	 * allowed move.
	 */
	int scrollBoundLeft, scrollBoundRight, scrollBoundTop, scrollBoundBottom;
	public boolean isScrollingBoundaryValid = false;
	
	/** Keeps track of the currently highlighted/selected object. */
	public GameObj selectedObj = null;
	
	/** This variable is used to keep track of the current state (STATE_NORMAL,
	 * STATE_OBJ_INSERT, STATE_OBJ_DRAG). */
	public int state = STATE_NORMAL;
	
	
	/**
	 * Nested class: All-purpose user interface listener
	 */
	class RPUIListener implements MouseListener, MouseMotionListener, MouseWheelListener {
		
		public void mouseClicked ( MouseEvent evt ) {
			if ( evt.getButton() == MouseEvent.BUTTON3 ) {
				// Right-click over an object?
				if ( selectedObj != null && state == STATE_NORMAL ) {
					// Pop up a menu with some options for the object:
					state = STATE_MENU;
					JPopupMenu menu = new JPopupMenu();
					
					JMenuItem item = new JMenuItem( "Delete this object" );
					item.addActionListener( new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								// Store the UndoOperation before removing:
								UndoOperation op = new UndoImpl.DeleteObjectOperation (
									Main.loadedRoom.gameObjects.indexOf( selectedObj ),
									selectedObj );
								HistoryManager.addUndoOperation( op, "delete game object" );
								
								// Remove the object:
								Main.loadedRoom.gameObjects.remove( selectedObj );
								selectedObj.highlighted = false;
								selectedObj = null;
								state = STATE_NORMAL;
								MainLayout.rebuildUI();
								
								Main.unsavedChanges = true;
							}
						} );
					menu.add( item );
					
					item = new JMenuItem( "Edit this object" );
					item.addActionListener( new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								// Pop up a dialog to edit the object:
								GameObj newObj = EditGameObjDialog.editGameObj( selectedObj );
								
								// User confirmed?
								if ( newObj != null ) {
									// Replace the old object with the new object:
									int index = Main.loadedRoom.gameObjects.indexOf( selectedObj );
									Main.loadedRoom.gameObjects.set( index, newObj );
									
									// Commit UndoOperation
									UndoOperation op = new UndoImpl.EditObjectOperation (
										selectedObj,
										newObj );
									HistoryManager.addUndoOperation( op, "edit object" );
									
									// Get rid of the old object...
									selectedObj.highlighted = false;
									selectedObj = null;
									
									// Update to show changes:
									MainLayout.canvas.repaint();
									
									Main.unsavedChanges = true;
								}
							}
						} );
					menu.add( item );
					
					item = new JMenuItem( "Clone this object" );
					item.addActionListener( new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								// Create copy of the object:
								GameObj newObj = new GameObj( selectedObj.id );
								
								for ( int i = 0; i < selectedObj.attributeTable.size(); i++ ) {
									String key = selectedObj.attributeTable.getKey( i );
									String value = selectedObj.attributeTable.getValue( i );
									
									newObj.attributeTable.putPair( key, value );
								}
								
								// Add the new object to the room and update the UI:
								newObj.x = (int) (-scrollX / zoomFactor) + (Main.loadedRoom.screenWidth  * Main.loadedRoom.blockSize / 2);;
								newObj.y = (int) (-scrollY / zoomFactor) + (Main.loadedRoom.screenHeight * Main.loadedRoom.blockSize / 2);;
								Main.loadedRoom.gameObjects.add( 0, newObj );
								Main.loadedRoom.getBGLayer( -1 ).isHidden = false;
								MainLayout.rebuildUI();
								
								// Let the RoomCanvas handle the positioning of the new
								// object:
								startGameObjPositioning( newObj );
								
								// Commit UndoOperation:
								UndoOperation op = new UndoImpl.CreateObjectOperation( 
									Main.loadedRoom.gameObjects.indexOf( newObj ),
									newObj );
								HistoryManager.addUndoOperation( op, "clone game object" );
								
								Main.unsavedChanges = true;
							}
						} );
					menu.add( item );
					
					item = new JMenuItem( "To front" );
					item.setMnemonic( KeyEvent.VK_F );
					item.addActionListener( new ActionListener () {
						public void actionPerformed ( ActionEvent evt ) {
							// Store the UndoOperation:
							UndoOperation op = new UndoImpl.ChangeObjectDepthOperation (
								Main.loadedRoom.gameObjects.indexOf( selectedObj ),
								0 );
							HistoryManager.addUndoOperation( op, "bring object to front" );
							
							// Place the object at the beginning of the list: 
							Main.loadedRoom.gameObjects.remove( selectedObj );
							Main.loadedRoom.gameObjects.add( 0, selectedObj );
							state = STATE_NORMAL;
							
							Main.unsavedChanges = true;
							
							repaint();
						} } );
					menu.add( item );
					
					item = new JMenuItem( "To back" );
					item.setMnemonic( KeyEvent.VK_B );
					item.addActionListener( new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								// Store the UndoOperation:
								UndoOperation op = new UndoImpl.ChangeObjectDepthOperation (
									Main.loadedRoom.gameObjects.indexOf( selectedObj ),
									Main.loadedRoom.gameObjects.size() - 1 );
								HistoryManager.addUndoOperation( op, "send object to back" );
								
								// Place the object at the tail of the list:
								Main.loadedRoom.gameObjects.remove( selectedObj );
								Main.loadedRoom.gameObjects.add( selectedObj );
								state = STATE_NORMAL;
								
								Main.unsavedChanges = true;
								
								repaint();
							}
						} );
					menu.add( item );
					
					menu.add( new JSeparator() );
					
					item = new JMenuItem( "Cancel" );
					item.addActionListener( new ActionListener () {
						public void actionPerformed ( ActionEvent evt ) {
							state = STATE_NORMAL;
							repaint();
						} } );
					menu.add( item );
					
					// Ensure state change when the menu disappears.
					menu.addPopupMenuListener( new PopupMenuListener() {
						public void popupMenuCanceled( PopupMenuEvent evt ) {}
						public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
							state = STATE_NORMAL;
							repaint();
						}
						public void popupMenuWillBecomeVisible(PopupMenuEvent e) {}
					} );
					
					// Show the menu on the mouse's coordinates:
					menu.show( MainLayout.canvas, mouseX, mouseY );
				}
			}
		}

		public void mouseEntered ( MouseEvent evt ) {
			mouseOutside = false;
			mouseMoved( evt );
		}

		public void mouseExited ( MouseEvent evt ) {
			MainLayout.statusBar.setText( " " );
			mouseOutside = true;
			repaint();
		}

		public void mousePressed ( MouseEvent evt ) {
			// Ignore pressing more than one button:
			if ( leftPress || rightPress )
				return;
			
			if ( evt.getButton() == MouseEvent.BUTTON1 )
				leftPress = true;
			else if ( evt.getButton() == MouseEvent.BUTTON3 )
				rightPress = true;
			
			mouseX = evt.getX();
			mouseY = evt.getY();
			
			// Left-button mouse click:
			if ( leftPress ) {
				// When the user clicks during an object insertion, fix the 
				// object's position and exit the insertion state.
				if ( state == STATE_OBJ_INSERT ) {
					selectedObj.x = canvasToRoomX( mouseX );
					selectedObj.y = canvasToRoomY( mouseY );
					
					state = STATE_OBJ_DRAG;
					selectedObj.highlighted = true;
				}
				// Simple click: 
				else if ( !evt.isControlDown() ) {
					// Have we clicked on an object? Ignore if the obstacle
					// layer is invisible.
					GameObj gameObj = checkMouseOverObjects( mouseX, mouseY );
					if ( gameObj != null && !Main.loadedRoom.getBGLayer(-1).isHidden ) {
						// De-select what was previously selected:
						if ( selectedObj != null )
							selectedObj.highlighted = false;
						
						// Select it and start dragging...
						selectedObj = gameObj;
						selectedObj.highlighted = true;
						state = STATE_OBJ_DRAG;
						
						// Store the object's old position, for the sake of 
						// UndoOperations:
						oldObjectPos = new Point( selectedObj.x, selectedObj.y );
					}
					// Didn't click on an object:
					else {
						// Set tile on working BG layer:
						int layerInx = MainLayout.getWorkingLayer();
						
						// Store the layer's old data, for the sake of
						// UndoOperations:
						oldBGData = Main.cloneArray( Main.loadedRoom.getBGData( layerInx ) );
						
						Main.loadedRoom.setTile(
							layerInx,
							(int) (mouseX / zoomFactor),  (int) (mouseY / zoomFactor),
							(int) (scrollX / zoomFactor), (int) (scrollY / zoomFactor), 
							((BGPanel) MainLayout.bgLayers.getSelectedComponent()).brush );
						
						Main.unsavedChanges = true;
						
						// Unhide it:
						if ( Main.loadedRoom.getBGLayer( layerInx ).isHidden ) {
							Main.loadedRoom.getBGLayer( layerInx ).isHidden = false;
							((BGPanel) MainLayout.bgLayers.getComponent( layerInx + 1 )).hideCheckBox.setSelected( false );
						}
					}
				}
				// Ctrl + left click:
				else {
					// Not a drawing operation:
					oldBGData = null;
					
					doSelectTile( evt );
				}
			}
			
			Main.updateCursors();
			repaint();
		}

		public void mouseReleased ( MouseEvent evt ) {
			if ( evt.getButton() == MouseEvent.BUTTON1 )
				leftPress = false;
			else if ( evt.getButton() == MouseEvent.BUTTON3 )
				rightPress = false;
			
			// Released left mouse button?
			if ( evt.getButton() == MouseEvent.BUTTON1 ) {
				// Are we dragging an object?
				if ( state == STATE_OBJ_DRAG ) {
					// Commit UndoOperation:
					if ( oldObjectPos != null ) {
						UndoOperation op = new UndoImpl.MoveObjectOperation (
							selectedObj,
							oldObjectPos,
							new Point(selectedObj.x, selectedObj.y) );
						HistoryManager.addUndoOperation( op, "move object" );
						
						Main.unsavedChanges = true;
					}
					
					// Release dragged object
					state = STATE_NORMAL;
					selectedObj.highlighted = false;
					selectedObj = checkMouseOverObjects( mouseX, mouseY );
					if ( selectedObj != null ) {
						selectedObj.highlighted = true;
					}
					oldObjectPos = null;
					
				}
				// Released during drawing tiles?
				else if ( state == STATE_NORMAL ) {
					if ( oldBGData != null ) {
						// Commit UndoOperation to the HistoryManager:
						int layerInx = MainLayout.getWorkingLayer();
						String descr = "drawing on " + (layerInx == -1 ? "obstacle layer" : "layer " + layerInx); 
						
						UndoOperation op = new UndoImpl.BGLayerDrawingOperation(
							layerInx,
							oldBGData,
							Main.loadedRoom.getBGData( layerInx ) );
						HistoryManager.addUndoOperation( op, descr );
						
						Main.unsavedChanges = true;
					}
				}
			}
			
			Main.updateCursors();
			repaint();
		}

		public void mouseDragged ( MouseEvent evt ) {
			int newX = evt.getX(), newY = evt.getY();
			
			// Right-button drag: Scroll screen
			if ( rightPress ) {
				scrollX += (newX - mouseX);
				scrollY += (newY - mouseY);
				
				// Check boundaries:
				enforceScrollingBoundaries();
				
				// Are we inserting a new object?
				if ( state == STATE_OBJ_INSERT ) {
					selectedObj.x = canvasToRoomX( newX );
					selectedObj.y = canvasToRoomY( newY );
				}
			}
			
			// Left-button drag:
			if ( leftPress ) {
				// Drag object? 
				if ( state == STATE_OBJ_DRAG ) {
					// For the UndoOperation:
					if ( oldObjectPos == null )
						oldObjectPos = new Point( selectedObj.x, selectedObj.y );
					
					// Update object position:
					selectedObj.x = canvasToRoomX( newX );
					selectedObj.y = canvasToRoomY( newY );
					
					Main.unsavedChanges = true;
					
					// Prevent object from leaving the room:
					if ( selectedObj.x < 0 )
						selectedObj.x = 0;
					else if ( selectedObj.x > Main.loadedRoom.getPixelWidth() )
						selectedObj.x = Main.loadedRoom.getPixelWidth();
					if ( selectedObj.y < 0 )
						selectedObj.y = 0;
					else if ( selectedObj.y > Main.loadedRoom.getPixelHeight() )
						selectedObj.y = Main.loadedRoom.getPixelHeight();
					
					MainLayout.statusBar.setText( "Px: " + canvasToRoomX(newX) + ", " + canvasToRoomY(mouseY) );
				}
				else {
					// Ctrl + click: Get tile
					if ( evt.isControlDown()) {
						doSelectTile( evt );
					}
					// Normal click: Set tiles in a straight line
					else {
						int layerInx = MainLayout.getWorkingLayer();
						Main.loadedRoom.setTilesInLine(
							layerInx,                                                  // active layer
							(int) (mouseX / zoomFactor),  (int) (mouseY / zoomFactor), // from
							(int) (newX / zoomFactor),    (int) (newY / zoomFactor),   // to
							(int) (scrollX / zoomFactor), (int) (scrollY / zoomFactor),   
							((BGPanel) MainLayout.bgLayers.getSelectedComponent()).brush );
						
						MainLayout.statusBar.setText( "Px: " + canvasToRoomX(mouseX) + ", " + canvasToRoomY(mouseY) );
						
						// Unhide it:
						if ( Main.loadedRoom.getBGLayer( layerInx ).isHidden ) {
							Main.loadedRoom.getBGLayer( layerInx ).isHidden = false;
							((BGPanel) MainLayout.bgLayers.getComponent( layerInx + 1 )).hideCheckBox.setSelected( false );
						}
					}
				}
			}
			
			mouseX = newX;
			mouseY = newY;
			
			repaint();
			Main.updateCursors();
		}

		public void mouseMoved ( MouseEvent evt ) {
			mouseX = evt.getX();
			mouseY = evt.getY();
			
			// Just in case... 
// TODO			if ( state != STATE_OBJ_INSERT && state != STATE_MENU ) {
//				state = STATE_NORMAL;
//				if ( selectedObj != null ) {
//					selectedObj.highlighted = false;
//					selectedObj = null;
//				}
//			}
			
			// Are we inserting a new object?
			if ( state == STATE_OBJ_INSERT ) {
				selectedObj.x = canvasToRoomX( mouseX );
				selectedObj.y = canvasToRoomY( mouseY );
				
				// Prevent object from leaving the room:
				if ( selectedObj.x < 0 )
					selectedObj.x = 0;
				else if ( selectedObj.x > Main.loadedRoom.getPixelWidth() )
					selectedObj.x = Main.loadedRoom.getPixelWidth();
				if ( selectedObj.y < 0 )
					selectedObj.y = 0;
				else if ( selectedObj.y > Main.loadedRoom.getPixelHeight() )
					selectedObj.y = Main.loadedRoom.getPixelHeight();
			}
			else {
				// Display the mouse coordinates, and highlight
				// objects "on mouse over"
				if ( !rightPress && !evt.isControlDown() ) {
					 int pxX = canvasToRoomX(mouseX), pxY = canvasToRoomY(mouseY);
					 MainLayout.statusBar.setText( "Px: " + pxX + ", " + pxY );

					// Test for "mouseOver" only if a menu is not displayed!
					if ( state != STATE_MENU ) {
						// Un-select whatever was selected first...
						if ( selectedObj != null ) {
							selectedObj.highlighted = false;
							selectedObj = null;
						}
						
						// Select object if there is "mouse over":
						GameObj gameObj = checkMouseOverObjects( mouseX, mouseY );
						if ( gameObj != null ) {
							selectedObj = gameObj;
							selectedObj.highlighted = true;
						}
					}
				}
			}
			
			Main.updateCursors();
			repaint();
		}
		
		public void mouseWheelMoved ( MouseWheelEvent evt ) {
			// Up or down?
			if ( evt.getWheelRotation() < 0 ) {
				// UP!
				
				// Zoom in.
				MainLayout.zoomInMenuItem.doClick();
			}
			else {
				// DOWN!
				
				// Zoom in.
				MainLayout.zoomOutMenuItem.doClick();
			}
		}
		
		
		/** Auxiliary method: Check for "mouse over" on all objects:
		 * Returns null if no object was found. (Canvas coordinates) */
		private GameObj checkMouseOverObjects ( int x, int y ) {
			for ( int i = Main.loadedRoom.gameObjects.size() - 1; i >= 0; i-- ) {
				GameObj gameObj = (GameObj) Main.loadedRoom.gameObjects.get( i );
				if ( gameObj.hasPoint( canvasToRoomX( mouseX ), canvasToRoomY( mouseY ) ) )
					return gameObj;
			}
			
			return null;
		}
		
		
		/** Auxiliary method: Selects a tile from the room, based on the
		 * MouseEvent received. */
		void doSelectTile ( MouseEvent evt ) {
			BGPanel workingLayerPanel = (BGPanel) MainLayout.bgLayers.getSelectedComponent();
			BGLayer bgLayer = Main.loadedRoom.getBGLayer(MainLayout.getWorkingLayer());
			
			// Get tile from working layer:
			try {
				int sMouseX = (int) (mouseX / zoomFactor);
				int sMouseY = (int) (mouseY / zoomFactor);
				int sScrollX = (int) (scrollX / zoomFactor);
				int sScrollY = (int) (scrollY / zoomFactor);
				
				int pickedTileID = Main.loadedRoom.getTile(
					MainLayout.getWorkingLayer(),
					sMouseX,  sMouseY,
					sScrollX, sScrollY );
				
				int tileRow = (int) ((sMouseY - sScrollY * bgLayer.parallaxFactorY) - bgLayer.translateY) / bgLayer.tileHeight; 
				int tileCol = (int) ((sMouseX - sScrollX * bgLayer.parallaxFactorX) - bgLayer.translateX) / bgLayer.tileWidth;
				
				// All right, we've got the tile...
				// Starting a new selection?
				if (workingLayerPanel.lastSelectionOnPanel ||
				    (!evt.isShiftDown() && !evt.isAltDown())) {
					if (workingLayerPanel.brush.length != 1 || workingLayerPanel.brush[0].length != 1) {
						workingLayerPanel.brush = new int[1][1];
					}
					workingLayerPanel.brush[0][0] = pickedTileID;
					workingLayerPanel.brushStartRow = tileRow;
					workingLayerPanel.brushStartCol = tileCol;
					
					workingLayerPanel.lastSelectionOnPanel = false;
					workingLayerPanel.bgPicker.repaint();
				}
				// Extending the existing selection:
				else {
					// Set/unset the tile:
					if (!evt.isAltDown())
						workingLayerPanel.setTileInBrush(pickedTileID, tileRow - workingLayerPanel.brushStartRow, tileCol - workingLayerPanel.brushStartCol);
					else
						workingLayerPanel.unsetTileInBrush(tileRow - workingLayerPanel.brushStartRow, tileCol - workingLayerPanel.brushStartCol);
				}
				
				workingLayerPanel.bgPicker.repaint();
			}
			catch ( ArrayIndexOutOfBoundsException exc ) {
				// Coordinates outside of the data matrix. Ignore.
			}
		}
		
	}
	
	
	/**
	 * Constructor:
	 */
	public RoomPanel () {
		super();
		
		// A HierarchyBoundsListener is necessary to receive a notification 
		// when the Canvas is resized.
		addHierarchyBoundsListener( new HierarchyBoundsAdapter () {
				public void ancestorResized ( HierarchyEvent e ) {
					// Invalidate the current backBuffer. Next time paint() is
					// called, it will re-create it with the proper size.
					backBuffer = null;
					
					// Recalculate scrolling bounds:
					isScrollingBoundaryValid = false;
				}
			} );
		
		// Listen for mouse events:
		RPUIListener rcuil = new RPUIListener();
		addMouseListener( rcuil );
		addMouseMotionListener( rcuil );
		addMouseWheelListener( rcuil );
		
	}	
	
	
	
	/**
	 * The backBuffer is an Image whose dimensions are the canvas', halved
	 * down. The Room will be drawn here, and then scaled by the zoom factor to
	 * be drawn onto the actual canvas.
	 */
	Image backBuffer = null;
	
	
	
	/**
	 * Displays the loaded room.
	 */
	public void paint ( Graphics g ) {
		// Create backBuffer if it has not been created yet:
		if ( backBuffer == null ) {
			backBuffer = createImage(
				(int) Math.ceil( getWidth()  / (float) zoomFactor ),
				(int) Math.ceil( getHeight() / (float) zoomFactor ) );
		}
		
		// Calculate scrolling bounds if they were not calculated yet:
		if ( !isScrollingBoundaryValid ) {
			calculateScrollingBounds();
			enforceScrollingBoundaries();
			isScrollingBoundaryValid = true;
		}
		
		// All drawing operations are performed on the backBuffer:
		Graphics bufferGraphics = backBuffer.getGraphics();
		
		bufferGraphics.setColor( BG_COLOR );
		bufferGraphics.fillRect( 0, 0, backBuffer.getWidth(Main.f), backBuffer.getHeight(Main.f) );
		
		// Ask the currently loaded room to draw itself onto the backBuffer:
		Main.loadedRoom.draw(
			bufferGraphics,
			(int) (scrollX/zoomFactor), (int) (scrollY/zoomFactor) );
		
		// 
		// Draw the brush outline for the working layer.
		// 
		BGPanel bgPanel = (BGPanel) MainLayout.bgLayers.getSelectedComponent(); 
		int[][] brush = bgPanel.brush;
		BGLayer bgLayer = Main.loadedRoom.getBGLayer( bgPanel.layerInx );
		
		// Calculate mouse's position within the BG layer's matrix:
		int mouseI = (int) (mouseY/zoomFactor - scrollY * bgLayer.parallaxFactorY / zoomFactor - bgLayer.translateY) / bgLayer.tileHeight;
		int mouseJ = (int) (mouseX/zoomFactor - scrollX * bgLayer.parallaxFactorX / zoomFactor - bgLayer.translateX) / bgLayer.tileWidth;
		int mouseLeftJ = mouseJ - brush[0].length/2;
		int mouseTopI = mouseI - brush.length/2;
		
		for ( int i = 0; i < brush.length; i++ ) {
			int baseY = (int) (bgLayer.parallaxFactorY * scrollY / zoomFactor + bgLayer.translateY);
			int cursorY = baseY + (mouseTopI + i) * bgLayer.tileHeight;
			int selectY = baseY + (bgPanel.brushStartRow + i) * bgLayer.tileHeight;
			
			for ( int j = 0; j < brush[0].length; j++ ) {
				if ( brush[i][j] != BGPanel.BRUSH_FREE_CELL_ID ) {
					int baseX = (int) (bgLayer.parallaxFactorX * scrollX / zoomFactor + bgLayer.translateX);
					int cursorX = baseX + (mouseLeftJ + j) * bgLayer.tileWidth;
					int selectX = baseX + (bgPanel.brushStartCol + j) * bgLayer.tileWidth;
					
					// Draw selected tiles' outline?
					if ( !bgPanel.lastSelectionOnPanel ) {
						Graphics2D g2D = (Graphics2D) bufferGraphics;
						
						bufferGraphics.setColor( BGPanel.SELECTED_TILE_COLOR );
						Stroke oldStroke = g2D.getStroke();
						g2D.setStroke( StrokeTimer.getCurrent() );
						
						// Draw lines:
						if ( j == 0 || brush[i][j - 1] == BGPanel.BRUSH_FREE_CELL_ID )
							g2D.drawLine(
								selectX, -1 + selectY,
								selectX, +1 + selectY + bgLayer.tileHeight );
						if ( j == brush[i].length - 1 || brush[i][j + 1] == BGPanel.BRUSH_FREE_CELL_ID )
							g2D.drawLine(
								selectX + bgLayer.tileWidth, -1 + selectY,
								selectX + bgLayer.tileWidth, +1 + selectY + bgLayer.tileHeight );
						if ( i == 0 || brush[i - 1][j] == BGPanel.BRUSH_FREE_CELL_ID )
							g2D.drawLine(
								-1 + selectX,                     selectY,
								+1 + selectX + bgLayer.tileWidth, selectY );
						if ( i == brush.length - 1 || brush[i + 1][j] == BGPanel.BRUSH_FREE_CELL_ID )
							g2D.drawLine(
								-1 + selectX,                     selectY + bgLayer.tileHeight,
								+1 + selectX + bgLayer.tileWidth, selectY + bgLayer.tileHeight );
						
						g2D.setStroke( oldStroke );
						
					}
					
					// Draw cursor outline?
					if ( !mouseOutside && !Main.ctrlDown && !rightPress && selectedObj == null ) {
						bufferGraphics.setColor( BRUSH_CURSOR_COLOR );
						bufferGraphics.fillRect(
							cursorX, cursorY,
							bgLayer.tileWidth, bgLayer.tileHeight );
					}
				}
			}
		}
		
		// Draw scroll arrows where needed:
		drawScrollArrows( bufferGraphics );
		
		// Transfer to the canvas:
		g.drawImage(
			backBuffer,
			0, 0,
			(int) (backBuffer.getWidth(Main.f) * zoomFactor), (int) (backBuffer.getHeight(Main.f) * zoomFactor),
			Main.f );
		
		// Draw grid if needed:
		if ( MainLayout.showGrid.isSelected() ) {
			int x = (int) (scrollX/zoomFactor);
			int y = (int) (scrollY/zoomFactor);
			int activeLayer = MainLayout.getWorkingLayer();
			
			// Calculate grid size, according to the active layer:
			int   gridWidth  = Main.loadedRoom.getBGLayer( activeLayer ).tileWidth;
			int   gridHeight = Main.loadedRoom.getBGLayer( activeLayer ).tileHeight;
			int translateX   = Main.loadedRoom.getBGLayer( activeLayer ).translateX;
			int translateY   = Main.loadedRoom.getBGLayer( activeLayer ).translateY;
			float parallaxX  = Main.loadedRoom.getBGLayer( activeLayer ).parallaxFactorX;
			float parallaxY  = Main.loadedRoom.getBGLayer( activeLayer ).parallaxFactorY;
			int[][] matrix   = Main.loadedRoom.getBGData( activeLayer );
			
			// Tile grid:
			MainLayout.drawGrid(
				g,
				(int) (zoomFactor * (translateX + (int) (parallaxX * x))),
				(int) (zoomFactor * (translateY + (int) (parallaxY * y))),
				matrix.length, matrix[0].length,
				(int) (zoomFactor * gridWidth),
				(int) (zoomFactor * gridHeight),
				Integer.MAX_VALUE,
				Room.TILE_GRID_COLOR );

			// Screen grid:
			MainLayout.drawGrid(
				g,
				(int) (zoomFactor * x), (int) (zoomFactor * y),
				Main.loadedRoom.roomHeight,
				Main.loadedRoom.roomWidth,
				(int) (zoomFactor * Main.loadedRoom.screenWidth * Main.loadedRoom.blockSize),
				(int) (zoomFactor * Main.loadedRoom.screenHeight * Main.loadedRoom.blockSize),
				Integer.MAX_VALUE,
				Room.SCREEN_GRID_COLOR );
		}
	}
	
	
	/**
	 * This will initiate the GameObj positioning within the room.
	 * The "isInsertingObject" flag is set to true and the new object is stored
	 * in the "selectedObj" pointer. 
	 */
	public void startGameObjPositioning( GameObj newObj ) {
		// De-select whatever was selected before
		if ( selectedObj != null )
			selectedObj.highlighted = false; 
		
		selectedObj = newObj;
		state = STATE_OBJ_INSERT;
	}
	
	
	
	//
	// Auxiliary methods:
	//
	
	// Convert between canvas coords. and room coords.
	public int canvasToRoomX ( int x ) {
		return (int) ((x - scrollX) / zoomFactor);
	}
	
	public int canvasToRoomY ( int y ) {
		return (int) ((y - scrollY) / zoomFactor);
	}
	
	public int roomToCanvasX ( int x ) {
		return (int) (zoomFactor * x + scrollX);
	}
	
	public int roomToCanvasY ( int y ) {
		return (int) (zoomFactor * y + scrollY);
	}
	 
	 
	// Keep scrolling bounds accurate:
	private void calculateScrollingBounds () {
		scrollBoundLeft   = (int) (-zoomFactor * (Main.loadedRoom.roomWidth - 1) * Main.loadedRoom.screenWidth * Main.loadedRoom.blockSize);
		scrollBoundRight  = 0;
		
		scrollBoundTop    = (int) (-zoomFactor * (Main.loadedRoom.roomHeight - 1) * Main.loadedRoom.screenHeight * Main.loadedRoom.blockSize);
		scrollBoundBottom = 0;
	}
	
	private void enforceScrollingBoundaries () {
		if ( scrollX < scrollBoundLeft )
			scrollX = scrollBoundLeft;
		else if ( scrollX > scrollBoundRight )
			scrollX = scrollBoundRight;

		if ( scrollY < scrollBoundTop )
			scrollY = scrollBoundTop;
		else if ( scrollY > scrollBoundBottom )
			scrollY = scrollBoundBottom;
	}
	
	// Draw arrows on corners where scrolling is possible:
	private int[] xPoints = new int[3], yPoints = new int[3];
	private void drawScrollArrows ( Graphics g ) {
		int midX = (int) (getWidth()  / (2 * zoomFactor));
		int midY = (int) (getHeight() / (2 * zoomFactor));
		int maxX = (int) (getWidth()  / zoomFactor);
		int maxY = (int) (getHeight() / zoomFactor);
		
		// Do nothing if screen is taller than the room:
		if ( scrollBoundTop != 0  ) {
			// Up:
			if ( scrollY < scrollBoundBottom ) {
				xPoints[0] = midX;                       yPoints[0] = 0;
				xPoints[1] = midX - SCROLL_ARROW_SIZE/2; yPoints[1] = SCROLL_ARROW_SIZE/2;
				xPoints[2] = midX + SCROLL_ARROW_SIZE/2; yPoints[2] = SCROLL_ARROW_SIZE/2;
				
				g.setColor( SCROLL_ARROW_COLOR );
				g.fillPolygon( xPoints, yPoints, 3 );
			}
			// Down:
			if ( scrollY > scrollBoundTop ) {
				xPoints[0] = midX;                       yPoints[0] = maxY;
				xPoints[1] = midX - SCROLL_ARROW_SIZE/2; yPoints[1] = maxY - SCROLL_ARROW_SIZE/2;
				xPoints[2] = midX + SCROLL_ARROW_SIZE/2; yPoints[2] = maxY - SCROLL_ARROW_SIZE/2;
		
				g.setColor( SCROLL_ARROW_COLOR );
				g.fillPolygon( xPoints, yPoints, 3 );
			}
		}
		// Do nothing if screen is wider than the room:
		if ( scrollBoundLeft != 0  ) {
			// Left:
			if ( scrollX < scrollBoundRight ) {
				xPoints[0] = 0;                   yPoints[0] = midY;
				xPoints[1] = SCROLL_ARROW_SIZE/2; yPoints[1] = midY - SCROLL_ARROW_SIZE/2;
				xPoints[2] = SCROLL_ARROW_SIZE/2; yPoints[2] = midY + SCROLL_ARROW_SIZE/2;
			
				g.setColor( SCROLL_ARROW_COLOR );
				g.fillPolygon( xPoints, yPoints, 3 );
			}
			// Right:
			if ( scrollX > scrollBoundLeft ) {
				xPoints[0] = maxX;                       yPoints[0] = midY;
				xPoints[1] = maxX - SCROLL_ARROW_SIZE/2; yPoints[1] = midY - SCROLL_ARROW_SIZE/2;
				xPoints[2] = maxX - SCROLL_ARROW_SIZE/2; yPoints[2] = midY + SCROLL_ARROW_SIZE/2;
	
				g.setColor( SCROLL_ARROW_COLOR );
				g.fillPolygon( xPoints, yPoints, 3 );
			}
		}
	}
	
	
	
	// UI-related stuff:
	private int mouseX = 0, mouseY = 0;
	private boolean leftPress = false;
	private boolean rightPress = false;
	private boolean mouseOutside = true;
	
	private Point   oldObjectPos;
	private int[][] oldBGData;
	
	public boolean isMouseOutside () {
		return mouseOutside;
	}
	
	public int getMouseX () {
		return mouseX;
	}
	public int getMouseY () {
		return mouseY;
	}
	
	public boolean isLeftPressed () {
		return leftPress;
	}
	public boolean isRightPressed () {
		return rightPress;
	}
	
}
