package qaf.room.view;

import java.awt.Frame;
import java.io.File;
import java.io.IOException;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import qaf.room.control.Main;
import qaf.room.model.BGLayer;
import qaf.room.model.Room;
import qaf.room.model.RoomIO;

/**
 * This class handles dialogs to load an existing room from the filesystem. The
 * recommended strategy is to use the static method loadRoom() rather than
 * creating the dialogs directly. 
 */
public abstract class OpenRoomDialog {
	
	/**
	 * This dialog asks the user to input a new path for a BGLayer's source
	 * image.
	 */
	static class NewSourceImageDialog extends JDialog {
		public final static int STATUS_NONE   = 0,
		                        STATUS_OK     = 1,
		                        STATUS_CANCEL = 2;
		public int status = STATUS_NONE;
		
		public String oldSourcePath;
		public String newSourcePath = null;
		
		public NewSourceImageDialog ( Frame parent, String oldSourcePath ) {
			super( parent, true ); // modal dialog
			setResizable( false );
		}
		
	}
	

	
	
	
	/**
	 * Loads a Room from the file system. If the supplied path is null, a
	 * dialog will be opened so the user can pick a file.
	 * 
	 * The value returned is an array with two Objects:
	 *  - The new Room, at index 0
	 *  - The new Room's filename (a String), at index 1
	 * 
	 * A null pointer is returned if the user canceled.
	 */
	public static Object[] loadRoom ( File path ) {
		if ( path == null ) {
			JFileChooser fDlg = new JFileChooser( Main.getBasePath() );
			fDlg.setFileSelectionMode( JFileChooser.FILES_ONLY );
			fDlg.setFileFilter( new Main.RoomFileFilter() );
			
			if ( fDlg.showOpenDialog( Main.f ) == JFileChooser.APPROVE_OPTION )
				path = fDlg.getSelectedFile();
		}
		
		// Did the user choose a file or did he cancel?
		if ( path != null ) {
			// Check image path for validity:
			if ( !Main.isInBasePath( path.getAbsolutePath() ) ) {
				MainLayout.showNotInBasePathDialog( Main.f );
				return null;
			}
			else {
				String filename = Main.getCanonicalPath( path );
				Room newRoom;
				
				// Load the room:
				try {
					newRoom = RoomIO.readRoom( filename );
				}
				catch ( IOException exc ) {
					String[] message = {
						"The file could not be read:",
						filename };
					JOptionPane.showMessageDialog(
						Main.f,                      // parent dialog
						message,                     // message
						"Error",                     // title
						JOptionPane.ERROR_MESSAGE ); // message type
					
					return null;
				}
				catch ( Exception exc ) {
					String[] message = {
						"This file does not appear to be a valid Room,",
						"or its data is corrupted." };
					JOptionPane.showMessageDialog(
						Main.f,                      // parent dialog
						message,                     // message
						"Error",                     // title
						JOptionPane.ERROR_MESSAGE ); // message type
					
					return null;
				}
				
				
				// Check and load BGLayer images:
				for ( int layerInx = 0; layerInx < newRoom.getNumberOfBGLayers(); layerInx++ ) {
					BGLayer bgLayer = newRoom.getBGLayer( layerInx );
					String sourcePath = Main.prependBasePath( bgLayer.sourceImagePath );
					
					if ( !new File( sourcePath ).exists() ) {
						String[] message = {
							"The source image for layer " + layerInx + " could not be found in the base path:",
							" ",
							bgLayer.sourceImagePath,
							" ",
							"What would you like to do?" };
						String[] options = {
							"Choose a new image",
							"Delete this layer",
							"Cancel" };
						int option = JOptionPane.showOptionDialog(
							Main.f,                     // parent
							message,                    // message
							"New room",                 // title
							JOptionPane.DEFAULT_OPTION, // option type
							JOptionPane.ERROR_MESSAGE,  // message type
							null,                       // icon
							options,                    // options
							options[0] );               // initial value
						
						if ( option == 0 ) {
							// Get new sourcePath:
							// Invalidate the current source path, and show a
							// dialog to edit the layer:
							bgLayer.sourceImagePath = null;
							BGLayer newBGLayer = EditBGLayerDialog.editLayer( newRoom, layerInx );
							
							// User canceled?
							if ( newBGLayer == null )
								return null;
							else
								newRoom.setBGLayer( layerInx, newBGLayer );
						}
						else if ( option == 1 ) {
							// Delete this layer:
							newRoom.removeBGLayer( layerInx );
							
							// Decrease layerInx, so we can move on to the next
							// layer:
							layerInx--;
						}
						else
							// User canceled:
							return null;
					}
					else
						bgLayer.data = Main.createImage( sourcePath );
				}
				
				// Done!
				Object[] returnValue = new Object[2];
				returnValue[0] = newRoom;
				returnValue[1] = filename;
				return returnValue;
			}
		}
		else
			// User canceled
			return null;
	}
	
}
