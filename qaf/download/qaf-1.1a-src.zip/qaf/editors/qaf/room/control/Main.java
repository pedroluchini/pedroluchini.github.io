/**
 * Keyboard shortcuts:
 *  
 *  Ctrl + B: View->Show/hide the obstacle layer
 *  Ctrl + G: View->Show grid
 *  Ctrl + H: View->Hide all BG layers
 *  Ctrl + L: View->Show all BG layers
 *  Ctrl + N: File->New room
 *  Ctrl + O: File->Open room
 *  Ctrl + S: File->Save room
 *  Ctrl + T: Room->Translate layer
 *  Ctrl + Y: Edit->Redo
 *  Ctrl + Z: Edit->Undo
 *  NumPad+ : View->Zoom->Zoom in
 *  NumPad- : View->Zoom->Zoom out
 */

// TODO: Room->Fill working layer with current tile (Ctrl + F)


package qaf.room.control;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileFilter;

import qaf.room.model.Room;
import qaf.room.model.RoomIO;
import qaf.room.view.BGPanel;
import qaf.room.view.MainLayout;
import qaf.room.view.OpenRoomDialog;
import qaf.room.view.StrokeTimer;

public class Main {
	public static final float QAF_VERSION = 1.1f;
	
	public static JFrame f = new JFrame( "Room Editor - Untitled" );
	
	public static Room    loadedRoom = null;
	public static String  loadedRoomFilename = null;
	public static boolean unsavedChanges = false;
	
	private static String basePath;
	public static String qafPath;
	
	public static Cursor dragCursor, eyedropCursor, eyedropPlusCursor, eyedropMinusCursor;
	public static boolean ctrlDown, shiftDown, altDown;
	
	/**
	 * Application's entry point.
	 */
	public static void main ( String[] args ) {
		qafPath = System.getenv("QAF_PATH");
		if ( qafPath == null )
			qafPath = "." + File.separator;
		
		// Make the JFrame visible so the obstacle BGLayer can be created...
		f.setVisible( true );
		
		// Start with a default room...
		loadedRoom = new Room( 32, 20, 15, 1, 1 );
		
		// Create cursors:
		Image dragCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/drag.gif");
		if ( dragCursorImg != null )
			dragCursor = Toolkit.getDefaultToolkit().createCustomCursor( dragCursorImg, new Point(10, 10), "drag cursor" );
		if ( dragCursor == null )
			dragCursor = Cursor.getDefaultCursor();
		
		Image eyedropCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eyedrop.gif");
		if ( eyedropCursorImg != null )
			eyedropCursor = Toolkit.getDefaultToolkit().createCustomCursor( eyedropCursorImg, new Point(8, 22), "eyedrop cursor" );
		if ( eyedropCursor == null )
			eyedropCursor = Cursor.getDefaultCursor();
		
		Image eyedropPlusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eyedropPlus.gif");
		if ( eyedropPlusCursorImg != null )
			eyedropPlusCursor = Toolkit.getDefaultToolkit().createCustomCursor( eyedropPlusCursorImg, new Point(8, 22), "eyedropPlus cursor" );
		if ( eyedropPlusCursor == null )
			eyedropPlusCursor = Cursor.getDefaultCursor();
		
		Image eyedropMinusCursorImg = Toolkit.getDefaultToolkit().createImage(qafPath + "img/eyedropMinus.gif");
		if ( eyedropMinusCursorImg != null )
			eyedropMinusCursor = Toolkit.getDefaultToolkit().createCustomCursor( eyedropMinusCursorImg, new Point(8, 22), "eyedropMinus cursor" );
		if ( eyedropMinusCursor == null )
			eyedropMinusCursor = Cursor.getDefaultCursor();
		
		f.setVisible( false );
		
		// Build window layout:
		f.getContentPane().add( MainLayout.buildLayout() );
		f.setJMenuBar( MainLayout.buildMenu() );
		
		// Enable dynamic layout (prevents Swing's "grey fog" during window
		// resizing):
		Toolkit.getDefaultToolkit().setDynamicLayout( true );
		
		// Override JFrame's standard behavior:
		f.setDefaultCloseOperation( WindowConstants.DO_NOTHING_ON_CLOSE );
		f.addWindowListener( 
			new WindowAdapter() {
				public void windowClosing ( WindowEvent evt ) {
					// Check if the user wants to save before closing:
					if ( checkUnsavedChanges() ) {
						f.dispose();
						StrokeTimer.t.stop();
					}
				}
			} );
		
		// Before packing, set the canvas' initial size:
		MainLayout.canvas.setPreferredSize( new Dimension(640, 480) );
		
		// Layout:
		f.pack();
		
		// Set the canvas' preferred size to 0, letting the JScrollPane shrink
		// it as needed:
		MainLayout.canvas.setPreferredSize( new Dimension(0, 0) );
		
		// Done!
		f.setVisible( true );
		
		// The basePath is important for determining relative paths. It will be
		// kept in a file and read every time the application starts.
		try {
			BufferedReader fh = new BufferedReader(
				new InputStreamReader(
					new FileInputStream(qafPath + "basePath.txt") ) );
			
			basePath = fh.readLine();
			fh.close();
			
			if ( ! new File( basePath ).isDirectory() )
				throw new FileNotFoundException();			
		}
		catch ( FileNotFoundException exc ) {
			// Could not open file! That must mean the basePath has not been
			// set yet.
			// Canceling is not an option!
			basePath = promptForBasePath( false );
			saveBasePath( basePath );
		}
		catch ( IOException exc ) {
			JOptionPane.showMessageDialog(
					f,                        // parent dialog
					"Could not read the base path from \"basePath.txt\".", // message
					"Error",                  // title
					JOptionPane.ERROR_MESSAGE // message type
				);
			System.exit( -1 );
		}
		
		MainLayout.statusBar.setText( "Base path: " + basePath );
		
		// Start with a loaded room?
		if ( args.length > 0 ) {
			Object[] result = OpenRoomDialog.loadRoom( new File(args[0]) );
			if ( result != null ) {
				setLoadedRoom( (Room) result[0], (String) result[1] );
			}
		}
		
		// Key listener to update cursors:
		KeyboardFocusManager kfm = KeyboardFocusManager.getCurrentKeyboardFocusManager();
		kfm.addKeyEventDispatcher( new KeyEventDispatcher() {
			public boolean dispatchKeyEvent ( KeyEvent evt ) {
				if ( evt.getID() == KeyEvent.KEY_PRESSED ) {
					if ( evt.getKeyCode() == KeyEvent.VK_CONTROL ) {
						if ( ctrlDown )
							return false;
						else
							ctrlDown = true;
					}
					if ( evt.getKeyCode() == KeyEvent.VK_SHIFT ) {
						if ( shiftDown )
							return false;
						else
							shiftDown = true;
					}
					if ( evt.getKeyCode() == KeyEvent.VK_ALT ) {
						if ( altDown )
							return false;
						else
							altDown = true;
					}
				}
				else if ( evt.getID() == KeyEvent.KEY_RELEASED ) {
					if ( evt.getKeyCode() == KeyEvent.VK_CONTROL ) {
						if ( !ctrlDown )
							return false;
						else
							ctrlDown = false;
					}
					if ( evt.getKeyCode() == KeyEvent.VK_SHIFT ) {
						if ( !shiftDown )
							return false;
						else
							shiftDown = false;
					}
					if ( evt.getKeyCode() == KeyEvent.VK_ALT ) {
						if ( !altDown )
							return false;
						else
							altDown = false;
					}
				}
				
				updateCursors();
				MainLayout.canvas.repaint();
				
				return false;
			}
		} );
		
		// Start the stroke timer:
		StrokeTimer.t.start();
	}
	
	
	/**
	 * Sets the loadedRoom and its filename.
	 */
	public static void setLoadedRoom ( Room newRoom, String newRoomFilename ) {
		loadedRoom = newRoom;
		loadedRoomFilename = newRoomFilename;
		unsavedChanges = false;
		
		if ( loadedRoomFilename != null )
			Main.f.setTitle( "Room Editor - "  + loadedRoomFilename );
		else
			Main.f.setTitle( "Room Editor - Untitled" );
		
		MainLayout.rebuildUI();
	}
	
	
	
	/**
	 * Tests the unsavedChanges variable. If it is true, performs the usual
	 * routine of "Do you want to save" before unloading the room. If the user 
	 * cancels at any point, the method will return false; otherwise it will
	 * save the room and return true.
	 */
	public static boolean checkUnsavedChanges () {
		if ( Main.unsavedChanges ) {
			// Ask the user if he wants to save
			String[] message = {
				"You have made changes to this room since",
				"the last time you saved. Would you like to",
				"save now?" }; 
			int option = JOptionPane.showConfirmDialog(
				Main.f,                           // parent dialog
				message,                          // message
				"Unsaved changes",                // title
				JOptionPane.YES_NO_CANCEL_OPTION, // option type
				JOptionPane.WARNING_MESSAGE );    // message type
	
			if ( option == JOptionPane.CANCEL_OPTION )
				//User canceled: Bail out
				return false;
			else if ( option == JOptionPane.YES_OPTION ) {
				// User chose to save:
				// he may still cancel if the loaded room had no filename.
				return Main.saveRoom();
			}
			else
				// User chose not to save:
				return true;
		}
		else
			return true;
	}
	
	
	
	/**
	 * Saves the currently loaded room to the path specified in
	 * loadedRoomFilename, or redirects to saveAs if the filename is null.
	 * 
	 * Returns false if the user canceled, or true if the room was saved.
	 */
	public static boolean saveRoom () {
		if ( loadedRoomFilename == null )
			return saveRoomAs();
		else {
			try {
				RoomIO.writeRoom( loadedRoom, loadedRoomFilename );
				
				MainLayout.statusBar.setText( "Saved to " + loadedRoomFilename );
				Main.f.setTitle( "Room Editor - " + loadedRoomFilename );
				
				unsavedChanges = false;
				return true;
			}
			catch ( IOException exc ) {
				String[] message = {
					"Could not write to file:",
					loadedRoomFilename };
					
				JOptionPane.showMessageDialog(
					f,                           // parent dialog
					 message,                    // message
					"Error",                     // title
					JOptionPane.ERROR_MESSAGE ); // message type
				
				return false;
			}
		}
	}
	
	/**
	 * Prompts the user for a filename, and writes the room data to it.
	 * 
	 * Returns false if the user canceled, or true if the room was saved.
	 */
	public static boolean saveRoomAs () {
		while ( true ) {
			JFileChooser fDlg = new JFileChooser();
			fDlg.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fDlg.setFileFilter( new RoomFileFilter() );
			if ( loadedRoomFilename != null )
				fDlg.setCurrentDirectory( new File( loadedRoomFilename ).getParentFile() );
			else
				fDlg.setCurrentDirectory( new File( basePath ) );
			
			// Show dialog and test whether the user has canceled
			if ( fDlg.showSaveDialog( f ) != JFileChooser.APPROVE_OPTION )
				return false;
			else {
				String filename = Main.getCanonicalPath( fDlg.getSelectedFile() );
				
				// Is this a valid path?
				if ( !Main.isInBasePath( filename ) ) {
					String[] message = {
						"The file path you chose is not contained in the base path",
						"or one of its subdirectories. The base path is",
						" ",
						Main.getBasePath() };
					JOptionPane.showMessageDialog(
						f,                           // parent dialog
						message,                     // message
						"Error",                     // title
						JOptionPane.ERROR_MESSAGE ); // message type
				}
				else {
					// Append "qr" extension?
					if ( !filename.endsWith( ".qr" ) )
						filename += ".qr";
					
					// If the selected file already exists, ask for
					// confirmation:
					if ( new File( filename ).exists() ) {
						String[] message = {
							"The selected file already exists.",
							"Overwrite it?" };
						
						int option = JOptionPane.showConfirmDialog(
							Main.f,                         // parent dialog
							message,                        // message
							"Saved room",                   // title
							JOptionPane.YES_NO_OPTION,      // option type
							JOptionPane.QUESTION_MESSAGE ); // message type
						
						if ( option == JOptionPane.NO_OPTION )
							// Show the file chooser again!
							continue;
					}
					
					
					loadedRoomFilename = filename;
					try {
						RoomIO.writeRoom( loadedRoom, loadedRoomFilename );
				
						MainLayout.statusBar.setText( "Saved to " + loadedRoomFilename );
						Main.f.setTitle( "Room Editor - " + loadedRoomFilename );
						
						unsavedChanges = false;
						return true;
					}
					catch ( IOException exc ) {
						JOptionPane.showMessageDialog(
							f,                           // parent dialog
							"Could not write to file: " + loadedRoomFilename , // message
							"Error",                     // title
							JOptionPane.ERROR_MESSAGE ); // message type
						
						return false;
					}
				}
			}
		}
	}
	
	
	
	
	
	/**
	 * Sets the base path and saves it to a config file.
	 */
	public static void setBasePath ( String newPath ) {
		basePath = newPath;
		saveBasePath( newPath );
	}
	
	/**
	 * Returns the base path in use.
	 */
	public static String getBasePath () {
		return basePath;
	}
	
	
	/**
	 * Saves the basePath to a file named "basePath.txt".
	 */
	private static void saveBasePath ( String path ) {
		try {
			BufferedWriter fh = new BufferedWriter(
				new OutputStreamWriter(
					new FileOutputStream(qafPath + "basePath.txt") ) );
			
			fh.write( path );
			fh.close();
		}
		catch ( IOException exc ) {
			JOptionPane.showMessageDialog(
					f,                           // parent dialog
					"Could not write the base path to \"basePath.txt\".", // message
					"Error",                     // title
					JOptionPane.ERROR_MESSAGE ); // message type
			System.exit( -1 );
		}
	}
	
	
	/**
	 * Given a path, tests whether it is contained in the base path or one of
	 * its subdirectories. The path will be converted to its canonicalPath
	 * before being tested automatically.
	 */
	public static boolean isInBasePath ( String path ) {
		path = getCanonicalPath( path );
		basePath = getCanonicalPath( basePath );
		
		// The path must "begin" with the base path:
		return (path.indexOf( basePath ) == 0);
	}
	
	/**
	 * Given a path, removes the basePath from its beginning, leaving only the
	 * relative path.
	 * 
	 * The canonical path can be obtained again with prependBasePath().
	 * 
	 * If the specified path is not "valid" (i.e., isInsideBasePath(path)
	 * returns false), the method returns null.
	 */
	public static String stripBasePath ( String path ) {
		if ( !isInBasePath( path ) )
			return null;
		
		// Remove trailing slash from the base path, if it is there:
		String cleanBasePath = basePath;
		if ( cleanBasePath.endsWith( File.separator ) )
			cleanBasePath = cleanBasePath.substring( 0, cleanBasePath.length() - File.separator.length() );
		
		return path.substring( cleanBasePath.length() + File.separator.length() );
	}
	
	/**
	 * Prepends thebase path to a relative path, so that it is once again a
	 * canonical path.
	 */
	public static String prependBasePath ( String relativePath ) {
		// Remove trailing slash from the base path, if it is there:
		String cleanBasePath = basePath;
		if ( cleanBasePath.endsWith( File.separator ) )
			cleanBasePath = cleanBasePath.substring( 0, cleanBasePath.length() - File.separator.length() );
		
		// Remove slash from the beginning of the relative path:
		if ( relativePath.startsWith( File.separator ) )
			relativePath = relativePath.substring( File.separator.length() );
		
		return cleanBasePath + File.separator + relativePath;
	}
	
	
	/**
	 * Pops up a warning to explain what the base path is and asks the user to
	 * input a path. The "cancelOption" flag indicates whether the dialog will
	 * contain a "Cancel" button.
	 * 
	 * This will return the path in its canonical form.
	 */
	public static String promptForBasePath ( boolean cancelOption) {
		String[] message = {
			"The \"base path\" is equivalent to the game's working directory.",
			"This editor uses it to determine relative paths between rooms",
			"and the image files that compose their background layers.",
			" ",
			"Every room you create and every BG image you use will",
			"be required to be inside the base path or its subdirectories." };
		
		final JDialog dlg = new JDialog( f, "Base path", true ); // modal dialog
		dlg.setDefaultCloseOperation( JDialog.DO_NOTHING_ON_CLOSE );
				
		final JTextField txtField = new JTextField( 30 );
		if ( basePath != null )
			txtField.setText( basePath );
		else
			txtField.setText( "Choose a directory" );
		
		txtField.select( 0, txtField.getText().length() );
		
		JButton browseButton = new JButton( "Browse..." );
		browseButton.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					JFileChooser fDlg = new JFileChooser();
					fDlg.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					if ( basePath != null ) 
						fDlg.setCurrentDirectory( new File( basePath ) );
					
					// Show dialog and test whether the user has canceled
					if ( fDlg.showOpenDialog( f ) == JFileChooser.APPROVE_OPTION &&
					     fDlg.getSelectedFile()   != null )
						txtField.setText( getCanonicalPath( fDlg.getSelectedFile() ) );
				}
			} );
		
		Box txtBrowseBox = Box.createHorizontalBox();
		txtBrowseBox.setAlignmentX( 0.5f );
		txtBrowseBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		txtBrowseBox.add( txtField );
		txtBrowseBox.add( browseButton );
		txtBrowseBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		
		final JButton okButton = new JButton( "OK" );
		okButton.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					// Must be a valid directory!
					if ( new File( txtField.getText() ).isDirectory() ) 
						dlg.dispose();
					else {
						JOptionPane.showMessageDialog(
							dlg,                                   // parent dialog
							"You must specify a valid directory.", // message
							"Error",                               // title
							JOptionPane.ERROR_MESSAGE              // message type
						);
					}
			} } );
		
		final JButton cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				txtField.setText( "" );
				dlg.dispose();
			} } );
		
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.5f );
		buttonBox.add( okButton );
		if ( cancelOption ) {
			buttonBox.add( Box.createRigidArea( new Dimension(15, 0) ) );
			buttonBox.add( cancelButton );
			
			// Handle escape key to close the dialog
			KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
			Action escapeAction = new AbstractAction() {
				public void actionPerformed(ActionEvent e) {
					cancelButton.doClick();
				} };
			dlg.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
			dlg.getRootPane().getActionMap().put("ESCAPE", escapeAction);
		}
		
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY( 0.0f );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		for ( int i = 0; i < message.length; i++ ) {
			Box b = Box.createHorizontalBox();
			b.setAlignmentX( 0.5f );
			b.add( new JLabel( message[i] ) );
			theBox.add( b );
		}
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		theBox.add( txtBrowseBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		theBox.add( buttonBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		dlg.getContentPane().add( theBox );
		dlg.getRootPane().setDefaultButton( okButton );
		dlg.setResizable( false );
		dlg.pack();
		dlg.setLocationRelativeTo( null ); // Center on screen
		
		// Show the dialog and wait for user input:
		dlg.setVisible( true );
		
		// User canceled?
		if ( txtField.getText().equals("") )
			return null;
		else
			return getCanonicalPath( txtField.getText() );
	}
	
	
	/**
	 * Sets the correct cursor on the room panel and BG panels, according to
	 * the ctrlPressed and shiftPressed variables.
	 */
	public static void updateCursors () {
		// Room panel cursors:
		if ( MainLayout.canvas.isRightPressed() )
			MainLayout.canvas.setCursor( dragCursor );
		else if ( ctrlDown && altDown )
			MainLayout.canvas.setCursor( eyedropMinusCursor );
		else if ( ctrlDown && shiftDown )
			MainLayout.canvas.setCursor( eyedropPlusCursor );
		else if ( ctrlDown )
			MainLayout.canvas.setCursor( eyedropCursor );
		else
			MainLayout.canvas.setCursor( null );
		
		if ( MainLayout.canvas.isRightPressed() )
			MainLayout.statusBar.setText( "Drag with the right mouse button to scroll." );
		else if ( ctrlDown )
			MainLayout.statusBar.setText( "Hold down Ctrl and click to select a tile from the displayed room. Shift + click to add, Alt + click to remove from the selection." );
		
		// BG panels cursors:
		for ( int i = 0; i < MainLayout.bgLayers.getComponentCount(); i++ ) {
			BGPanel bgPanel = (BGPanel) MainLayout.bgLayers.getComponentAt( i );
			bgPanel.updateCursor();
		}
	}
	
	
	/**
	 * Auxiliary method: Opens an image and waits for it to load using a
	 * MediaTracker.
	 * 
	 * Filename is NOT relative to the base path.
	 */
	public static Image createImage ( String filename ) {
		Image data = Toolkit.getDefaultToolkit().createImage( filename );
		
		// Wait for image to load:
		MediaTracker mediaTracker = new MediaTracker( f );
		mediaTracker.addImage( data, 0 );
		try {
			mediaTracker.waitForID( 0 );
		}
		catch ( InterruptedException ie ) {
			ie.printStackTrace();
		}
		
		return data;
	}
	
	
	
	/**
	 * This is an auxiliary method to get the canonical path without going
	 * through all the hassle of handling IOExceptions. It will return the 
	 * absolute pathname if the canonical query fails.
	 */
	public static String getCanonicalPath ( File file ) {
		try {
			return file.getCanonicalPath();
		}
		catch ( IOException exc ) {
			return file.getAbsolutePath();
		}
	}
	
	public static String getCanonicalPath ( String file ) {
		return getCanonicalPath( new File( file ) );
	}
	
	
	
	/**
	 * Auxiliary method: Returns a copy of the integer array
	 */
	public static int[][] cloneArray ( int[][] src ) {
		int rows = src.length;
		int cols = src[0].length;
		
		int[][] clone = new int[rows][cols];
		
		for ( int i = 0; i < rows; i++ )
			for ( int j = 0; j < cols; j++ )
				clone[i][j] = src[i][j];
		
		return clone;
	}
	
	/**
	 * Auxiliary method: Copies data from one array into another 
	 */
	public static void copyArray ( int[][] dest, int[][] src ) {
		for ( int i = 0; i < src.length; i++ )
			for ( int j = 0; j < src[i].length; j++ )
				dest[i][j] = src[i][j];
	}
	
	/**
	 * Auxiliary method: Copies a section of an integer matrix onto another.
	 */
	public static void blitMatrix ( int[][] dest, int[][] src, int orgRow, int orgCol ) {
		for ( int i = 0; i < src.length; i++ )
			for ( int j = 0; j < src[i].length; j++ )
				try {
					dest[i + orgRow][j + orgCol] = src[i][j];
				}
				catch ( ArrayIndexOutOfBoundsException exc ) {}
	}
	
	
	
	/**
	 * A file filter that only accepts .QR files.
	 */
	public static class RoomFileFilter extends FileFilter {
		public String getDescription () {
			return "Qaf room files (*.QR)";
		}
		public boolean accept ( File f ) {
			if ( !f.isFile() )
				return true; // Show directories, drives, etc.
			else
				return f.getName().toLowerCase().endsWith( ".qr" );
		}
	}
}
