/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_OBJ_SPRITEPARTICLEOBJ_H
#define QAF_OBJ_SPRITEPARTICLEOBJ_H

#include "../qafGameObj.h"
#include <hgesprite.h>

namespace qaf {
	
	/**
	 * This is an object that renders itself as a sprite, with optional
	 * linear/angular speeds. Its size and color values are interpolated 
	 * linearly between the creation time and the <tt>lifetime</tt> parameter.
	 * 
	 * The <tt>size</tt> parameter is used to scale the sprite when rendered.
	 * If you want the sprite at its original size, use 1.0.
	 * 
	 * When its lifetime has expired, the object will remove itself from the
	 * <tt>Environment</tt>.
	 * 
	 * @see qaf::AnimParticleObj
	 */
	class SpriteParticleObj : public GameObj {
		public:
			
			/**
			 * @param sprite       The sprite used to render this particle.
			 * @param x            The object's initial X position.
			 * @param y            The object's initial Y position.
			 * @param angle        The object's initial rotation.
			 * @param vx           The object's X speed (pixels/second).
			 * @param vy           The object's Y speed (pixels/second).
			 * @param vr           The object's angular speed (radians/second).
			 * @param ax           The object's X acceleration (pixels/second<sup>2</sup>).
			 * @param ay           The object's Y acceleration (pixels/second<sup>2</sup>).
			 * @param initialSizeX The sprite's initial horiz. scale.
			 * @param initialSizeY The sprite's initial horiz. scale.
			 * @param finalSizeX   The sprite's vert. scale when it is about to die.
			 * @param finalSizeY   The sprite's vert. scale when it is about to die.
			 * @param initialColor The sprite's initial color.
			 * @param finalColor   The sprite's color when it is about to die.
			 * @param blendMode    The blend mode used to render the sprite.
			 * @param lifetime     The object's lifetime, in seconds. 
			 */
			SpriteParticleObj (
				const hgeSprite * sprite,
				float x, float y,
				float angle,
				float vx, float vy,
				float vr,
				float ax, float ay,
				float initialSizeX, float initialSizeY,
				float finalSizeX, float finalSizeY,
				DWORD initialColor, DWORD finalColor,
				DWORD blendMode,
				float lifetime );
			
			
			
			/**
			 * Returns a reference to the particle's sprite.
			 */
			inline hgeSprite * getSprite () {
				return &sprite;
			}
			
			/**
			 * Returns true if the particle's lifetime has expired.
			 */
			inline bool isDead () {
				return (timer >= lifetime);
			}
			
			/**
			 * Returns the particle's current position. Any of the parameters
			 * may be NULL, indicating that they shouldn't be returned.
			 */
			void getPos ( float * _x, float * _y, float * _angle ) {
				if ( _x )
					*_x = x;
				if ( _y )
					*_y = y;
				if ( _angle )
					*_angle = angle;
			}
			
			/**
			 * Returns the particle's current velocity. Any of the parameters
			 * may be NULL, indicating that they shouldn't be returned.
			 */
			inline void getVel ( float * _vx, float * _vy, float * _vr ) {
				if ( _vx )
					*_vx = vx;
				if ( _vy )
					*_vy = vy;
				if ( _vr )
					*_vr = vr;
			}
			
			/**
			 * Returns the particle's current color.
			 */
			inline DWORD getColor () {
				float timeRatio = (timer/lifetime);
	
				int newR = initialR + (int) (timeRatio * deltaR);
				int newG = initialG + (int) (timeRatio * deltaG);
				int newB = initialB + (int) (timeRatio * deltaB);
				int newA = initialA + (int) (timeRatio * deltaA);
				
				return ARGB( newA, newR, newG, newB );
			}
			
			/**
			 * Returns the particle's blend mode.
			 */
			inline DWORD getBlendMode () {
				return blendMode;
			}
			
			/**
			 * Returns the particle's current size.
			 */
			inline void getSize ( float * xScale, float * yScale ) {
				float timeRatio = (timer/lifetime);
				
				if ( xScale )
					*xScale = initialSizeX + (timeRatio * (finalSizeX - initialSizeX));
				if ( yScale )
					*yScale = initialSizeY + (timeRatio * (finalSizeY - initialSizeY));
			}
			
			/**
			 * Returns how much time has passed since the particle was created.
			 */
			inline float getAge () {
				return timer;
			}
			
			
			
			void update ( int objLayer, float dt );
			void render ( int objLayer, float scrollX, float scrollY );
			
		protected:
			hgeSprite sprite;
			float x, y, angle, vx, vy, vr, ax, ay, initialSizeX, initialSizeY, finalSizeX, finalSizeY, lifetime;
			int initialR, initialG, initialB, initialA;
			int deltaR, deltaG, deltaB, deltaA;
			DWORD blendMode;
			float timer;
	};
	
}



#endif

