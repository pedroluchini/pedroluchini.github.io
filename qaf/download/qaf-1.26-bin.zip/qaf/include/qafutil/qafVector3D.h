/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_UTIL_VECTOR3D_H
#define QAF_UTIL_VECTOR3D_H

#include <math.h>
#include "../qafDef.h"


namespace qaf {
	
	/**
	 * Vector in the R<sup>3</sup> space, with (x, y, z) components.
	 * 
	 * This class overloads several operators to make evaluating formulae
	 * easier.
	 * 
	 * The multiplication operator (<tt>*</tt>) can be used with a
	 * scalar argument (i.e., a <tt>float</tt> value), or with another vector,
	 * in which case it stands for the dot product.
	 * 
	 * The modulus operator (<tt>%%</tt>) represents a cross product.
	 */ 
	class Vector3D {
	public:
		float x, y, z;
		
		Vector3D () : x(0), y(0), z(0) {}
		Vector3D ( float _x, float _y, float _z ) : x(_x), y(_y), z(_z) {}
		Vector3D ( int _x, int _y, int _z ) : x((float) _x), y((float) _y), z((float) _z) {}
		
		inline Vector3D & operator =  ( const Vector3D & v );
		
		/** Returns the Euclidian norm of this vector. */
		inline float      length      () const;
		
		/** Returns a copy of the vector, with length equal to 1. */
		inline Vector3D   unit        () const;
		
		/** Returns the distance between the points denoted by this and that. */
		inline float      dist        ( const Vector3D & that ) const;
		
		/** Resizes the vector so it will have length equal to 1. */
		inline void       normalize   ();
		
		/** Returns the projection of this vector onto another. */
		inline Vector3D   project     ( const Vector3D & onto ) const;
		
		/** Returns the reflection of this vector relative to <tt>around</tt>. */
		inline Vector3D   reflect     ( const Vector3D & around ) const;
		
		/** Returns a rotated copy of this vector around <tt>axis</tt>. */
		inline Vector3D   rotate      ( const Vector3D & axis, float angle ) const;
		
		inline Vector3D & operator += ( const Vector3D & v );
		inline Vector3D & operator -= ( const Vector3D & v );
		inline Vector3D   operator +  ( const Vector3D & v ) const;
		inline Vector3D   operator -  ( const Vector3D & v ) const;
		inline Vector3D   operator -  () const;
		
		inline Vector3D & operator *= ( float s );
		inline Vector3D   operator *  ( float s ) const;
		inline Vector3D & operator /= ( float s );
		inline Vector3D   operator /  ( float s ) const;
		
		/** Returns the dot product of this vector and <tt>v</tt>. */
		inline float      operator *  ( const Vector3D & v ) const;
		
		/// @{
		/** Returns the cross product of this vector and <tt>v</tt>. */
		inline Vector3D & operator %= ( const Vector3D & v );
		inline Vector3D   operator %  ( const Vector3D & v ) const;
		/// @}
		
	};

	inline Vector3D  operator *  ( float s, const Vector3D & t );
	
	
	
	Vector3D & Vector3D::operator = ( const Vector3D & v ) {
		x = v.x;
		y = v.y;
		z = v.z;
		
		return *this;
	}


	float Vector3D::length () const {
		return sqrtf( x * x + y * y + z * z );
	}


	float Vector3D::dist ( const Vector3D & that ) const {
		return sqrtf( ((x - that.x) * (x - that.x)) +
		              ((y - that.y) * (y - that.y)) +
		              ((z - that.z) * (z - that.z)) );
	}


	Vector3D Vector3D::unit () const {
		float abs = length();
		if ( abs <= QAF_EPSILON ) // Prevent division by zero
			return (*this);
		else
			return Vector3D(
				x / abs,
				y / abs,
				z / abs );
	}

	void Vector3D::normalize () {
		float abs = length();
		if ( abs <= QAF_EPSILON ) // Prevent division by zero
			return;
		else {
			x /= abs;
			y /= abs;
			z /= abs;
		}
	}


	Vector3D Vector3D::project ( const Vector3D & onto ) const {
		// Prevent division by zero:
		if ( fabs(onto * onto) < QAF_EPSILON ) 
			return Vector3D( 0, 0, 0 );
		
		// Dot product of this with the other, divided by the dot product of the
		// other with itself:
		float newScale = ((*this) * onto)/(onto * onto);

		// Resize the other vector, and assign to this:
		return Vector3D (
			onto.x * newScale,
			onto.y * newScale,
			onto.z * newScale );
	}
	
	
	Vector3D Vector3D::reflect ( const Vector3D & around ) const {
		// Projection of this vector onto the "mirror":
		Vector3D vProj = this->project( around );
		
		// Distance to the "mirror":
		Vector3D vIncrH ( vProj.x - x, vProj.y - y, vProj.z - z );
		
		// Result:
		return Vector3D (
			vProj.x + vIncrH.x,
			vProj.y + vIncrH.y,
			vProj.z + vIncrH.z );
	}
	
	
	Vector3D Vector3D::rotate ( const Vector3D & axis, float angle ) const {
		float axisLength = axis.length();
		
		if ( axisLength >= QAF_EPSILON ) {
			float cos_a = cosf( angle );
			float sin_a = sinf( angle );
			
			Vector3D e = axis / axisLength;
			
			return Vector3D (
					(cos_a + (1 - cos_a)*e.x*e.x)     * x  +  (e.x*e.y*(1 - cos_a) - e.z*sin_a) * y  +  (e.z*e.x*(1 - cos_a) + e.y*sin_a) * z,
					(e.x*e.y*(1 - cos_a) + e.z*sin_a) * x  +  (cos_a + (1 - cos_a)*e.y*e.y)     * y  +  (e.y*e.z*(1 - cos_a) - e.x*sin_a) * z,
					(e.x*e.z*(1 - cos_a) - e.y*sin_a) * x  +  (e.y*e.z*(1 - cos_a) + e.x*sin_a) * y  +  (cos_a + (1 - cos_a)*e.z*e.z)     * z );
		}
		else {
			// Axis too small to rotate.
			return (*this);
		}
	}
	
	
	Vector3D & Vector3D::operator += ( const Vector3D & v ) {
		x += v.x;
		y += v.y;
		z += v.z;
		
		return *this;
	}

	Vector3D & Vector3D::operator -= ( const Vector3D & v ) {
		x -= v.x;
		y -= v.y;
		z -= v.z;
		
		return *this;
	}

	Vector3D Vector3D::operator + ( const Vector3D & v ) const {
		return Vector3D (
			x + v.x,
			y + v.y,
			z + v.z );
	}

	Vector3D Vector3D::operator - ( const Vector3D & v ) const {
		return Vector3D (
			x - v.x,
			y - v.y,
			z - v.z );
	}

	Vector3D Vector3D::operator - () const {
		return Vector3D (
			-x,
			-y,
			-z);
	}


	Vector3D & Vector3D::operator *= ( float s ) {
		x *= s;
		y *= s;
		z *= s;
		
		return *this;
	}

	Vector3D Vector3D::operator * ( float s ) const {
		return Vector3D (
			x * s,
			y * s,
			z * s );
	}

	Vector3D operator *  ( float s, const Vector3D & t ) {
		return Vector3D (
			t.x * s,
			t.y * s,
			t.z * s );
	}

	Vector3D & Vector3D::operator /= ( float s ) {
		x /= s;
		y /= s;
		z /= s;
		
		return *this;
	}

	Vector3D Vector3D::operator / ( float s ) const {
		return Vector3D (
			x / s,
			y / s,
			z / s );
	}


	float Vector3D::operator * ( const Vector3D & v ) const {
		return x * v.x + y * v.y + z * v.z;
	}


	Vector3D & Vector3D::operator %= ( const Vector3D & v ) {
		x = y * v.z - z * v.y;
		y = z * v.x - x * v.z;
		z = x * v.y - y * v.x;
		
		return *this;
	}

	Vector3D Vector3D::operator % ( const Vector3D & v ) const {
		return Vector3D (
			y * v.z - z * v.y,
			z * v.x - x * v.z,
			x * v.y - y * v.x );
	}
	
	
}


#endif
