/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_BIGTEXTURE_H
#define QAF_BIGTEXTURE_H

#include <hge.h>


namespace qaf {

	/**
	 * Stores an arbitrary-sized image.
	 * 
	 * Following a "slower and working is better than faster and broken" philosopy,
	 * <tt>BigTexture</tt> will juggle textures and sub-textures for you, ensuring
	 * your large tile libraries will look the same no matter what the video card's
	 * texture dimension constraints are.
	 * 
	 * <tt>BigTexture</tt> is an extension for 
	 * <a href="http://hge.relishgames.com/">Haaf's Game Engine</a>, using
	 * Direct3DX as its image loader.
	 * 
	 * When you create a <tt>BigTexture</tt> object, the constructor will
	 * automatically divide the source image into smaller images until all of them
	 * fit within the video card's texture dimension constraints. This is
	 * transparent to the user; you just tell BT to render a rectangular area from
	 * the source image.
	 */
	class BigTexture {
		public:
			/**
			 * Loads the image, breaking it into sub-textures as needed.
			 * 
			 * If any errors are encountered, they will be reported in the HGE
			 * log file.
			 * 
			 * This process is <em>very</em> slow; you should manage your BTs
			 * so as to minimize the creation/destruction of these objects.
			 * 
			 * @see Environment::loadBigTexture()
			 */
			BigTexture ( const char * sourceImage );
			
			
			/**
			 * @return The original image's width, in pixels.
			 */
			inline int getImageWidth () const {
				return imageWidth;
			}
			
			/**
			 * @return The original image's height, in pixels.
			 */
			inline int getImageHeight () const {
				return imageHeight;
			}
			
			/**
			 * Draws an axis-aligned rectangular area from this image.
			 * 
			 * Make sure you invoke this method between a pair of
			 * <tt>Gfx_BeginScene()</tt>/<tt>Gfx_EndScene()</tt> calls.
			 * 
			 * @param x0     Screen coordinates of the rectangle's top-left corner
			 * @param y0     Screen coordinates of the rectangle's top-left corner
			 * @param tx     Coordinates of the rectangle's top-left corner in the
			 *               image space.
			 * @param ty     Coordinates of the rectangle's top-left corner in the
			 *               image space
			 * @param width  Width of the rectangular area to be drawn. If zero or
			 *               negative, the image's width is used.
			 * @param height Height of the rectangular area to be drawn. If zero or
			 *               negative, the image's height is used.
			 * @param color  Has the same effect as the <tt>color</tt> field in
			 *               <tt>hgeVertex</tt>. Default is full-alpha white.
			 * @param blend  Has the same effect as the <tt>blend</tt> field in
			 *               <tt>hgeQuad</tt>.
			 * @param flipX  If true, the rectangle will be flipped along the X
			 *               axis.
			 * @param flipY  If true, the rectangle will be flipped along the Y
			 *               axis.
			 * 
			 * @note
			 * If the rectangle exceeds the image's bounds, it will be clipped.
			 */
			void renderRectangle ( int x0, int y0,
			                       int tx = 0, int ty = 0,
			                       int width = 0, int height = 0,
			                       unsigned long color = 0xFFFFFFFF,
			                       unsigned long blend = 2,
			                       bool flipX = false,
			                       bool flipY = false ) const;
			
			
			/**
			 * Use this to render a triangular section of the big texture. All
			 * the hgeTriple fields have their usual meanings; this method
			 * works exactly like <tt>HGE::Gfx_RenderTriple()</tt>, with the
			 * following exceptions:
			 *  - The <tt>tex</tt> field is ignored, and the <tt>Bigtexture</tt>
			 *    is used instead.
			 *  - If the triple's texture coordinates fall outside the texture
			 *    area (i.e., if any texture coordinates are less than zero or
			 *    greater than 1), the texture will be clipped, rather than
			 *    being repeated.
			 * 
			 * This method is much slower than its "core" HGE equivalent; use
			 * it sparingly.
			 * 
			 * You are advised to disable <tt>HGE_TEXTUREFILTER</tt> before
			 * invoking this method.
			 */
			void renderTriple ( const hgeTriple * triple ) const;
			
			
			/**
			 * Use this to render a freeform rectangular area of the texture.
			 * See <tt>renderTriple()</tt> for more information.
			 */
			void renderQuad ( const hgeQuad * quad ) const;
			
			
			/**
			 * Deletes the sub-textures.
			 */
			virtual ~BigTexture ();
			
		private:
			struct SubTexture {
				unsigned long tex;
				int width, height;
			};
			
			SubTexture * subTextures;
			int rows, cols;
			int imageWidth, imageHeight;
			
			void * pHGE;
			
			// Users should not use copy constructors or assignment operators.
			BigTexture ( BigTexture & btl );
			void operator = ( BigTexture & btl );
			
	};
	
}

#endif
