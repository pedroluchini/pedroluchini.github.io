package control.tool;

import java.awt.Insets;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JToggleButton;

import model.BGLayer;
import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.BGTileColorSelectionSet;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;
import model.selection.GameObjSelectionSet;
import model.selection.SelectionSet;
import view.RoomPanel;
import control.HistoryManager;
import control.UndoImpl;

public class ToolBar extends Box {
	final static long serialVersionUID = 0;
	
	public final static int TILEBRUSH_TOOL_INX        = 0;
	public final static int TILEERASER_TOOL_INX       = 1;
	public final static int TILEFILLTOOL_INX          = 2;
	public final static int TILESELECTION_TOOL_INX    = 3;
	public final static int COLORBRUSH_TOOL_INX       = 4;
	public final static int COLORFILL_TOOL_INX        = 5;
	public final static int COLORSELECTION_TOOL_INX   = 6;
	public final static int GAMEOBJSELECTION_TOOL_INX = 7;
	public final static int SCROLL_TOOL_INX           = 8;
	
	
	
	
	public static interface Listener {
		public void toolChanged ( ToolBar src );
	}
	
	
	
	
	private class ToolDescrMouseAdapter extends MouseAdapter {
		Tool tool;
		
		public ToolDescrMouseAdapter ( Tool tool ) {
			this.tool = tool;
		}
		
		public void mouseEntered ( MouseEvent evt ) {
			statusBar.setText( tool.getToolDescription() );
		}
		
		public void mouseExited ( MouseEvent evt ) {
			statusBar.setText( " " );
		}
	}
	
	
	
	
	private class RoomListener implements Room.Listener {
		
		public void bgLayerAdded(Room src, int newLayerIndex) {
			BGTilePicker bgTilePicker = new BGTilePicker( src.getBGLayer( newLayerIndex ) );
			bgTilePickers.add( newLayerIndex, bgTilePicker );
		}
		
		public void bgLayerRemoved(Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] bgTileColorMatrix) {
			bgTilePickers.remove( oldLayerIndex );
		}
		
		public void bgLayerSwapped(Room src, int bgInx1, int bgInx2) {
			BGTilePicker bgtp1 = bgTilePickers.get( bgInx1 );
			BGTilePicker bgtp2 = bgTilePickers.get( bgInx2 );
			
			bgTilePickers.set( bgInx1, bgtp2 );
			bgTilePickers.set( bgInx2, bgtp1 );
		}
		
		public void bgTileChanged(Room src, int layerIndex, int row, int col) {}
		public void bgTileColorChanged(Room src, int layerIndex, int row, int col) {}
		public void blockChanged(Room src, int row, int col) {}
		public void defaultObjLayerChanged(Room src) {}
		public void gameObjAdded(Room src, int newIndex) {}
		public void gameObjRemoved(Room src, int oldIndex, GameObj obj) {}
		public void gameObjSwapped(Room src, int i1, int i2) {}
		public void waterLevelChanged(Room src) {}
		
	}
	
	
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {

		public void basePathChanged(GlobalEditorModel src) {}
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
		public void gridVisibilityChanged(GlobalEditorModel src) {}
		public void scrollChanged(GlobalEditorModel src) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		public void zoomChanged(GlobalEditorModel src) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
		
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {
			oldRoom.removeListener( roomListener );
			src.getLoadedRoom().addListener( roomListener );
			
			recreateTilePickers();
			
			tileToolBox.revalidate();
			tileToolBox.repaint();
		}
		
		public void workingLayerChanged(GlobalEditorModel src) {
			tileToolBox.removeAll();
			
			int layerInx = src.getWorkingLayer();
			if ( layerInx == -1 )
				tileToolBox.add( blockPicker );
			else
				tileToolBox.add( bgTilePickers.get( layerInx ), 0 );
			
			tileToolBox.revalidate();
			tileToolBox.repaint();
		}
		
		public void selectionChanged ( GlobalEditorModel src, SelectionSet oldSelection ) {}
		
	}
	
	
	
	
	private RoomPanel roomPanel;
	private JLabel statusBar;
	private ButtonGroup btnGroup = new ButtonGroup();
	private Vector<JToggleButton> buttons = new Vector<JToggleButton>();
	private Vector<Tool> tools = new Vector<Tool>();
	private Vector<Tool.Listener> toolListeners = new Vector<Tool.Listener>();
	private int currToolInx = -1;
	private GlobalEditorModel globalEditorModel;
	
	private Box tileToolBox = Box.createHorizontalBox();
	private Vector<BGTilePicker> bgTilePickers = new Vector<BGTilePicker>();
	private BlockPicker blockPicker;
	
	private ColorToolBox colorToolBox = new ColorToolBox();
	
	
	private GlobalEditorModelListener globalEditorModelListener = new GlobalEditorModelListener();
	private RoomListener roomListener = new RoomListener();
	
	private Vector<Listener> listeners = new Vector<Listener>();
	
	
	
	
	public void addListener ( Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	
	
	
	public void removeListener ( Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	public ToolBar ( GlobalEditorModel globalEditorModel,
	                 Tool.Listener[] toolListeners,
	                 RoomPanel roomPanel,
	                 JLabel statusBar ) {
		super( BoxLayout.X_AXIS );
		setAlignmentX( 0 );
		setAlignmentY( 0 );
		
		this.roomPanel = roomPanel;
		this.statusBar = statusBar;
		this.globalEditorModel = globalEditorModel;
		for ( int i = 0; i < toolListeners.length; i++ )
			this.toolListeners.add( toolListeners[i] );
		
		globalEditorModel.addListener( globalEditorModelListener );
		globalEditorModel.getLoadedRoom().addListener( roomListener );
		
		// 
		// TILE TOOL BOX
		// 
		this.blockPicker = new BlockPicker( globalEditorModel.getLoadedRoom().getBlockSize() );
		recreateTilePickers();
		// Set initial active layer:
		globalEditorModelListener.workingLayerChanged( globalEditorModel );
		
		// Create and register tools:
		Tool[] toolArray = {
			new TileBrushTool( globalEditorModel, this ),
			new TileEraserTool( globalEditorModel, this ),
			new TileFillTool( globalEditorModel, this ),
			new TileSelectionTool( globalEditorModel, this ),
			null,
			new ColorBrushTool( globalEditorModel, this ),
			new ColorFillTool( globalEditorModel, this ),
			new ColorSelectionTool( globalEditorModel, this ),
			null,
			new GameObjSelectionTool( globalEditorModel, this ),
			null,
			new ScrollTool( globalEditorModel, this )
		};
		
		for ( int i = 0; i < toolArray.length; i++ ) {
			Tool tool = toolArray[i];
			
			if ( tool == null ) {
				add( Box.createHorizontalStrut( 5 ) );
			}
			else {
				JToggleButton btn = new JToggleButton( tool.getToolIcon() );
				btn.setMargin( new Insets(0, 0, 0, 0) );
				btn.setToolTipText( tool.getToolName() );
				btn.addMouseListener( new ToolDescrMouseAdapter( tool ) );
				btn.setActionCommand( Integer.toString(tools.size()) );
				btn.addActionListener( new ActionListener () {
					public void actionPerformed ( ActionEvent evt ) {
						int i = Integer.parseInt( evt.getActionCommand() );
						setCurrentTool( i );
					}
				} );
				
				btnGroup.add( btn );
				buttons.add( btn );
				tools.add( tool );
				add( Box.createHorizontalStrut( 1 ) );
				add( btn );
			}
		}
		
		add( Box.createHorizontalGlue() );
		
		// Done!
		setCurrentTool( 0 );
	}
	
	
	
	
	public void setCurrentTool ( int toolInx ) {
		if ( currToolInx == toolInx )
			return;
		
		// Remove listeners from current tool...
		Tool oldTool = null;
		if ( currToolInx != -1 ) {
			oldTool = tools.get( currToolInx );
			for ( int i = 0; i < toolListeners.size(); i++ )
				oldTool.removeListener( toolListeners.get( i ) );
			
			roomPanel.removeMouseListener( oldTool );
			roomPanel.removeMouseMotionListener( oldTool );
			KeyboardFocusManager.getCurrentKeyboardFocusManager().removeKeyEventDispatcher( oldTool );
		}
		
		// Release selection if it was floating:
		if ( globalEditorModel.isSelectionFloating() ) {
			UndoImpl.Composite undoOp = new UndoImpl.Composite();
			int layerInx = globalEditorModel.getWorkingLayer();
			SelectionSet selection = globalEditorModel.getSelectionSet().clone();
			
			// Defloat:
			Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			globalEditorModel.defloatSelection();
			Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
			
			undoOp.add(
				new UndoImpl.DefloatSelection(
					globalEditorModel,
					this,
					currToolInx,
					layerInx,
					oldState,
					newState,
					selection ) );
			
			// Commit undo operation:
			HistoryManager.addUndoOperation( undoOp, "defloat selection" );
		}
		
		// ...And set the new tool:
		currToolInx = toolInx;
		Tool newTool = tools.get( toolInx );
		for ( int i = 0; i < toolListeners.size(); i++ )
			newTool.addListener( toolListeners.get( i ) );
		
		roomPanel.addMouseListener( newTool );
		roomPanel.addMouseMotionListener( newTool );
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher( newTool );
		
		btnGroup.setSelected( buttons.get( toolInx ).getModel(), true );
		
		// Transfer input state:
		if ( oldTool != null )
			SmartInputAdapter.transfer( oldTool, newTool, roomPanel );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).toolChanged( this );
		
		// Send notifications:
		if ( oldTool != null )
			oldTool.lostToolBarFocus();
		newTool.gainedToolBarFocus();
	}
	
	
	
	
	public Tool getCurrentTool () {
		return tools.get( currToolInx );
	}
	
	
	
	
	public Tool getTool ( int inx ) {
		return tools.get( inx );
	}
	
	
	
	
	public static int getSelectionToolIndex ( SelectionSet selection ) {
		if ( selection == null )
			throw new IllegalArgumentException("Can't determine selection tool for null selection.");
		else
		if ( selection instanceof BlockSelectionSet ||
		     selection instanceof BGTileSelectionSet )
			return TILESELECTION_TOOL_INX;
		else
		if ( selection instanceof BGTileColorSelectionSet )
			return COLORSELECTION_TOOL_INX;
		else
		if ( selection instanceof GameObjSelectionSet )
			return GAMEOBJSELECTION_TOOL_INX;
		else
			throw new IllegalArgumentException("Unknown selection type: " + selection.getClass().getSimpleName() );
	}
	
	
	
	
	public BlockPicker getBlockPicker () {
		return blockPicker;
	}
	
	
	
	
	public BGTilePicker getBGTilePicker ( int layerInx ) {
		return bgTilePickers.get( layerInx );
	}
	
	
	
	
	public Box getTileToolBox () {
		return tileToolBox;
	}
	
	
	
	
	private void recreateTilePickers () {
		Room room = globalEditorModel.getLoadedRoom();
		
		bgTilePickers.removeAllElements();
		
		for ( int i = 0; i < room.getNumOfBGLayers(); i++ )
			bgTilePickers.add( new BGTilePicker( room.getBGLayer( i ) ) );
	}
	
	
	
	
	public ColorToolBox getColorToolBox () {
		return colorToolBox;
	}
	
}
