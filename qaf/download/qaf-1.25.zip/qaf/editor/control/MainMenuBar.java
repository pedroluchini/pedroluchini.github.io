package control;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Vector;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

import model.BGLayer;
import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.SelectionSet;
import control.dlg.EditBGLayerDialog;
import control.dlg.EditGameObjDialog;
import control.dlg.NewRoomDialog;
import control.dlg.OpenRoomDialog;
import control.dlg.TranslateLayerDialog;
import control.tool.ToolBar;


public class MainMenuBar extends JMenuBar {
	static final long serialVersionUID = 0;
	
	public static final float[] ZOOM_FACTORS = { 1.0f/3, 1.0f/2, 1, 2, 3 };
	public static final int INITIAL_ZOOM_INDEX = 2; 
	
	
	
	
	private class HistoryManagerListener implements HistoryManager.Listener {

		public void historyChanged() {
			if ( HistoryManager.nextUndoDescription() == null ) {
				undoMenuItem.setText( "Undo" );
				undoMenuItem.setEnabled( false );
			}
			else {
				undoMenuItem.setText( "Undo " + HistoryManager.nextUndoDescription() );
				undoMenuItem.setEnabled( true );
			}
			
			if ( HistoryManager.nextRedoDescription() == null ) {
				redoMenuItem.setText( "Redo" );
				redoMenuItem.setEnabled( false );
			}
			else {
				redoMenuItem.setText( "Redo " + HistoryManager.nextRedoDescription() );
				redoMenuItem.setEnabled( true );
			}
		}
		
	}
	
	
	
	
	private class RoomListener implements Room.Listener {

		public void bgLayerSwapped(Room src, int bgInx1, int bgInx2) {}
		public void bgTileChanged(Room src, int layerIndex, int row, int col) {}
		public void bgTileColorChanged(Room src, int layerIndex, int row, int col) {}
		public void blockChanged(Room src, int row, int col) {}
		public void defaultObjLayerChanged(Room src) {}
		public void gameObjAdded(Room src, int newIndex) {}
		public void gameObjRemoved(Room src, int oldIndex, GameObj obj) {}
		public void gameObjSwapped(Room src, int i1, int i2) {}
		public void waterLevelChanged(Room src) {}
		
		public void bgLayerAdded(Room src, int newLayerIndex) {
			recreateShowBGLayerMenuItems();
		}

		public void bgLayerRemoved(Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] bgTileColorMatrix) {
			recreateShowBGLayerMenuItems();
		}
		
	}
	
	
	
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {

		public void basePathChanged(GlobalEditorModel src) {}
		public void scrollChanged(GlobalEditorModel src) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		
		public void workingLayerChanged(GlobalEditorModel src) {
			clipboardChanged( src, null );
		}
		
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {
			showObstacleMenuItem.setSelected( globalEditorModel.isBlockLayerVisible() );
		}
		
		public void gridVisibilityChanged(GlobalEditorModel src) {
			showGridMenuItem.setSelected( globalEditorModel.isGridVisible() );
		}
		
		public void zoomChanged (GlobalEditorModel src) {
			if ( src.getZoom() <= ZOOM_FACTORS[0] )
				zoomOutMenuItem.setEnabled( false );
			else
				zoomOutMenuItem.setEnabled( true );
			
			if ( src.getZoom() >= ZOOM_FACTORS[ZOOM_FACTORS.length - 1] )
				zoomInMenuItem.setEnabled( false );
			else
				zoomInMenuItem.setEnabled( true );
		}
		
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {
			oldRoom.removeListener( roomListener );
			src.getLoadedRoom().addListener( roomListener );
			
			recreateShowBGLayerMenuItems();
			
			clipboardChanged( src, null );
		}
		
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {
			updateShowBGLayerMenuItems();
		}
		
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {
			if ( src.getSelectionSet() != null ) {
				cutMenuItem.setEnabled( true );
				copyMenuItem.setEnabled( true );
				flipSelectionHorizontallyMenuItem.setEnabled( true );
				flipSelectionVerticallyMenuItem.setEnabled( true );
				selectNoneMenuItem.setEnabled( true );
			}
			else {
				cutMenuItem.setEnabled( false );
				copyMenuItem.setEnabled( false );
				flipSelectionHorizontallyMenuItem.setEnabled( false );
				flipSelectionVerticallyMenuItem.setEnabled( false );
				selectNoneMenuItem.setEnabled( false );
			}
		}
		
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {
			if ( src.getClipboardContents() == null ) {
				pasteMenuItem.setEnabled( false );
				pasteInPlaceMenuItem.setEnabled( false );
			}
			else {
				pasteMenuItem.setEnabled( src.getClipboardContents().canPaste( src ) );
				pasteInPlaceMenuItem.setEnabled( src.getClipboardContents().canPaste( src ) );
			}
		}
		
	}
	
	
	
	
	private GlobalEditorModel globalEditorModel;
	private JMenuItem undoMenuItem,
	                  redoMenuItem,
	                  cutMenuItem,
	                  copyMenuItem,
	                  pasteMenuItem,
	                  pasteInPlaceMenuItem,
	                  flipSelectionHorizontallyMenuItem,
	                  flipSelectionVerticallyMenuItem,
	                  selectNoneMenuItem,
	                  zoomInMenuItem,
	                  zoomOutMenuItem;
	private JCheckBoxMenuItem showGridMenuItem,
	                          showObstacleMenuItem;
	private Vector<JCheckBoxMenuItem> showBGLayerMenuItems = new Vector<JCheckBoxMenuItem>();
	private JMenu showBGLayerMenu;
	private ToolBar toolBar;
	private int currZoomInx = INITIAL_ZOOM_INDEX;
	
	private RoomListener roomListener = new RoomListener();
	
	
	
	
	public MainMenuBar ( GlobalEditorModel _globalEditorModel ) {
		this.globalEditorModel = _globalEditorModel;
		
		HistoryManager.addListener( new HistoryManagerListener() );
		globalEditorModel.addListener( new GlobalEditorModelListener() );
		globalEditorModel.getLoadedRoom().addListener( roomListener );
		
		// The menus:
		JMenu fileMenu = new JMenu( "File" );
		fileMenu.setMnemonic( KeyEvent.VK_F );
		JMenu editMenu = new JMenu( "Edit" );
		editMenu.setMnemonic( KeyEvent.VK_E );
		JMenu viewMenu = new JMenu( "View" );
		viewMenu.setMnemonic( KeyEvent.VK_V );
		JMenu roomMenu = new JMenu( "Room" );
		roomMenu.setMnemonic( KeyEvent.VK_R );
		
		add( fileMenu );
		add( editMenu );
		add( viewMenu );
		add( roomMenu );
		
		
		///////////////////////////////////////////////////////////////////////
		// FILE:
		//
		// New room:
		JMenuItem newRoomMenuItem = new JMenuItem( "New room..." );
		newRoomMenuItem.setMnemonic( KeyEvent.VK_N );
		newRoomMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.CTRL_MASK) );
		newRoomMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				// Check unsaved changes before unloading the room:
				if ( Main.checkUnsavedChanges( globalEditorModel, toolBar ) ) {
					// Show the "New room" dialog:
					if ( NewRoomDialog.newRoom( globalEditorModel ) ) {
						// If the user confirmed, all previous UndoOperations
						// are now invalid.
						HistoryManager.clear();
						
						globalEditorModel.setUnsavedChanges( false );
					}
				}
			} } );
		fileMenu.add( newRoomMenuItem );
		
		
		// Open room:
		JMenuItem openRoomMenuItem = new JMenuItem( "Open room..." );
		openRoomMenuItem.setMnemonic( KeyEvent.VK_O );
		openRoomMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_O, KeyEvent.CTRL_MASK) );
		openRoomMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				if ( !Main.checkUnsavedChanges( globalEditorModel, toolBar ) )
					return;
				
				// Open and load the room:
				if ( OpenRoomDialog.openRoom( globalEditorModel, null ) ) {
					// If the user confirmed, all previous UndoOperations are
					// now invalid.
					HistoryManager.clear();
					
					globalEditorModel.setUnsavedChanges( false );
				}
			} } );
		fileMenu.add( openRoomMenuItem );
		
		
		// Save room:
		JMenuItem saveRoomMenuItem = new JMenuItem( "Save room" );
		saveRoomMenuItem.setMnemonic( KeyEvent.VK_S );
		saveRoomMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_S, KeyEvent.CTRL_MASK) );
		saveRoomMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				Main.saveRoom( globalEditorModel, toolBar );
			} } );
		fileMenu.add( saveRoomMenuItem );
		
		
		// Save room as:
		JMenuItem saveRoomAsMenuItem = new JMenuItem( "Save room as..." );
		saveRoomAsMenuItem.setMnemonic( KeyEvent.VK_A );
		saveRoomAsMenuItem.setDisplayedMnemonicIndex( 10 );
		saveRoomAsMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				Main.saveRoomAs( globalEditorModel, toolBar );
			} } );
		fileMenu.add( saveRoomAsMenuItem );
		
		
		fileMenu.add( new JSeparator() );
		
		
		// Change base path:
		JMenuItem changeBasePathMenuItem = new JMenuItem( "Change base path..." );
		changeBasePathMenuItem.setMnemonic( KeyEvent.VK_B );
		changeBasePathMenuItem.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					if ( globalEditorModel.getLoadedRoom().getNumOfBGLayers() > 0 ) {
						String[] message = {
							"The room you are working on contains BGlayers. Those",
							"layers, in turn, have loaded images that depend on the",
							"base path.",
							" ",
							"Before changing the base path, you must either delete",
							"the room's layers or choose File->New room." };
						
						JOptionPane.showMessageDialog(
							Main.f,                      // parent dialog
							message,                     // message
							"Change base path",          // title
							JOptionPane.ERROR_MESSAGE ); // message type
					}
					else {
						String newPath = Main.promptForBasePath( globalEditorModel.getBasePath(), true );
						if ( newPath != null ) {
							// Commit UndoOperation:
							UndoOperation op = new UndoImpl.ChangeBasePath(
								globalEditorModel,
								globalEditorModel.getBasePath(),
								newPath );
							HistoryManager.addUndoOperation( op, "change base path" );
							
							// Update the base path:
							globalEditorModel.setBasePath( newPath );
						}
					}
				}
			} );
		fileMenu.add( changeBasePathMenuItem );
		
		
		fileMenu.add( new JSeparator() );
		
		
		// Exit:
		JMenuItem exitMenuItem = new JMenuItem( "Exit" );
		exitMenuItem.setMnemonic( KeyEvent.VK_X );
		exitMenuItem.addActionListener( new ActionListener() {
			 public void actionPerformed ( ActionEvent evt ) {
			 	if ( Main.checkUnsavedChanges( globalEditorModel, toolBar ) )
			 		Main.f.dispose();
			 } } );
		fileMenu.add( exitMenuItem );
		
		
		///////////////////////////////////////////////////////////////////////
		// EDIT:
		//
		// Undo and Redo:
		undoMenuItem = new JMenuItem( "Undo" );
		undoMenuItem.setEnabled( false ); // No undo available yet
		undoMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_Z, KeyEvent.CTRL_MASK ) );
		undoMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				HistoryManager.undo();
			} } );
		
		redoMenuItem = new JMenuItem( "Redo" );
		redoMenuItem.setEnabled( false ); // No redo available yet
		redoMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_Y, KeyEvent.CTRL_MASK ) );
		redoMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				HistoryManager.redo();
			} } );
		
		editMenu.add( undoMenuItem );
		editMenu.add( redoMenuItem );
		
		editMenu.add( new JSeparator() );
		
		// Cut, copy, and paste:
		cutMenuItem = new JMenuItem( "Cut" );
		cutMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_X, KeyEvent.CTRL_MASK ) );
		cutMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				Main.copy( globalEditorModel );
				
				// Simulate selection being deleted:
				Main.processSelectionKeyEvent(
					globalEditorModel,
					toolBar,
					new KeyEvent(
						MainMenuBar.this,
						KeyEvent.KEY_PRESSED,
						System.currentTimeMillis(),
						0,
						KeyEvent.VK_DELETE,
						'\0' ) );
			} } );
		editMenu.add( cutMenuItem );
		
		copyMenuItem = new JMenuItem( "Copy" );
		copyMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_C, KeyEvent.CTRL_MASK ) );
		copyMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				Main.copy( globalEditorModel );
			} } );
		editMenu.add( copyMenuItem );
		
		pasteMenuItem = new JMenuItem( "Paste" );
		pasteMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_V, KeyEvent.CTRL_MASK ) );
		pasteMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				Main.paste( globalEditorModel, toolBar, true );
			} } );
		editMenu.add( pasteMenuItem );
		
		pasteInPlaceMenuItem = new JMenuItem( "Paste in place" );
		pasteInPlaceMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_V, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK ) );
		pasteInPlaceMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				Main.paste( globalEditorModel, toolBar, false );
			} } );
		editMenu.add( pasteInPlaceMenuItem );
		
		editMenu.add( new JSeparator() );
		
		// Select none:
		selectNoneMenuItem = new JMenuItem( "Select none" );
		selectNoneMenuItem.setEnabled( false );
		selectNoneMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_D, KeyEvent.CTRL_MASK ) );
		selectNoneMenuItem.addActionListener(
			new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					int selectionToolInx = ToolBar.getSelectionToolIndex( globalEditorModel.getSelectionSet() );
					Main.setSelectionSet( globalEditorModel, toolBar, selectionToolInx, null );
				}
			} );
		editMenu.add( selectNoneMenuItem );
		
		// Flip selection:
		flipSelectionHorizontallyMenuItem = new JMenuItem( "Flip selection horizontally" );
		flipSelectionHorizontallyMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_X, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK ) );
		flipSelectionHorizontallyMenuItem.addActionListener(
			new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					Main.flipSelection( globalEditorModel, toolBar, true, false );
				}
			} );
		editMenu.add( flipSelectionHorizontallyMenuItem );
		flipSelectionHorizontallyMenuItem.setEnabled( false );
		
		flipSelectionVerticallyMenuItem = new JMenuItem( "Flip selection vertically" );
		flipSelectionVerticallyMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_Y, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK ) );
		flipSelectionVerticallyMenuItem.addActionListener(
			new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					Main.flipSelection( globalEditorModel, toolBar, false, true );
				}
			} );
		editMenu.add( flipSelectionVerticallyMenuItem );
		flipSelectionVerticallyMenuItem.setEnabled( false );
		
		///////////////////////////////////////////////////////////////////////
		// VIEW:
		//
		// Show/hide grid:
		showGridMenuItem = new JCheckBoxMenuItem( "Show grid", globalEditorModel.isGridVisible() );
		showGridMenuItem.setMnemonic( KeyEvent.VK_G );
		showGridMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_G, KeyEvent.CTRL_MASK ) );
		showGridMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				globalEditorModel.setGridVisibility( showGridMenuItem.isSelected() );
			} } );
		viewMenu.add( showGridMenuItem );
		
		// Zoom menu:
		JMenu zoomMenu = new JMenu( "Zoom" );
		zoomMenu.setMnemonic( KeyEvent.VK_Z );
		
		zoomInMenuItem = new JMenuItem( "Zoom in" );
		zoomInMenuItem.setMnemonic( KeyEvent.VK_I );
		zoomInMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_ADD, 0 ) );
		zoomInMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
/*				// Calculate center point in the viewport:
				Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
				int viewCenterX = viewRect.x + viewRect.width/2;
				int viewCenterY = viewRect.y + viewRect.height/2;
				int roomCenterX = globalEditorModel.roomFromPanelX( viewCenterX );
				int roomCenterY = globalEditorModel.roomFromPanelY( viewCenterY ); */
				
				// Set new zoom:
				currZoomInx++;
				globalEditorModel.setZoom( ZOOM_FACTORS[currZoomInx] );
				
/*				// Calculate new center point in the viewport:
				Rectangle newViewRect = globalEditorModel.getViewport().getViewRect();
				int newViewCenterX = newViewRect.x + newViewRect.width/2;
				int newViewCenterY = newViewRect.y + newViewRect.height/2;
				int newRoomCenterX = globalEditorModel.roomFromPanelX( newViewCenterX );
				int newRoomCenterY = globalEditorModel.roomFromPanelY( newViewCenterY );
				
				// How much has the point moved?
				int dx = newRoomCenterX - roomCenterX;
				int dy = newRoomCenterY - roomCenterY;
				
				// Recalculate scrollbar position to maintain viewport center:
				Point p = globalEditorModel.getViewport().getViewPosition();
				p.x -= dx;
				p.y -= dy;
				globalEditorModel.getViewport().setViewPosition( p ); */
			} } );
		
		zoomOutMenuItem = new JMenuItem( "Zoom out" );
		zoomOutMenuItem.setMnemonic( KeyEvent.VK_O );
		zoomOutMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_SUBTRACT, 0 ) );
		zoomOutMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
/*				// Calculate center point in the viewport:
				Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
				int viewCenterX = viewRect.x + viewRect.width/2;
				int viewCenterY = viewRect.y + viewRect.height/2;
				int roomCenterX = globalEditorModel.roomFromPanelX( viewCenterX );
				int roomCenterY = globalEditorModel.roomFromPanelY( viewCenterY ); */
				
				// Set new zoom:
				currZoomInx--;
				globalEditorModel.setZoom( ZOOM_FACTORS[currZoomInx] );
				
/*				// Calculate new center point in the viewport:
				Rectangle newViewRect = globalEditorModel.getViewport().getViewRect();
				int newViewCenterX = newViewRect.x + newViewRect.width/2;
				int newViewCenterY = newViewRect.y + newViewRect.height/2;
				int newRoomCenterX = globalEditorModel.roomFromPanelX( newViewCenterX );
				int newRoomCenterY = globalEditorModel.roomFromPanelY( newViewCenterY );
				
				// How much has the point moved?
				int dx = newRoomCenterX - roomCenterX;
				int dy = newRoomCenterY - roomCenterY;
				
				// Recalculate scrollbar position to maintain viewport center:
				Point p = globalEditorModel.getViewport().getViewPosition();
				p.x -= dx;
				p.y -= dy;
				globalEditorModel.getViewport().setViewPosition( p ); */
			} } );
		
		zoomMenu.add( zoomInMenuItem );
		zoomMenu.add( zoomOutMenuItem );
		viewMenu.add( zoomMenu );
		
		viewMenu.add( new JSeparator() );
		
		// Show/hide obstacle layer:
		showObstacleMenuItem = new JCheckBoxMenuItem( "Show obstacle layer" );
		showObstacleMenuItem.setMnemonic( KeyEvent.VK_B );
		showObstacleMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_B, KeyEvent.CTRL_MASK ) );
		showObstacleMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				if ( showObstacleMenuItem.isSelected() != globalEditorModel.isBlockLayerVisible() )
					globalEditorModel.setBlockLayerVisibility( showObstacleMenuItem.isSelected() );
			} } );
		viewMenu.add( showObstacleMenuItem );
		showObstacleMenuItem.setSelected( globalEditorModel.isBlockLayerVisible() );
		
		// Show BG layers submenu:
		showBGLayerMenu = new JMenu( "BG layers" );
		showBGLayerMenu.setMnemonic( KeyEvent.VK_L );
		showBGLayerMenu.setDisplayedMnemonicIndex( 3 );
		{	
			JMenuItem showAllLayersMenuItem = new JMenuItem( "Show all BG layers" );
			showAllLayersMenuItem.setMnemonic( KeyEvent.VK_S );
			showAllLayersMenuItem.setDisplayedMnemonicIndex( 0 );
			showAllLayersMenuItem.addActionListener( new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					for ( int i = 0; i < globalEditorModel.getLoadedRoom().getNumOfBGLayers(); i++ )
						globalEditorModel.setBGLayerVisibility( i, true );
				} } );
			showBGLayerMenu.add( showAllLayersMenuItem );
				
			// Hide all BG layers:
			JMenuItem hideAllLayersMenuItem = new JMenuItem( "Hide all BG layers" );
			hideAllLayersMenuItem.setMnemonic( KeyEvent.VK_H );
			showAllLayersMenuItem.setDisplayedMnemonicIndex( 0 );
			hideAllLayersMenuItem.addActionListener( new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					for ( int i = 0; i < globalEditorModel.getLoadedRoom().getNumOfBGLayers(); i++ )
						globalEditorModel.setBGLayerVisibility( i, false );
				} } );
			showBGLayerMenu.add( hideAllLayersMenuItem );
			
			showBGLayerMenu.add( new JSeparator() );
			
			recreateShowBGLayerMenuItems();
		}
		viewMenu.add( showBGLayerMenu );
		
		
		///////////////////////////////////////////////////////////////////////
		// ROOM:
		//
		// New game object:
		JMenuItem addGameObjMenuItem = new JMenuItem( "New game object..." );
		addGameObjMenuItem.setMnemonic( KeyEvent.VK_O );
		addGameObjMenuItem.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					// Prompt for new GameObj:
					GameObj newObj = EditGameObjDialog.createGameObj();
					if ( newObj != null ) {
						// Calculate center point in the viewport:
						Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
						int viewCenterX = viewRect.x + viewRect.width/2;
						int viewCenterY = viewRect.y + viewRect.height/2;
						int roomCenterX = globalEditorModel.roomXFromPanelX( viewCenterX );
						int roomCenterY = globalEditorModel.roomYFromPanelY( viewCenterY );
						
						// Set object positiont to the center of the viewport:
						newObj.setPosition( roomCenterX, roomCenterY );
						
						// Add it to the room:
						globalEditorModel.getLoadedRoom().addGameObj( 0, newObj );
						
						// Commit UndoOperation:
						UndoOperation op = new UndoImpl.CreateObject(
								globalEditorModel,
								globalEditorModel.getLoadedRoom(),
								0,
								newObj );
						HistoryManager.addUndoOperation( op, "create game object" );
						
						globalEditorModel.setUnsavedChanges( true );
					}
				}
			} );
		roomMenu.add( addGameObjMenuItem );
		
		// New BG Layer:
		JMenuItem addBGLayerMenuItem = new JMenuItem( "New BG layer..." );
		addBGLayerMenuItem.setMnemonic( KeyEvent.VK_L );
		addBGLayerMenuItem.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					Room room = globalEditorModel.getLoadedRoom();
					int oldDefObjLayer = room.getDefaultObjLayer();
					if ( EditBGLayerDialog.createLayer( globalEditorModel ) ) {
						// User confirmed.
						UndoImpl.Composite undoOp = new UndoImpl.Composite();
						
						// Unselect everything:
						if ( globalEditorModel.isSelectionFloating() ) {
							int layerInx = globalEditorModel.getWorkingLayer();
							SelectionSet selection = globalEditorModel.getSelectionSet().clone();
							
							Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
							globalEditorModel.defloatSelection();
							Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
							
							undoOp.add(
								new UndoImpl.DefloatSelection(
									globalEditorModel,
									toolBar,
									ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
									layerInx,
									oldState,
									newState,
									selection ) );
						}
						if ( globalEditorModel.getSelectionSet() != null ) {
							SelectionSet oldSelection = globalEditorModel.getSelectionSet();
							boolean oldFloating = globalEditorModel.isSelectionFloating();
							globalEditorModel.setSelectionSet(null, false);
							undoOp.add(
								new UndoImpl.SelectionSetChanged(
									globalEditorModel,
									toolBar,
									ToolBar.getSelectionToolIndex(oldSelection),
									globalEditorModel.getWorkingLayer(),
									oldSelection,
									globalEditorModel.getSelectionSet(),
									oldFloating,
									globalEditorModel.isSelectionFloating() ) );
						}
						
						// Create the layer:
						int layerInx = room.getNumOfBGLayers() - 1;
						BGLayer bgLayer = room.getBGLayer( layerInx );
						int[][] bgTileMatrix = Main.getLayerTileMatrix( room, layerInx );
						ColorTile[][] bgTileColorMatrix = Main.getLayerTileColorMatrix( room, layerInx );
						
						undoOp.add(
							new UndoImpl.CreateBGLayer(
								globalEditorModel,
								room,
								layerInx,
								bgLayer,
								bgTileMatrix,
								bgTileColorMatrix,
								oldDefObjLayer,
								room.getDefaultObjLayer() ) );
						
						// Commit UndoOperation:
						HistoryManager.addUndoOperation( undoOp, "create BG layer " + layerInx );
						
						globalEditorModel.setUnsavedChanges( true );
						
						// Focus on this layer:
						globalEditorModel.setWorkingLayer( layerInx );
					}
				}
			} );
		roomMenu.add( addBGLayerMenuItem );
		
		roomMenu.add( new JSeparator() );
		
		// Translate layer:
		JMenuItem translateLayerMenuItem = new JMenuItem( "Translate layer..." );
		translateLayerMenuItem.setMnemonic( KeyEvent.VK_T );
		translateLayerMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_T, KeyEvent.CTRL_MASK ) );
		translateLayerMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				int workingLayerInx = globalEditorModel.getWorkingLayer();
				if ( workingLayerInx == -1 )
					JOptionPane.showMessageDialog(
						Main.f,                      // parent dialog
						"The obstacle layer cannot be translated.", // message
						"Translate layer",           // title
						JOptionPane.ERROR_MESSAGE ); // message type
				else {
					BGLayer bgLayer = globalEditorModel.getLoadedRoom().getBGLayer( workingLayerInx );
					Point oldTrans = new Point( bgLayer.getTranslationX(), bgLayer.getTranslationY() );
					if ( TranslateLayerDialog.showTranslateDialog( bgLayer ) ) {
						// User confirmed.
						// Commit UndoOperation:
						UndoOperation op = new UndoImpl.TranslateBGLayer(
								globalEditorModel,
								bgLayer,
								oldTrans,
								new Point(bgLayer.getTranslationX(), bgLayer.getTranslationY()) );
						
						HistoryManager.addUndoOperation( op, "translate BG layer " + workingLayerInx );
						
						globalEditorModel.setUnsavedChanges( true );
					}
				}
			} } );
		roomMenu.add( translateLayerMenuItem );
		
		// Done!
		
	}
	
	
	
	
	private void recreateShowBGLayerMenuItems () {
		// Remove all items:
		while ( showBGLayerMenuItems.size() > 0 ) {
			showBGLayerMenu.remove( showBGLayerMenuItems.get( 0 ) );
			showBGLayerMenuItems.remove( 0 );
		}
		
		// Create menu items:
		Room room = globalEditorModel.getLoadedRoom();
		if ( room.getNumOfBGLayers() == 0 ) {
			JCheckBoxMenuItem menuItem = new JCheckBoxMenuItem( "No BG layers" );
			menuItem.setEnabled( false );
			
			showBGLayerMenuItems.add( menuItem );
			showBGLayerMenu.add( menuItem );
		}
		
		for ( int layerInx = 0; layerInx < room.getNumOfBGLayers(); layerInx++ ) {
			JCheckBoxMenuItem menuItem = new JCheckBoxMenuItem( "Show BG layer " + layerInx );
			menuItem.setActionCommand( Integer.toString(layerInx) );
			if ( layerInx < 10 ) {
				menuItem.setMnemonic( makeKeyCodeFromDigit( layerInx ) );
				menuItem.setAccelerator( KeyStroke.getKeyStroke( makeKeyCodeFromDigit( layerInx ), KeyEvent.CTRL_MASK ) );
			}
			menuItem.addActionListener(
				new ActionListener() {
					public void actionPerformed ( ActionEvent evt )  {
						int layerInx = Integer.parseInt( evt.getActionCommand() );
						JCheckBoxMenuItem menuItem = showBGLayerMenuItems.get( layerInx );
						globalEditorModel.setBGLayerVisibility( layerInx, menuItem.isSelected() );
					}
				} );
			
			showBGLayerMenuItems.add( menuItem );
			showBGLayerMenu.add( menuItem );
		}
		
		updateShowBGLayerMenuItems();
	}
	
	
	
	
	private void updateShowBGLayerMenuItems () {
		for ( int i = 0; i < globalEditorModel.getLoadedRoom().getNumOfBGLayers(); i++ )
			showBGLayerMenuItems.get( i ).setSelected( globalEditorModel.isBGLayerVisible( i ) );
	}
	
	
	
	
	private int makeKeyCodeFromDigit ( int digit ) {
		switch ( digit ) {
		case 0:
			return KeyEvent.VK_0;
		case 1:
			return KeyEvent.VK_1;
		case 2:
			return KeyEvent.VK_2;
		case 3:
			return KeyEvent.VK_3;
		case 4:
			return KeyEvent.VK_4;
		case 5:
			return KeyEvent.VK_5;
		case 6:
			return KeyEvent.VK_6;
		case 7:
			return KeyEvent.VK_7;
		case 8:
			return KeyEvent.VK_8;
		case 9:
			return KeyEvent.VK_9;
		default:
			throw new IllegalArgumentException( "Cannot create keyboard shortcut from \"" + digit + "\"" );
		}
	}
	
	
	
	
	public void setCutEnabled ( boolean enabled ) {
		cutMenuItem.setEnabled( enabled );
	}
	
	
	
	
	public void setCopyEnabled ( boolean enabled ) {
		copyMenuItem.setEnabled( enabled );
	}
	
	
	
	
	public void setPasteEnabled ( boolean enabled ) {
		pasteMenuItem.setEnabled( enabled );
		pasteInPlaceMenuItem.setEnabled( enabled );
	}
	
	
	
	
	public void setToolBar ( ToolBar toolBar ) {
		this.toolBar = toolBar;
	}
	
}
