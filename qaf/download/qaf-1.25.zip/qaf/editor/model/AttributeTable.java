package model;

import java.util.Vector;

public class AttributeTable {
	
	// The object's attributes are stored as a list of String pairs (i.e.,
	// arrays with two elements each), where index 0 is the "key" and index 1
	// is the "value" -- sort of like a hashtable, but keeping them in this
	// format here makes it easier to edit them.
	private Vector<String[]> data = new Vector<String[]>();
	
	
	
	
	/**
	 * @return The value at the specified key, or null if none has been set. 
	 */
	public String getValue ( String key ) {
		// Search the Vector:
		int i = indexOf( key );
		
		if ( i != -1 ) {
			String[] pair = (String[]) data.get( i );
			return pair[1];
		}
		else
			// Couldn't find the key:
			return null;
	}
	
	
	
	
	/**
	 * If the key is already present, its value is overwritten. Otherwise, 
	 * the pair key/value is appended to the end of the Vector.
	 * If the value is null, the key will be removed.
	 */
	public void putPair ( String key, String value ) {
		// Search the Vector:
		int i = indexOf( key );
		
		if ( i != -1 ) {
			// The key already exists.
			String[] pair = (String[]) data.get( i );
			
			if ( value != null )
				pair[1] = value;
			else {
				// Remove:
				data.remove( i );
			}
		}
		else {
			// Append new pair:
			String[] pair = new String[2];
			
			pair[0] = key;
			pair[1] = value;
			
			data.add( pair );
		}
	}
	
	
	
	
	/**
	 * @return The number of keys present in this table.
	 */
	public int size () {
		return data.size();
	}
	
	
	
	
	/**
	 * @return the index of the specified key in the Vector, or -1 if it's not
	 * found.
	 */
	public int indexOf ( String key ) {
		// Search the Vector:
		for ( int i = 0; i < data.size(); i++ ) {
			String[] pair = (String[]) data.get( i );
			
			// Found it?
			if ( pair[0].equals( key ) )
				return i;
		}
		
		// Couldn't find the key:
		return -1;
	}
	
	
	
	
	/**
	 * @return The key at the specified index, or null if an invalid index is
	 * used. 
	 */
	public String getKey ( int i ) {
		if ( i < 0 || i >= data.size() )
			return null;
		else
			return ((String[]) data.get(i))[0];
	}
	
	
	
	
	/**
	 * @return The value at the specified index, or null if an invalid index
	 * is used. 
	 */
	public String getValue ( int i ) {
		if ( i < 0 || i >= data.size() )
			return null;
		else
			return ((String[]) data.get(i))[1];
	}
	
	
	
	
	public void removeAll () {
		data.removeAllElements();
	}
	
}
