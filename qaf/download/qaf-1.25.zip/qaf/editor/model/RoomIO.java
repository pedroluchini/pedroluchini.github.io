package model;

import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JOptionPane;

import control.Main;

/**
 * This class aggregates methods for reading/writing room files.
 * 
 * Integers are stored with a variant of UTF-8, which allows me to encode
 * negative integers.
 * 
 * The file format is:
 * 
 * - Version number:
 *   - "x" ints: described as a string that may be parsed and converted to a
 *               floating-point number.
 *   - 1 int: NULL character, to terminate the previous string
 * - The room header:
 *   - 1 int: obstacle block size (both width and height), in pixels
 *   - 1 int: screen width, in blocks
 *   - 1 int: screen height, in block
 *   - 1 int: room width, in screens
 *   - 1 int: room height, in screens
 *   - 1 int: water level
 *   - 1 int: default obj layer index
 *   - 1 int: number of game objects
 *   - 1 int: number of BG layers
 * - Game objects: For each game object,
 *   - "x" ints: ID
 *   - 1 int: NULL character, to terminate the previous string
 *   - 1 int: x position
 *   - 1 int: y position
 *   - 1 int: number of attributes
 *   - Attributes: For each attribute,
 *     - "x" ints: key
 *     - 1 int: NULL character, to terminate the previous string
 *     - "x" ints: value
 *     - 1 int: NULL character, to terminate the previous string
 * - Obstacle matrix:
 *   - 1 int: number of rows
 *   - 1 int: number of columns
 *   - rows * colums ints: block IDs, stored in row-order
 * - BG layers: For each layer,
 *   - "x" ints: source image path
 *   - 1 int: NULL character, to terminate the previous string
 * Version 1.0 {
 *   - "x" ints: parallax factor, described as a string that may be parsed and
 *               converted to a floating-point number.
 *   - 1 int: NULL character, to terminate the previous string
 * }
 * Version 1.1 {
 *   - "x" ints: X parallax factor, described as a string that may be parsed and
 *               converted to a floating-point number.
 *   - 1 int: NULL character, to terminate the previous string
 *   - "x" ints: Y parallax factor, described as a string that may be parsed and
 *               converted to a floating-point number.
 *   - 1 int: NULL character, to terminate the previous string
 * }
 *   - 1 int: tile width
 *   - 1 int: tile height
 *   - 1 int: translation along the X axis
 *   - 1 int: translation along the Y axis
 *   - Data matrix:
 *     - 1 int: number of rows
 *     - 1 int: number of columns
 *     - rows * columns: The layer's data matrix, stored in row-first order.
 *       - 1 int: The tile ID
 * Version 1.2 {
 *       If the COLORED_TILE_MASK bit is set:
 *       - 1 int: Blend mode
 *       - 1 int: ARGB of top-left vertex
 *       - 1 int: ARGB of top-right vertex
 *       - 1 int: ARGB of bottom-right vertex
 *       - 1 int: ARGB of bottom-left vertex
 * }
 * 
 */
public abstract class RoomIO {
	
	public static class RoomFormatException extends Exception {
		static final long serialVersionUID = 0;
	}
	
	
	
	
	/**
	 * Given a room, writes it to a file. (The specified path is NOT treated as
	 * relative to the base path.)
	 */
	public static void writeRoom ( Room room, String filename ) throws IOException {
		IntegerOutputStream file = new IntegerOutputStream( filename );
		
		// VERSION NUMBER:
		file.writeNullterminatedString( Float.toString( Main.QAF_VERSION ) );
		
		// ROOM HEADER:
		file.writeInt( room.getBlockSize() );
		file.writeInt( room.getScreenWidth() );
		file.writeInt( room.getScreenHeight() );
		file.writeInt( room.getRoomWidth() );
		file.writeInt( room.getRoomHeight() );
		file.writeInt( room.getWaterLevel() );
		file.writeInt( room.getDefaultObjLayer() );
		file.writeInt( room.getNumOfObjs() );
		file.writeInt( room.getNumOfBGLayers() );
		
		// GAME OBJECTS:
		for ( int objInx = 0; objInx < room.getNumOfObjs(); objInx++ ) {
			GameObj obj = room.getObj( objInx );
			
			file.writeNullterminatedString( obj.getID() );
			file.writeInt( obj.getX() );
			file.writeInt( obj.getY() );
			
			String[] attributes = obj.getAttributeKeys();
			
			file.writeInt( attributes.length );
			
			for ( int attrInx = 0; attrInx < attributes.length; attrInx++ ) {
				file.writeNullterminatedString( attributes[attrInx] );
				file.writeNullterminatedString( obj.getAttribute( attributes[attrInx] ) );
			}
		}
		
		// OBSTACLE MATRIX:
		{
			int rows = room.getBlockMatrixRows();
			int cols = room.getBlockMatrixCols();
			
			file.writeInt( rows );
			file.writeInt( cols );
			for ( int i = 0;i < rows; i++ )
				for ( int j = 0; j < cols; j++ )
					file.writeInt( room.getBlock( i, j ) );
		}
		
		// BG LAYERS:
		for ( int layerInx = 0; layerInx < room.getNumOfBGLayers(); layerInx++ ) {
			BGLayer bgLayer = room.getBGLayer( layerInx );
			
			file.writeNullterminatedString( bgLayer.getImageFileName() );
			file.writeNullterminatedString( Float.toString( bgLayer.getParallaxX() ) );
			file.writeNullterminatedString( Float.toString( bgLayer.getParallaxY() ) );
			file.writeInt( bgLayer.getTileWidth() );
			file.writeInt( bgLayer.getTileHeight() );
			file.writeInt( bgLayer.getTranslationX() );
			file.writeInt( bgLayer.getTranslationY() );
			
			int rows = room.getBGTileMatrixRows( layerInx );
			int cols = room.getBGTileMatrixCols( layerInx );
			
			file.writeInt( rows );
			file.writeInt( cols );
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ ) {
					int tileID = room.getBGTile( layerInx, i, j );
					ColorTile tileColor = room.getBGTileColor( layerInx, i, j );
					
					if ( tileID == -1 || ColorTile.DEFAULT.equals( tileColor ) )					
						file.writeInt( tileID );
					else {
						tileID |= Room.COLORED_TILE_MASK;
						
						file.writeInt( tileID );
						file.writeInt( tileColor.getBlend() );
						file.writeInt( tileColor.getColor(0).getRGB() );
						file.writeInt( tileColor.getColor(1).getRGB() );
						file.writeInt( tileColor.getColor(2).getRGB() );
						file.writeInt( tileColor.getColor(3).getRGB() );
					}
				}
		}
		
		// Done!
		file.close();
	}
	
	
	
	/**
	 * Given a filename, opens it and decodes its contents as a room. (The path
	 * is NOT treated as relative to the base path.)
	 */
	public static Room readRoom ( String filename, GlobalEditorModel globalEditorModel ) throws IOException, RoomFormatException, NumberFormatException {
		IntegerInputStream file = new IntegerInputStream( filename );
		Room room = null;
		
		// VERSION NUMBER:
		float versionNo = Float.parseFloat( file.readNullTerminatedString() );
		if ( versionNo > Main.QAF_VERSION ) {
			JOptionPane.showMessageDialog(
				Main.f,
				"This room was created with a later version of Qaf.\n" +
				"Your current version (" + Main.QAF_VERSION + ") cannot read it.",
				"Version mismatch",
				JOptionPane.ERROR_MESSAGE );
			
			throw new NumberFormatException();
		}
		
		// ROOM HEADER:
		int blockSize      = file.readInt();
		int screenWidth    = file.readInt();
		int screenHeight   = file.readInt();
		int roomWidth      = file.readInt();
		int roomHeight     = file.readInt();
		int waterLevel     = file.readInt();
		int defObjLayer    = file.readInt();
		int numOfGameObj   = file.readInt();
		int numOfBGLayers  = file.readInt();
		
		room = new Room( blockSize, screenWidth, screenHeight, roomWidth, roomHeight, waterLevel );
		
		// GAME OBJECTS:
		for ( int objInx = 0; objInx < numOfGameObj; objInx++ ) {
			String id = file.readNullTerminatedString();
			int x     = file.readInt();
			int y     = file.readInt();
			
			GameObj obj = new GameObj( id, x, y );
			
			int numOfAttributes = file.readInt();
			for ( int attrInx = 0; attrInx < numOfAttributes; attrInx++ ) {
				String key   = file.readNullTerminatedString();
				String value = file.readNullTerminatedString();
				
				obj.setAttribute( key, value );
			}
			
			room.addGameObj( obj );
		}
		
		// OBSTACLE MATRIX:
		{
			int rows = file.readInt();
			int cols = file.readInt();
			
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ )
					room.setBlock( i, j, file.readInt() ); 
		}
		
		// BG LAYERS:
		for ( int layerInx = 0; layerInx < numOfBGLayers; layerInx++ ) {
			String sourceImagePath = file.readNullTerminatedString();
			float parallaxFactorX, parallaxFactorY;
			if ( versionNo >= 1.1f ) {
				parallaxFactorX = Float.parseFloat( file.readNullTerminatedString() );
				parallaxFactorY = Float.parseFloat( file.readNullTerminatedString() );
			}
			else {
				parallaxFactorX = Float.parseFloat( file.readNullTerminatedString() );
				parallaxFactorY = parallaxFactorX;
			}
			int tileWidth  = file.readInt();
			int tileHeight = file.readInt();
			int translateX = file.readInt();
			int translateY = file.readInt();
			
			int rows = file.readInt();
			int cols = file.readInt();
			
			room.addBGLayer( new BGLayer(
					Main.createImage( globalEditorModel.prependBasePath( sourceImagePath ) ),
					sourceImagePath,
					tileWidth, tileHeight,
					parallaxFactorX, parallaxFactorY,
					translateX, translateY ) );
			
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ ) {
					int tileID = file.readInt();
					
					if ( tileID == -1 || (tileID & Room.COLORED_TILE_MASK) == 0 || versionNo < 1.2 )
						room.setBGTile( layerInx, i, j, tileID );
					else {
						tileID &= ~Room.COLORED_TILE_MASK;
						room.setBGTile( layerInx, i, j, tileID );
						
						int blend = file.readInt();
						int argb0 = file.readInt();
						int argb1 = file.readInt();
						int argb2 = file.readInt();
						int argb3 = file.readInt();
						room.setBGTileColor(
							layerInx, i, j,
							new ColorTile(
								blend,
								new Color(argb0, true),
								new Color(argb1, true),
								new Color(argb2, true),
								new Color(argb3, true) ) );
					}
				}
		}
		
		if ( file.available() > 0 )
			throw new RoomFormatException();
		
		// Now, set the def. obj layer:
		room.setDefaultObjLayer( defObjLayer );
		
		// Done!
		file.close();
		return room; 
	}
	
	
	
	
	
	/**
	 * A FileOutputStream wrapper, which writes "int" primitives in my
	 * modified UTF-8 encoding.
	 */
	public static class IntegerOutputStream {
		private FileOutputStream file;
		
		public IntegerOutputStream ( String filename ) throws FileNotFoundException {
			file = new FileOutputStream( filename );
		}
		
		/**
		 * Writes the specified integer to the file, encoding it as needed.
		 */
		public void writeInt ( int value ) throws IOException {
			int[] encValue = encodeInt( value );
			
			for ( int i = 0; i < encValue.length; i++ )
				file.write( encValue[i] );
		}
		
		/**
		 * Closes the file.
		 */
		public void close () throws IOException {
			file.close(); 
		}
		
		/**
		 * Writes a null-terminated string to the file, converting each of its
		 * characters to integers and encoding the result.
		 */
		public void writeNullterminatedString ( String str ) throws IOException {
			for ( int i = 0; i < str.length(); i++ )
				writeInt( str.charAt( i ) );
		
			writeInt( 0 );
		}
		
		/**
		 * Auxiliary method: Encodes a 32-bit integer as a modified UTF-8
		 * sequence, MSBF. The returned array may contain up to seven bytes.
		 */
		public static int[] encodeInt ( int value ) {
			int[] enc;
			
			if ( value == 0x80000000 ) {
				// Special case, 'cause this doesn't fit in 31 bits and can't
				// be turned into a positive number.
				return new int[] { 0x7F };
			}
			else
			if ( value < 0 ) {
				// Precede negative numbers with 0xFF:
				int[] positiveEnc = encodeInt( -value );
				
				enc = new int[ positiveEnc.length + 1 ];
				enc[0] = 0xFF;
				for ( int i = 0; i < positiveEnc.length; i++ )
					enc[i + 1] = positiveEnc[i];
		
				return enc;
			}
			else
			if ( value >= 0 && value <= 0x0000007F ) {
				// ASCII:
				enc = new int[1];
				enc[0] = value;
				return enc;
			}
			else
			if ( value >= 0x00000080 && value <= 0x000007FF ) {
				// Two-byte sequence:
				enc = new int[2];
				
				// 110xxxxx 10xxxxxx
				enc[0] = mkByte("11000000") | (value >>> 6);
				enc[1] = mkByte("10000000") | ((value >>> 0) & mkByte("00111111"));
				return enc;
			}
			else
			if ( value >= 0x00000800 && value <= 0x0000FFFF ) {
				// Three-byte sequence:
				enc = new int[3];
				
				// 1110xxxx 10xxxxxx 10xxxxxx
				enc[0] = mkByte("11100000") | (value >>> 12);
				enc[1] = mkByte("10000000") | ((value >>> 6) & mkByte("00111111"));
				enc[2] = mkByte("10000000") | ((value >>> 0) & mkByte("00111111"));
				return enc;
			}
			else
			if ( value >= 0x00010000 && value <= 0x001FFFFF ) {
				// Four-byte sequence:
				enc = new int[4];
				
				// 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx 
				enc[0] = mkByte("11110000") | (value  >>> 18);
				enc[1] = mkByte("10000000") | ((value >>> 12) & mkByte("00111111"));
				enc[2] = mkByte("10000000") | ((value >>>  6) & mkByte("00111111"));
				enc[3] = mkByte("10000000") | ((value >>>  0) & mkByte("00111111"));
				return enc;
			}
			else
			if ( value >= 0x00200000 && value <= 0x03FFFFFF ) {
				// Five-byte sequence:
				enc = new int[5];
				
				// 111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
				enc[0] = mkByte("11111000") | (value  >>> 24);
				enc[1] = mkByte("10000000") | ((value >>> 18) & mkByte("00111111"));
				enc[2] = mkByte("10000000") | ((value >>> 12) & mkByte("00111111"));
				enc[3] = mkByte("10000000") | ((value >>>  6) & mkByte("00111111"));
				enc[4] = mkByte("10000000") | ((value >>>  0) & mkByte("00111111"));
				return enc;
			}
			else
			if ( value >= 0x04000000 && value <= 0x7FFFFFFF ) {
				// Six-byte sequence:
				enc = new int[6];
				
				// 1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 
				enc[0] = mkByte("11111100") | (value  >>> 30);
				enc[1] = mkByte("10000000") | ((value >>> 24) & mkByte("00111111"));
				enc[2] = mkByte("10000000") | ((value >>> 18) & mkByte("00111111"));
				enc[3] = mkByte("10000000") | ((value >>> 12) & mkByte("00111111"));
				enc[4] = mkByte("10000000") | ((value >>>  6) & mkByte("00111111"));
				enc[5] = mkByte("10000000") | ((value >>>  0) & mkByte("00111111"));
				
				return enc;			
			}
			else
				return null;
		}
	}
	
	
	
	
	/**
	 * A FileInputStream wrapper, which reads "int" primitives in my
	 * modified UTF-8 encoding.
	 */
	public static class IntegerInputStream {
		private FileInputStream file;
		
		public IntegerInputStream ( String filename ) throws FileNotFoundException {
			file = new FileInputStream( filename );
		}
		
		/**
		 * Closes the file.
		 */
		public void close () throws IOException {
			file.close(); 
		}
		
		public int available () throws IOException {
			return file.available();
		}
		
		/**
		 * Decodes the next encoded integer from the file. Throws a
		 * RoomFormatException if the file contains invalid encoding or
		 * end-of-file is reached.
		 */
		public int readInt () throws IOException, RoomFormatException {
			// Get the "header" byte:
			int b = file.read();
			
			// 01111111?
			if ( b == 0x7F ) {
				// Special case.
				return 0x80000000;
			}
			// 11111111?
			else
			if ( b == mkByte("11111111") ) {
				// The next integer is a negative number:
				return -readInt();
			}
			// 0xxxxxxx?
			else
			if ( (b & mkByte("10000000")) == 0 ) {
				// ASCII:
				return b;
			}
			// 10xxxxxx?
			else
			if ( (b & mkByte("11000000")) == mkByte("10000000") ) {
				// Error! Encoded integers cannot start with "10xxxxxx"!
				throw new RoomFormatException();
			}
			// 110xxxxx?
			else
			if ( (b & mkByte("11100000")) == mkByte("11000000") ) {
				// Two-byte sequence:
				int result = 0;
				
				// 110xxxxx 10xxxxxx
				result += (b & mkByte("00011111")) << 6;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 0;
				
				return result;
			}
			// 1110xxxx?
			else
			if ( (b & mkByte("11110000")) == mkByte("11100000") ) {
				// Three-byte sequence:
				int result = 0;
			
				// 1110xxxx 10xxxxxx 10xxxxxx
				result += (b & mkByte("00001111")) << 12;
			
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 6;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 0;
				
				return result;
			}
			// 11110xxx?
			else
			if ( (b & mkByte("11111000")) == mkByte("11110000") ) {
				// Four-byte sequence:
				int result = 0;
			
				// 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx 
				result += (b & mkByte("00000111")) << 18;
			
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 12;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 6;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 0;
				
				return result;
			}
			// 111110xx?
			else
			if ( (b & mkByte("11111100")) == mkByte("11111000") ) {
				// Five-byte sequence:
				int result = 0;
			
				// 111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 
				result += (b & mkByte("00000011")) << 24;
			
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 18;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 12;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 6;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 0;
				
				return result;
			}
			// 1111110x?
			else
			if ( (b & mkByte("11111110")) == mkByte("11111100") ) {
				// Six-byte sequence:
				int result = 0;
			
				// 1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 
				result += (b & mkByte("00000001")) << 30;
			
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 24;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 18;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 12;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 6;
				
				b = file.read();
				if ( (b & mkByte("11000000")) != mkByte("10000000") ) throw new RoomFormatException();
				else result += (b & mkByte("00111111")) << 0;
				
				return result;
			}
			else
				throw new RoomFormatException();
		}
		
		/**
		 * Reads integers from the file until a NULL character is found, and
		 * returns the read characters as a string (excluding the NULL).
		 */
		public String readNullTerminatedString () throws IOException, RoomFormatException {
			String str = "";
			int b;
			
			while ( true ) {
				b = readInt();
				if ( b == 0 )
					break;
				else
					str += (char) b;
			}
			
			return str;
		}
	
	}
	
	
	
	
	// Auxiliary method: Constructs a byte from the specified bits, e.g.
	//    mkByte( "01100010" )
	private static int mkByte ( String str ) {
		if ( str.length() != 8 )
			throw new NumberFormatException();
		else
			return Integer.parseInt( str, 2 );
	}
	
}
