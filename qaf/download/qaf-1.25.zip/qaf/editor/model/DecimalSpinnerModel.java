package model;

import java.math.BigDecimal;
import java.util.Vector;

import javax.swing.SpinnerModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Accepts any decimal value.
 */
public class DecimalSpinnerModel implements SpinnerModel {
	Vector<ChangeListener> changeListeners = new Vector<ChangeListener>();
	private BigDecimal value;
	
	public DecimalSpinnerModel ( float initialValue ) {
		value = new BigDecimal( Float.toString(initialValue) );
	}
	
	public void addChangeListener(ChangeListener c) {
		changeListeners.add( c );
	}
	public void removeChangeListener(ChangeListener c) {
		changeListeners.remove( c );
	}
	
	public Object getNextValue() {
		return value.add( new BigDecimal( "0.1" ) ).toString();
	}
	public Object getPreviousValue() {
		return value.subtract( new BigDecimal( "0.1" ) ).toString();
	}
	
	public Object getValue() {
		return value.toString();
	}
	public void setValue(Object obj) {
		try {
			BigDecimal newValue = new BigDecimal( obj.toString() );
			
			value = newValue;
			
			ChangeEvent evt = new ChangeEvent( this );
			for ( int i = 0; i < changeListeners.size(); i++ )
				((ChangeListener) changeListeners.get( i )).stateChanged( evt );
		}
		catch ( NumberFormatException exc ) {
			throw new IllegalArgumentException();
		}
	}
	
	public float getFloatValue () {
		return value.floatValue();
	}
}
