/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_OBJ_TUBECURSOROBJ_H
#define QAF_OBJ_TUBECURSOROBJ_H

#include "../qafGameObj.h"
#include "../qafutil/qafVector2D.h"


namespace qaf {
	
	/**
	 * Demonstrates moving-segment collision.
	 * 
	 * Use the arrow keys to move the blue cursor. Use the mouse to control the
	 * yellow cursor.
	 * 
	 * Press PageUp/PageDown to rotate the segment. Press NumPad +/- to change
	 * the segment's size.
	 * 
	 * A yellow "tube" is shot from the blue cursor to the yellow cursor. Red
	 * lines are drawn to display the contact points and normals.
	 */
	class TubeCursorObj : public GameObj {
		public:
			
			Vector2D pos, aim;
			Vector2D vel;
			float angle, length;
			
			TubeCursorObj ( float _x, float _y );
			virtual ~TubeCursorObj ();
			
			void update ( int objLayer, float dt );
			void render ( int objLayer, float scrollX, float scrollY );
			
		private:
			void * pHGE;
	};
	
}

#endif