package qaf.room.control;

public interface UndoOperation {
	/**
	 * Undoes the operation. What this means is that after this method is run,
	 * the application's state must be the same as it was before
	 * HistoryManager.addUndoOperation() was called. 
	 */
	public void perform ();
	
	/**
	 * Returns the equivalent of "Redo" for this "Undo" operation, and
	 * vice-versa.
	 */
	public UndoOperation getInverse ();
}
