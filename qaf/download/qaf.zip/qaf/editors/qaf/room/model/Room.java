package qaf.room.model;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Vector;

import qaf.room.view.BGPanel;

public class Room {
	
	/** Water level discretization: How much the level will change when
	 * raiseWaterLevel() and lowerWaterLevel() are called. */
	public static final int WATER_LEVELS_PER_BLOCK = 2;
	
	/** Color used to paint the tile grid, when it is enabled: */
	public static final Color TILE_GRID_COLOR = new Color( 130, 0, 0 ); 
	
	/** Color used to paint the screen grid, when it is enabled: */
	public static final Color SCREEN_GRID_COLOR = new Color( 255, 255, 200 );
	
	
	/** Contains instances of class BGLayer. */
	private Vector bgLayers = new Vector();
	
	/** Contains int matrices (int[][]), representing the tiles that make up
	 * this room's background layout. */
	private Vector bgData = new Vector();
	
	/** Contains instances of class GameObjectInstance. */
	public Vector gameObjects = new Vector();
	
	/** A matrix of integers, representing this room's obstacle layout. */
	private int[][] obstacleLayer;
	
	/** The water level present in this room, relative to the screen's top and
	 * measured in pixels. */
	private int waterLevel;
	
	/** Zero means objects will be drawn in front of all BGLayers; 1 means
	 * objects will be drawn in front of BGLayer 1; 2 means objects will be
	 * drawn in front of BGLayer 2; etc. */
	private int defaultObjLayerPosition; 
	
	/** Obstacle tile size, in pixels: */
	public final int blockSize;
	
	/** Screen size, in blocks: */
	public final int screenWidth, screenHeight;
	
	/** This room's size, in screens. */
	public final int roomWidth, roomHeight;
	
	
	/** Tied to the control package. A "fake" BGLayer representing the obstacle
	 * layer. */
	private BGLayer fakeOstacleLayer = null;
	
	
	/**
	 * Constructor: Empty room, with no BGLayers
	 */
	public Room ( int blockSize, int screenWidth, int screenHeight, int roomWidth, int roomHeight, int waterLevel, int defaultObjLayerPosition ) {
		this.blockSize               = blockSize;
		this.screenWidth             = screenWidth;
		this.screenHeight            = screenHeight;
		this.roomWidth               = roomWidth;
		this.roomHeight              = roomHeight;
		this.waterLevel              = waterLevel;
		this.defaultObjLayerPosition = defaultObjLayerPosition;
		
		obstacleLayer = new int[roomHeight * screenHeight][roomWidth * screenWidth];
		for ( int i = 0; i < obstacleLayer.length; i++ )
			for ( int j = 0; j < obstacleLayer[i].length; j++ )
				obstacleLayer[i][j] = -1;
		
		this.fakeOstacleLayer = BGLayer.createFakeObstacleLayer( blockSize );
	}
	
	/**
	 * Constructor: Empty room, with no BGLayers, no water, and default obj.
	 * layer at position zero.
	 */
	public Room ( int blockSize, int screenWidth, int screenHeight, int roomWidth, int roomHeight ) {
		this.blockSize           = blockSize;
		this.screenWidth         = screenWidth;
		this.screenHeight        = screenHeight;
		this.roomWidth           = roomWidth;
		this.roomHeight          = roomHeight;
		this.waterLevel          = roomHeight * screenHeight * blockSize + blockSize/WATER_LEVELS_PER_BLOCK;
		this.defaultObjLayerPosition = 0;
		
		obstacleLayer = new int[roomHeight * screenHeight][roomWidth * screenWidth];
		for ( int i = 0; i < obstacleLayer.length; i++ )
			for ( int j = 0; j < obstacleLayer[0].length; j++ )
				obstacleLayer[i][j] = -1;
		
		this.fakeOstacleLayer = BGLayer.createFakeObstacleLayer( blockSize );
	}
	
	
	
	/**
	 * Returns false if the water level could not be raised because it is at
	 * its highest level.
	 */
	public boolean raiseWaterLevel () {
		waterLevel -= blockSize / WATER_LEVELS_PER_BLOCK;
		
		if ( waterLevel < -1 ) {
			waterLevel = -1;
			return false;
		}
		else
			return true;
	}
	
	/**
	 * Returns false if the water level could not be lowered because it it at
	 * its lowest level.
	 */
	public boolean lowerWaterLevel () {
		waterLevel += blockSize / WATER_LEVELS_PER_BLOCK;
		
		if ( waterLevel > getPixelHeight() + 1 ) {
			waterLevel = roomHeight * screenHeight * blockSize + blockSize/WATER_LEVELS_PER_BLOCK;
			return false;
		}
		else
			return true;
	}
	
	
	/**
	 * Control this room's positioning of the default object layer.
	 */
	public void defaultObjLayerToFront () {
		defaultObjLayerPosition--;
		
		if ( defaultObjLayerPosition < 0 )
			defaultObjLayerPosition = 0;
	}
	
	public void defaultObjLayerToBack () {
		defaultObjLayerPosition++;
		
		if ( defaultObjLayerPosition > bgLayers.size() )
			defaultObjLayerPosition = bgLayers.size();
	}
	
	
	/**
	 * Returns the BGLayer at index "layer", or constant OBSTACLE_LAYER if
	 * index -1 is used.
	 */
	public BGLayer getBGLayer ( int layer ) {
		if ( layer == -1 )
			return fakeOstacleLayer;
		else
			return (BGLayer) bgLayers.get( layer );
	}
	
	/**
	 * Swaps the position of two layers in the layer order.
	 * Index -1 is NOT valid.
	 */
	public void swapLayers ( int layer1, int layer2 ) {
		if ( layer1 == -1 || layer2 == -1 )
			throw new ArrayIndexOutOfBoundsException();
		
		BGLayer bgLayer1 = getBGLayer( layer1 );
		BGLayer bgLayer2 = getBGLayer( layer2 );
		int[][] bgData1  = getBGData( layer1 );
		int[][] bgData2  = getBGData( layer2 );
		
		bgLayers.set( layer1, bgLayer2 );
		bgLayers.set( layer2, bgLayer1 );
		bgData.set( layer1, bgData2 );
		bgData.set( layer2, bgData1 );
	}
	
	/**
	 * Adds the BGLayer to the Room at the specified index, creating its
	 * correspondent bgData matrix.
	 */
	public void addBGLayer ( int layerInx, BGLayer newLayer ) {
		// Given the parallax factor, the number of tiles in this layer may
		// have to be lower or higher than the room's actual size.
		int virtualPixelWidth  = (int) (screenWidth  * blockSize + (roomWidth  - 1) * screenWidth  * blockSize * Math.abs(newLayer.parallaxFactor));
		int virtualPixelHeight = (int) (screenHeight * blockSize + (roomHeight - 1) * screenHeight * blockSize * Math.abs(newLayer.parallaxFactor));
		
		int rows = (int) Math.ceil( (float) virtualPixelHeight / newLayer.tileHeight ) + 1; 
		int cols = (int) Math.ceil( (float) virtualPixelWidth  / newLayer.tileWidth  ) + 1;
		
		int[][] newBGData = new int[rows][cols];
		for ( int i = 0; i < newBGData.length; i++ )
			for ( int j = 0; j < newBGData[i].length; j++ )
				newBGData[i][j] = -1;
		
		// At last... add the layer:
		bgLayers.add( layerInx, newLayer );
		bgData.add( layerInx, newBGData );
	}
	
	/**
	 * Appends the BGLayer to the end of the layer list, creating its
	 * correspondent bgData matrix.
	 */
	public void addBGLayer ( BGLayer newLayer ) {
		addBGLayer( bgLayers.size(), newLayer );
	}
	
	/**
	 * Updates a currently existent BGLayer.
	 * 
	 * The corresponding bgData matrix will be resized; the tile IDs will be
	 * copied into the new matrix, being trimmed down or padded out with -1 as
	 * needed.
	 */
	public void setBGLayer ( int layerInx, BGLayer newLayer ) {
//		BGLayer oldLayer = getBGLayer( layerInx );
		
		// Calculate new data matrix dimensions:
		// Given the parallax factor, the number of tiles in this layer may
		// have to be lower or higher than the room's actual size.
		int virtualPixelWidth  = (int) (screenWidth  * blockSize + (roomWidth  - 1) * screenWidth  * blockSize * Math.abs(newLayer.parallaxFactor));
		int virtualPixelHeight = (int) (screenHeight * blockSize + (roomHeight - 1) * screenHeight * blockSize * Math.abs(newLayer.parallaxFactor));

		int rows = (int) Math.ceil( (float) virtualPixelHeight / newLayer.tileHeight ) + 1; 
		int cols = (int) Math.ceil( (float) virtualPixelWidth  / newLayer.tileWidth  ) + 1;

		int[][] newBGData = new int[rows][cols];
		for ( int i = 0; i < newBGData.length; i++ )
			for ( int j = 0; j < newBGData[i].length; j++ )
				newBGData[i][j] = -1;
		
		// Copy old BGData:
		int[][] oldBGData = getBGData( layerInx );
		rows = Math.min( oldBGData.length, newBGData.length );
		cols = Math.min( oldBGData[0].length, newBGData[0].length );
		
		for ( int i = 0; i < rows; i++ )
			for ( int j = 0; j < cols; j++ )
				newBGData[i][j] = oldBGData[i][j];
		
		// Replace old BG data:
		bgData.set( layerInx, newBGData );
		
		// Replace old layer:
		bgLayers.set( layerInx, newLayer );
	}
	
	/**
	 * Removes a BGLayer and its data matrix. Index -1 is NOT valid.
	 */
	public void removeBGLayer ( int layerInx ) {
		bgLayers.remove( layerInx );
		bgData.remove( layerInx );
	}
	
	/**
	 * Returns the number of BG layers present in the room.
	 */
	public int getNumberOfBGLayers () {
		return bgLayers.size();
	}
	
	/**
	 * Returns the BG data matrix at index "layer", or the obstacle matrix if
	 * index -1 is used.
	 */
	public int[][] getBGData ( int layer ) {
		if ( layer == -1 )
			return obstacleLayer;
		else
			return (int[][]) bgData.get( layer );
	}
	
	
	
	/**
	 * Paints this room onto the specified Graphics object.
	 * The top-left corner will be at coordinates (x,y).
	 */
	public void draw ( Graphics g, int x, int y ) {
		// Clear the room with a black background:
		g.setColor( Color.BLACK );
		g.fillRect( x,
		            y,
		            getPixelWidth(),
		            getPixelHeight() );
		
		// Iterate over this room's BGLayers (in reverse order; higher-index
		// layers must appear behind lower-index layers):
		boolean defaultObjLayerDrawn = false;
		for ( int bgInx = bgLayers.size() - 1; bgInx >= 0; bgInx-- ) {
			// Insertion point for "object layer"
			if ( bgInx < defaultObjLayerPosition && !defaultObjLayerDrawn ) {
				drawObjectLayer( g, x, y );
				defaultObjLayerDrawn = true;
			}
			
			// Draw BGLayer:
			BGLayer bgLayer = getBGLayer( bgInx );
			if ( !bgLayer.isHidden ) {
				int[][] bgData = getBGData( bgInx );
				
				for ( int i = 0; i < bgData.length; i++ ) {
					for ( int j = 0; j < bgData[i].length; j++ ) {
						bgLayer.drawTile(
							bgData[i][j],
							(int) (bgLayer.parallaxFactor * x) + j * bgLayer.tileWidth,
							(int) (bgLayer.parallaxFactor * y) + i * bgLayer.tileHeight,
							g );
					}
				} 
			}
		}
		
		if ( !defaultObjLayerDrawn )
			drawObjectLayer( g, x, y );
		
		// Water level:
		g.setColor( Color.CYAN );
		g.drawLine( x,                   y + waterLevel,
					x + getPixelWidth(), y + waterLevel );
		g.drawLine( x,                   y + waterLevel - 1,
					x + getPixelWidth(), y + waterLevel - 1 );
	}
	
	// Auxiliary method: Draw obstacle layer and enemy instances:
	private void drawObjectLayer ( Graphics g, int x, int y ) {
		// Draw obstacle layer and EnemyInstances where objects would be.
		// Is the obstacle layer visible?
		if ( !getBGLayer( -1 ).isHidden ) {
			for ( int i = 0; i < obstacleLayer.length; i++ ) {
				for ( int j = 0; j < obstacleLayer[i].length; j++ ) {
					ObstacleBlockTypes.drawBlock(
						obstacleLayer[i][j],
						x + j * blockSize, y + i * blockSize,
						blockSize,
						g );
				}
			}
		
			// Draw gameObjInstances:
			for ( int i = gameObjects.size() - 1; i >= 0; i-- ) {
				GameObj gameObj = (GameObj) gameObjects.get( i );
				gameObj.draw( (Graphics2D) g, x, y );
			}
		}
	}
	
	
	
	/**
	 * Sets the tile of the specified layer at coordinates (x, y) to 
	 * the specified values in the brush. The arguments scrollX and scrollY
	 * denote the Room's top-left corner.
	 * 
	 * All coordinates must be expressed in the Graphics display's system, and
	 * not in relation to the Room's top-left corner.
	 */
	public void setTile ( int layer, int x, int y, int scrollX, int scrollY, int[][] brush ) {
		BGLayer bgLayer = getBGLayer( layer );
		
		// Translate the coordinates according to the layer's parallax and
		// translation: 
		x = (int) (x - scrollX * bgLayer.parallaxFactor) - bgLayer.translateX; 
		y = (int) (y - scrollY * bgLayer.parallaxFactor) - bgLayer.translateY;
		
		// Calculate tile coordinates in the matrix:
		int centerI = y / bgLayer.tileHeight;
		int centerJ = x / bgLayer.tileWidth;
		
		int topI  = centerI - brush.length/2;
		int leftJ = centerJ - brush[0].length/2;
		
		int[][] bgLayerData = getBGData( layer );
		
		for ( int i = 0; i < brush.length; i++ ) {
			for ( int j = 0; j < brush[0].length; j++ ) {
				 if ( brush[i][j] != BGPanel.BRUSH_FREE_CELL_ID ) {
					// Prevent ArrayIndexOutOfBoundsException:
					if ( (topI + i)  >= 0 && (topI + i)  < bgLayerData.length &&
						 (leftJ + j) >= 0 && (leftJ + j) < bgLayerData[i].length ) {
						bgLayerData[topI + i][leftJ + j] = brush[i][j];
					}
				}
			}
		}
	}
	
	/**
	 * Interpolates all coordinates between "from" and "to", setting their
	 * tiles to the specified values in the brush.
	 * 
	 * All coordinates must be expressed in the Graphics display's system, and
	 * not in relation to the Room's top-left corner.
	 */
	public void setTilesInLine ( int layer, int fromX, int fromY, int toX, int toY, int scrollX, int scrollY, int[][] brush ) {
		BGLayer bgLayer = getBGLayer( layer );
		
		int deltaX = toX - fromX;
		int deltaY = toY - fromY;
		
		// Categorize the line (from->to) based on its predominant axis:
		// Vertical:
		if ( Math.abs(deltaX) > Math.abs(deltaY) ) {
			// Swap "from" and "to" if the line goes from right to left
			// (simplifies things a lot):
			if ( deltaX < 0 ) {
				deltaX *= -1;
				deltaY *= -1;
				
				int tmp = fromX;
				fromX = toX;
				toX = tmp;
				
				tmp = fromY;
				fromY = toY;
				toY = tmp;
			}
			
			// Steps:
			// dy = a * dx
			// a = deltaY / deltaX
			float stepX = (float) bgLayer.tileWidth;
			float stepY = ((float) deltaY / deltaX) * stepX;
			
			float x = fromX, y = fromY;
			while ( x < toX ) {
				setTile( layer, (int) x, (int) y, scrollX, scrollY, brush );
				
				// "Step" to the next tile
				x += stepX;
				y += stepY;
			}
		}
		// Horizontal:
		else {
			// Swap "from" and "to" if the line goes from bottom to top
			// (simplifies things a lot):
			if ( deltaY < 0 ) {
				deltaX *= -1;
				deltaY *= -1;
	 			
				int tmp = fromX;
				fromX = toX;
				toX = tmp;
	 			
				tmp = fromY;
				fromY = toY;
				toY = tmp;
			}
	 
			// Steps:
			// dx = dy / a
			// a = deltaY / deltaX
			float stepY = (float) bgLayer.tileHeight;
			float stepX = ((float) deltaX / deltaY) * stepY;
	 		
			float x = fromX, y = fromY;
			while ( y < toY ) {
				setTile( layer, (int) x, (int) y, scrollX, scrollY, brush );
				
				// "Step" to the next tile
				x += stepX;
				y += stepY;
			}
		}
	}
	
	/**
	 * Returns the tile of the specified layer at coordinates (x, y).
	 * 
	 * All coordinates must be expressed in the Graphics display's system, and
	 * not in relation to the Room's top-left corner.
	 * 
	 * This method will throw an ArrayIndexOutOfBoundsException if the
	 * coordinates lay outside of the layer's data matrix.
	 */
	public int getTile ( int layer, int x, int y, int scrollX, int scrollY ) {
		BGLayer bgLayer = getBGLayer( layer );
		
		// Translate the coordinates according to the layer's parallax and
		// translation: 
		x = (int) (x - scrollX * bgLayer.parallaxFactor) - bgLayer.translateX; 
		y = (int) (y - scrollY * bgLayer.parallaxFactor) - bgLayer.translateY;
		
		// Calculate tile coordinates in the matrix:
		int i = y / bgLayer.tileHeight;
		int j = x / bgLayer.tileWidth;
		
		return getBGData( layer )[i][j];
	}
	
	
	
	/**
	 * Returns a string describing this room's size, e.g.:
	 *   "1x1 screens (16x16 tiles)"
	 */
	public String getSizeDescription () {
		return roomWidth + "x" + roomHeight + " screens (" + getPixelWidth() + "x" + getPixelHeight() + " pixels)";
	}
	
	
	/**
	 * Returns a string describing how many game objects are in this room.
	 */
	public String getGameObjDescription () {
		switch ( gameObjects.size() ) {
			case 0:
				return "No game objects in this room.";
			case 1:
				return "1 game object in this room.";
			default:
				return gameObjects.size() + " game objects in this room.";
		}
	}
	
	
	/**
	 * Return this room's width, in virtual pixels.
	 */
	public int getPixelWidth () {
		return roomWidth  * screenWidth  * blockSize;
	}
	
	
	/**
	 * Return this room's height, in virtual pixels.
	 */
	public int getPixelHeight () {
		return roomHeight * screenHeight * blockSize;
	}
	
	
	// Public accessor methods:
	public int getWaterLevel() {
		return waterLevel;
	}
	public int getDefaultObjLayerPosition () {
		return defaultObjLayerPosition;
	}
	

}
