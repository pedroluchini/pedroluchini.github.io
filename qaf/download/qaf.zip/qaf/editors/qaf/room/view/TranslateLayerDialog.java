package qaf.room.view;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

import qaf.room.control.HistoryManager;
import qaf.room.control.Main;
import qaf.room.control.UndoImpl;
import qaf.room.control.UndoOperation;
import qaf.room.model.BGLayer;

/**
 * Use the showTranslateDialog() method.
 */
public class TranslateLayerDialog extends JDialog {
	/** Status values used by clients to determine which button in the dialog 
	 * was pressed. */
	public final static int STATUS_NONE = 0, STATUS_OK = 1, STATUS_CANCEL = 2;

	/** Used to indicate which button was pressed by the user. */
	private int status = STATUS_NONE;

	/** The layer being edited. */
	private BGLayer bgLayer;

	/** The layer's translation before being edited. */
	private Point oldTrans;

	private JButton leftButton    = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/left.png")),
	                rightButton   = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/right.png")),
	                upButton      = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/up.png")),
	                downButton    = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/down.png")),
	                toLeftButton  = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/toLeft.png")),
	                toRightButton = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/toRight.png")),
	                toTopButton   = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/toTop.png")),
	                toBottButton  = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/toBott.png")),
	                dummyButton   = new JButton(new ImageIcon(System.getenv("QAF_PATH") + "img/dummy.png"));

	/**
	 * Constructor: Receives the parent Frame and the layer being edited. Its
	 * data will be copied to initialize the editor's fields. (Passing a null
	 * argument will create a new layer.)
	 */
	private TranslateLayerDialog(Frame parent, BGLayer _bgLayer) {
		// Invoke the constructor from the JDialog superclass:
		// Bind it to the "parent" and define it as modal.
		super(parent, true);
		setResizable(false);

		this.bgLayer = _bgLayer;
		this.oldTrans = new Point(_bgLayer.translateX, _bgLayer.translateY);

		// DummyButton is just a filler:
		dummyButton.setEnabled(false);
		dummyButton.setMargin(new Insets(0, 0, 0, 0));

		leftButton.setMargin(new Insets(0, 0, 0, 0));
		rightButton.setMargin(new Insets(0, 0, 0, 0));
		upButton.setMargin(new Insets(0, 0, 0, 0));
		downButton.setMargin(new Insets(0, 0, 0, 0));
		toLeftButton.setMargin(new Insets(0, 0, 0, 0));
		toRightButton.setMargin(new Insets(0, 0, 0, 0));
		toTopButton.setMargin(new Insets(0, 0, 0, 0));
		toBottButton.setMargin(new Insets(0, 0, 0, 0));
		dummyButton.setMargin(new Insets(0, 0, 0, 0));

		// Disable buttons as needed:
		checkBoundaries();

		// Build layout:
		//
		// +======================================+
		// |               [ Top  ]               |
		// |               [  Up  ]               |
		// |  [ << ] [ < ] [      ] [ > ] [ >> ]  |
		// |               [ Down ]               |
		// |               [ Bott ]               |
		// |                                      |
		// |           [ OK ]  [ Cancel ]         |
		// +--------------------------------------+
		//

		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY(0.0f);
		theBox.add(Box.createRigidArea(new Dimension(0, 15)));

		Box topBox = Box.createHorizontalBox();
		topBox.setAlignmentX(0.0f);
		topBox.add(Box.createHorizontalGlue());
		topBox.add(toTopButton);
		topBox.add(Box.createHorizontalGlue());
		theBox.add(topBox);

		Box upBox = Box.createHorizontalBox();
		upBox.setAlignmentX(0.0f);
		upBox.add(Box.createHorizontalGlue());
		upBox.add(upButton);
		upBox.add(Box.createHorizontalGlue());
		theBox.add(upBox);

		Box midBox = Box.createHorizontalBox();
		midBox.setAlignmentX(0.0f);
		midBox.add(Box.createHorizontalGlue());
		midBox.add(toLeftButton);
		midBox.add(leftButton);
		midBox.add(dummyButton);
		midBox.add(rightButton);
		midBox.add(toRightButton);
		midBox.add(Box.createHorizontalGlue());
		theBox.add(midBox);

		Box downBox = Box.createHorizontalBox();
		downBox.setAlignmentX(0.0f);
		downBox.add(Box.createHorizontalGlue());
		downBox.add(downButton);
		downBox.add(Box.createHorizontalGlue());
		theBox.add(downBox);

		Box toBottBox = Box.createHorizontalBox();
		toBottBox.setAlignmentX(0.0f);
		toBottBox.add(Box.createHorizontalGlue());
		toBottBox.add(toBottButton);
		toBottBox.add(Box.createHorizontalGlue());
		theBox.add(toBottBox);

		theBox.add(Box.createRigidArea(new Dimension(0, 15)));
		theBox.add(new JSeparator());
		theBox.add(Box.createRigidArea(new Dimension(0, 15)));

		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX(0.0f);
		buttonBox.add(Box.createHorizontalGlue());

		final JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				status = STATUS_OK;
				dispose();
			} } );
		buttonBox.add(okButton);

		buttonBox.add(Box.createRigidArea(new Dimension(20, 0)));

		final JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				status = STATUS_CANCEL;
				dispose();
			} } );
		buttonBox.add(cancelButton);

		// DIRECTIONAL BUTTON CALLBACKS:
		leftButton.setToolTipText( "1 pixel to the left" );
		leftButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateX--;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});
		toLeftButton.setToolTipText( "10 pixels to the left" );
		toLeftButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateX -= 10; // bgLayer.translateX = -bgLayer.tileWidth;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});

		rightButton.setToolTipText( "1 pixel to the right" );
		rightButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateX++;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});
		toRightButton.setToolTipText( "10 pixels to the right" );
		toRightButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateX += 10; // bgLayer.translateX = 0;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});

		upButton.setToolTipText( "1 pixel upwards" );
		upButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateY--;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});
		toTopButton.setToolTipText( "10 pixels upwards" );
		toTopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateY -= 10; // bgLayer.translateY = -bgLayer.tileHeight;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});

		downButton.setToolTipText( "1 pixel downwards" );
		downButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateY++;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});
		toBottButton.setToolTipText( "10 pixels downwards" );
		toBottButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				bgLayer.translateY += 10; // bgLayer.translateY = 0;
				checkBoundaries();
				MainLayout.updateBGPanels();
				MainLayout.canvas.repaint();
			}
		});

		buttonBox.add(Box.createHorizontalGlue());
		theBox.add(buttonBox);

		theBox.add(Box.createRigidArea(new Dimension(0, 15)));

		// A box to fill up the edges with some space
		Box fillerBox = Box.createHorizontalBox();
		fillerBox.setAlignmentX(0.0f);
		fillerBox.add(Box.createRigidArea(new Dimension(5, 0)));
		fillerBox.add(theBox);
		fillerBox.add(Box.createRigidArea(new Dimension(5, 0)));

		getContentPane().add(fillerBox);

		// Set "OK" as the default button:
		getRootPane().setDefaultButton(okButton);

		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke keyStroke =
			KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
		// Pressing ESC, no modifiers, as soon as it's pressed
		Action action = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				cancelButton.doClick();
			}
		};
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
			keyStroke,
			"ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", action);

		// Handle keypresses as shortcuts for the buttons:
		keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0, false);
		// Pressing LEFT, no modifiers, as soon as it's pressed
		action = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				leftButton.doClick();
			}
		};
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
			keyStroke,
			"LEFT");
		getRootPane().getActionMap().put("LEFT", action);

		keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0, false);
		// Pressing RIGHT, no modifiers, as soon as it's pressed
		action = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				rightButton.doClick();
			}
		};
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
			keyStroke,
			"RIGHT");
		getRootPane().getActionMap().put("RIGHT", action);

		keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0, false);
		// Pressing UP, no modifiers, as soon as it's pressed
		action = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				upButton.doClick();
			}
		};
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
			keyStroke,
			"UP");
		getRootPane().getActionMap().put("UP", action);

		keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0, false);
		// Pressing DOWN, no modifiers, as soon as it's pressed
		action = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				downButton.doClick();
			}
		};
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
			keyStroke,
			"DOWN");
		getRootPane().getActionMap().put("DOWN", action);
	}

	/**
	 * Checks the translation boundaries, disabling buttons as necessary.
	 */
	private void checkBoundaries() {
		// RIGHT:
		if (bgLayer.translateX >= 0) {
			bgLayer.translateX = 0;
			rightButton.setEnabled(false);
			toRightButton.setEnabled(false);
		} else {
			rightButton.setEnabled(true);
			toRightButton.setEnabled(true);
		}

		// LEFT:
		if (bgLayer.translateX <= -bgLayer.tileWidth) {
			bgLayer.translateX = -bgLayer.tileWidth;
			leftButton.setEnabled(false);
			toLeftButton.setEnabled(false);
		} else {
			leftButton.setEnabled(true);
			toLeftButton.setEnabled(true);
		}

		// DOWN:
		if (bgLayer.translateY >= 0) {
			bgLayer.translateY = 0;
			downButton.setEnabled(false);
			toBottButton.setEnabled(false);
		} else {
			downButton.setEnabled(true);
			toBottButton.setEnabled(true);
		}

		// UP:
		if (bgLayer.translateY <= -bgLayer.tileHeight) {
			bgLayer.translateY = -bgLayer.tileHeight;
			upButton.setEnabled(false);
			toTopButton.setEnabled(false);
		} else {
			upButton.setEnabled(true);
			toTopButton.setEnabled(true);
		}
	}

	/**
	 * Pops up a dialog to edit the layer's translation.
	 * 
	 * This method will take care of adding the necessary UndoOperation to the
	 * HistoryManager.
	 */
	public static void showTranslateDialog(int layer) {
		// Pop up a window with the editor:
		TranslateLayerDialog dlg =
			new TranslateLayerDialog(Main.f, Main.loadedRoom.getBGLayer(layer));
		dlg.setTitle("Translate BG layer " + layer);
		dlg.pack();
		dlg.setLocationRelativeTo(null); // Center on screen
		dlg.setVisible( true );
		// Thread will block here, waiting for the JDialog to be closed

		// Check status: User canceled?
		if (dlg.status != STATUS_OK) {
			// Restore the layer's previous translation:
			BGLayer bgLayer = Main.loadedRoom.getBGLayer(layer);
			bgLayer.translateX = dlg.oldTrans.x;
			bgLayer.translateY = dlg.oldTrans.y;
		} else {
			// Commit changes to the HistoryManager:
			UndoOperation op = new UndoImpl.TranslateBGLayerOperation(
					layer,
					dlg.oldTrans,
					new Point(dlg.bgLayer.translateX, dlg.bgLayer.translateY));
			HistoryManager.addUndoOperation(op, "translate layer " + layer);
			
			Main.unsavedChanges = true;
		}

		MainLayout.updateBGPanels();
		MainLayout.canvas.repaint();
	}

}
