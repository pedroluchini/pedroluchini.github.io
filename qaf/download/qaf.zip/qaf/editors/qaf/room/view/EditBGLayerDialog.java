package qaf.room.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.math.BigDecimal;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpinnerModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import qaf.room.control.Main;
import qaf.room.model.BGLayer;
import qaf.room.model.Room;


/**
 * Accepts any decimal value.
 */
class DecimalSpinnerModel implements SpinnerModel {
	Vector changeListeners = new Vector();
	BigDecimal value;
	
	public DecimalSpinnerModel ( float initialValue ) {
		value = new BigDecimal( Float.toString(initialValue) );
	}
	
	public void addChangeListener(ChangeListener c) {
		changeListeners.add( c );
	}
	public void removeChangeListener(ChangeListener c) {
		changeListeners.remove( c );
	}
	
	public Object getNextValue() {
		return value.add( new BigDecimal( "0.1" ) ).toString();
	}
	public Object getPreviousValue() {
		return value.subtract( new BigDecimal( "0.1" ) ).toString();
	}
	
	public Object getValue() {
		return value.toString();
	}
	public void setValue(Object obj) {
		try {
			BigDecimal newValue = new BigDecimal( obj.toString() );
			
			value = newValue;
			
			ChangeEvent evt = new ChangeEvent( this );
			for ( int i = 0; i < changeListeners.size(); i++ )
				((ChangeListener) changeListeners.get( i )).stateChanged( evt );
		}
		catch ( NumberFormatException exc ) {
			throw new IllegalArgumentException();
		}
	}
}



/**
 * This is a JDialog created specifically for editing BGLayers. The recommended
 * strategy is to use the static methods createLayer() and editLayer() rather
 * than creating the dialog directly. 
 */
public class EditBGLayerDialog extends JDialog {
	/** Status values used by clients to determine which button in the dialog 
	 * was pressed. */
	public final static int STATUS_NONE   = 0,
	                        STATUS_OK     = 1,
	                        STATUS_CANCEL = 2;
	
	
	/** Used to indicate which button was pressed by the user. */
	private int status = STATUS_NONE;
	
	/** The layer being edited. */
	private BGLayer bgLayer = new BGLayer( null, null, Main.loadedRoom.blockSize, Main.loadedRoom.blockSize, 1.0f, 0, 0 );
	
	// Storing the GUI components here lets me use them later for callbacks:
	private JButton     okButton,
	                    cancelButton;
	private JTextField  imagePathTxtField  = new JTextField( 20 );
	private JLabel      imageSizeLabel     = new JLabel( "Image size:" );
	private JSpinner    parallaxField,
	                    tileWidthField,
	                    tileHeightField;
	private JScrollPane imagePreviewPane;
	private JPanel      imagePreviewPanel = new JPanel () {
		public void paint ( Graphics g ) {
			MainLayout.clearBGWithHatches( g, getWidth(), getHeight() );
			
			// Draw the source image, if it is present:
			if ( bgLayer.data != null ) {
				g.drawImage( bgLayer.data, 0, 0, Main.f );
				
				// Draw tile grid:
				MainLayout.drawGrid(
					g,
					0, 0,
					bgLayer.getRows(), bgLayer.getCols(),
					bgLayer.tileWidth, bgLayer.tileHeight,
					BGLayer.MAX_TILE_ID,
					Color.RED );
			}
		}
		
		public Dimension getPreferredSize () {
			return getMinimumSize();
		}
		
		public Dimension getMinimumSize () {
			if ( bgLayer.data != null )
				return new Dimension(
					bgLayer.data.getWidth(Main.f),
					bgLayer.data.getHeight(Main.f) );
			else
				return new Dimension(0,0);
		}
	};
	
	
	/**
	 * Constructor: Receives the parent Frame and the layer being edited. Its
	 * data will be copied to initialize the editor's fields. (Passing a null
	 * argument will create a new layer.)
	 */
	private EditBGLayerDialog ( Frame parent, BGLayer _bgLayer ) {
		// Invoke the constructor from the JDialog superclass:
		// Bind it to the "parent" and define it as modal.
		super( parent, true );
		setResizable( false );
		
		// Copy data from bgLayer
		if ( _bgLayer != null ) {
			bgLayer.data            = _bgLayer.data;
			bgLayer.sourceImagePath = _bgLayer.sourceImagePath;
			bgLayer.parallaxFactor  = _bgLayer.parallaxFactor;
			bgLayer.tileHeight      = _bgLayer.tileHeight;
			bgLayer.tileWidth       = _bgLayer.tileWidth;
		}
		
		
		// Build BGEditor layout:
		//
		// +=============================================+
		// | Source image: [______________][ Browse... ] |
		// | +-----------------------------------------+ |
		// | |                                         | |
		// | | (Preview)                               | |
		// | |                                         | |
		// | |                                         | |
		// | |                                         | |
		// | +-----------------------------------------+ |
		// | Image size: 320 x 240 pixels
		// |                                             |
		// | Parallax factor: [___]                      |
		// | Tile size: [___] x [___]      [Fit to image]|
		// |                                             |
		// |           [  OK  ]  [  Cancel  ]            |
		// +---------------------------------------------+
		//
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY( 0.0f );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
				
		// SOURCE IMAGE CHOOSER:
		imagePathTxtField.setEditable( false );
		if ( bgLayer.sourceImagePath != null ) 
			imagePathTxtField.setText( Main.prependBasePath( bgLayer.sourceImagePath ) );
		Box imageChooserBox = Box.createHorizontalBox();
		imageChooserBox.setAlignmentX( 0.0f );
		imageChooserBox.add( new JLabel("Source image: ") );
		imageChooserBox.add( imagePathTxtField );
		
		JButton browseButton = new JButton( "Browse..." );
		browseButton.addActionListener( new ActionListener() { // Click the button, get an image file
			public void actionPerformed ( ActionEvent evt ) {
				JFileChooser fDlg = new JFileChooser( Main.getBasePath() );
				fDlg.setFileSelectionMode(JFileChooser.FILES_ONLY);
				fDlg.setFileFilter( new FileFilter () {
					public boolean accept ( File f ) {
						String fName = f.getName().toLowerCase();
						return f.isDirectory()         ||
						       fName.endsWith(".jpg")  ||
						       fName.endsWith(".jpeg") ||
						       fName.endsWith(".png");
					}
					public String getDescription () {
						return "Image files (*.JPG, *.JPEG, *.PNG)";
					}
				} );
				fDlg.setAcceptAllFileFilterUsed( false );

				// Did the user choose a file or did he cancel?
				if ( fDlg.showOpenDialog( EditBGLayerDialog.this ) == JFileChooser.APPROVE_OPTION &&
					 fDlg.getSelectedFile()      != null ) {
					// Check image path for validity:
					if ( !Main.isInBasePath( fDlg.getSelectedFile().getAbsolutePath() ) ||
					     !fDlg.getSelectedFile().canRead() )
					     MainLayout.showNotInBasePathDialog( EditBGLayerDialog.this );
					else {
						String imagePath = Main.getCanonicalPath( fDlg.getSelectedFile() );
						
						// Load and preview image:
						imagePathTxtField.setText( imagePath );
						bgLayer.data = Main.createImage( imagePath );
						bgLayer.sourceImagePath = Main.stripBasePath( imagePath );
						imagePreviewPane.revalidate();
						imagePreviewPanel.repaint();
						imageSizeLabel.setText( "Image size: " + bgLayer.data.getWidth(Main.f) + " x " + bgLayer.data.getHeight(Main.f) );
					}
				}
			} } );
		imageChooserBox.add( browseButton );
				
		theBox.add( imageChooserBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// IMAGE PREVIEWER:
		imagePreviewPane = new JScrollPane( imagePreviewPanel );
		imagePreviewPane.setAlignmentX( JScrollPane.LEFT_ALIGNMENT );
		imagePreviewPane.setAlignmentY( JScrollPane.TOP_ALIGNMENT );
		imagePreviewPane.setPreferredSize( new Dimension(300, 300) );
		if ( bgLayer.data != null )
			imageSizeLabel.setText( "Image size: " + bgLayer.data.getWidth(Main.f) + " x " + bgLayer.data.getHeight(Main.f) );
		
		theBox.add( imagePreviewPane );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		theBox.add( imageSizeLabel );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// PARALLAX FACTOR:
		parallaxField = new JSpinner( new DecimalSpinnerModel( bgLayer.parallaxFactor ) );
		((JSpinner.DefaultEditor) parallaxField.getEditor()).getTextField().setEditable( true );
		parallaxField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.parallaxFactor = ((DecimalSpinnerModel) ((JSpinner) evt.getSource()).getModel()).value.floatValue();
			} } );
		Box parallaxBox = Box.createHorizontalBox();
		parallaxBox.setAlignmentX( 0.0f );
		parallaxBox.add( new JLabel("Parallax factor: ") );
		parallaxBox.add( parallaxField );
		
		theBox.add( parallaxBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
				
		// TILE SIZE:
		tileWidthField = new JSpinner( new MainLayout.PositiveIntegerSpinnerModel( bgLayer.tileWidth ) );
		((JSpinner.DefaultEditor) tileWidthField.getEditor()).getTextField().setEditable( true );
		tileWidthField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.tileWidth = ((MainLayout.PositiveIntegerSpinnerModel) ((JSpinner) evt.getSource()).getModel()).value;
				imagePreviewPanel.repaint();
			} } );
		tileHeightField = new JSpinner( new MainLayout.PositiveIntegerSpinnerModel( bgLayer.tileHeight ) );
		((JSpinner.DefaultEditor) tileHeightField.getEditor()).getTextField().setEditable( true );
		tileHeightField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.tileHeight = ((MainLayout.PositiveIntegerSpinnerModel) ((JSpinner) evt.getSource()).getModel()).value;
				imagePreviewPanel.repaint();
			} } );
		JButton fitToImageButton = new JButton( "Fit to image " );
		fitToImageButton.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				if ( bgLayer.data != null ) {
					tileWidthField.setValue( new Integer( bgLayer.data.getWidth(Main.f) ) );
					tileHeightField.setValue( new Integer( bgLayer.data.getHeight(Main.f) ) );
				}
			} } );
		Box tileSizeBox = Box.createHorizontalBox();
		tileSizeBox.setAlignmentX( 0.0f );
		tileSizeBox.add( new JLabel("Tile size: ") );
		tileSizeBox.add( tileWidthField );
		tileSizeBox.add( new JLabel(" x ") );
		tileSizeBox.add( tileHeightField );
		tileSizeBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		tileSizeBox.add( fitToImageButton );
		
		theBox.add( tileSizeBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
				
		// BUTTONS:
		// Upon being pressed, these will set the "status" field to the
		// appropriate value and close the dialog:
		okButton = new JButton( "OK" );
		okButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				// Validate source image:
				if ( bgLayer.sourceImagePath == null ) {
					JOptionPane.showMessageDialog(
						EditBGLayerDialog.this,                 // parent dialog
						"You must specify a source image.", // message
						"Error",                            // title
						JOptionPane.ERROR_MESSAGE           // message type
					);
				}
				// Validate tile size: The tiles must fit within the image's
				// boundaries:
				else if ( bgLayer.tileWidth  > bgLayer.data.getWidth(Main.f)       ||
				          bgLayer.tileHeight > bgLayer.data.getHeight(Main.f)      ||
				          bgLayer.data.getWidth(Main.f)  % bgLayer.tileWidth  != 0 ||
				          bgLayer.data.getHeight(Main.f) % bgLayer.tileHeight != 0 ) {
					String[] message = {
						"Invalid tile size.",
						"The tiles must fit within the boundaries of the source image." };
					JOptionPane.showMessageDialog(
						EditBGLayerDialog.this,       // parent dialog
						message,                  // message
						"Error",                  // title
						JOptionPane.ERROR_MESSAGE // message type
					);
				}
				// OK!
				else {
					status = STATUS_OK;
					dispose();
				}
			} } );
		cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				status = STATUS_CANCEL;
				dispose();
			} } );
		
		theBox.add( new JSeparator() );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// Add the buttons to the dialog:
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.0f );
		buttonBox.add( Box.createGlue() );
		buttonBox.add( okButton );
		buttonBox.add( Box.createRigidArea( new Dimension(15, 0) ) );
		buttonBox.add( cancelButton );
		buttonBox.add( Box.createGlue() );
		theBox.add( buttonBox );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// Add fillers to the left and right of the box:
		Box filler = Box.createHorizontalBox();
		filler.setAlignmentX( 0.0f );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		filler.add( theBox );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		getContentPane().add( filler );
		
		// Layout done!
		
		// Set "OK" as the default button:
		getRootPane().setDefaultButton( okButton );
		
		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
		Action escapeAction = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				cancelButton.doClick();
			} };
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", escapeAction);
		
	}
	
	
	
	
	
	/**
	 * Prompts the user for a new BGLayer.
	 * Returns the BGLayer created, or null if the user canceled.
	 */
	public static BGLayer createLayer () {
		// Pop up a window with the editor:
		EditBGLayerDialog editor = new EditBGLayerDialog( Main.f, null );
		editor.setTitle( "Create new BG layer" );
		editor.pack();
		editor.setLocationRelativeTo( null ); // Center on screen
		editor.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
		
		// Check status:
		// User cancelled or closed the window?
		if ( editor.status != STATUS_OK )
			return null;
		// User confirmed?
		else
			return editor.bgLayer;
	}
	
	
	/**
	 * Opens up a dialog to edit an existing layer.
	 * Returns a new BGLayer (the altered data), or null if the user canceled.
	 */
	public static BGLayer editLayer ( Room room, int layer ) {
		// Pop up a window with the editor:
		EditBGLayerDialog dlg = new EditBGLayerDialog( Main.f, room.getBGLayer( layer ) );
		dlg.setTitle( "Editing BG layer " + layer );
		dlg.pack();
		dlg.setLocationRelativeTo( null ); // Center on screen
		dlg.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
	
		// Check status:
		// User cancelled or closed the window?
		if ( dlg.status != STATUS_OK )
			return null;
		// User confirmed?
		else
			return dlg.bgLayer;
	}
	
}
