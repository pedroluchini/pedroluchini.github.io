package qaf.room.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.SpinnerModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import qaf.room.control.HistoryManager;
import qaf.room.control.Main;
import qaf.room.control.UndoImpl;
import qaf.room.control.UndoOperation;
import qaf.room.model.BGLayer;
import qaf.room.model.GameObj;
import qaf.room.model.Room;

/**
 * MainLayout is the "factory" that creates and assembles the main window's
 * components, associates their actions, and handles other GUI-related tasks.
 */ 
public abstract class MainLayout {
	public static JLabel            roomSizeInfo    = new JLabel();
	public static JCheckBoxMenuItem showGrid        = new JCheckBoxMenuItem( "Show grid", true );
	public static JTabbedPane       bgLayers        = new JTabbedPane();	
	public static JMenuItem         undoMenuItem    = new JMenuItem( "Undo" ),
							        redoMenuItem    = new JMenuItem( "Redo" ),
							        zoomInMenuItem  = new JMenuItem( "Zoom in" ),
							        zoomOutMenuItem = new JMenuItem( "Zoom out" );
	
	public static JLabel            statusBar    = new JLabel( " " );
	
	public static RoomPanel         canvas;
	
	
	/**
	 * This class' main method. It will build the application's window layout
	 * and return it as a Component to be added to the JFrame.
	 */
	public static Component buildLayout () {
		// Main window layout:
		//
		// +============================+
		// |           |                |
		// |  Toolbox  |     Canvas     |
		// |           |                |
		// +----------------------------+
		// | Status                     |
		// +----------------------------+
		//
		Box theBox = Box.createVerticalBox();
		
		// Tool box layout:
		//
		// +------------+
		// |  InfoPane  |
		// |------------|
		// |            |
		// |   BGPane   |
		// |            |
		// +------------+
		//
		
		// Info box layout:
		//
		// +------------------------------------+
		// | Size: 1x1 screens (16x12 tiles)    |
		// | Water level:        | [-] [+]      |
		// | Default Obj. layer: | [-] [+]      |
		// +------------------------------------+
		//
		Box infoBoxRow1 = Box.createHorizontalBox();
		infoBoxRow1.setAlignmentX( Box.LEFT_ALIGNMENT );
		infoBoxRow1.add( Box.createRigidArea( new Dimension(5, 0) ) );
		infoBoxRow1.add( new JLabel( "Size: ") );
		roomSizeInfo.setText( Main.loadedRoom.getSizeDescription() );
		infoBoxRow1.add( roomSizeInfo );
		
		Box infoBoxRow2 = Box.createHorizontalBox();
		infoBoxRow2.setAlignmentX( Box.LEFT_ALIGNMENT );
		infoBoxRow2.add( Box.createRigidArea( new Dimension(5, 0) ) );
		infoBoxRow2.add( new JLabel( "Water level: ") );
		JButton wlMinus = new JButton( "-" );
		JButton wlPlus  = new JButton( "+" );
		wlMinus.setToolTipText( "Lower water level" );
		wlPlus.setToolTipText( "Raise water level" );
		wlMinus.addActionListener( new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					if ( !Main.loadedRoom.lowerWaterLevel() )
						statusBar.setText( "When the water level surpasses the room's bottom, it means the room will contain no water at all." );
					
					Main.unsavedChanges = true;
					canvas.repaint();
				}
			} );
		wlPlus.addActionListener( new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					if ( !Main.loadedRoom.raiseWaterLevel() )
						statusBar.setText( "When the water level surpasses the room's top, it means the entire room will be filled with water." );
					
					Main.unsavedChanges = true;
					canvas.repaint();
				}
			} );
		infoBoxRow2.add( wlMinus );
		infoBoxRow2.add( wlPlus  );
		
		Box infoBoxRow3 = Box.createHorizontalBox();
		infoBoxRow3.setAlignmentX( Box.LEFT_ALIGNMENT );
		infoBoxRow3.add( Box.createRigidArea( new Dimension(5, 0) ) );
		infoBoxRow3.add( new JLabel( "Default obj. layer: ") );
		JButton dolMinus = new JButton( "-" );
		JButton dolPlus  = new JButton( "+" );
		dolMinus.setToolTipText( "Bring default obj. layer to front" );
		dolPlus.setToolTipText( "Send default obj. layer to back" );
		dolMinus.addActionListener( new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					Main.loadedRoom.defaultObjLayerToFront();
					Main.unsavedChanges = true;
					canvas.repaint();
				}
			} );
		dolPlus.addActionListener( new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					Main.loadedRoom.defaultObjLayerToBack();
					Main.unsavedChanges = true;
					canvas.repaint();
				}
			} );
		infoBoxRow3.add( dolMinus );
		infoBoxRow3.add( dolPlus  );
		
		Box infoBox = Box.createVerticalBox();
		infoBox.setAlignmentX( Box.LEFT_ALIGNMENT );
		infoBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		infoBox.add( infoBoxRow1 );
		infoBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		infoBox.add( infoBoxRow2 );
		infoBox.add( Box.createRigidArea( new Dimension(1, 5) ) );
		infoBox.add( infoBoxRow3 );
		infoBox.add( Box.createRigidArea( new Dimension(1, 5) ) );
		
		JScrollPane infoPane = new JScrollPane( infoBox );
		
		
		// BGPanels
		bgLayers.addTab( "Obst.", null,	new BGPanel( -1 ),	"Obstacle layer" );
		
		// Respond to tab changes by repainting the room. This is necessary
		// because the grid will need to be resized due to the change in the
		// active layer.
		bgLayers.addChangeListener( new ChangeListener () {
				public void stateChanged ( ChangeEvent evt ) {
					canvas.repaint();
				}
			} );
		
		
		// At last, the toolbox!
		JSplitPane toolPane = new JSplitPane( JSplitPane.VERTICAL_SPLIT, infoPane, bgLayers );
		toolPane.setContinuousLayout( true );
				
		
		// Canvas:
		// Wrapping the Canvas within a JScrollPane ensures it will receive
		// ancestorResized events.
		canvas = new RoomPanel();
		canvas.setSize( 640, 480 );
		JScrollPane canvasScrollPane = new JScrollPane( canvas );
		
		// Split window space between toolBox and canvas:
		JSplitPane mainSpace = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT, toolPane, canvasScrollPane );
		mainSpace.setOneTouchExpandable(true);
		mainSpace.setContinuousLayout( true );
		mainSpace.setResizeWeight( 0.0 );
		toolPane.setMinimumSize( new Dimension(0, 0));
		canvas.setMinimumSize( new Dimension(0, 0));
		
		// Final touches: Group the mainSpace and the statusBar
		theBox.add( mainSpace );
		theBox.add( statusBar );
		
		return theBox;
	}
	
	
	
	/**
	 * Builds the application's menu bar.
	 */
	public static JMenuBar buildMenu () {
		// First things first: Create an empty bar...
		JMenuBar menuBar = new JMenuBar();
		
		// The menus:
		JMenu fileMenu = new JMenu( "File" );
		fileMenu.setMnemonic( KeyEvent.VK_F );
		JMenu editMenu = new JMenu( "Edit" );
		editMenu.setMnemonic( KeyEvent.VK_E );
		JMenu viewMenu = new JMenu( "View" );
		viewMenu.setMnemonic( KeyEvent.VK_V );
		JMenu roomMenu = new JMenu( "Room" );
		roomMenu.setMnemonic( KeyEvent.VK_R );
		
		menuBar.add( fileMenu );
		menuBar.add( editMenu );
		menuBar.add( viewMenu );
		menuBar.add( roomMenu );
		
		
		///////////////////////////////////////////////////////////////////////
		// FILE:
		//
		// New room:
		JMenuItem newRoomMenuItem = new JMenuItem( "New room..." );
		newRoomMenuItem.setMnemonic( KeyEvent.VK_N );
		newRoomMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.CTRL_MASK) );
		newRoomMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				// Check unsaved shanges before unloading the room:
				if ( Main.checkUnsavedChanges() ) {
					// Show the "New room" dialog:
					Room newRoom = NewRoomDialog.createRoom();
					
					// If the user confirmed, set this as the loaded room:
					if ( newRoom != null ) {
						Main.setLoadedRoom( newRoom, null );
						
						// All previous UndoOperations are now invalid.
						HistoryManager.clear();
					}
				}
			} } );
		fileMenu.add( newRoomMenuItem );
		
		
		// Open room:
		JMenuItem openRoomMenuItem = new JMenuItem( "Open room..." );
		openRoomMenuItem.setMnemonic( KeyEvent.VK_O );
		openRoomMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_O, KeyEvent.CTRL_MASK) );
		openRoomMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				if ( !Main.checkUnsavedChanges() )
					return;
				
				// Open and load the room:
				Object[] newRoom = OpenRoomDialog.loadRoom( null );
				
				if ( newRoom != null ) {
					Main.setLoadedRoom( (Room) newRoom[0], (String) newRoom[1] );
					
					// All previous UndoOperations are now invalid.
					HistoryManager.clear();
				}
			} } );
		fileMenu.add( openRoomMenuItem );
		
		
		// Save room:
		JMenuItem saveRoomMenuItem = new JMenuItem( "Save room" );
		saveRoomMenuItem.setMnemonic( KeyEvent.VK_S );
		saveRoomMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_S, KeyEvent.CTRL_MASK) );
		saveRoomMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				Main.saveRoom();
			} } );
		fileMenu.add( saveRoomMenuItem );
		
		
		// Save room as:
		JMenuItem saveRoomAsMenuItem = new JMenuItem( "Save room as..." );
		saveRoomAsMenuItem.setMnemonic( KeyEvent.VK_A );
		saveRoomAsMenuItem.setDisplayedMnemonicIndex( 10 );
		saveRoomAsMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				Main.saveRoomAs();
			} } );
		fileMenu.add( saveRoomAsMenuItem );
		
		
		fileMenu.add( new JSeparator() );
		
		
		// Change base path:
		JMenuItem changeBasePathMenuItem = new JMenuItem( "Change base path..." );
		changeBasePathMenuItem.setMnemonic( KeyEvent.VK_B );
		changeBasePathMenuItem.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					if ( Main.loadedRoom.getNumberOfBGLayers() > 0 ) {
						String[] message = {
							"The room you are working on contains BGlayers. Those",
							"layers, in turn, have loaded images that depend on the",
							"base path.",
							" ",
							"Before changing the base path, you must either delete",
							"the room's layers or choose File->New room." };
						
						JOptionPane.showMessageDialog(
							Main.f,                      // parent dialog
							message,                     // message
							"Change base path",          // title
							JOptionPane.ERROR_MESSAGE ); // message type
					}
					else {
						String newPath = Main.promptForBasePath( true );
						if ( newPath != null ) {
							// Commit UndoOperation:
							UndoOperation op = new UndoImpl.ChangeBasePathOperation(
								Main.getBasePath(),
								newPath );
							HistoryManager.addUndoOperation( op, "change base path" );
							
							// Update the base path:
							Main.setBasePath( newPath );
						}
					}
				}
			} );
		fileMenu.add( changeBasePathMenuItem );
		
		
		fileMenu.add( new JSeparator() );
		
		
		// Change base path:
		JMenuItem exitMenuItem = new JMenuItem( "Exit" );
		exitMenuItem.setMnemonic( KeyEvent.VK_X );
		exitMenuItem.addActionListener( new ActionListener() {
			 public void actionPerformed ( ActionEvent evt ) {
			 	if ( Main.checkUnsavedChanges() )
			 		Main.f.dispose();
			 } } );
		fileMenu.add( exitMenuItem );
		
		
		///////////////////////////////////////////////////////////////////////
		// EDIT:
		//
		// Undo and Redo:
		undoMenuItem.setEnabled( false ); // No undo available yet
		undoMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_Z, KeyEvent.CTRL_MASK ) );
		undoMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				HistoryManager.undo();
				
				if ( HistoryManager.nextUndoDescription() != null )
					undoMenuItem.setText( "Undo " + HistoryManager.nextUndoDescription() );
				else {
					undoMenuItem.setText( "Undo" );
					undoMenuItem.setEnabled( false );
				}
				
				redoMenuItem.setText( "Redo " + HistoryManager.nextRedoDescription() );
				redoMenuItem.setEnabled( true );
			} } );
		
		redoMenuItem.setEnabled( false ); // No redo available yet
		redoMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_Y, KeyEvent.CTRL_MASK ) );
		redoMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				HistoryManager.redo();
		
				if ( HistoryManager.nextRedoDescription() != null )
					redoMenuItem.setText( "Redo " + HistoryManager.nextRedoDescription() );
				else {
					redoMenuItem.setText( "Redo" );
					redoMenuItem.setEnabled( false );
				}
		
				undoMenuItem.setText( "Undo " + HistoryManager.nextUndoDescription() );
				undoMenuItem.setEnabled( true );
			} } );
		
		editMenu.add( undoMenuItem );
		editMenu.add( redoMenuItem );
		
		
		///////////////////////////////////////////////////////////////////////
		// VIEW:
		//
		// Show/hide grid:
		showGrid.setMnemonic( KeyEvent.VK_G );
		showGrid.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_G, KeyEvent.CTRL_MASK ) );
		showGrid.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				canvas.repaint();
			} } );
		viewMenu.add( showGrid );
		
		// Zoom menu:
		JMenu zoomMenu = new JMenu( "Zoom" );
		zoomMenu.setMnemonic( KeyEvent.VK_Z );
		
		zoomInMenuItem.setMnemonic( KeyEvent.VK_I );
		zoomInMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_ADD, 0 ) );
		zoomInMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				// Change zoom state:
				if ( canvas.zoomFactor < RoomPanel.ZOOM_IN_LIMIT ) {
					if ( canvas.zoomFactor >= 1 )
						canvas.zoomFactor += 1;
					else {
						float zoomState = 1.0f / canvas.zoomFactor;
						zoomState -= 1;
						canvas.zoomFactor = 1.0f / zoomState;
					}
					
					// Force refresh on the canvas:
					canvas.isScrollingBoundaryValid = false;
					canvas.backBuffer = null;
					
					// Repaint to show changes:
					canvas.repaint();
				}
			} } );
		
		zoomOutMenuItem.setMnemonic( KeyEvent.VK_O );
		zoomOutMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_SUBTRACT, 0 ) );
		zoomOutMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				// Change zoom state:
				if ( canvas.zoomFactor > RoomPanel.ZOOM_OUT_LIMIT ) {
					if ( canvas.zoomFactor > 1 )
						canvas.zoomFactor -= 1;
					else {
						float zoomState = 1.0f / canvas.zoomFactor;
						zoomState += 1;
						canvas.zoomFactor = 1.0f / zoomState;
					}
					
					// Force refresh on the canvas:
					canvas.isScrollingBoundaryValid = false;
					canvas.backBuffer = null;
					
					// Repaint to show changes:
					canvas.repaint();
				}
			} } );
		
		zoomMenu.add( zoomInMenuItem );
		zoomMenu.add( zoomOutMenuItem );
		viewMenu.add( zoomMenu );
		
		viewMenu.add( new JSeparator() );
		
		// Show/hide obstacle layer:
		JMenuItem toggleObstacleMenuItem = new JMenuItem( "Show/hide the obstacle layer" );
		toggleObstacleMenuItem.setMnemonic( KeyEvent.VK_B );
		toggleObstacleMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_B, KeyEvent.CTRL_MASK ) );
		toggleObstacleMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				BGPanel obstPanel = (BGPanel) bgLayers.getComponent( 0 );
				obstPanel.hideCheckBox.doClick();
			} } );
		viewMenu.add( toggleObstacleMenuItem );
		
		// Show all BG layers:
		JMenuItem showAllLayersMenuItem = new JMenuItem( "Show all BG layers" );
		showAllLayersMenuItem.setMnemonic( KeyEvent.VK_L );
		showAllLayersMenuItem.setDisplayedMnemonicIndex( 12 );
		showAllLayersMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_L, KeyEvent.CTRL_MASK ) );
		showAllLayersMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				// Start from index 1, i.e., skip the obstacle layer:
				for ( int i = 1; i < bgLayers.getComponentCount(); i++ ) {
					BGPanel bgPanel = (BGPanel) bgLayers.getComponent( i );
					bgPanel.hideCheckBox.setSelected( true );
					bgPanel.hideCheckBox.doClick();
				}
			} } );
		viewMenu.add( showAllLayersMenuItem );
		
		// Hide all BG layers:
		JMenuItem hideAllLayersMenuItem = new JMenuItem( "Hide all BG layers" );
		hideAllLayersMenuItem.setMnemonic( KeyEvent.VK_H );
		hideAllLayersMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_H, KeyEvent.CTRL_MASK ) );
		hideAllLayersMenuItem.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				// Start from index 1, i.e., skip the obstacle layer:
				for ( int i = 1; i < bgLayers.getComponentCount(); i++ ) {
					BGPanel bgPanel = (BGPanel) bgLayers.getComponent( i );
					bgPanel.hideCheckBox.setSelected( false );
					bgPanel.hideCheckBox.doClick();
				}
			} } );
		viewMenu.add( hideAllLayersMenuItem );
		
		
		///////////////////////////////////////////////////////////////////////
		// ROOM:
		//
		// New game object:
		JMenuItem addGameObjMenuItem = new JMenuItem( "New game object..." );
		addGameObjMenuItem.setMnemonic( KeyEvent.VK_O );
		addGameObjMenuItem.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					// If the user is already in an object insertion state (he
					// just gave the command to create an object but hasn't
					// positioned it yet), don't do anything.
					if ( canvas.state == RoomPanel.STATE_OBJ_INSERT ) {
						JOptionPane.showMessageDialog(
							Main.f,                   // parent dialog
							"You are currently inserting an object in the room.\nSet this object's position by clicking on the display area before inserting a new one.", // message
							"New game object",        // title
							JOptionPane.ERROR_MESSAGE // message type
						);
						
						return;
					}
					
					
					// Prompt for new GameObj:
					GameObj newObj = EditGameObjDialog.createGameObj();
					if ( newObj != null ) {
						// Add the new object to the room and update the UI:
						newObj.x = (int) (-canvas.scrollX / canvas.zoomFactor) + (Main.loadedRoom.screenWidth  * Main.loadedRoom.blockSize / 2);
						newObj.y = (int) (-canvas.scrollY / canvas.zoomFactor) + (Main.loadedRoom.screenHeight * Main.loadedRoom.blockSize / 2);
						Main.loadedRoom.gameObjects.add( 0, newObj );
						Main.loadedRoom.getBGLayer( -1 ).isHidden = false;
						rebuildUI();
						
						// Let the RoomCanvas handle the positioning of the new
						// object:
						canvas.startGameObjPositioning( newObj );
						
						// Commit UndoOperation:
						UndoOperation op = new UndoImpl.CreateObjectOperation( 
							Main.loadedRoom.gameObjects.indexOf( newObj ),
							newObj );
						HistoryManager.addUndoOperation( op, "create game object" );
						
						Main.unsavedChanges = true;
					}
				}
			} );
		roomMenu.add( addGameObjMenuItem );
		
		// New BG Layer:
		JMenuItem addBGLayerMenuItem = new JMenuItem( "New BG layer..." );
		addBGLayerMenuItem.setMnemonic( KeyEvent.VK_L );
		addBGLayerMenuItem.addActionListener( new ActionListener() {
				public void actionPerformed ( ActionEvent evt ) {
					BGLayer newLayer = EditBGLayerDialog.createLayer();
					
					// User confirmed?
					if ( newLayer != null ) {
						// Add the layer to the room...
						Main.loadedRoom.addBGLayer( newLayer );
						
						// ...and add the layer's control panel to the UI:
						rebuildUI();
						
						// Set this layer as the working layer:
						int layerInx = Main.loadedRoom.getNumberOfBGLayers() - 1;
						setWorkingLayer( layerInx );
						
						// Commit UndoOperation:
						UndoOperation op = new UndoImpl.CreateBGLayerOperation(
							layerInx,
							newLayer,
							Main.loadedRoom.getBGData( layerInx ) );
						
						HistoryManager.addUndoOperation( op, "create BG layer " + layerInx );
					}
				}
			} );
		roomMenu.add( addBGLayerMenuItem );
		
		roomMenu.add( new JSeparator() );
		
		// Translate layer:
		JMenuItem translateLayerMenuItem = new JMenuItem( "Translate layer..." );
		translateLayerMenuItem.setMnemonic( KeyEvent.VK_T );
		translateLayerMenuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_T, KeyEvent.CTRL_MASK ) );
		translateLayerMenuItem.addActionListener( new ActionListener() {
			public void actionPerformed ( ActionEvent evt ) {
				if ( getWorkingLayer() == -1 )
					JOptionPane.showMessageDialog(
						Main.f,                      // parent dialog
						"The obstacle layer cannot be translated.", // message
						"Translate layer",           // title
						JOptionPane.ERROR_MESSAGE ); // message type
				else
					TranslateLayerDialog.showTranslateDialog( getWorkingLayer() );
			} } );
		roomMenu.add( translateLayerMenuItem );
		
		// Done!
		return menuBar;
	}
	
	
	
	/**
	 * Auxiliary method: Updates all UI elements
	 * 
	 * This will remove all the BGpanels and re-add them, thus losing
	 * information about which layer was selected and the selected tiles.
	 */
	public static void rebuildUI () {
		// Room info:
		roomSizeInfo.setText( Main.loadedRoom.getSizeDescription() );		
		
		// Update obstacleLayer panel:
		BGPanel obstaclePanel = (BGPanel) bgLayers.getComponentAt( 0 );
		obstaclePanel.bgPicker.repaint();
		obstaclePanel.hideCheckBox.setSelected( Main.loadedRoom.getBGLayer(-1).isHidden );
		obstaclePanel.infoLabel.setText( Main.loadedRoom.getGameObjDescription() );
		obstaclePanel.tileSizeLabel.setText( "Tile size: " + Main.loadedRoom.blockSize + "x" + Main.loadedRoom.blockSize );
		
		// Remove all BGPanels and re-add them to force their GUI and position
		// to be updated:
		while ( bgLayers.getComponentCount() > 1 )
			bgLayers.remove( 1 );
		
		for ( int i = 0; i < Main.loadedRoom.getNumberOfBGLayers(); i++ )
			bgLayers.addTab(
				Integer.toString( i ),     // tab text
				null,                      // icon
				new BGPanel( i ),          // component
				"Background layer " + i ); // tooltip
		
		// Just to be on the safe side...
		if ( canvas.selectedObj != null ) {
			canvas.selectedObj.highlighted = false;
			canvas.selectedObj = null;
		}
		canvas.state = RoomPanel.STATE_NORMAL;
		canvas.isScrollingBoundaryValid = false;
		canvas.repaint();
	}
	
	/**
	 * Updates all BGPanels. This is less drastic than rebuildUI(), and will not
	 * lose information about seleected layers or tiles. However, it will also
	 * fail to detect changes in the room's layer list, such as removal or
	 * position swap.
	 */
	public static void updateBGPanels () {
		for ( int i = 0; i < bgLayers.getComponentCount(); i++ )
			((BGPanel) bgLayers.getComponent( i )).updateLayerParameters();
	}
	
	
	/**
	 * Returns the working layer index. (-1 for the obstacle layer)
	 */
	public static int getWorkingLayer () {
		return bgLayers.getSelectedIndex() - 1;
	}
	
	/**
	 * Sets the working layer index. (-1 for the obstacle layer)
	 */
	public static void setWorkingLayer ( int layerInx ) {
		bgLayers.setSelectedIndex( layerInx + 1 );
	}
	
	
	/**
	 * Fills a Graphics area with black-on-gray hatches.
	 */
	public static void clearBGWithHatches ( Graphics g, int width, int height ) {
		g.setColor( Color.DARK_GRAY );
		g.fillRect( 0, 0, width, height );
	
		g.setColor( Color.BLACK );
		for ( int i = 0; i < Math.max(width, height); i += 3 ) {
			g.drawLine( i, 0, i + height, height );
			g.drawLine( -i, 0, -i + height, height );
		}
	}
	
	
	/**
	 * Draws a grid with up to maxCount blocks onto the specified Graphics
	 * object, with its top-left corner at coordinates (x, y).
	 */
	public static void drawGrid ( Graphics g, int x, int y, int rows, int cols, int gridWidth, int gridHeight, int maxCount, Color c ) {
		g.setColor( c );
		int count = 0;
		int i = 0, j = 0;
		
		ROW_LOOP: for ( i = 0; i < rows; i++ ) {
			for ( j = 0; j < cols; j++ ) {
				count++;
				if ( count > maxCount )
					break ROW_LOOP;
				
				int left   = x + j * gridWidth,
				    right  = left + gridWidth,
				    top    = y + i * gridHeight,
				    bottom = top + gridHeight;
				// Draw lines below and on the right of the tile:
				g.drawLine( left + 1, bottom,  right, bottom );
				g.drawLine( right,    top + 1, right, bottom - 1 );
			}
		}
		
		// Finish the grid with lines above and on the left of the whole grid:
		int colsDrawn = (i > 0         ? cols : j);
		int rowsDrawn = ((cols != 0 ? j % cols : 0) == 0 ? i    : i + 1);
		int left   = x,
			right  = left + gridWidth * colsDrawn,
			top    = y,
			bottom = top + gridHeight * rowsDrawn; 
		g.drawLine( left, top,     right, top );
		g.drawLine( left, top + 1, left,  bottom );
	}	
	
	
	
	
	
	
	
	/**
	 * Nested class: A JSpinner that accepts integer values greater than 1.
	 */
	public static class PositiveIntegerSpinnerModel implements SpinnerModel {
		Vector changeListeners = new Vector();
		int value;
	
		public PositiveIntegerSpinnerModel ( int initialValue ) {
			value = initialValue;
		}
	
		public void addChangeListener(ChangeListener c) {
			changeListeners.add( c );
		}
		public void removeChangeListener(ChangeListener c) {
			changeListeners.remove( c );
		}
	
		public Object getNextValue() {
			return new Integer(value + 1);
		}
		public Object getPreviousValue() {
			if ( value > 1 )
				return new Integer( value - 1 );
			else
				return null;
		}
	
		public Object getValue() {
			return new Integer( value );
		}
		public void setValue(Object obj) {
			try {
				int newValue = Integer.parseInt( obj.toString() );
			
				if ( newValue >= 1 ) {
					value = newValue;
				
					ChangeEvent evt = new ChangeEvent( this );
					for ( int i = 0; i < changeListeners.size(); i++ )
						((ChangeListener) changeListeners.get( i )).stateChanged( evt );
				}
				else
					throw new IllegalArgumentException();
			}
			catch ( NumberFormatException exc ) {
				throw new IllegalArgumentException();
			}
		}
	}
	
	
	/**
	 * Shows a dialog with the message "The path you chose is not contained in
	 * the base path".
	 */
	public static void showNotInBasePathDialog ( Component parent) {
		String[] message = {
			"The file you chose is not contained in the base path",
			"or one of its subdirectories. The base path is",
			" ",
			Main.getBasePath() };
		JOptionPane.showMessageDialog(
			parent,                      // parent dialog
			message,                     // message
			"Error",                     // title
			JOptionPane.ERROR_MESSAGE ); // message type
	}
	
}
