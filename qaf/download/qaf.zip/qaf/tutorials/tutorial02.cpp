/**
 * @page tutorial02 Tutorial 2 - Creating and Loading a Room File
 * 
 * In this tutorial, you will be introduced to the Qaf Room Editor and some of
 * its features.
 * 
 * @section tut02s01 The Base Path
 * 
 * The Editor is a separate application, which can be accessed by running
 * <b>editors/RoomEditor.bat</b>. If this is the first time the Editor is run,
 * you will be greeted by the following dialog:
 * 
 * <center>
 * @image html tut02basepath.png
 * </center>
 * 
 * You should enter the directory where your executable is generated. For
 * instance, if your game's resources are arranged in the same manner as the
 * structure presented in \ref tutorial01, the base path would be the project's
 * <b>Debug</b> directory.
 * 
 * The base path can be changed by clicking <b>File -> Change base path</b>.
 * 
 * @section tut02s02 Obstacles and Background Layers
 * 
 * This is what the window should look like now:
 * 
 * <center>
 * @image html tut02emptyroom.png
 * </center>
 * 
 * The Editor will start with a default 640x480 room. The screen, in turn, is
 * further divided into the elementary structural components of the game's
 * environment: The <i>obstacle blocks</i>. The level designer is allowed to
 * choose from a set of primitives when outlining the backgrounds' structure;
 * these are visible in the Editor's lower-left panel. You can select a
 * primitive by clicking on it, and then place it on the room's grid by
 * "drawing" with the left mouse button.
 * 
 * <center>
 * @image html tut02obstacles.png
 * </center>
 * 
 * With the floor and walls set up, it's time to draw the actual backgrounds.
 * 
 * Click on the <b>Room</b> menu and choose to create a <b>New BG layer</b>.
 * You should see the following dialog:
 * 
 * <center>
 * @image html tut02newbglayer.png
 * </center>
 * 
 * Most of these elements are pretty self-explanatory. As noted above, the
 * <i>source image</i> must be placed somewhere within the base path's
 * subdirectories. (If you're following the previous tutorial, that would be
 * <b>Debug</b>, and you'd have to copy the image files into that directory.)
 * 
 * Go ahead and create three background layers with the following parameters:
 * 
 * <table>
 *   <tr>
 *      <th> Source image </th>
 *      <th> Parallax factor </th>
 *      <th> Tile size </th>
 *   </tr>
 *   <tr>
 *      <td align=center> background00.png </td>
 *      <td align=center> 1.0 </td>
 *      <td align=center> 32 x 32 </td>
 *   </tr>
 *   <tr>
 *      <td align=center> background01.png </td>
 *      <td align=center> 0.8 </td>
 *      <td align=center> 320 x 240 </td>
 *   </tr>
 *   <tr>
 *      <td align=center> background_moon.png </td>
 *      <td align=center> 0 </td>
 *      <td align=center> 640 x 480 </td>
 *   </tr>
 * </table>
 * 
 * You will notice that a tab is added to the lower-left panel every time you
 * add a background layer. Clicking on a tab displays the tiles stored in that
 * layer, and allows you to click-select-and-click-draw like you did with the
 * obstacle blocks. Now, let your creative side run loose... or just replicate
 * the room below:
 * 
 * <center>
 * @image html tut02layers.png
 * </center>
 * 
 * <table border=0 width=80% align="center" bgcolor="#FFFFDD">
 *    <tr>
 *       <td> <center> @b Tip </center>
 *            The Editor doesn't have an "eraser" tool. If you want to remove
 *            tiles from the grid, select the @b \<Blank> tile and use it to
 *            draw over the area you want to erase. </td>
 *       <td> @image html tut02tip_blank.png </td>
 * </table>
 * 
 * <table border=0 width=80% align="center" bgcolor="#FFFFDD">
 *    <tr>
 *       <td> @image html tut02tip_pick.png </td>
 *       <td> <center> @b Tip </center>
 *            You can select a tile by holding down Ctrl and clicking on the
 *            editor's main area. </td>
 * </table>
 * 
 * You'll notice I placed the tiles on layer #0 so that they would overlap the
 * obstacle blocks. This is deliberate, and the reason will become clear in the
 * next tutorial.
 * 
 * OK, the room is ready. Save it as <b>room01.qr</b> in the same directory as
 * your executable and exit the Room Editor.
 * 
 * @section tut02s03 Loading and Displaying the Room
 * 
 * This is actually the easiest part. After initializing Qaf, you just need to
 * tell it which room to load:
 * 
 * @code
 * 	// Set up the environment:
 * 	Environment::initialize( false, true );
 * 	
 * 	// Load the room:
 * 	Environment::loadRoom( "room01.qr" );
 * @endcode
 * 
 * Other than, that, very little has changed in the code from the first
 * tutorial.
 *  - The screen does not need to be cleared, since the whole area is covered
 *    by the room's backgrounds.
 *  - The FPS rate is printed out in the frame function.
 *  - I removed the prologue function, as it doesn't do anything now.
 * 
 * See the full source code for this tutorial in the file: <b>tutorials/tutorial02.cpp</b>
 * 
 */


#include <hge.h>
#include <qafEnvironment.h>

using namespace qaf;

HGE * hge = NULL;

// The frame function:
bool frameFunction () {
	// Output text:
	Environment::cout << hge->Timer_GetFPS() << " FPS\n";
	
	// Perform Qaf's game loop:
	Environment::update( hge->Timer_GetDelta() );
	
	return false;
}




// Application entry point:
int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ) {
	
	// Set up HGE:
	hge = hgeCreate( HGE_VERSION );
	
	hge->System_SetState( HGE_FRAMEFUNC,     frameFunction );
	hge->System_SetState( HGE_FPS,           HGEFPS_UNLIMITED );
	hge->System_SetState( HGE_SCREENWIDTH,   640 );
	hge->System_SetState( HGE_SCREENHEIGHT,  480 );
	hge->System_SetState( HGE_WINDOWED,      true );
	
	if ( !hge->System_Initiate() )
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	
	// Set up the environment:
	Environment::initialize( false, true );
	
	// Load the room:
	Environment::loadRoom( "room01.qr" );
	
	// Start the game loop:
	if ( !hge->System_Start() ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	}
	
	// Shutdown:
	Environment::shutdown();
	hge->System_Shutdown();
	hge->Release();
	
	return 0;
}




