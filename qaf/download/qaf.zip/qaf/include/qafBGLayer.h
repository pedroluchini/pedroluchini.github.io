/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_BGLAYER_H
#define QAF_BGLAYER_H

#include "qafutil/qafBigTexture.h"
#include "qafutil/qafContainer.h"
#include "qafutil/qafMatrix.h"
#include <string>


namespace qaf {
	
	#ifndef QAF_ENVIRONMENT_H
	class Environment;
	#endif
	
	#ifndef QAF_ROOM_H
	class Room;
	#endif
	
	/**
	 * Represents a background layer in the loaded room. An instance of this
	 * class will hold a handle to the tile library (i.e., the image that stores
	 * the layer's tiles) and a data matrix (which contains the layer's tile
	 * layout).
	 * 
	 * The tile library is loaded via <tt>Environment::loadBigTexture()</tt>.
	 * This means that:
	 *  - The tile library's source image may have any size;
	 *  - The image will benefit from the <tt>Environment</tt>'s caching
	 *    system, avoiding duplicate tile libraries and gaining a performance
	 *    boost if you have lots of rooms with the same tile libraries.
	 * 
	 * The <tt>bgData</tt> matrix is public and freely accessible. If you want
	 * the background's tiles to change dynamically, fell free to edit the
	 * matrix's cells.
	 */
	class BGLayer {
	public:
		
		/**
		 * The tile size, needed to position tiles in the correct places upon
		 * drawing.
		 */
		const int tileWidth, tileHeight;
		
		/**
		 * The tile matrix. Each cell contains a tile ID, which is used to
		 * determine which portion of the tile library should be drawn at the
		 * cell's position.
		 */
		Matrix<int> bgData;
		
		/**
		 * When the parallax factor is equal to 1.0, the layer will appear to
		 * be on the same plane as the obstacle layer; a factor greater than
		 * 1.0 will make it seem closer to the screen; a factor less than 1.0
		 * will make it seem farther away.
		 * 
		 * For instance, a static "sky" layer would need a parallax factor
		 * equal to zero.
		 */
		const float parallaxFactor;
		
		/**
		 * The translation is applied to the entire layer, and is not affected
		 * by the parallax factor.
		 */
		int translateX, translateY;
		
		
		
	private:
		const BigTexture * libTexture;
		
		friend class Environment;
		friend class Room;
		
		// The constructor will load the source image and use it as a tile
		// library.
		// 
		// The parameters <tt>rows</tt> and <tt>columns</tt> refer to the data
		// matrix's dimensions.
		BGLayer ( std::string sourceImagePath,
				  int tileWidth, int tileHeight,
				  float parallaxFactor,
				  int translateX, int translateY,
				  int rows, int columns );
		
		
		// Draws the layer using HGE functions. The supplied coordinates
		// (<tt>x</tt>, <tt>y</tt>) are interpreted as the room's top-left
		// corner (in <tt>Environment</tt> terms, they're the scrolling point,
		// but with its sign reversed).
		// 
		// What this means is that if the layer's parallax factor is not 1.0,
		// its top-left corner will not be drawn exactly at (<tt>x</tt>,
		// <tt>y</tt>), but will be scaled so that the parallax is consistent.
		void render ( int x, int y );
		
		// Deletes the data matrix and frees the tile library.
		virtual ~BGLayer ();
	};

}


#endif