/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_GAMEOBJFACTORY_H
#define QAF_GAMEOBJFACTORY_H

#include "qafGameObj.h"

// MS Visual Studio 6: Disables the "identifier was truncated to '255'
// characters in the browser information" warning:
#pragma warning (disable:4786)

#include <map>
#include <string>


namespace qaf {
	
	/**
	 * A shortcut so we don't have to write the whole type declaration all the
	 * time.
	 */
	typedef std::map<std::string, std::string> AttributeTable;
	
	/**
	 * The object factory will be queried by the <tt>Environment</tt> to create the
	 * Room's game objects. Implementations should be registered via the
	 * <tt>Environment::setGameObjFactory()</tt> method.
	 */
	class GameObjFactory {
	public:
		
		/**
		 * Creates a <tt>GameObj</tt> instance based on its parameters.
		 * 
		 * When a room is loaded, the <tt>Environment</tt> will read the game
		 * objects stored in it and forward their data to the registered
		 * factory.
		 *
		 * The object returned by this method will be inserted into the room's
		 * default object layer and its <tt>initialize()</tt> method will be
		 * called.
		 * 
		 * The object's attribute table is transformed into a <tt>map</tt>
		 * (from the C++ STL), where keys and values are both <tt>string</tt>s.
		 * 
		 * @param objID      The object ID defined in the %Room Editor.
		 * @param objX       The X position the object was placed at in the
		 *                   %Room Editor.
		 * @param objY       The Y position the object was placed at in the
		 *                   %Room Editor.
		 * @param attributes The attributes defined for this object in the
		 *                   %Room Editor.
		 * 
		 * @return A new game object to be inserted into the
		 *         <tt>Environment</tt>, or <tt>NULL</tt> if the object could
		 *         not be created.
		 */
		virtual GameObj * createObject ( std::string & objID,
		                                 int objX, int objY,
		                                 AttributeTable & attributes ) = 0;
		
		virtual ~GameObjFactory () {}
		
	};
	
}

#endif
