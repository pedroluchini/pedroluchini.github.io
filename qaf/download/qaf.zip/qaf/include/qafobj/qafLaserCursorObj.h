/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_OBJ_LASERCURSOR_H
#define QAF_OBJ_LASERCURSOR_H

#include "../qafGameObj.h"
#include "../qafutil/qafVector2D.h"


namespace qaf {
	
	/**
	 * Demonstrates moving-point collision.
	 * 
	 * Use the arrow keys to move the blue cursor. Use the mouse to control the
	 * yellow cursor.
	 * 
	 * A yellow "laser" is shot from the blue to the yellow cursor. If the
	 * laser touches an obstacle, a red line is drawn to display the contact
	 * point and normal.
	 */
	class LaserCursorObj : public GameObj {
		public:
			
			Vector2D pos, aim;
			Vector2D vel;
			
			LaserCursorObj ( float _x, float _y );
			virtual ~LaserCursorObj ();
			
			void update ( int objLayer, float dt );
			void render ( int objLayer, int scrollX, int scrollY );
			
		private:
			void * pHGE;
	};
	
}

#endif