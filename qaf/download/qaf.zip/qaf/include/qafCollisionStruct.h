/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_COLLISIONSTRUCT_H
#define QAF_COLLISIONSTRUCT_H	

#include "qafutil/qafContainer.h"
#include "qafutil/qafVector2D.h"


namespace qaf {
	
	/**
	 * Represents a geometric boundary for use in collision tests.
	 * 
	 * <tt>CollisionStruct</tt> is an abstract class that represents generic
	 * boundaries. In your <tt>GameObj</tt>s, you should return either 
	 * <tt>CollisionStruct::Box</tt> or <tt>CollisionStruct::Polygon</tt>.
	 * 
	 * @warning
	 * Do <em>not</em> derive from this class to implement your own collision
	 * tests.
	 * 
	 * @see GameObj::getCollisionStruct()
	 */
	class CollisionStruct {
		public:
			
			/**
			 * @return true if this struct is colliding against the supplied
			 *         pointer.
			 */
			virtual bool collidesWith ( CollisionStruct * otherStruct ) = 0;
			
			
			virtual ~CollisionStruct () {}
			
			class Box;
			class Polygon;
			
	};
	
	
	
	
	/**
	 * Represents rectangular collision boundaries.
	 */
	class CollisionStruct::Box : public CollisionStruct {
		public:
			/**
			 * Initializes the box's boundaries.
			 */
			Box ( float x, float y, float w, float h );
			
			/**
			 * Initializes the box's boundaries to (0, 0, 0, 0)
			 */
			Box ();
			
			
			/// @{{
			/**
			 * Setters and getters.
			 */
			void setX      ( float x );
			void setY      ( float y );
			void setWidth  ( float w );
			void setHeight ( float h );
			
			inline float getX () {
				return x;
			}
			inline float getY () {
				return y;
			}
			inline float getWidth () {
				return w;
			}
			inline float getHeight () {
				return h;
			}
			/// @}}
			
			/**
			 * For debug purposes, this will render the current collision
			 * boundaries as a set of lines.
			 */
			void render ( int scrollX, int scrollY, unsigned long color );
			
			
			bool collidesWith ( CollisionStruct * otherStruct );
		
		private:
			float x, y, w, h;
			Container<Vector2D> poly;
			
			inline void updateHoriz () {
				poly[0].x = poly[3].x = x;
				poly[1].x = poly[2].x = x + w;
			};
			inline void updateVert () {
				poly[0].y = poly[1].y = y;
				poly[2].y = poly[3].y = y + h;
			};
			
			// The Polygon needs access to the Box's points.
			friend CollisionStruct::Polygon;
			
	};
	
	
	
	
	/**
	 * Represents a polygonal collision boundary.
	 * 
	 * The polygon may be concave and its edges may intersect. You could hardly
	 * ask for anything more generic than this, although it is much less
	 * efficient than a <tt>CollisionStruct::Box</tt>.
	 * 
	 * The polygon defined by <tt>points</tt> is assumed to be the
	 * "untranslated" version of the collision boundary. If this were
	 * an hgeSprite, think of the point (0, 0) as the polygon's hot
	 * spot.
	 * 
	 * Typically, you would specify the object's polygon points
	 * relative to its sprite's hot spot, and then update the
	 * polygon's position to the object's position once per frame.
	 */
	class CollisionStruct::Polygon : public CollisionStruct {
		public:
			/**
			 * The constructor receives a series of points that represent the
			 * polygon's outline. The polygon is always assumed to be closed
			 * (i.e., the last point will be "linked" with the first point).
			 */
			Polygon ( Container<Vector2D> & points );
			
			/**
			 * Default constructor, that creates an "empty" polygon.
			 */
			Polygon ();
			
			
			/**
			 * For debug purposes, this will render the current collision
			 * boundaries as a set of lines.
			 */
			void render ( int scrollX, int scrollY, unsigned long color );
			
			
			/**
			 * Updates the points that represent the polygon's outline.
			 */
			void setPoints( Container<Vector2D> & points );
			
			/**
			 * Sets the object's displacement relative to (0, 0).
			 */
			void setPosition( float x, float y );
			
			
			bool collidesWith ( CollisionStruct * otherStruct );
			
		private:
			Container<Vector2D> userPoints, realPoints;
			Vector2D pos;
			
	};
	
	
	
}


#endif
