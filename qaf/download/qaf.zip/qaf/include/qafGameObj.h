/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_GAMEOBJ_H
#define QAF_GAMEOBJ_H

#include "qafCollisionStruct.h"

namespace qaf {
	
	/**
	 * <tt>GameObj</tt>s represent the "active" components of the game.
	 * Instances of this class are returned by a <tt>GameObjFactory</tt>
	 * object.
	 * 
	 * Typically, you will create a different subclass of <tt>GameObj</tt> for
	 * each kind of character, enemy, item, etc. that takes part in the game,
	 * and override the relevant methods to define its behavior.
	 */
	class GameObj {
	public:

		/**
		 * Method invoked every time the <tt>GameObj</tt> is inserted into the
		 * <tt>Environment</tt>, as a result of
		 * <tt>Environment::loadRoom()</tt> being called. By the time
		 * <tt>initialize()</tt> is invoked, the object is already inserted in
		 * the <tt>Room</tt>'s default object layer.
		 * 
		 * All <tt>Environment</tt>-related tasks should be performed here,
		 * rather than in the object's constructor.
		 * 
		 * If the object needs to be in a layer that is not the room's default,
		 * this would be the moment to reposition it with
		 * <tt>Environment::moveGameObj()</tt>.
		 * 
		 * The default implementation does nothing.
		 */
		virtual void initialize ();
		
		/**
		 * The object's "frame function". It will be called once per frame by
		 * the <tt>Environment</tt>. Update the object's internal state here.
		 * 
		 * The default implementation does nothing.
		 * 
		 * @param objLayer The object layer where this <tt>GameObj</tt> is
		 *                 residing.
		 * @param dt       The same value that was passed to
		 *                 <tt>Environment::update()</tt>.
		 */
		virtual void update ( int objLayer, float dt );
		
		/**
		 * This is where the object should draw itself using HGE functions.
		 * 
		 * The render target is not transformed; thus, objects should implement
		 * their own translation using the <tt>Environment</tt>'s scrolling
		 * point.
		 * 
		 * The default implementation does nothing.
		 * 
		 * @see Environment::getScrollingX(), Environment::getScrollingY(), 
		 *      Environment::getBackBuffer()
		 * 
		 * @param objLayer The object layer where this <tt>GameObj</tt> is
		 *                 residing.
		 * @param scrollX  The scrolling point's current X coordinate.
		 * @param scrollY  The scrolling point's current Y coordinate.
		 */
		virtual void render ( int objLayer, int scrollX, int scrollY );
		
		/**
		 * A "volatile object" will be removed from the <tt>Environment</tt>
		 * and <tt>delete</tt>d when the room is unloaded.
		 * 
		 * If this method returns false, the object will be kept and reinserted
		 * into the <tt>Environment</tt>, in the new room's default object
		 * layer.
		 * 
		 * The default implementation returns true.
		 *
		 * @return true if this is a volatile object.
		 * 
		 * @see Environment::unloadRoom()
		 */
		virtual bool isVolatile ();
		
		/**
		 * Returns the collision structure associated with this object.
		 * 
		 * This method may be invoked many times during a single frame, so it's
		 * important to keep its implementation efficient. Specifically, you
		 * shouldn't allocate a new <tt>CollisionStruct</tt> in every call, but
		 * rather keep a pointer to one of these objects in your
		 * <tt>GameObj</tt> and set its positional parameters in the
		 * <tt>update()</tt> method.
		 * 
		 * It is allowed to return NULL in this method. The object will be
		 * assumed to have no collision boundaries, and thus will not collide
		 * against any other object.
		 * 
		 * The default implementation returns NULL.
		 * 
		 * @see CollisionStruct::Box, CollisionStruct::Polygon
		 */
		virtual CollisionStruct * getCollisionStruct ();
		
		
		virtual ~GameObj () {}
	};
	
}


#endif
