/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_UTIL_INTEGERINPUTSTREAM_H
#define QAF_UTIL_INTEGERINPUTSTREAM_H

#include "qafHgeInputStream.h"
#include <string>


namespace qaf {

	/**
	 * Encapsulates decoding of an integer stream.
	 * 
	 * The Qaf editors use a modified version of UTF-8 to store integers in
	 * their files, which allows any integer value (including negative numbers)
	 * to be written or read.
	 * 
	 * This class reads integers from one of those files. An exception will be
	 * thrown if the UTF-8 encoding in the file is invalid.
	 */
	class IntegerInputStream : private HgeInputStream {
		public:
			/**
			* Represents an unexpected end-of-file during reading operations.
			*/
			class EndOfFileException {};
			
			/**
			* Represents an encoding error in the pseudo-UTF-8 stream.
			*/
			class EncodingException {};
			
			
			/**
			* The constructor will open the specified file, preparing it for
			* reading. Before accessing the stream with its reading methods, it
			* is advisable to check if the operation was successful with
			* <tt>canRead()</tt>.
			*/
			IntegerInputStream ( const char * filename );
			
			/**
			* @return true if the file has been successfully opened and/or
			*         there are more bytes to be read from it.
			* 
			* @warning This does <em>not</em> mean you can call
			*          <tt>readInt()</tt> without checking for exceptions.
			*          There may not be enough bytes in the stream, or there
			*          may be an error in their encoding.
			*/
			bool canRead ();
			
			/**
			* Reads the next integer from the stream.
			* @return The integer value.
			* @throw EndOfFileException if the end of the file is reached.
			* @throw EncodingException if the stream contains invalid encoding.
			*/
			int readInt ();
			
			/**
			* Reads integers from the stream until a NUL value (zero) is found,
			* converts them to characters and wraps them in a <tt>string</tt>.
			* 
			* @return The string read.
			* @throw EndOfFileException if the end of the file is reached
			*        before a NUL value.
			* @throw EncodingException if the stream contains invalid encoding.
			*/
			std::string readNullTerminatedString ();
			
			/**
			* Destructor: If the file is open, it will be automatically closed
			* before this object is destroyed.
			*/
			virtual ~IntegerInputStream ();
			
		private:
			// Throws an EndOfFileException if the end of the file is reached.
			int nextByte ();
	};
}

#endif
