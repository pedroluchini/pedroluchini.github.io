/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_UTIL_GEOM_H
#define QAF_UTIL_GEOM_H

#include "qafContainer.h"
#include "qafVector2D.h"
#include "../qafDef.h"


/**
 * If any value is lower than this, it will be considered to be zero.
 */
#define QAF_GEOM_EPSILON 1e-4f


namespace qaf {

	/**
	 * Provides static methods for useful geometric operations.
	 */
	class Geom {
		public:
			
			/**
			 * Tests for segment intersection.
			 * Stores the intersection point, if any, in the "point" vector, if
			 * it is not NULL.
			 *
			 * Based on the algorithms seen here:
			 *   http://www.geometryalgorithms.com/Archive/algorithm_0108/algorithm_0108.htm
			 * 
			 * @return true if the two segments intersect each other
			 */
			inline static bool segmentIntersection (
									float s1x1, float s1y1,
									float s1x2, float s1y2,
									float s2x1, float s2y1, 
									float s2x2, float s2y2,
									Vector2D * point ) {
				float lsign, rsign;
				bool  p1Overlap = false, p2Overlap = false;
				
				lsign = isLeft(s1x1, s1y1, s1x2, s1y2, s2x1, s2y1);    // s2 left point sign
				rsign = isLeft(s1x1, s1y1, s1x2, s1y2, s2x2, s2y2);    // s2 right point sign
				
				if (lsign * rsign > 0) // s2 endpoints have same sign relative to s1
					return false;      // => on same side => no intersect is possible
				else if ( ABS(lsign) < QAF_GEOM_EPSILON && ABS(rsign) < QAF_GEOM_EPSILON )
					p1Overlap = true;
				
				lsign = isLeft(s2x1, s2y1, s2x2, s2y2, s1x1, s1y1);    // s1 left point sign
				rsign = isLeft(s2x1, s2y1, s2x2, s2y2, s1x2, s1y2);    // s1 right point sign
			    
				if (lsign * rsign > 0) // s1 endpoints have same sign relative to s2
					return false;      // => on same side => no intersect is possible
				else if ( ABS(lsign) < QAF_GEOM_EPSILON && ABS(rsign) < QAF_GEOM_EPSILON )
					p2Overlap = true;
				
				// Segments overlap?
				if ( p1Overlap && p2Overlap ) {
					float minS1x = MIN(s1x1, s1x2), maxS1x = MAX(s1x1, s1x2);
					float minS1y = MIN(s1y1, s1y2), maxS1y = MAX(s1y1, s1y2);
					float minS2x = MIN(s2x1, s2x2), maxS2x = MAX(s2x1, s2x2);
					float minS2y = MIN(s2y1, s2y2), maxS2y = MAX(s2y1, s2y2);
					
					// Segment1 not contained in segment2?
					if ( maxS1x < minS2x || maxS2x < minS1x ||
						maxS1y < minS2y || maxS2y < minS1y )
						return false;
				}
			    
				// the segments s1 and s2 straddle each other
				
				// Calculate intersection point...?
				if ( point ) {
					// Special cases:
					float dx1 = s1x1 - s1x2, dx2 = s2x1 - s2x2;
					if ( ABS(dx1) < QAF_GEOM_EPSILON && ABS(dx2) < QAF_GEOM_EPSILON ) {
						// Both segments are vertical!
						// Set the intersection at the midpoint:
						point->x = s1x1;
						point->y = (s1y1 + s1y2)/2;
					}
					else if ( ABS(dx1) < QAF_GEOM_EPSILON ) {
						// Segment 1 is vertical!
						point->x = s1x1;
						
						// Use proportions to calculate the Y coordinate in segment 2:
						float horizProportion = ABS((float) (s1x1 - s2x1) / dx2);
						point->y = s2y1 + (horizProportion * (s2y2 - s2y1));
					}
					else if ( ABS(dx2) < QAF_GEOM_EPSILON ) {
						// Segment 2 is vertical!
						point->x = s2x1;
						
						// Use proportions to calculate the Y coordinate in segment 1:
						float horizProportion = ABS((float) (s2x1 - s1x1) / dx1);
						point->y = s1y1 + (horizProportion * (s1y2 - s1y1));
					}
					else {
						// y = a * x + b
						float a1, a2, b1, b2;
						
						// Sort points by X coordinate:
						if ( s1x1 > s1x2 )
							a1 = (s1y1 - s1y2)/(s1x1 - s1x2);
						else
							a1 = (s1y2 - s1y1)/(s1x2 - s1x1);
						b1 = s1y1 - a1 * s1x1;
						
						if ( s2x1 > s2x2 )
							a2 = (s2y1 - s2y2)/(s2x1 - s2x2);
						else
							a2 = (s2y2 - s2y1)/(s2x2 - s2x1);
						b2 = s2y1 - a2 * s2x1;
						
						// Intersection:
						point->x = ((b2 - b1)/(a1 - a2));
						point->y = (a1 * (point->x) + b1);
					}
				}
					
				return true;           // => an intersect exists
			} // End of method: segmentIntersection
			
			
			
			
			/** 
			 * Given the polygon described by the <tt>Container</tt>, returns
			 * true if the point <tt>p</tt> lies inside it.
			 * 
			 * Based on the code seen here:
			 *   http://astronomy.swin.edu.au/~pbourke/geometry/insidepoly/
			 */ 
			inline static bool insidePolygon ( Vector2D & p, Container<Vector2D> & polygon ) {
				int counter = 0;
				int i;
				double xinters;
				Vector2D p1, p2;
				
				p1 = polygon[0];
				for (i=1;i<=polygon.getCount();i++) {
					p2 = polygon[i % polygon.getCount()];
					if (p.y > MIN(p1.y,p2.y)) {
						if (p.y <= MAX(p1.y,p2.y)) {
							if (p.x <= MAX(p1.x,p2.x)) {
								if (p1.y != p2.y) {
									xinters = (p.y-p1.y)*(p2.x-p1.x)/(p2.y-p1.y)+p1.x;
									if (p1.x == p2.x || p.x <= xinters)
										counter++;
								}
							}
						}
					}
					p1 = p2;
				}
				
				if (counter % 2 == 0)
					return false;
				else
					return true;
			} // End of method: insidePolygon
			
			
			
			
			/**
			 * Renders the specified polygon as a set of lines in the specified
			 * color, translated as requested.
			 */
			static void renderPolygon ( Container<Vector2D> & points, float translateX, float translateY, unsigned long color );
			

			/**
			 * The infamous "fast inverse square root" function.
			 */
			static inline float invSqrt ( float x ) {
				float xhalf = 0.5f*x;
				int i = *(int*)&x; // get bits for floating value
				i = 0x5f3759df - (i>>1); // gives initial guess y0
				x = *(float*)&i; // convert bits back to float
				x = x*(1.5f-xhalf*x*x); // Newton step, repeating increases accuracy
				
				return x;
			}
			
		private:
			
			//
			// Auxiliary function:
			// Tests if point P2 is Left|On|Right of the line P0 to P1.
			//      returns: >0 for left, 0 for on, and <0 for right of the line.
			//
			static inline float isLeft ( float p0X, float p0Y,
			                             float p1X, float p1Y,
			                             float p2X, float p2Y ) {
				return (p1X - p0X)*(p2Y - p0Y) - (p2X - p0X)*(p1Y - p0Y);
			}
			

	};
	
}



#endif
