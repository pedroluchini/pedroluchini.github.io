/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_BIGTEXTURE_H
#define QAF_BIGTEXTURE_H


namespace qaf {

	/**
	 * Stores an arbitrary-sized image.
	 * 
	 * Following a "slower and working is better than faster and broken" philosopy,
	 * <tt>BigTexture</tt> will juggle textures and sub-textures for you, ensuring
	 * your large tile libraries will look the same no matter what the video card's
	 * texture dimension constraints are.
	 * 
	 * <tt>BigTexture</tt> is an extension for 
	 * <a href="http://hge.relishgames.com/">Haaf's Game Engine</a>, using
	 * Direct3DX as its image loader.
	 * 
	 * When you create a <tt>BigTexture</tt> object, the constructor will
	 * automatically divide the source image into smaller images until all of them
	 * fit within the video card's texture dimension constraints. This is
	 * transparent to the user; you just tell BT to render a rectangular area from
	 * the source image.
	 */
	class BigTexture {
		public:
			/**
			 * Loads the image, breaking it into sub-textures as needed.
			 * 
			 * If any errors are encountered, they will be reported in the HGE
			 * log file.
			 * 
			 * This process is <em>very</em> slow; you should manage your BTs
			 * so as to minimize the creation/destruction of these objects.
			 * 
			 * @see Environment::loadBigTexture()
			 */
			BigTexture ( const char * sourceImage );
			
			
			/**
			 * @return The original image's width, in pixels.
			 */
			inline int getImageWidth () const {
				return imageWidth;
			}
			
			/**
			 * @return The original image's height, in pixels.
			 */
			inline int getImageHeight () const {
				return imageHeight;
			}
			
			/**
			 * Draws an axis-aligned rectangular area from this image.
			 * 
			 * Make sure you invoke this method between a pair of
			 * <tt>Gfx_BeginScene()</tt>/<tt>Gfx_EndScene()</tt> calls.
			 * 
			 * @param x0     Screen coordinates of the rectangle's top-left corner
			 * @param y0     Screen coordinates of the rectangle's top-left corner
			 * @param tx     Coordinates of the rectangle's top-left corner in the
			 *               image space.
			 * @param ty     Coordinates of the rectangle's top-left corner in the
			 *               image space
			 * @param width  Width of the rectangular area to be drawn. If zero or
			 *               negative, the image's width is used.
			 * @param height Height of the rectangular area to be drawn. If zero or
			 *               negative, the image's height is used.
			 * @param color  Has the same effect as the <tt>color</tt> field in
			 *               <tt>hgeVertex</tt>. Default is full-alpha white.
			 * @param blend  Has the same effect as the <tt>blend</tt> field in
			 *               <tt>hgeQuad</tt>.
			 * 
			 * @note
			 * If the rectangle exceeds the image's bounds, it will be clipped.
			 */
			void renderRectangle ( int x0, int y0,
			                       int tx = 0, int ty = 0,
			                       int width = 0, int height = 0,
			                       unsigned long color = 0xFFFFFFFF,
			                       unsigned long blend = 2 ) const;
			
			
			/**
			 * Deletes the sub-textures.
			 */
			virtual ~BigTexture ();
			
		private:
			struct SubTexture {
				unsigned long tex;
				int width, height;
			};
			
			SubTexture * subTextures;
			int rows, cols;
			int imageWidth, imageHeight;
			
			void * pHGE;
			
			// Users should not use copy constructors or assignment operators.
			BigTexture ( BigTexture & btl );
			void operator = ( BigTexture & btl );
			
	};
	
}

#endif
