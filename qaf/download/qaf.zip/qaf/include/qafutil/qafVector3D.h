/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_UTIL_VECTOR3D_H
#define QAF_UTIL_VECTOR3D_H

#include <math.h>


namespace qaf {
	
	/**
	 * Vector in the R3 space, with (x, y, z) components.
	 * 
	 * This class overloads several operators to make evaluating formulae
	 * easier.
	 * 
	 * The multiplication operator (<tt>*</tt>) can be used with a
	 * scalar argument (i.e., a <tt>float</tt> value), or with another vector,
	 * in which case it stands for the dot product.
	 * 
	 * The modulus operator (<tt>%%</tt>) represents a cross product.
	 */ 
	class Vector3D {
	public:
		float x, y, z;
		
		Vector3D () {}
		Vector3D ( float _x, float _y, float _z ) : x(_x), y(_y), z(_z) {}
		
		inline Vector3D & operator =  ( const Vector3D & otherVector3D );
		
		inline float      length      () const;
		
		inline Vector3D   unit        () const;
		inline void       normalize   ();
		
		inline Vector3D   project     ( const Vector3D & onto ) const;
		
		inline Vector3D   reflect     ( const Vector3D & around ) const;
		
		inline Vector3D   rotate      ( const Vector3D & axis, float angle ) const;
		
		inline Vector3D & operator += ( const Vector3D & otherVector3D );
		inline Vector3D & operator -= ( const Vector3D & otherVector3D );
		inline Vector3D   operator +  ( const Vector3D & otherVector3D ) const;
		inline Vector3D   operator -  ( const Vector3D & otherVector3D ) const;
		inline Vector3D   operator -  () const;
		
		inline Vector3D & operator *= ( float s );
		inline Vector3D   operator *  ( float s ) const;
		inline Vector3D & operator /= ( float s );
		inline Vector3D   operator /  ( float s ) const;
		
		/** Dot product. */
		inline float      operator *  ( const Vector3D & otherVector3D ) const;
		
		/// @{
		/** Cross product. */
		inline Vector3D & operator %= ( const Vector3D & otherVector3D );
		inline Vector3D   operator %  ( const Vector3D & otherVector3D ) const;
		/// @}
		
	};

	inline Vector3D  operator *  ( float s, const Vector3D & t );
	
	
	
	Vector3D & Vector3D::operator = ( const Vector3D & otherVector3D ) {
		x = otherVector3D.x;
		y = otherVector3D.y;
		z = otherVector3D.z;
		
		return *this;
	}


	float Vector3D::length () const {
		return sqrtf( x * x + y * y + z * z );
	}


	Vector3D Vector3D::unit () const {
		float abs = length();
		if ( abs <= 1e-10 ) // Prevent division by zero
			return (*this);
		else
			return Vector3D(
				x / abs,
				y / abs,
				z / abs );
	}

	void Vector3D::normalize () {
		float abs = length();
		if ( abs <= 1e-10 ) // Prevent division by zero
			return;
		else {
			x /= abs;
			y /= abs;
			z /= abs;
		}
	}


	Vector3D Vector3D::project ( const Vector3D & onto ) const {
		// Prevent division by zero:
		if ( fabs(onto * onto) < 1e-10 ) 
			return Vector3D( 0, 0, 0 );
		
		// Dot product of this with the other, divided by the dot product of the
		// other with itself:
		float newScale = ((*this) * onto)/(onto * onto);

		// Resize the other vector, and assign to this:
		return Vector3D (
			onto.x * newScale,
			onto.y * newScale,
			onto.z * newScale );
	}
	
	
	Vector3D Vector3D::reflect ( const Vector3D & around ) const {
		// Projection of this vector onto the "mirror":
		Vector3D vProj = this->project( around );
		
		// Distance to the "mirror":
		Vector3D vIncrH ( vProj.x - x, vProj.y - y, vProj.z - z );
		
		// Result:
		return Vector3D (
			vProj.x + vIncrH.x,
			vProj.y + vIncrH.y,
			vProj.z + vIncrH.z );
	}
	
	
	Vector3D Vector3D::rotate ( const Vector3D & axis, float angle ) const {
		float axisLength = axis.length();
		
		if ( axisLength >= 1e-10 ) {
			float cos_a = cosf( angle );
			float sin_a = sinf( angle );
			
			Vector3D e = axis / axisLength;
			
			return Vector3D (
					(cos_a + (1 - cos_a)*e.x*e.x)     * x  +  (e.x*e.y*(1 - cos_a) - e.z*sin_a) * y  +  (e.z*e.x*(1 - cos_a) + e.y*sin_a) * z,
					(e.x*e.y*(1 - cos_a) + e.z*sin_a) * x  +  (cos_a + (1 - cos_a)*e.y*e.y)     * y  +  (e.y*e.z*(1 - cos_a) - e.x*sin_a) * z,
					(e.x*e.z*(1 - cos_a) - e.y*sin_a) * x  +  (e.y*e.z*(1 - cos_a) + e.x*sin_a) * y  +  (cos_a + (1 - cos_a)*e.z*e.z)     * z );
		}
		else {
			// Axis too small to rotate.
			return (*this);
		}
	}
	
	
	Vector3D & Vector3D::operator += ( const Vector3D & otherVector3D ) {
		x += otherVector3D.x;
		y += otherVector3D.y;
		z += otherVector3D.z;
		
		return *this;
	}

	Vector3D & Vector3D::operator -= ( const Vector3D & otherVector3D ) {
		x -= otherVector3D.x;
		y -= otherVector3D.y;
		z -= otherVector3D.z;
		
		return *this;
	}

	Vector3D Vector3D::operator + ( const Vector3D & otherVector3D ) const {
		return Vector3D (
			x + otherVector3D.x,
			y + otherVector3D.y,
			z + otherVector3D.z );
	}

	Vector3D Vector3D::operator - ( const Vector3D & otherVector3D ) const {
		return Vector3D (
			x - otherVector3D.x,
			y - otherVector3D.y,
			z - otherVector3D.z );
	}

	Vector3D Vector3D::operator - () const {
		return Vector3D (
			-x,
			-y,
			-z);
	}


	Vector3D & Vector3D::operator *= ( float s ) {
		x *= s;
		y *= s;
		z *= s;
		
		return *this;
	}

	Vector3D Vector3D::operator * ( float s ) const {
		return Vector3D (
			x * s,
			y * s,
			z * s );
	}

	Vector3D operator *  ( float s, const Vector3D & t ) {
		return Vector3D (
			t.x * s,
			t.y * s,
			t.z * s );
	}

	Vector3D & Vector3D::operator /= ( float s ) {
		x /= s;
		y /= s;
		z /= s;
		
		return *this;
	}

	Vector3D Vector3D::operator / ( float s ) const {
		return Vector3D (
			x / s,
			y / s,
			z / s );
	}


	float Vector3D::operator * ( const Vector3D & otherVector3D ) const {
		return x * otherVector3D.x + y * otherVector3D.y + z * otherVector3D.z;
	}


	Vector3D & Vector3D::operator %= ( const Vector3D & otherVector3D ) {
		x = y * otherVector3D.z - z * otherVector3D.y;
		y = z * otherVector3D.x - x * otherVector3D.z;
		z = x * otherVector3D.y - y * otherVector3D.x;
		
		return *this;
	}

	Vector3D Vector3D::operator % ( const Vector3D & otherVector3D ) const {
		return Vector3D (
			y * otherVector3D.z - z * otherVector3D.y,
			z * otherVector3D.x - x * otherVector3D.z,
			x * otherVector3D.y - y * otherVector3D.x );
	}
	
	
}


#endif
