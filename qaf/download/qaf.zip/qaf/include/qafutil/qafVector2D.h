/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_UTIL_VECTOR2D_H
#define QAF_UTIL_VECTOR2D_H

#include <math.h>

namespace qaf {
	
	/**
	 * Vector in the R2 space, with (x, y) components.
	 * 
	 * This class overloads several operators to make evaluating formulae
	 * easier.
	 * 
	 * The multiplication operator (<tt>*</tt>) can be used with a
	 * scalar argument (i.e., a <tt>float</tt> value), or with another vector,
	 * in which case it stands for the dot product.
	 */ 
	class Vector2D {
	public:
		float x, y;
		
		Vector2D () : x(0), y(0) {}
		Vector2D ( float _x, float _y ) : x(_x),  y(_y) {}
		
		inline Vector2D & operator =  ( const Vector2D & otherVector2D );
		
		inline float      length      () const;
		
		inline Vector2D   unit        () const;
		inline void       normalize   ();
		
		inline Vector2D   project     ( const Vector2D & onto ) const;
		
		inline Vector2D   reflect     ( const Vector2D & around ) const;
		
		inline Vector2D   rotate      ( float radians ) const;
		
		inline Vector2D & operator += ( const Vector2D & otherVector2D );
		inline Vector2D & operator -= ( const Vector2D & otherVector2D );
		inline Vector2D   operator +  ( const Vector2D & otherVector2D ) const;
		inline Vector2D   operator -  ( const Vector2D & otherVector2D ) const;
		inline Vector2D   operator -  () const;
		
		inline Vector2D & operator *= ( float s );
		inline Vector2D   operator *  ( float s ) const;
		inline Vector2D & operator /= ( float s );
		inline Vector2D   operator /  ( float s ) const;
		
		/** Dot product. */
		inline float      operator *  ( const Vector2D & otherVector2D ) const;
		
		
	};
	
	inline Vector2D  operator *  ( float s, const Vector2D & t );
	
	
	
	Vector2D & Vector2D::operator = ( const Vector2D & otherVector2D ) {
		x = otherVector2D.x;
		y = otherVector2D.y;
		
		return *this;
	}

	float Vector2D::length () const {
		return sqrtf( x * x + y * y );
	}


	Vector2D Vector2D::unit () const {
		float abs = length();
		if ( abs <= 1e-10 ) // Prevent division by zero
			return (*this);
		else
			return Vector2D(
				x / abs,
				y / abs );
	}

	void Vector2D::normalize () {
		float abs = length();
		if ( abs <= 1e-10 ) // Prevent division by zero
			return;
		else {
			x /= abs;
			y /= abs;
		}
	}


	Vector2D Vector2D::project ( const Vector2D & onto ) const {
		// Prevent division by zero:
		if ( fabs(onto * onto) < 1e-10 ) 
			return Vector2D( 0, 0 );

		// Dot product of this with the other, divided by the dot product of the
		// other with itself:
		float newScale = ((*this) * onto)/(onto * onto);

		// Resize the other vector, and assign to this:
		return Vector2D (
			onto.x * newScale,
			onto.y * newScale );
	}


	Vector2D Vector2D::reflect ( const Vector2D & around ) const {
		// Projection of this vector onto the "mirror":
		Vector2D vProj = this->project( around );

		// Distance to the "mirror":
		Vector2D vIncrH ( vProj.x - x, vProj.y - y );

		// Result:
		return Vector2D (
			vProj.x + vIncrH.x,
			vProj.y + vIncrH.y );
	}


	Vector2D Vector2D::rotate ( float radians ) const {
		float cosR  = cosf( radians );
		float cosMR = cosf( -radians );
		float sinMR = sinf( -radians );
		
		return Vector2D (
			x * cosMR + y * sinMR,
			y * cosR - x * sinMR );
	}


	Vector2D & Vector2D::operator += ( const Vector2D & otherVector2D ) {
		x += otherVector2D.x;
		y += otherVector2D.y;
		
		return *this;
	}

	Vector2D & Vector2D::operator -= ( const Vector2D & otherVector2D ) {
		x -= otherVector2D.x;
		y -= otherVector2D.y;
		
		return *this;
	}

	Vector2D Vector2D::operator + ( const Vector2D & otherVector2D ) const {
		return Vector2D (
			x + otherVector2D.x,
			y + otherVector2D.y );
	}

	Vector2D Vector2D::operator - ( const Vector2D & otherVector2D ) const {
		return Vector2D (
			x - otherVector2D.x,
			y - otherVector2D.y );
	}

	Vector2D Vector2D::operator - () const {
		return Vector2D ( -x, -y );
	}


	Vector2D & Vector2D::operator *= ( float s ) {
		x *= s;
		y *= s;
		
		return *this;
	}

	Vector2D Vector2D::operator * ( float s ) const {
		return Vector2D (
			x * s,
			y * s );
	}

	Vector2D operator *  ( float s, const Vector2D & t ) {
		return Vector2D (
			t.x * s,
			t.y * s );
	}

	Vector2D & Vector2D::operator /= ( float s ) {
		x /= s;
		y /= s;
		
		return *this;
	}

	Vector2D Vector2D::operator / ( float s ) const {
		return Vector2D (
			x / s,
			y / s );
	}


	float Vector2D::operator * ( const Vector2D & otherVector2D ) const {
		return x * otherVector2D.x + y * otherVector2D.y;
	}
	
}

#endif
