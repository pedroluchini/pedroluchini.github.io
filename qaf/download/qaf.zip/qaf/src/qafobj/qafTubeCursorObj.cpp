/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafobj/qafTubeCursorObj.h>

#include <hge.h>
#include <qafEnvironment.h>

using namespace qaf;

#define hge ((HGE *) pHGE)



	
TubeCursorObj::TubeCursorObj ( float _x, float _y ) {
	pHGE = hgeCreate( HGE_VERSION );

	pos.x = _x;
	pos.y = _y;
	
	vel.x = vel.y = 0;
	angle = 0;
	length = 10;
}




TubeCursorObj::~TubeCursorObj () {
	hge->Release();
}



void TubeCursorObj::update ( int objLayer, float dt ) {
	// Move the yellow cursor (aim) to the mouse position:
	hge->Input_GetMousePos( &aim.x, &aim.y );
	aim.x += Environment::getScrollingX();
	aim.y += Environment::getScrollingY();
	
	// Move the blue cursor (pos) according to the key states:
	if ( hge->Input_GetKeyState( HGEK_LEFT ) )
		vel.x -= 900 * dt;
	else if ( hge->Input_GetKeyState( HGEK_RIGHT ) )
		vel.x += 900 * dt;
	else if ( vel.x > 900 * dt )
		vel.x -= 900 * dt;
	else if ( vel.x < -900 * dt )
		vel.x += 900 * dt;
	else
		vel.x = 0;
	
	if ( hge->Input_GetKeyState( HGEK_UP ) )
		vel.y -= 900 * dt;
	else if ( hge->Input_GetKeyState( HGEK_DOWN ) )
		vel.y += 900 * dt;
	else if ( vel.y > 900 * dt )
		vel.y -= 900 * dt;
	else if ( vel.y < -900 * dt )
		vel.y += 900 * dt;
	else
		vel.y = 0;
	
	// Limit speed:
	if ( vel.x > 200 )
		vel.x = 200;
	else if ( vel.x < -200 )
		vel.x = -200;
	
	if ( vel.y > 200 )
		vel.y = 200;
	else if ( vel.y < -200 )
		vel.y = -200;
	
	// Rotate the segment (angle) according to the key states:
	if ( hge->Input_GetKeyState( HGEK_PGUP ) )
		angle += M_PI / 180 * 30 * dt;
	if ( hge->Input_GetKeyState( HGEK_PGDN ) )
		angle -= M_PI / 180 * 30 * dt;
	
	// Resize the segment (length) according to the key states:
	if ( hge->Input_GetKeyState( HGEK_ADD ) )
		length += 30 * dt;
	if ( hge->Input_GetKeyState( HGEK_SUBTRACT ) )
		if ( length > 0 )
			length -= 30 * dt;
	
	// Move the cursor:
	pos += vel * dt;
	
	// Center screen on the blue cursor:
	Environment::centerScrollingPoint( (int) pos.x, (int) pos.y );
	
}




void TubeCursorObj::render ( int objLayer, int scrollX, int scrollY ) {
	float dx = length * cosf( angle ), dy = length * sinf( angle );
	Vector2D delta = aim - pos;
	
	// Segment extremities:
	Vector2D blueCursor1 = Vector2D( pos.x + dx, pos.y + dy );
	Vector2D blueCursor2 = Vector2D( pos.x - dx, pos.y - dy );
	
	Vector2D yellowCursor1 = blueCursor1 + delta;
	Vector2D yellowCursor2 = blueCursor2 + delta;
	
	// Test for segment collision from blue->yellow
	Container<Vector2D> contacts, normals;
	Vector2D validDisplacement(0, 0);
	
	if ( Environment::getLoadedRoom()->segmentCollision(
			blueCursor1.x, blueCursor1.y,
			blueCursor2.x, blueCursor2.y,
			delta.x, delta.y,
			true,
			&contacts, &normals, &validDisplacement ) ) {
		
		// Replace the yellow segment so its displacement is valid:
		yellowCursor1 = blueCursor1 + validDisplacement;
		yellowCursor2 = blueCursor2 + validDisplacement;
		
	}
	
	
	// Blue segment:
	hge->Gfx_RenderLine (
		blueCursor1.x - scrollX, blueCursor1.y - scrollY,
		blueCursor2.x - scrollX, blueCursor2.y - scrollY,
		0xFF00FFFF );
	
	// Yellow segment:
	hge->Gfx_RenderLine (
		yellowCursor1.x - scrollX, yellowCursor1.y - scrollY,
		yellowCursor2.x - scrollX, yellowCursor2.y - scrollY,
		0xFFFFFF00 );
	
	hge->Gfx_RenderLine (
		blueCursor1.x   - scrollX, blueCursor1.y   - scrollY,
		yellowCursor1.x - scrollX, yellowCursor1.y - scrollY,
		0xFFFFFF00 );
	hge->Gfx_RenderLine (
		blueCursor2.x   - scrollX, blueCursor2.y   - scrollY,
		yellowCursor2.x - scrollX, yellowCursor2.y - scrollY,
		0xFFFFFF00 );
	
	// Draw red normals at contact points:
	for ( int pInx = 0; pInx < contacts.getCount(); pInx++ ) {
		Vector2D normal = normals[pInx], contact = contacts[pInx];
		
		// The collision method returns normals as vectors. Makes them 10
		// pixels long!
		normal *= 10;
		
		hge->Gfx_RenderLine (
			contact.x            - scrollX, contact.y            - scrollY,
			contact.x + normal.x - scrollX, contact.y + normal.y - scrollY,
			0xFFFF0000 );
	}
	
	
	// Blue cursor:
	// Draw two lines in a cross shape, 10 pixels tall and 10 pixels wide.
	hge->Gfx_RenderLine (
		pos.x - scrollX - 5, pos.y - scrollY,
		pos.x - scrollX + 5, pos.y - scrollY,
		0xFF00FFFF );
	hge->Gfx_RenderLine (
		pos.x - scrollX, pos.y - scrollY - 5,
		pos.x - scrollX, pos.y - scrollY + 5,
		0xFF00FFFF );
	
	// Yellow cursor:
	// Draw two lines in a cross shape, 4 pixels tall and 4 pixels wide.
	hge->Gfx_RenderLine (
		aim.x - scrollX - 2, aim.y - scrollY,
		aim.x - scrollX + 2, aim.y - scrollY,
		0xFFFFFF00 );
	hge->Gfx_RenderLine (
		aim.x - scrollX, aim.y - scrollY - 2,
		aim.x - scrollX, aim.y - scrollY + 2,
		0xFFFFFF00 );
	
}



