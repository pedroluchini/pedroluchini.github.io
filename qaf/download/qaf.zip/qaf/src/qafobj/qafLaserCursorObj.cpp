/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafobj/qafLaserCursorObj.h>

#include <hge.h>
#include <qafEnvironment.h>

using namespace qaf;

#define hge ((HGE *) pHGE)




LaserCursorObj::LaserCursorObj ( float _x, float _y ) {
	pHGE = hgeCreate( HGE_VERSION );
	
	pos.x = _x;
	pos.y = _y;
	
	vel.x = vel.y = 0;
}




LaserCursorObj::~LaserCursorObj () {
	hge->Release();
}



void LaserCursorObj::update ( int objLayer, float dt ) {
	// Move the yellow cursor (aim) to the mouse position:
	hge->Input_GetMousePos( &aim.x, &aim.y );
	aim.x += Environment::getScrollingX();
	aim.y += Environment::getScrollingY();
	
	// Move the blue cursor (pos) according to the key states:
	if ( hge->Input_GetKeyState( HGEK_LEFT ) )
		vel.x -= 900 * dt;
	else if ( hge->Input_GetKeyState( HGEK_RIGHT ) )
		vel.x += 900 * dt;
	else if ( vel.x > 900 * dt )
		vel.x -= 900 * dt;
	else if ( vel.x < -900 * dt )
		vel.x += 900 * dt;
	else
		vel.x = 0;
	
	if ( hge->Input_GetKeyState( HGEK_UP ) )
		vel.y -= 900 * dt;
	else if ( hge->Input_GetKeyState( HGEK_DOWN ) )
		vel.y += 900 * dt;
	else if ( vel.y > 900 * dt )
		vel.y -= 900 * dt;
	else if ( vel.y < -900 * dt )
		vel.y += 900 * dt;
	else
		vel.y = 0;
	
	// Limit speed:
	if ( vel.x > 200 )
		vel.x = 200;
	else if ( vel.x < -200 )
		vel.x = -200;
	
	if ( vel.y > 200 )
		vel.y = 200;
	else if ( vel.y < -200 )
		vel.y = -200;
	
	// Move the cursor:
	pos += vel * dt;
	
	// Center screen on the blue cursor:
	Environment::centerScrollingPoint( (int) pos.x, (int) pos.y );
	
}



void LaserCursorObj::render ( int objLayer, int scrollX, int scrollY ) {
	// Blue cursor:
	// Draw two lines in a cross shape, 10 pixels tall and 10 pixels wide.
	hge->Gfx_RenderLine (
		pos.x - 5 - scrollX, pos.y - scrollY,
		pos.x + 5 - scrollX, pos.y - scrollY,
		0xFF00FFFF );
	hge->Gfx_RenderLine (
		pos.x - scrollX, pos.y - 5 - scrollY,
		pos.x - scrollX, pos.y + 5 - scrollY,
		0xFF00FFFF );
	
	// Yellow cursor:
	// Draw two lines in a cross shape, 4 pixels tall and 4 pixels wide.
	hge->Gfx_RenderLine (
		aim.x - scrollX - 2, aim.y - scrollY,
		aim.x - scrollX + 2, aim.y - scrollY,
		0xFFFFFF00 );
	hge->Gfx_RenderLine (
		aim.x - scrollX, aim.y - scrollY - 2,
		aim.x - scrollX, aim.y - scrollY + 2,
		0xFFFFFF00 );
	
	// Laser touched the obstacle layer?
	Vector2D contact, normal;
	
	bool collide = Environment::getLoadedRoom()->pointCollision(
		pos.x, pos.y, aim.x, aim.y, true,
		&contact, &normal );
	
	if ( collide ) {
		// Draw yellow laser from the blue cursor to the contact point:
		hge->Gfx_RenderLine (
			pos.x     - scrollX, pos.y     - scrollY,
			contact.x - scrollX, contact.y - scrollY,
			0xFFFFFF00 );
		
		// Draw the normal as a red line, 10 pixels long:
		Vector2D normalPoint = contact + normal * 10;
		
		hge->Gfx_RenderLine (
			contact.x     - scrollX, contact.y     - scrollY,
			normalPoint.x - scrollX, normalPoint.y - scrollY,
			0xFFFF0000 );
	}
	else {
		// Draw yellow laser from the blue cursor to the yellow cursor:
		hge->Gfx_RenderLine (
			pos.x - scrollX, pos.y - scrollY,
			aim.x - scrollX, aim.y - scrollY,
			0xFFFFFF00 );
	}
}
