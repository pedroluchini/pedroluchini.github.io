/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafutil/qafGeom.h>

#include <hge.h>

using namespace qaf;



void Geom::renderPolygon ( Container<Vector2D> & points, float translateX, float translateY, unsigned long color ) {
	// Get an HGE interface:
	HGE * hge = hgeCreate( HGE_VERSION );
	
	// Iterate over all points:
	for ( int i = 0, j = 1; i < points.getCount(); i++, j++ ) {
		// "j" index has passed the container's limits?
		if ( j >= points.getCount() )
			j = 0;
		
		hge->Gfx_RenderLine(
			points[i].x + translateX, // x1
			points[i].y + translateY, // y1
			points[j].x + translateX, // x2
			points[j].y + translateY, // y2
			color );                  // color
	}
	
	// Release HGE interface:
	hge->Release();
	
} // End of method: Geom::renderPolygon
