/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafUtil/qafBigTexture.h>


#include <d3d8.h>
#include <d3dx8tex.h>
#include <dxerr8.h>
#include <hge.h>
#include <math.h>
#include <qafUtil/qafMatrix.h>

using namespace qaf;


#define hge ((HGE *) pHGE)

#ifndef MAX
	#define MAX(a, b)  ((a) > (b) ? (a) : (b))
	#define MIN(a, b)  ((a) < (b) ? (a) : (b))
#endif




BigTexture::BigTexture ( const char * sourceImage )
 : subTextures(NULL),
   rows(0),
   cols(0),
   imageWidth(0),
   imageHeight(0) {
	// Temp. variable declarations here:
	HTEXTURE tmpTex = NULL;
	LPDIRECT3DSURFACE8 imgSurface = NULL;
	LPDIRECT3DDEVICE8  pD3DDevice = NULL;
	HRESULT hres;
	
	// Get an HGE interface:
	pHGE = hgeCreate( HGE_VERSION );
	
	// Load the file's data:
	DWORD imgFileSize = 0;
	void * imgFile = hge->Resource_Load( (char *) sourceImage, &imgFileSize );
	
	// Failed?
	if ( imgFile == NULL )
		goto BT_CTOR_FAILED;
	
	// 
	// Load the image into a surface.
	// 
	// I'm going to need a Direct3D device for that.
	// Using Haaf's D3D hack...
	tmpTex = hge->Texture_Create(2,2); 
	hres = ((LPDIRECT3DTEXTURE8) tmpTex)->GetSurfaceLevel( 0, &imgSurface );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	hres = imgSurface->GetDevice( &pD3DDevice );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// Got the device!
	
	imgSurface->Release();
	imgSurface = NULL;
	hge->Texture_Free( tmpTex );
	tmpTex = NULL;
	
	// There. Now, I need to know the image size in order to create the surface
	// that will hold it...
	D3DXIMAGE_INFO imgInfo;
	hres = D3DXGetImageInfoFromFileInMemory( imgFile,     // LPCVOID pSrcData,
	                                         imgFileSize, // UINT SrcDataSize,
	                                         &imgInfo );  // D3DXIMAGE_INFO* pSrcInfo
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// Store image dimensions:
	imageWidth  = imgInfo.Width;
	imageHeight = imgInfo.Height;
	
	// Now, I can create my surface to hold the image:
	hres = pD3DDevice->CreateImageSurface( imageWidth,
	                                       imageHeight,
	                                       D3DFMT_A8R8G8B8,
	                                       &imgSurface );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// ...And load the image:
	hres = D3DXLoadSurfaceFromFileInMemory( imgSurface,       // LPDIRECT3DSURFACE8 pDestSurface,
	                                        NULL,             // CONST PALETTEENTRY* pDestPalette,
	                                        NULL,             // CONST RECT* pDestRect,
	                                        imgFile,          // LPCVOID pSrcData,
	                                        imgFileSize,      // UINT SrcData,
	                                        NULL,             // CONST RECT* pSrcRect,
	                                        D3DX_FILTER_NONE, // DWORD Filter,
	                                        0,                // D3DCOLOR ColorKey,
	                                        &imgInfo );       // D3DXIMAGE_INFO* pSrcInfo
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// The file is no longer needed.
	hge->Resource_Free( imgFile );
	imgFile = NULL;
	
	// Lock the surface so I can read its pixels:
	D3DLOCKED_RECT lockRect;
	hres = imgSurface->LockRect( &lockRect, NULL, D3DLOCK_READONLY );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// IMAGE LOADED!
	
	// For all I know right now, the image *could* fit in a single texture...
	rows = cols = 1;
	
	// Try and create it as a single texture.
	// This is just to test the video card's capabilities; I won't need the
	// created texture right now.
	tmpTex = hge->Texture_Create( imageWidth, imageHeight );
	
	int tmpTexWidth = hge->Texture_GetWidth( tmpTex );
	int tmpTexHeight = hge->Texture_GetHeight( tmpTex );
	hge->Texture_Free( tmpTex );
	
	// Image was too big for the video card?
	if ( tmpTexWidth < imageWidth )
		cols = (int) ceil( (float) imageWidth / tmpTexWidth );
	
	if ( tmpTexHeight < imageHeight )
		rows = (int) ceil( (float) imageHeight / tmpTexHeight );
	
	// Allocate the sub-texture matrix:
	subTextures = new SubTexture[rows * cols];
	
	// How many pixels were already transferred from the image to the
	// sub-textures:
	int pixelsX = 0, pixelsY = 0;
	
	for ( int i = 0; i < rows; i++ ) {
		for ( int j = 0; j < cols; j++ ) {
			
			// Create the sub-texture at position (i, j) in the matrix.
			// Try to create it so it will be able to store whatever's left in
			// the image:
			tmpTex = hge->Texture_Create( tmpTexWidth, tmpTexHeight );
			
			// Lock the texture so I can fill it with pixel data:
			DWORD * tmpTexData = hge->Texture_Lock( tmpTex, false );
			
			for ( int x = 0; x < tmpTexWidth; x++ ) {
				for ( int y = 0; y < tmpTexHeight; y++ ) {
					// Look up the pixel's components:
					// Out of image bounds?
					if ( pixelsY + y >= imageHeight || pixelsX + x >= imageWidth )
						tmpTexData[y * tmpTexWidth + x] = 0; // Use a transparent black -- doesn't matter
					else {
						// Row offset:
						DWORD * row = (DWORD *) ((unsigned char *) lockRect.pBits + lockRect.Pitch * (pixelsY + y));
						
						tmpTexData[y * tmpTexWidth + x] = row[pixelsX + x];
					}
				}
			}
			
			// This sub-texture is done.
			hge->Texture_Unlock( tmpTex );
			
			// Store it:
			subTextures[i * cols + j].tex    = tmpTex;
			subTextures[i * cols + j].width  = tmpTexWidth;
			subTextures[i * cols + j].height = tmpTexHeight;
			
			// Done with this texture:
			tmpTex = NULL;
			
			// Advance the amount of pixels read.
			pixelsX += tmpTexWidth;
			
			// This row finished?
			if ( pixelsX >= imageWidth ) {
				// Go to the beginning of the next row:
				pixelsX = 0;
				pixelsY += tmpTexHeight;
			}
		}
	}
	
	// Done!
	
	// Unlock the surface now:
	hres = imgSurface->UnlockRect(); // TODO: Is it possible to fail here?!
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
BT_CTOR_FAILED:
	// Clean up!
	if ( tmpTex ) {
		hge->Texture_Free( tmpTex );
		tmpTex = NULL;
	}
	
	if ( imgSurface ) {
		imgSurface->Release();
		imgSurface = NULL;
	}
	
	if ( pD3DDevice ) {
		pD3DDevice->Release();
		pD3DDevice = NULL;
	}
	
	if ( imgFile ) {
		hge->Resource_Free( imgFile );
		imgFile = NULL;
	}
	
	return;
	
} // End of method: BigTexture::BigTexture




BigTexture::~BigTexture () {
	// Release the sub-texture matrix:
	if ( subTextures ) {
		for ( int i = 0; i < rows; i++ )
			for ( int j = 0; j < cols; j++ )
				hge->Texture_Free( subTextures[i * cols + j].tex );
		
		delete[] subTextures;
	}
	
	// Release the HGE pointer:
	hge->Release();
	
} // End of method: BigTexture::~BigTexture




void BigTexture::renderRectangle ( int x0, int y0, int tx, int ty, int width, int height, unsigned long color, unsigned long blend ) const {
	// Width/height negative?
	if ( width <= 0 )
		width = imageWidth;
	
	if ( height <= 0 )
		height = imageHeight;
	
	// Clamp Bounds:
	{
		int xLeft = tx, xRight = tx + width;
		int yTop  = ty, yBott  = ty + height;
		
		if ( xLeft < 0 ) {
			x0 -= xLeft;
			xLeft = 0;
		}
		else if ( xLeft > imageWidth )
			return;
		
		if ( xRight > imageWidth )
			xRight = imageWidth;
		else if ( xRight < 0 )
			return;
		
		if ( yTop < 0 ) {
			y0 -= yTop;
			yTop = 0;
		}
		else if ( yTop > imageHeight )
			return;
		
		if ( yBott > imageHeight )
			yBott = imageHeight;
		else if ( yBott < 0 )
			return;
		
		// Recalculate...
		tx     = xLeft;
		ty     = yTop;
		width  = xRight - xLeft;
		height = yBott - yTop;
	}
	
	// Which sub-textures are covered by this rectangle?
	int iInit = ty / subTextures[0].height;
	int jInit = tx / subTextures[0].width;
	
	int iFinal = (ty + height - 1) / subTextures[0].height;
	int jFinal = (tx + width  - 1) / subTextures[0].width;
	
	// Check bounds:
//	if ( tx < 0 || tx + width  >= imageWidth  ||
//	     ty < 0 || ty + height >= imageHeight ||
//		 iInit  < 0 || iInit  >= rows ||
//	     iFinal < 0 || iFinal >= rows ||
//	     iInit > iFinal ||
//	     jInit < 0 || jInit   >= cols ||
//	     jFinal < 0 || jFinal >= cols ||
//	     jInit > jFinal )
//		return;
	
	// Draw several hgeQuads:
	int yTop   = y0;
	int yBott  = y0 + MIN( MIN( height, subTextures[0].height ), (subTextures[0].height - (ty % subTextures[0].height) <= 0 ? 0x7FFFFFFF : subTextures[0].height - (ty % subTextures[0].height)) );
	int tyTop  = ty;
	int tyBott = ty  + MIN( MIN( height, subTextures[0].height ), (subTextures[0].height - (ty % subTextures[0].height) <= 0 ? 0x7FFFFFFF : subTextures[0].height - (ty % subTextures[0].height)) );
	
	for ( int i = iInit; i <= iFinal; i++ ) {
		int xLeft   = x0;
		int xRight  = x0 + MIN( MIN( width, subTextures[0].width ), (subTextures[0].width - (tx % subTextures[0].width) <= 0 ? 0x7FFFFFFF : subTextures[0].width - (tx % subTextures[0].width)) );
		int txLeft  = tx;
		int txRight = tx  + MIN( MIN( width, subTextures[0].width ), (subTextures[0].width - (tx % subTextures[0].width) <= 0 ? 0x7FFFFFFF : subTextures[0].width - (tx % subTextures[0].width)) );
		
		for ( int j = jInit; j <= jFinal; j++ ) {
			static hgeQuad q = {
				{
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 },
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 },
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 },
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 }
				}, 
				NULL,
				0
			};
			
			// The matrix index for the current sub-texture:
			int mInx = i * cols + j;
			
			q.blend = blend;
			q.tex   = subTextures[mInx].tex;
			
			// Top left:
			q.v[0].x   = (float) xLeft;
			q.v[0].y   = (float) yTop;
			q.v[0].tx  = ((float) txLeft / subTextures[mInx].width );
			q.v[0].ty  = ((float) tyTop  / subTextures[mInx].height);
			q.v[0].col = color;
			
			// Top right:
			q.v[1].x   = (float) xRight;
			q.v[1].y   = (float) yTop;
			q.v[1].tx  = ((float) txRight / subTextures[mInx].width );
			q.v[1].ty  = ((float) tyTop   / subTextures[mInx].height);
			q.v[1].col = color;
			
			// Bott right:
			q.v[2].x   = (float) xRight;
			q.v[2].y   = (float) yBott;
			q.v[2].tx  = ((float) txRight / subTextures[mInx].width );
			q.v[2].ty  = ((float) tyBott  / subTextures[mInx].height);
			q.v[2].col = color;
			
			// Bott left:
			q.v[3].x   = (float) xLeft;
			q.v[3].y   = (float) yBott;
			q.v[3].tx  = ((float) txLeft / subTextures[mInx].width );
			q.v[3].ty  = ((float) tyBott / subTextures[mInx].height);
			q.v[3].col = color;
			
			// Render it!
			hge->Gfx_RenderQuad( &q );
			
			// Next sub-texture (to the right):
			txLeft  = txRight;
			txRight += MIN( x0 + width - xRight, subTextures[0].width ); // This *must* come before the screen coordinates are updated!
			xLeft   = xRight;
			xRight  += MIN( x0 + width - xRight, subTextures[0].width );
		}
		
		// Next sub-texture (to the bottom):
		tyTop  = tyBott;
		tyBott += MIN( y0 + height - yBott, subTextures[0].height ); // This *must* come before the screen coordinates are updated!
		yTop   = yBott;
		yBott  += MIN( y0 + height - yBott, subTextures[0].height );
	}
	
} // End of method: BigTexture::renderRectangle
