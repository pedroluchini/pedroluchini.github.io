/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafGameObj.h>

using namespace qaf;


void GameObj::initialize () {}
void GameObj::update     ( int objLayer, float dt ) {}
void GameObj::render     ( int objLayer, int scrollX, int scrollY ) {}
bool GameObj::isVolatile () { return true; }
CollisionStruct * GameObj::getCollisionStruct () { return NULL; }
