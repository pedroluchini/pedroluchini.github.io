/* 
** Qaf Framework 1.0
** October 2005
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafCollisionStruct.h>

#include <qafDef.h>
#include <qafutil/qafGeom.h>

using namespace qaf;


///////////////////////////////////////////////////////////////////////////////
// 
// BOX COLLISION STUCTURE:
// 
///////////////////////////////////////////////////////////////////////////////

CollisionStruct::Box::Box ( float _x, float _y, float _w, float _h ) {
	x = _x;
	y = _y;
	w = _w;
	h = _h;
	
	// Create initial polygon points:
	poly.add( Vector2D( x,     y     ) );
	poly.add( Vector2D( x + w, y     ) );
	poly.add( Vector2D( x + w, y     ) );
	poly.add( Vector2D( x,     y + h ) );
}




CollisionStruct::Box::Box () {
	x = 0;
	y = 0;
	w = 0;
	h = 0;
	
	// Create initial polygon points:
	poly.add( Vector2D( x,     y     ) );
	poly.add( Vector2D( x + w, y     ) );
	poly.add( Vector2D( x + w, y     ) );
	poly.add( Vector2D( x,     y + h ) );
}




void CollisionStruct::Box::setX ( float _x ) {
	x = _x;
	
	updateHoriz();
}




void CollisionStruct::Box::setY ( float _y ) {
	y = _y;
	
	updateVert();
}




void CollisionStruct::Box::setWidth ( float _w ) {
	w = _w;
	
	updateHoriz();
}




void CollisionStruct::Box::setHeight ( float _h ) {
	h = _h;
	
	updateVert();
}




bool CollisionStruct::Box::collidesWith ( CollisionStruct * otherStruct ) {
	
	// What kind of struct is that?
	CollisionStruct::Box     * otherBox     = NULL;
	CollisionStruct::Polygon * otherPolygon = NULL;
	
	if ( (otherBox = dynamic_cast<CollisionStruct::Box*>( otherStruct )) ) {
		// Box with box... easiest of all:
		
		float top   = MIN( y, y + h );
		float bott  = MAX( y, y + h );
		float left  = MIN( x, x + w );
		float right = MAX( x, x + w );
		
		float otherTop   = MIN( otherBox->y, otherBox->y + otherBox->h );
		float otherBott  = MAX( otherBox->y, otherBox->y + otherBox->h );
		float otherLeft  = MIN( otherBox->x, otherBox->x + otherBox->w );
		float otherRight = MAX( otherBox->x, otherBox->x + otherBox->w );
		
		return !(right < otherLeft  ||
		         left  > otherRight ||
		         bott  < otherTop   ||
		         top   > otherBott);
	}
	else if ( (otherPolygon = dynamic_cast<CollisionStruct::Polygon*>( otherStruct )) ) {
		// Box with polygon... Let the polygon handle this:
		return otherPolygon->collidesWith( this );
	}
	else {
		// Unknown type...
		return false;
	}
	
}




void CollisionStruct::Box::render ( int scrollX, int scrollY, unsigned long color ) {
	// Ask the "Geom" module to render the polygon:
	Geom::renderPolygon(
		poly,
		(float) -scrollX,
		(float) -scrollY,
		color );
}




///////////////////////////////////////////////////////////////////////////////
// 
// POLYGON COLLISION STUCTURE:
// 
///////////////////////////////////////////////////////////////////////////////

CollisionStruct::Polygon::Polygon () {
	// Set translation to zero:
	pos.x = 0;
	pos.y = 0;
}




CollisionStruct::Polygon::Polygon ( Container<Vector2D> & _points )
: userPoints( _points ), realPoints( _points )
{
	// Set translation to zero:
	pos.x = 0;
	pos.y = 0;
}




void CollisionStruct::Polygon::render ( int scrollX, int scrollY, unsigned long color ) {
	// Ask the "Geom" module to render the polygon:
	Geom::renderPolygon(
		realPoints,
		(float) -scrollX,
		(float) -scrollY,
		color );
	
}




void CollisionStruct::Polygon::setPoints( Container<Vector2D> & points ) {
	// Copy all points to the userPoints container... and translate them for
	// the realPoints container.
	userPoints.removeAll();
	realPoints.removeAll();
	
	for ( int i = 0; i < points.getCount(); i++ ) {
		userPoints.add( points[i] );
		realPoints.add( points[i] + pos );
	}
}




void CollisionStruct::Polygon::setPosition ( float x, float y ) {
	// Set the position:
	pos.x = x;
	pos.y = y;
	
	// Update real points:
	realPoints.removeAll();
	for ( int i = 0; i < userPoints.getCount(); i++ ) {
		realPoints.add( userPoints[i] + pos );
	}
}




bool CollisionStruct::Polygon::collidesWith ( CollisionStruct * otherStruct ) {
	
	// What kind of struct is that?
	CollisionStruct::Box     * otherBox     = NULL;
	CollisionStruct::Polygon * otherPolygon = NULL;
	Container<Vector2D> * otherPoints;
	
	if ( (otherBox = dynamic_cast<CollisionStruct::Box*>( otherStruct )) ) {
		// Get the box's boundary points:
		otherPoints = &otherBox->poly;
	}
	else if ( (otherPolygon = dynamic_cast<CollisionStruct::Polygon*>( otherStruct )) ) {
		// Get the polygon's boundary points:
		otherPoints = &otherPolygon->realPoints;
	}
	else {
		// Unknown type...
		return false;
	}
	
	// Box with polygon or polygon with polygon:
	// Here's the strategy:
	// - For every point in the other polygon, test if it is contained in this
	//   polygon.
	// - If that fails: For every point in this polygon, test if it is
	//   contained in the other polygon.
	// - If that fails: For every two segments (one from each polygon), test if
	//   they intersect.
	for ( int otherInx = 0; otherInx < otherPoints->getCount(); otherInx++ )
		if ( Geom::insidePolygon( otherPoints->elem(otherInx), realPoints ) )
			// Collision!
			return true;
	
	for ( int thisInx = 0; thisInx < realPoints.getCount(); thisInx++ )
		if ( Geom::insidePolygon( realPoints[thisInx], *otherPoints ) )
			// Collision!
			return true;
	
	for ( thisInx = 0; thisInx < realPoints.getCount(); thisInx++ ) {
		for ( otherInx = 0; otherInx < otherPoints->getCount(); otherInx++ ) {
			int thisNext  = ((thisInx  + 1) >= realPoints.getCount()   ? 0 : (thisInx  + 1));
			int otherNext = ((otherInx + 1) >= otherPoints->getCount() ? 0 : (otherInx + 1));
			
			if ( Geom::segmentIntersection(
					realPoints[thisInx].x, realPoints[thisInx].y,
					realPoints[thisNext].x, realPoints[thisNext].y,
					otherPoints->elem(otherInx).x, otherPoints->elem(otherInx).y, 
					otherPoints->elem(otherNext).x, otherPoints->elem(otherNext).y,
					NULL ) )
				// Collision!
				return true;
		}
	}
	
	// No collision!
	return false;
	
}
