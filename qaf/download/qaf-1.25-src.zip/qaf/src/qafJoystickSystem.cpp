/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafJoystickSystem.h>

#include <dxerr8.h>
#include <hge.h>

using namespace qaf;

#define hge ((HGE *) pHGE)




static HRESULT hr;

///////////////////////////////////////////////////////////////////////////////
// 
// JOYSTICK:
//
///////////////////////////////////////////////////////////////////////////////

// Auxiliary method: Convert from Qaf's enum to DirectInput offset:
static DWORD objOffset ( JoystickObject obj ) {
	switch ( obj ) {
		case QAF_JOY_X_AXIS:
			return DIJOFS_X;
		case QAF_JOY_Y_AXIS:
			return DIJOFS_Y;
		case QAF_JOY_Z_AXIS:
			return DIJOFS_Z;
		case QAF_JOY_X_AXIS_ROTATION:
			return DIJOFS_RX;
		case QAF_JOY_Y_AXIS_ROTATION:
			return DIJOFS_RY;
		case QAF_JOY_Z_AXIS_ROTATION:
			return DIJOFS_RZ;
		case QAF_JOY_SLIDER_0:
			return DIJOFS_SLIDER(0);
		case QAF_JOY_SLIDER_1:
			return DIJOFS_SLIDER(1);
		case QAF_JOY_POV_0:
			return DIJOFS_POV(0);
		case QAF_JOY_POV_1:
			return DIJOFS_POV(1);
		case QAF_JOY_POV_2:
			return DIJOFS_POV(2);
		case QAF_JOY_POV_3:
			return DIJOFS_POV(3);
		default:
			// Is it a button?
			if ( QAF_JOY_ISBUTTON( obj ) )
				return DIJOFS_BUTTON( obj - QAF_JOY_BUTTON_0 );
			else
				return 0xFFFFFFFF;
	}
}


// Callback for enumerating axes and setting their properties:
// A structure to store the properties is needed, so I'll store it in the
// pContext parameter.
struct AxisParameters {
	Joystick * pJ;
	bool absolute;
	int minValue;
	int maxValue;
	float deadZone;
	float saturation;
	bool failed;
};

BOOL CALLBACK Joystick::enumAxesCallback ( const DIDEVICEOBJECTINSTANCE * pdidoi, void * pContext ) {
	// Retrieve parameters from the pContext:
	AxisParameters * ap = (AxisParameters *) pContext;
	
	// Set absolute/relative:
	DIPROPDWORD dwProp;
	dwProp.diph.dwSize       = sizeof(dwProp);
	dwProp.diph.dwHeaderSize = sizeof(dwProp.diph);
	dwProp.diph.dwHow        = DIPH_DEVICE;
	dwProp.diph.dwObj        = 0;
	
	dwProp.dwData            = (ap->absolute ? DIPROPAXISMODE_ABS : DIPROPAXISMODE_REL );
	if ( FAILED(hr = ap->pJ->pJoystick->SetProperty( DIPROP_AXISMODE, &dwProp.diph )) ) {
		HGE * pHGE = hgeCreate( HGE_VERSION );
		hge->System_Log( "Joystick::enumAxesCallback() --> Failed setting axis mode: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		hge->Release();
		
		ap->failed = true;
	}
	
	// Set range:
	DIPROPRANGE rangeProp;
	rangeProp.diph.dwSize       = sizeof(DIPROPRANGE);
	rangeProp.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	rangeProp.diph.dwHow        = DIPH_BYID;
	rangeProp.diph.dwObj        = pdidoi->dwType;
	
	rangeProp.lMax = ap->maxValue;
	rangeProp.lMin = ap->minValue;
	if ( FAILED(hr = ap->pJ->pJoystick->SetProperty( DIPROP_RANGE, &rangeProp.diph )) ) {
		HGE * pHGE = hgeCreate( HGE_VERSION );
		hge->System_Log( "Joystick::enumAxesCallback() --> Failed setting range: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		hge->Release();
		
		ap->failed = true;
	}
	
	
	// Set deadzone:
	dwProp.dwData = (DWORD) (10000 * ap->deadZone);
	if ( FAILED(hr = ap->pJ->pJoystick->SetProperty( DIPROP_DEADZONE, &dwProp.diph )) ) {
		HGE * pHGE = hgeCreate( HGE_VERSION );
		hge->System_Log( "Joystick::enumAxesCallback() --> Failed setting deadzone: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		hge->Release();
		
		ap->failed = true;
	}
	
	// Set saturation:
	dwProp.dwData = (DWORD) (10000 * ap->saturation);
	if ( FAILED(hr = ap->pJ->pJoystick->SetProperty( DIPROP_SATURATION, &dwProp.diph )) ) {
		HGE * pHGE = hgeCreate( HGE_VERSION );
		hge->System_Log( "Joystick::enumAxesCallback() --> Failed setting saturation: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		hge->Release();
		
		ap->failed = true;
	}
	
	return DIENUM_CONTINUE;
}




// Callback used to enumerate joystick axes that support force-feedback:
// A pointer to the Joystick object must be provided in the pContext parameter.
BOOL CALLBACK Joystick::enumFFAxesCallback ( const DIDEVICEOBJECTINSTANCE * pdidoi, void * pContext ) {
	// Add this axis to the list:
	if ( pdidoi->dwFlags & DIDOI_FFACTUATOR ) {
		((Joystick *) pContext)->effectAxesOfs.add( pdidoi->dwOfs );
	}
	
	return DIENUM_CONTINUE;
}



			
// A callback for enumerating available force-feedback effect.
// A pointer to the Joystick object must be provided in the pContext parameter.
BOOL CALLBACK Joystick::enumEffectsCallback ( LPCDIEFFECTINFO pei, void * pContext ) {
	// Add this effect to the list:
	((Joystick *) pContext)->effectGUIDs.add( pei->guid );
	return DIENUM_CONTINUE;
}




Joystick::Joystick ( LPDIRECTINPUTDEVICE8 _pJoystick, HWND _hWindow ) {
	pHGE = hgeCreate( HGE_VERSION );
	
	pJoystick = _pJoystick;
	resetStates();
	
	for ( int i = 0; i < QAF_JOY_MAX_OBJECTS; i++ )
		objNames[i] = NULL;
	
	if ( !setHWND( _hWindow ) ) {
		initialized = false;
		return;
	}
	
	// Start out initialized... If anything goes wrong, I'll set this to false.
	initialized = true;
	
	try {
		// Set the joystick's data format:
		if ( FAILED(hr = pJoystick->SetDataFormat( &c_dfDIJoystick2 )) ) {
			hge->System_Log( "Joystick::Joystick() --> Failed setting dataformat: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			initialized = false;
			return;
		}
		
		// Set default parameters for the joystick's axes:
		if ( !setAxesParameters( true, -1000, +1000, 0.1f, 1.0f ) ) {
			initialized = false;
			return;
		}
		
		// Get the device name:
		DIDEVICEINSTANCE didi;
		didi.dwSize = sizeof(didi);
		if ( FAILED(hr = pJoystick->GetDeviceInfo( &didi )) ) {
			initialized = false;
			return;
		}
		strcpy( deviceName, didi.tszInstanceName );
		
		// Obtain available force-feedback effects:
		if ( FAILED(hr = pJoystick->EnumEffects( enumEffectsCallback, (void *) this, DIEFT_PERIODIC )) ) {
			hge->System_Log( "Joystick::Joystick() --> Failed enumerating force-feedback effects: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			initialized = false;
			return;
		}
		
		// Obtain available force-feedback axes:
		if ( FAILED(hr = pJoystick->EnumObjects( enumFFAxesCallback, (void *) this, DIDFT_AXIS | DIDFT_FFACTUATOR )) ) {
			hge->System_Log( "Joystick::Joystick() --> Failed enumerating force-feedback actuators: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			initialized = false;
			return;
		}
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::Joystick() --> Unkown error during joystick setup. (%s, line %d)", __FILE__, __LINE__ );
		initialized = false;
		return;
	}
	
}



Joystick::~Joystick () {
	// Release created effects:
	for ( int effectInx = 0; effectInx < createdEffects.getCount(); effectInx++ )
		if ( createdEffects[effectInx] != NULL )
			deleteEffect( effectInx );
	
	try{
		if ( FAILED(hr = pJoystick->Unacquire()) ) {
			hge->System_Log( "Joystick::~Joystick() --> Could not unacquire the device: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		}
		
		if ( FAILED(hr = pJoystick->Release()) ) {
			hge->System_Log( "Joystick::~Joystick() --> Could not release the device: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		}
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::~Joystick() --> Unknown error during joystick shutdown.(%s, line %d)", __FILE__, __LINE__ );
	}
	
	// Free object name buffers:
	for ( int i = 0; i < QAF_JOY_MAX_OBJECTS; i++ )
		if ( objNames[i] )
			delete[] objNames[i];
	
	// Release HGE pointer:
	hge->Release();
}




bool Joystick::isInitialized () {
	return initialized;
}




bool Joystick::poll () {
	try {
		// Poll the joystick to read its data:
		if ( FAILED(hr = pJoystick->Poll()) ) {
			// Joystick input lost! Try to re-acquire it:
			hr = pJoystick->Acquire();
			
			// Prevent infinite loop:
			int count = 100;
			while ( hr == DIERR_INPUTLOST && count > 0 ) {
				hr = pJoystick->Acquire();
				count--;
			}
			
			if ( count == 0 ) {
				// Failed to read joystick data:
				hge->System_Log( "Joystick::poll() --> Could not acquire the device: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
				resetStates();
				return false;
			}
		}
		
		// Read joystick state:
		if ( FAILED(hr = pJoystick->GetDeviceState( sizeof(DIJOYSTATE2), &state )) ) {
			hge->System_Log( "Joystick::poll() --> Failed to read device state: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return false;
		}
		
		// Success!
		return true;
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::poll() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
		return false;
	}
}




int Joystick::getObjectState ( JoystickObject obj ) {
	// Start out with the simple inputs:
	switch ( obj ) {
		case QAF_JOY_X_AXIS:
			return state.lX;
			
		case QAF_JOY_Y_AXIS:
			return state.lY;
			
		case QAF_JOY_Z_AXIS:
			return state.lZ;
			
		case QAF_JOY_X_AXIS_ROTATION:
			return state.lRx;
			
		case QAF_JOY_Y_AXIS_ROTATION:
			return state.lRy;
			
		case QAF_JOY_Z_AXIS_ROTATION:
			return state.lRz;
			
		case QAF_JOY_SLIDER_0:
			return state.rglSlider[0];
			
		case QAF_JOY_SLIDER_1:
			return state.rglSlider[1];
			
		case QAF_JOY_POV_0:
			// POV centered?
			if ( (LOWORD(state.rgdwPOV[0]) == 0xFFFF) )
				return -1;
			else
				return state.rgdwPOV[0];
			
		case QAF_JOY_POV_1:
			// POV centered?
			if ( (LOWORD(state.rgdwPOV[1]) == 0xFFFF) )
				return -1;
			else
				return state.rgdwPOV[1];
			
		case QAF_JOY_POV_2:
			// POV centered?
			if ( (LOWORD(state.rgdwPOV[2]) == 0xFFFF) )
				return -1;
			else
				return state.rgdwPOV[2];
			
		case QAF_JOY_POV_3:
			// POV centered?
			if ( (LOWORD(state.rgdwPOV[3]) == 0xFFFF) )
				return -1;
			else
				return state.rgdwPOV[3];
	}
	
	// None of the above... Is it a button?
	if ( QAF_JOY_ISBUTTON( obj) ) {
		return state.rgbButtons[obj - QAF_JOY_BUTTON_0];
	}
	else
		// Invalid ID:
		return 0;
}




const char * Joystick::getObjectName ( JoystickObject obj ) {
	// Invalid object?
	if ( obj == QAF_JOY_NONE )
		return NULL;
	
	// Has this name been retrieved yet?
	if ( objNames[obj - QAF_JOY_X_AXIS] )
		return objNames[obj - QAF_JOY_X_AXIS];
	
	// I need to convert from Qaf's enum to DirectInput's.
	DWORD dwOffset = objOffset( obj );
	
	// Query the joystick for the requested object:
	try {
		DIDEVICEOBJECTINSTANCE didoi;
		didoi.dwSize = sizeof( didoi );
		if ( FAILED(hr = pJoystick->GetObjectInfo( &didoi, dwOffset, DIPH_BYOFFSET )) ) {
			hge->System_Log( "Joystick::getObjectName() --> Failed to get object info: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return NULL;
		}
		
		// The device's name is stored in the tszName field:
		// Copy it to the object name buffer:
		objNames[obj - QAF_JOY_X_AXIS] = new char[strlen( didoi.tszName ) + 1];
		strcpy( objNames[obj - QAF_JOY_X_AXIS], didoi.tszName );
		
		return objNames[obj - QAF_JOY_X_AXIS];
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::getObjectName() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
		return NULL;
	}
}




const char * Joystick::getDeviceName () {
	return deviceName;
}




bool Joystick::setHWND ( HWND _hWindow ) {
	hWindow = _hWindow;
	
	try {
		if ( FAILED(hr = pJoystick->SetCooperativeLevel( hWindow, DISCL_EXCLUSIVE | DISCL_FOREGROUND )) ) {
			hge->System_Log( "Joystick::setHWND() --> Failed to set cooperative level: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return false;
		}
		else
			return true;
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::setHWND() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
		return false;
	}
}




bool Joystick::setAxesParameters ( bool absolute, int minValue, int maxValue, float deadZone, float saturation ) {
	// Store parameters in an AxisParameters structure:
	AxisParameters ap;
	ap.absolute = absolute;
	ap.deadZone = deadZone;
	ap.maxValue = maxValue;
	ap.minValue = minValue;
	ap.saturation = saturation;
	ap.pJ = this;
	ap.failed = false; // Didn't fail... yet. Let's see if the callback sets this.
	
	try {
		if ( FAILED(hr = pJoystick->EnumObjects( enumAxesCallback, (void*) &ap, DIDFT_AXIS )) ) {
			hge->System_Log( "Joystick::setAxesParameters() --> Failed to enumerate objects: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return false;
		}
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::setAxesParameters() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
		return false;
	}
	
	return !ap.failed;
}




void Joystick::resetStates () {
	state.lX = 0;
	state.lY = 0;
	state.lZ = 0;
	state.lRx = 0;
	state.lRy = 0;
	state.lRz = 0;
	state.rglSlider[0] = 0;
	state.rglSlider[1] = 0;
	state.rgdwPOV[0] = 0;
	state.rgdwPOV[1] = 0;
	state.rgdwPOV[2] = 0;
	state.rgdwPOV[3] = 0;
	for ( int i = 0; i < 128; i++ )
		state.rgbButtons[i] = 0;
}




int Joystick::createVibrationEffect ( float magnitude, float duration, float period ) {
	// Let's see if all requirements are met... There must be at least one
	// GUID, and at least one available axis.
	if ( effectGUIDs.getCount() == 0 || effectAxesOfs.getCount() == 0 )
		// The effect can't be created.
		return -1;
	
	// Let's try and create the effect:
	IDirectInputEffect * pEffect = NULL;
	
	// Try with all axes, until something works:
	for ( int axisInx = 0; axisInx < effectAxesOfs.getCount(); axisInx++ ) {
		DWORD dwAxes[1] = { effectAxesOfs[axisInx] };
		LONG  lDirection[1] = { 0 };

		DIPERIODIC diPeriodic;      // type-specific parameters
		DIEFFECT   diEffect;        // general parameters
		
		diPeriodic.dwMagnitude = (DWORD) (magnitude * DI_FFNOMINALMAX);
		diPeriodic.lOffset = 0; 
		diPeriodic.dwPhase = 0; 
		diPeriodic.dwPeriod = (DWORD)(period * DI_SECONDS);
		
		diEffect.dwSize = sizeof(DIEFFECT); 
		diEffect.dwFlags = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS; 
		diEffect.dwDuration = (DWORD) (duration * DI_SECONDS);

		diEffect.dwSamplePeriod = 0;               // = default 
		diEffect.dwGain = DI_FFNOMINALMAX;         // no scaling
		diEffect.dwTriggerButton = DIEB_NOTRIGGER;
		diEffect.dwTriggerRepeatInterval = 0;      
		diEffect.cAxes = 1;
		diEffect.rgdwAxes = dwAxes; 
		diEffect.rglDirection = lDirection; 
		diEffect.lpEnvelope = NULL; 
		diEffect.cbTypeSpecificParams = sizeof(diPeriodic);
		diEffect.lpvTypeSpecificParams = &diPeriodic;  
		diEffect.dwStartDelay = 0;
		
		// Try with all GUIDs until something works:
		for ( int guidInx = 0; guidInx < effectGUIDs.getCount(); guidInx++ ) {
			try {
				if ( !FAILED(hr = pJoystick->CreateEffect(
									effectGUIDs[guidInx], // GUID from enumeration
									&diEffect,      // where the data is
									&pEffect,       // where to put interface pointer
									NULL )) ) {     // no aggregation
					// The effect was created!
					// Add it to the effect list:
					// Look for an empty position...
					for ( int j = 0; j < createdEffects.getCount(); j++ ) {
						if ( createdEffects[j] == NULL ) {
							// Place it here:
							createdEffects[j] = pEffect;
							return j;
						}
					}
					
					// Couldn't find an empty position. Increase the Container size:
					createdEffects.add( pEffect );
					return createdEffects.getCount() - 1;
				}
				else {
					hge->System_Log( "Joystick::createVibrationEffect() --> Failed to create periodic effect: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
				}
			}
			catch ( ... ) {
				hge->System_Log( "Joystick::createVibrationEffect() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
			}
		}
	}
	
	// The effect could not be created.
	return -1;
}




bool Joystick::changeVibrationMagnitude ( int effectID, float newMagnitude, float newPeriod ) {
	if ( effectID < 0 || effectID >= createdEffects.getCount() ||
         createdEffects[effectID] == NULL )
		// Fail!
		return false;
	
	// Create a DIPERIODIC structure to change the parameters:
	DWORD dwAxes[1] = { DIJOFS_X };
	LONG lDirection[1] = { 0 };
	DIPERIODIC diPeriodic;      // type-specific parameters
	DIEFFECT   diEffect;        // general parameters
	
	diPeriodic.dwMagnitude = (DWORD) (newMagnitude * DI_FFNOMINALMAX);
	diPeriodic.lOffset = 0; 
	diPeriodic.dwPhase = 0; 
	diPeriodic.dwPeriod = (DWORD)(newPeriod * DI_SECONDS);
	
	diEffect.dwSize = sizeof(DIEFFECT); 
	diEffect.dwFlags = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS; 
	diEffect.cbTypeSpecificParams = sizeof(diPeriodic);
	diEffect.lpvTypeSpecificParams = &diPeriodic;  
	
	HRESULT hr;
	try {
		if ( FAILED(hr = createdEffects[effectID]->SetParameters( &diEffect, DIEP_TYPESPECIFICPARAMS )) ) {
			hge->System_Log( "Joystick::setVibrationMagnitude() --> Failed to set parameters for effect #%d: %s (%s, line %d)", effectID, DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return false;
		}
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::setVibrationMagnitude() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
		return false;
	}
	
	return true;
}



bool Joystick::deleteEffect ( int effectID ) {
	// First thing: Is this a valid ID?
	if ( effectID < 0 || effectID >= createdEffects.getCount() ||
         createdEffects[effectID] == NULL )
		// Fail!
		return false;
	
	// Delete the effect:
	try {
		if ( FAILED(hr = createdEffects[effectID]->Unload() ) ||
			 FAILED(hr = hr = createdEffects[effectID]->Release()) ) {
			hge->System_Log( "Joystick::deleteEffect() --> Failed to release effect #%d: %s (%s, line %d)", effectID, DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return false;
		}
		else {
			createdEffects[effectID] = NULL;
			return true;
		}
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::deleteEffect() --> Unknown error. (%s, line %d)", __FILE__, __LINE__ );
		return false;
	}
}




bool Joystick::playEffect ( int effectID, int repetitions ) {
	// First thing: Is this a valid ID?
	if ( effectID < 0 || effectID >= createdEffects.getCount() ||
         createdEffects[effectID] == NULL ) {
		// Fail!
		hge->System_Log( "Joystick::playEffect() --> Invalid effectID specified: %d (%s, line %d)", effectID, __FILE__, __LINE__ );
		return false;
	}
	
	try {
		// Make sure the device is acquired:
		pJoystick->Acquire();
		
		// Download the effect:
		IDirectInputEffect * pEffect = createdEffects[effectID];
		if ( FAILED(hr = pEffect->Download()) ) {
			// The device is full?
			if ( hr & DIERR_DEVICEFULL ) {
				// Unload another effect:
				int effectToUnload = (effectID + 1) % createdEffects.getCount();
				
				if ( FAILED(hr = createdEffects[effectToUnload]->Unload()) ) {
					hge->System_Log( "Joystick::playEffect() --> The device is full, and no other effect could be unloaded: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
					return false;
				}
				else  {
					hge->System_Log( "Joystick::playEffect() --> The device is full. Another effect (#%d) has been successfully unloaded. (%s, line %d)", effectToUnload, DXGetErrorString8( hr ), __FILE__, __LINE__ );
					// Effect unloaded. Try again...
					if ( FAILED(hr = pEffect->Download()) ) {
						hge->System_Log( "Joystick::playEffect() --> The effect #%d could not be downloaded. (%s, line %d)", effectID, DXGetErrorString8( hr ), __FILE__, __LINE__ );
						return false;
					}
				}
			}
			else {
				hge->System_Log( "Joystick::playEffect() --> Failed to download effect #%d: %s (%s, line %d)", effectID, DXGetErrorString8( hr ), __FILE__, __LINE__ );
				return false;
			}
		}
		
		// Start the effect:
		if ( FAILED(hr = createdEffects[effectID]->Start( repetitions, 0 )) ) {
			hge->System_Log( "Joystick::playEffect() --> Failed to start effect #%d: %s (%s, line %d)", effectID, DXGetErrorString8( hr ), __FILE__, __LINE__ );
			return false;
		}
		
		return true;
	}
	catch ( ... ) {
		hge->System_Log( "Joystick::playEffect() --> An unknown exception has occurred when attempting to play effect #%d (%s, line %d)", effectID, __FILE__, __LINE__ );
		return false;
	}
}




///////////////////////////////////////////////////////////////////////////////
// 
// JOYSTICK SYSTEM:
//
///////////////////////////////////////////////////////////////////////////////

JoystickSystem::JoystickSystem () {
	pHGE = hgeCreate( HGE_VERSION );

	pDI = NULL;
}


JoystickSystem::~JoystickSystem () {
	shutdown();
	
	hge->Release();
}


// Callback for enumerating the joysticks:
// The callback needs a pointer to the JoystickSystem and the HWND... So I'll
// store them in a struct, and pass a pointer to that in the pContext
// parameter.
struct jsCallbackCtx {
	JoystickSystem * jSystem;
	HWND hWindow;
};

BOOL CALLBACK JoystickSystem::enumJoysticksCallback ( const DIDEVICEINSTANCE * pdidInstance, void * pContext) {
	JoystickSystem * jSystem = ((jsCallbackCtx *) pContext)->jSystem;
	
	// Obtain an interface to the enumerated joystick.
	LPDIRECTINPUTDEVICE8 pJoystick;
    HRESULT hr = jSystem->pDI->CreateDevice( pdidInstance->guidInstance, &pJoystick, NULL );
	
	// Success?
	if ( !FAILED( hr ) ) {
		// Create Joystick interface:
		Joystick * newJS = new Joystick( pJoystick, ((jsCallbackCtx *) pContext)->hWindow );
		
		// Success?
		if ( newJS->isInitialized() ) {
			// Add it to the JoystickSystem's list:
			jSystem->joysticks.add( newJS );
		}
		else {
			// Delete this joystick:
			delete newJS;
		}
	}
	else {
		HGE * pHGE = hgeCreate( HGE_VERSION );
		hge->System_Log( "JoystickSystem::JoystickSystem() --> Failed to create joystick device: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		hge->Release();
	}
	
	return DIENUM_CONTINUE;
}




bool JoystickSystem::initialize ( HWND hWindow ) {
	// System already initialized?
	if ( pDI )
		return true;
	
	// Try to get a pointer to the DirectInput object:
	HINSTANCE hInst = GetModuleHandle(NULL);
	HRESULT   hr    = DirectInput8Create( hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**) &pDI, NULL );
	if ( FAILED(hr) ) { 
		hge->System_Log( "Joystick::initialize() --> Failed to create DI interface: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		return false;
	}
	
	// Enumerate the joysticks:
	jsCallbackCtx context;
	context.jSystem = this;
	context.hWindow = hWindow;
	
	if ( FAILED(hr = pDI->EnumDevices( DI8DEVCLASS_GAMECTRL, enumJoysticksCallback, (void *) &context, DIEDFL_ATTACHEDONLY )) ) {
		hge->System_Log( "Joystick::initialize() --> Failed to enumerate devices: %s (%s, line %d)", DXGetErrorString8( hr ), __FILE__, __LINE__ );
		return false;
	}
	
	// Success!
	return true;
}




void JoystickSystem::shutdown () {
	// Delete all joysticks:
	for ( int i = 0; i < joysticks.getCount(); i++ )
		delete joysticks[i];
	
	joysticks.removeAll();
	
	// Release DirectInput interface:
	if ( pDI ) {
		pDI->Release();
		pDI = NULL;
	}
}




int JoystickSystem::getNumberOfJoysticks () {
	return joysticks.getCount();
}




Joystick * JoystickSystem:: getJoystick ( int i ) {
	if ( i >= 0 && i < joysticks.getCount() )
		return joysticks[i];
	else
		return NULL;
}
