package control;

import java.awt.Image;
import java.awt.Point;
import java.util.Vector;

import model.AttributeTable;
import model.BGLayer;
import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.SelectionSet;
import control.tool.ToolBar;

/**
 * Contains implementations of all UndoOperations the aplications needs.
 */
public abstract class UndoImpl {
	
	/**
	 * Represents a batch of undo operations. When performed, all ops added to
	 * the composite will be performed in REVERSE order. The inverse is a
	 * composite containing the inverse of all ops, in reverse order.
	 */
	public static class Composite implements UndoOperation {
		Vector<UndoOperation> ops = new Vector<UndoOperation>();
		
		public void add ( UndoOperation op ) {
			ops.add( op );
		}
		
		public int getCount () {
			return ops.size();
		}
		
		public void perform () {
			for ( int i = ops.size() - 1; i >= 0; i-- )
				ops.get(i).perform();
		}
		
		public UndoOperation getInverse () {
			Composite inverse = new Composite();
			for ( int i = ops.size() - 1; i >= 0; i-- )
				inverse.add( ops.get(i).getInverse() );
			return inverse;
		}
	}
	
	/**
	 * Represents a change made to the base path. Undoing this operation will
	 * restore the base path's former value. 
	 */
	public static class ChangeBasePath implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		String oldValue, newValue;
		
		public ChangeBasePath ( GlobalEditorModel globalEditorModel, String oldValue, String newValue ) {
			this.globalEditorModel = globalEditorModel;
			this.oldValue = oldValue;
			this.newValue = newValue;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new:
			return new ChangeBasePath( globalEditorModel, newValue, oldValue );
		}
		
		public void perform () {
			globalEditorModel.setBasePath( oldValue );
		}
	}
	
	
	
	/**
	 * Represents "drawing" operations on the a layer's tiles (including the
	 * obstacle layer). Undoing this operation will restore the layer's data
	 * to its previous state.
	 */
	public static class TileDrawing implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int layerInx;
		int[][] oldState;
		int[][] newState;
		
		public TileDrawing ( GlobalEditorModel globalEditorModel, Room room, int layerInx, int[][] oldState, int[][] newState ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.layerInx = layerInx;
			this.oldState = oldState;
			this.newState = newState;
		}
		
		public UndoOperation getInverse() {
			// Reverse oldState and newState:
			return new TileDrawing( globalEditorModel, room, layerInx, newState, oldState );
		}
		
		public void perform() {
			for ( int i = 0; i < oldState.length; i++ )
				for ( int j = 0; j < oldState[i].length; j++ )
					if ( layerInx == -1 )
						room.setBlock( i, j, oldState[i][j] );
					else
						room.setBGTile( layerInx, i, j, oldState[i][j] );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	/**
	 * Represents "drawing" operations on the a layer's tiles' colors. Undoing
	 * this operation will restore the layer's color data to its previous state.
	 */
	public static class TileColorDrawing implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int layerInx;
		ColorTile[][] oldState;
		ColorTile[][] newState;
		
		public TileColorDrawing ( GlobalEditorModel globalEditorModel, Room room, int layerInx, ColorTile[][] oldState, ColorTile[][] newState ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.layerInx = layerInx;
			this.oldState = oldState;
			this.newState = newState;
		}
		
		public UndoOperation getInverse() {
			// Reverse oldState and newState:
			return new TileColorDrawing( globalEditorModel, room, layerInx, newState, oldState );
		}
		
		public void perform() {
			for ( int i = 0; i < oldState.length; i++ )
				for ( int j = 0; j < oldState[i].length; j++ )
					room.setBGTileColor( layerInx, i, j, oldState[i][j] );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	/**
	 * Represents the creation of a BGLayer. Undoing this operation will
	 * REMOVE the BGLayer from the loaded room.
	 */
	public static class CreateBGLayer implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room    room;
		int     layerInx;
		BGLayer bgLayer;
		int[][] bgLayerTileMatrix;
		ColorTile[][] bgLayerTileColorMatrix;
		int oldDefObjLayer, newDefObjLayer;
		
		public CreateBGLayer ( GlobalEditorModel globalEditorModel, Room room, int layerInx, BGLayer bgLayer, int[][] bgLayerTileMatrix, ColorTile[][] bgLayerTileColorMatrix, int oldDefObjLayer, int newDefObjLayer ) {
			this.globalEditorModel      = globalEditorModel;
			this.room                   = room;
			this.layerInx               = layerInx;
			this.bgLayer                = new BGLayer( bgLayer.getImage(), bgLayer.getImageFileName(), bgLayer.getTileWidth(), bgLayer.getTileHeight(), bgLayer.getParallaxX(), bgLayer.getParallaxY(), bgLayer.getTranslationX(), bgLayer.getTranslationY() );
			this.bgLayerTileMatrix      = bgLayerTileMatrix;
			this.bgLayerTileColorMatrix = bgLayerTileColorMatrix;
			this.oldDefObjLayer         = oldDefObjLayer;
			this.newDefObjLayer         = newDefObjLayer;
		}
		
		
		public UndoOperation getInverse() {
			return new DeleteBGLayer( globalEditorModel, room, layerInx, bgLayer, bgLayerTileMatrix, bgLayerTileColorMatrix, newDefObjLayer, oldDefObjLayer );
		}

		public void perform() {
			room.removeBGLayer( layerInx );
			
			room.setDefaultObjLayer( oldDefObjLayer );
			
			globalEditorModel.setUnsavedChanges( true );
		}

	}
	
	
	
	/**
	 * Represents the removal of a BGLayer. Undoing this operation will
	 * INSERT the BGLayer into the loaded room.
	 */
	public static class DeleteBGLayer implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room    room;
		int     layerInx;
		BGLayer bgLayer;
		int[][] bgLayerTileMatrix;
		ColorTile[][] bgLayerTileColorMatrix;
		int oldDefObjLayer, newDefObjLayer;
		
		public DeleteBGLayer ( GlobalEditorModel globalEditorModel, Room room, int layerInx, BGLayer bgLayer, int[][] bgLayerTileMatrix, ColorTile[][] bgLayerTileColorMatrix, int oldDefObjLayer, int newDefObjLayer ) {
			this.globalEditorModel      = globalEditorModel;
			this.room                   = room;
			this.layerInx               = layerInx;
			this.bgLayer                = new BGLayer( bgLayer.getImage(), bgLayer.getImageFileName(), bgLayer.getTileWidth(), bgLayer.getTileHeight(), bgLayer.getParallaxX(), bgLayer.getParallaxY(), bgLayer.getTranslationX(), bgLayer.getTranslationY() );
			this.bgLayerTileMatrix      = bgLayerTileMatrix;
			this.bgLayerTileColorMatrix = bgLayerTileColorMatrix;
			this.oldDefObjLayer         = oldDefObjLayer;
			this.newDefObjLayer         = newDefObjLayer;
		}
		
		
		public UndoOperation getInverse() {
			return new CreateBGLayer( globalEditorModel, room, layerInx, bgLayer, bgLayerTileMatrix, bgLayerTileColorMatrix, newDefObjLayer, oldDefObjLayer );
		}

		public void perform() {
			room.addBGLayer( layerInx, bgLayer );
			
			globalEditorModel.setWorkingLayer( layerInx );
			
			for ( int i = 0; i < room.getBGTileMatrixRows( layerInx ); i++ )
				for ( int j = 0; j < room.getBGTileMatrixCols( layerInx ); j++ )
					room.setBGTile( layerInx, i, j, bgLayerTileMatrix[i][j] );
			
			for ( int i = 0; i < room.getBGTileMatrixRows( layerInx ); i++ )
				for ( int j = 0; j < room.getBGTileMatrixCols( layerInx ); j++ )
					room.setBGTileColor( layerInx, i, j, bgLayerTileColorMatrix[i][j] );
			
			room.setDefaultObjLayer( oldDefObjLayer );
			
			globalEditorModel.setUnsavedChanges( true );
		}

	}
	
	
	
	/**
	 * Represents a swap of layer positions in the Room's layer order. Undoing 
	 * this operation will un-swap the layers.
	 */
	public static class SwapBGLayerDepth implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int layer1, layer2;
		
		public SwapBGLayerDepth ( GlobalEditorModel globalEditorModel, Room room, int layer1, int layer2 ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.layer1 = layer1;
			this.layer2 = layer2;
		}
		
		public UndoOperation getInverse() {
			// Swap layer indices:
			return new SwapBGLayerDepth( globalEditorModel, room, layer2, layer1 );
		}

		public void perform() {
			room.swapBGLayers( layer1, layer2 );
			globalEditorModel.setWorkingLayer( layer1 );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	/**
	 * Represents changes made to a BGLayer via the "Edit" button. Undoing this
	 * operation will restore the BGLayer's parameters and its bgData matrix. 
	 */
	public static class EditBGLayer implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int layerInx;
		BGLayer bgLayer;
		Image oldImage, newImage;
		String oldImageFileName, newImageFileName;
		int oldTileWidth, newTileWidth;
		int oldTileHeight, newTileHeight;
		float oldParallaxX, newParallaxY;
		float oldParallaxY, newParallaxX;
		int oldTranslationX, newTranslationX;
		int oldTranslationY, newTranslationY;
		int[][] oldBGTileMatrix, newBGTileMatrix;
		ColorTile[][] oldBGTileColorMatrix, newBGTileColorMatrix;
		
		public EditBGLayer (
				GlobalEditorModel globalEditorModel,
				Room room,
				int layerInx,
				BGLayer bgLayer,
				Image oldImage, Image newImage,
				String oldImageFileName, String newImageFileName,
				int oldTileWidth, int newTileWidth,
				int oldTileHeight, int newTileHeight,
				float oldParallaxX, float newParallaxY,
				float oldParallaxY, float newParallaxX,
				int oldTranslationX, int newTranslationX,
				int oldTranslationY, int newTranslationY,
				int[][] oldBGTileMatrix, int[][] newBGTileMatrix,
				ColorTile[][] oldBGTileColorMatrix, ColorTile[][] newBGTileColorMatrix) {
			this.globalEditorModel = globalEditorModel;
			
			this.room = room;
			
			this.layerInx = layerInx;
			
			this.bgLayer = bgLayer;
			
			this.oldImage = oldImage;
			this.newImage = newImage;
			this.oldImageFileName = oldImageFileName;
			this.newImageFileName = newImageFileName;
			
			this.oldTileWidth    = oldTileWidth;
			this.newTileWidth    = newTileWidth;
			this.oldTileHeight   = oldTileHeight;
			this.newTileHeight   = newTileHeight; 
			
			this.oldParallaxX    = oldParallaxX;
			this.newParallaxY    = newParallaxY;
			this.oldParallaxY    = oldParallaxY;
			this.newParallaxX    = newParallaxX;
			
			this.oldTranslationX = oldTranslationX;
			this.newTranslationX = newTranslationX;
			this.oldTranslationY = oldTranslationY;
			this.newTranslationY = newTranslationY;
			
			this.oldBGTileMatrix = oldBGTileMatrix;
			this.newBGTileMatrix = newBGTileMatrix;
			
			this.oldBGTileColorMatrix = oldBGTileColorMatrix;
			this.newBGTileColorMatrix = newBGTileColorMatrix;
		}
		
		public UndoOperation getInverse() {
			// Swap "old" and "new" data:
			return new EditBGLayer(
					globalEditorModel,
					room,
					layerInx,
					bgLayer,
					newImage,         oldImage,
					newImageFileName, oldImageFileName,
					newTileWidth,     oldTileWidth,
					newTileHeight,    oldTileHeight,
					newParallaxX,     oldParallaxY,
					newParallaxY,     oldParallaxX,
					newTranslationX,  oldTranslationX,
					newTranslationY,  oldTranslationY,
					newBGTileMatrix,  oldBGTileMatrix,
					newBGTileColorMatrix,  oldBGTileColorMatrix );
					
		}
		
		public void perform() {
			bgLayer.setImage( oldImage, oldImageFileName );
			bgLayer.setParallax( oldParallaxX, oldParallaxY );
			bgLayer.setTileSize( oldTileWidth, oldTileHeight );
			bgLayer.setTranslation( oldTranslationX, oldTranslationY );
			
			for ( int i = 0; i < room.getBGTileMatrixRows( layerInx ); i++ )
				for ( int j = 0; j < room.getBGTileMatrixCols( layerInx ); j++ )
					room.setBGTile( layerInx, i, j, oldBGTileMatrix[i][j] );
			
			for ( int i = 0; i < room.getBGTileMatrixRows( layerInx ); i++ )
				for ( int j = 0; j < room.getBGTileMatrixCols( layerInx ); j++ )
					room.setBGTileColor( layerInx, i, j, oldBGTileColorMatrix[i][j] );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	/**
	 * Represents changes made to a BGLayer's translation coordinates. Undoing
	 * this operation will restore the BGLayer's previous parameters. 
	 */
	public static class TranslateBGLayer implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		BGLayer bgLayer;
		Point oldTrans;
		Point newTrans;
		
		public TranslateBGLayer ( GlobalEditorModel globalEditorModel, BGLayer bgLayer, Point oldTrans, Point newTrans ) {
			this.globalEditorModel = globalEditorModel;
			this.bgLayer  = bgLayer;
			this.oldTrans = oldTrans;
			this.newTrans = newTrans;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new:
			return new TranslateBGLayer( globalEditorModel, bgLayer, newTrans, oldTrans );
		}
		
		public void perform () {
			// Restore the BGLayer's old translation:
			bgLayer.setTranslation( oldTrans.x, oldTrans.y );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	
	/**
	 * Represents the insertion of an object in the Room. Undoing the operation
	 * will REMOVE the object.
	 */
	public static class CreateObject implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int inx;
		GameObj obj;
		
		public CreateObject ( GlobalEditorModel globalEditorModel, Room room, int inx, GameObj obj ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.inx = inx;
			this.obj = obj;
		}
		
		public UndoOperation getInverse () {
			return new DeleteObject( globalEditorModel, room, inx, obj );
		}
		
		public void perform () {
			room.removeGameObj( inx );
			
			globalEditorModel.setUnsavedChanges( true );	
		}
	}
	
	
	
	/**
	 * Represents the removal of an object in the Room. Undoing the operation
	 * will INSERT the object.
	 */
	public static class DeleteObject implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int inx;
		GameObj obj;
			
		public DeleteObject ( GlobalEditorModel globalEditorModel, Room room, int inx, GameObj obj ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.inx = inx;
			this.obj = obj;
		}
	
		public UndoOperation getInverse () {
			return new CreateObject( globalEditorModel, room, inx, obj );
		}
	
		public void perform () {
			room.addGameObj( inx, obj );
		
			globalEditorModel.setUnsavedChanges( true );	
		}
	}	
	
	
	
	/**
	 * Represents an object's change of position. Undoing this operation will
	 * place the object in its previous position.
	 */
	public static class MoveObject implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		GameObj obj;
		Point oldPos;
		Point newPos;
		
		public MoveObject ( GlobalEditorModel globalEditorModel, GameObj obj, Point oldPos, Point newPos ) {
			this.globalEditorModel = globalEditorModel;
			this.obj = obj;
			this.oldPos = new Point( oldPos );
			this.newPos = new Point( newPos );
		}
		
		public UndoOperation getInverse () {
			// Swap old and new positions:
			return new MoveObject( globalEditorModel, obj, newPos, oldPos );
		}
		
		public void perform () {
			obj.setPosition( oldPos.x, oldPos.y );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	/**
	 * Represents a change in the object's parameters. Undoing this operation
	 * will restore the object's previous parameters.
	 */
	public static class EditObject implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		GameObj obj;
		String oldID, newID;
		Point oldPos, newPos;
		AttributeTable oldAttr, newAttr;
		
		
		public EditObject (
				GlobalEditorModel globalEditorModel,
				GameObj obj,
				String oldID, String newID,
				Point oldPos, Point newPos,
				AttributeTable oldAttr, AttributeTable newAttr ) {
			this.globalEditorModel = globalEditorModel;
			this.obj = obj;
			
			this.oldID = oldID;
			this.newID = newID;
			
			this.oldPos = new Point( oldPos );
			this.newPos = new Point( newPos );
			
			this.oldAttr = oldAttr;
			this.newAttr = newAttr;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new parameters:
			return new EditObject(
					globalEditorModel,
					obj,
					newID,   oldID,
					newPos,  oldPos,
					newAttr, oldAttr );
		}
		
		public void perform () {
			obj.setID( oldID );
			obj.setPosition( oldPos.x, oldPos.y );
			obj.setAttributeTable( oldAttr );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	/**
	 * Represents a "to front" or "to back" operation on a game object.
	 * Undoing it will place the object in its previous depth. 
	 */
	public static class SwapObjectDepth implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		Room room;
		int oldPos;
		int newPos;
		
		public SwapObjectDepth ( GlobalEditorModel globalEditorModel, Room room, int oldPos, int newPos ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.oldPos = oldPos;
			this.newPos = newPos;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new:
			return new SwapObjectDepth( globalEditorModel, room, newPos, oldPos ); 
		}
		
		public void perform () {
			room.swapGameObjs( oldPos, newPos );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	
	/**
	 * Represents a change in the def. obj. layer. 
	 */
	public static class DefObjLayerChanged implements UndoOperation {
		private GlobalEditorModel globalEditorModel;
		private Room room;
		private int oldDefLayer, newDefLayer;
		
		public DefObjLayerChanged ( GlobalEditorModel globalEditorModel, Room room, int oldDefLayer, int newDefLayer ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.oldDefLayer = oldDefLayer;
			this.newDefLayer = newDefLayer;
		}
		
		public void perform () {
			room.setDefaultObjLayer( oldDefLayer );
			
			globalEditorModel.setUnsavedChanges( true );
		}
		
		public UndoOperation getInverse () {
			// Swap new and old:
			return new DefObjLayerChanged( globalEditorModel, room, newDefLayer, oldDefLayer );
		}
	}
	
	
	
	
	/**
	 * Represents a change in the water level. 
	 */
	public static class WaterLevelChanged implements UndoOperation {
		private GlobalEditorModel globalEditorModel;
		private Room room;
		private int oldWLevel, newWLevel;
		
		public WaterLevelChanged ( GlobalEditorModel globalEditorModel, Room room, int oldWLevel, int newWLevel ) {
			this.globalEditorModel = globalEditorModel;
			this.room = room;
			this.oldWLevel = oldWLevel;
			this.newWLevel = newWLevel;
		}
		
		public void perform () {
			room.setWaterLevel( oldWLevel );
			
			globalEditorModel.setUnsavedChanges( true );
		}
		
		public UndoOperation getInverse () {
			// Swap new and old:
			return new WaterLevelChanged( globalEditorModel, room, newWLevel, oldWLevel );
		}
		
		public void setNewWaterLevel ( int newWaterLevel ) {
			this.newWLevel = newWaterLevel;
		}
	}
	
	
	
	
	/**
	 * Represents the act of floating a tile selection. Undoing this will
	 * defloat the selection.
	 */
	public static class FloatSelection implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		ToolBar toolBar;
		int selectionToolInx;
		int layerInx;
		Object oldState, newState;
		SelectionSet selection;
		
		public FloatSelection ( GlobalEditorModel globalEditorModel, ToolBar toolBar, int selectionToolInx, int layerInx, Object oldState, Object newState, SelectionSet selection ) {
			this.globalEditorModel = globalEditorModel;
			this.toolBar = toolBar;
			this.selectionToolInx = selectionToolInx;
			this.layerInx = layerInx;
			this.oldState = oldState;
			this.newState = newState;
			this.selection = selection;
		}
		
		public void perform () {
			globalEditorModel.setWorkingLayer( layerInx );
			
			globalEditorModel.setSelectionSet( selection, false );
			globalEditorModel.getSelectionSet().restoreState( globalEditorModel, layerInx, oldState );
			
			globalEditorModel.setUnsavedChanges( true );
		}
		
		public UndoOperation getInverse () {
			return new DefloatSelection( globalEditorModel, toolBar, selectionToolInx, layerInx, newState, oldState, selection.clone() );
		}
		
	}
	
	
	
	
	/**
	 * Represents the act of defloating a selection. Undoing this will
	 * float the selection and set the appropriate tool.
	 */
	public static class DefloatSelection implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		ToolBar toolBar;
		int selectionToolInx;
		int layerInx;
		Object oldState, newState;
		SelectionSet selection;
		
		public DefloatSelection ( GlobalEditorModel globalEditorModel, ToolBar toolBar, int selectionToolInx, int layerInx, Object oldState, Object newState, SelectionSet selection ) {
			this.globalEditorModel = globalEditorModel;
			this.toolBar = toolBar;
			this.selectionToolInx = selectionToolInx;
			this.layerInx = layerInx;
			this.oldState = oldState;
			this.newState = newState;
			this.selection = selection;
		}
		
		public void perform () {
			toolBar.setCurrentTool( selectionToolInx );
			globalEditorModel.setWorkingLayer( layerInx );
			globalEditorModel.setSelectionSet( selection, true );
			globalEditorModel.getSelectionSet().restoreState( globalEditorModel, layerInx, oldState );
			
			globalEditorModel.setUnsavedChanges( true );
		}
		
		public UndoOperation getInverse () {
			return new FloatSelection( globalEditorModel, toolBar, selectionToolInx, layerInx, newState, oldState, selection.clone() );
		}
		
	}
	
	
	
	
	/**
	 * Represents the act of nudging a selection.
	 */
	public static class MoveSelection implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		int horiz, vert;
		int layerInx;
		
		public MoveSelection ( GlobalEditorModel globalEditorModel, int layerInx, int horiz, int vert ) {
			this.globalEditorModel = globalEditorModel;
			this.layerInx = layerInx;
			this.horiz = horiz;
			this.vert = vert;
		}
		
		public void perform () {
			globalEditorModel.setWorkingLayer( layerInx );
			globalEditorModel.getSelectionSet().move( -horiz, -vert );
			globalEditorModel.setUnsavedChanges( true );
		}
		
		public UndoOperation getInverse () {
			return new MoveSelection( globalEditorModel, layerInx, -horiz, -vert );
		}
	}
	
	
	
	
	/**
	 * Represents the act of flipping a selection.
	 */
	public static class FlipSelection implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		boolean horiz, vert;
		int layerInx;
		
		public FlipSelection ( GlobalEditorModel globalEditorModel, int layerInx, boolean horiz, boolean vert ) {
			this.globalEditorModel = globalEditorModel;
			this.layerInx = layerInx;
			this.horiz = horiz;
			this.vert = vert;
		}
		
		public void perform () {
			globalEditorModel.setWorkingLayer( layerInx );
			globalEditorModel.getSelectionSet().flip( horiz, vert );
			globalEditorModel.setUnsavedChanges( true );
		}
		
		public UndoOperation getInverse () {
			return new FlipSelection( globalEditorModel, layerInx, horiz, vert );
		}
	}
	
	
	
	
	/**
	 * Represents the act of changing the selection set.
	 */
	public static class SelectionSetChanged implements UndoOperation {
		GlobalEditorModel globalEditorModel;
		ToolBar toolBar;
		int selectionToolInx;
		int layerInx;
		SelectionSet oldSet, newSet;
		boolean oldFloating, newFloating;
		
		public SelectionSetChanged ( GlobalEditorModel globalEditorModel, ToolBar toolBar, int selectionToolInx, int layerInx, SelectionSet oldSet, SelectionSet newSet, boolean oldFloating, boolean newFloating ) {
			this.globalEditorModel = globalEditorModel;
			this.toolBar = toolBar;
			this.selectionToolInx = selectionToolInx;
			this.layerInx = layerInx;
			this.oldSet = (oldSet == null ? null : oldSet.clone());
			this.newSet = (newSet == null ? null : newSet.clone());
			this.oldFloating = oldFloating;
			this.newFloating = newFloating;
		}
		
		public void perform () {
			globalEditorModel.setWorkingLayer( layerInx );
			
			if ( oldFloating )
				toolBar.setCurrentTool( selectionToolInx );
			
			globalEditorModel.setSelectionSet( oldSet, oldFloating );
		}
		
		public UndoOperation getInverse () {
			return new SelectionSetChanged( globalEditorModel, toolBar, selectionToolInx, layerInx, newSet, oldSet, newFloating, oldFloating );
		}
	}
	
}
