package control.tool;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.util.Vector;

import javax.swing.Icon;

public abstract class Tool extends SmartInputAdapter {
	
	public static interface Listener {
		
		/**
		 * Sends a notification that the tool's cursor has changed.
		 */
		public void cursorChanged ( Tool src );
		
		/**
		 * Sends a notifications that the tool wishes to change the status bar
		 * text.
		 */
		public void statusBarChanged ( Tool src );
		
		/**
		 * Sends a notification to repaint the room panel.
		 */
		public void repaint ( Tool src );
		
	}
	
	/**
	 * A list of all the listeners that need to be notifies of Tool events.
	 */
	protected Vector<Tool.Listener> listeners = new Vector<Tool.Listener>();
	
	
	
	
	/**
	 * Returns the name of the tool, for the button's tooltip.
	 */
	public abstract String getToolName ();
	
	/**
	 * Returns an icon for the tool's button.
	 */
	public abstract Icon getToolIcon ();
	
	/**
	 * Returns a longer description.
	 */
	public abstract String getToolDescription ();
	
	/**
	 * This method receives the main room panel's Graphics object. The tool
	 * should use it to render anything that must appear above the displayed
	 * room. The graphics object is untransformed; implementations must take
	 * into account the scrolling, parallax, etc.
	 */
	public abstract void paintOverlay ( Graphics g );
	
	/**
	 * Returns the tool's current cursor, which will be displayed in the room
	 * panel.
	 */
	public abstract Cursor getCursor ();
	
	/**
	 * Returns the text that should be displayed in the status bar.
	 */
	public abstract String getStatusBarText ();
	
	/**
	 * Returns a Component to be displayed in the space below the room info
	 * box.
	 */
	public abstract Component getToolBox ();
	
	/**
	 * Notifies the tool that the user has selected it.
	 */
	public abstract void gainedToolBarFocus ();
	
	/**
	 * Notifies the tool that it is no longer in use by the user.
	 */
	public abstract void lostToolBarFocus ();
	
	/**
	 * Registers a listener as an agent that's interested in receiving tool
	 * events.
	 */
	public void addListener ( Tool.Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	/**
	 * Unregisters a listener.
	 */
	public void removeListener ( Tool.Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	/**
	 * Notifies all listeners that the cursor has changed.
	 */
	protected void fireCursorChangedEvent () {
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).cursorChanged( this );
	}
	
	/**
	 * Notifies all listeners that the status bar text has changed.
	 */
	protected void fireStatusBarChangedEvent () {
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).statusBarChanged( this );
	}
	
	/**
	 * Notifies all listeners that the room panel must be repainted.
	 */
	protected void fireRepaintEvent () {
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).repaint( this );
	}
}
