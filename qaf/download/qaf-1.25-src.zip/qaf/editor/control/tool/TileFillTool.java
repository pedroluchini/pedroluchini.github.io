package control.tool;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import control.HistoryManager;
import control.Main;
import control.UndoImpl;
import model.GlobalEditorModel;
import model.Room;
import model.TileBrushMatrix;
import model.selection.BGTileSelectionSet;
import model.selection.BlockSelectionSet;

public class TileFillTool extends TileBrushTool {
	
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	
	
	
	
	public TileFillTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super( globalEditorModel, toolBar );
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
	}
	
	

	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) )
			return super.getCursor();
		else
			return Main.fillCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBar.getTileToolBox();
	}
	
	
	
	
	public String getToolDescription() {
		return "Fill tiles in the current layer with a brush pattern.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/tileFill.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Tile fill";
	}
	
	
	
	
	public void paintOverlay(Graphics g) {
		super.paintOverlay( g );
	}
	
	
	
	
	public void safeMouseEntered(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseExited(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) ) {
			super.safeMouseExited( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			super.safeMouseMoved( evt );
		}
	}
	
	
	
	
	public void safeMousePressed ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) ) {
			super.safeMousePressed( evt );
			fireCursorChangedEvent();
		}
		else
		if ( getCurrMouseButton() == MouseEvent.BUTTON1 ) {
			final Point currRowAndCol = new Point();
			int layerInx = globalEditorModel.getWorkingLayer();
			Room room = globalEditorModel.getLoadedRoom();
			
			// Back up layer state:
			int[][] oldTileMatrix = Main.getLayerTileMatrix( room, layerInx );
			
			// Calculate current row and column:
			currRowAndCol.x = globalEditorModel.tileColFromPanelX( evt.getX(), globalEditorModel.getWorkingLayer() );
			currRowAndCol.y = globalEditorModel.tileRowFromPanelY( evt.getY(), globalEditorModel.getWorkingLayer() );
			
			TileBrushMatrix tileBrushMatrix;
			if ( layerInx == -1 )
				tileBrushMatrix = toolBar.getBlockPicker().tileBrushMatrix;
			else
				tileBrushMatrix = toolBar.getBGTilePicker( layerInx ).tileBrushMatrix;
			
			// Adjust to center on the brush:
			int leftCol = currRowAndCol.x - (tileBrushMatrix.getNumOfCols() / 2);
			int topRow  = currRowAndCol.y - (tileBrushMatrix.getNumOfRows() / 2);
			
			// Adjust to top/leftmost position:
			while ( leftCol > 0 )
				leftCol -= tileBrushMatrix.getNumOfCols();
			while ( topRow > 0 )
				topRow -= tileBrushMatrix.getNumOfRows();
			
			// Fill whole matrix:
			int lastRow, lastCol;
			if ( layerInx == -1 ) {
				lastRow = room.getBlockMatrixRows() - 1;
				lastCol = room.getBlockMatrixCols() - 1;
			}
			else {
				lastRow = room.getBGTileMatrixRows( layerInx ) - 1;
				lastCol = room.getBGTileMatrixCols( layerInx ) - 1;
			}
			
			for ( int roomRow = 0; roomRow <= lastRow; roomRow++ ) {
				for ( int roomCol = 0; roomCol <= lastCol; roomCol++ ) {
					// If there's a tile selection, restrict drawn tiles to the
					// selected tiles.
					if ( globalEditorModel.getSelectionSet() instanceof BlockSelectionSet ||
					     globalEditorModel.getSelectionSet() instanceof BGTileSelectionSet ) {
						TileBrushMatrix selectionSet = (TileBrushMatrix) globalEditorModel.getSelectionSet();
						if ( selectionSet.getTileAtGlobalCoords(roomRow, roomCol) == TileBrushMatrix.FREE_CELL )
							continue;
					}
					
					// Adjust row/col to brush position:
					int brushRow = roomRow - topRow;
					brushRow %= tileBrushMatrix.getNumOfRows();
					int brushCol = roomCol - leftCol;
					brushCol %= tileBrushMatrix.getNumOfCols();
					
					// Set it:
					int tileID = tileBrushMatrix.getTileAtBrushCoords(brushRow, brushCol);
					if ( tileID == TileBrushMatrix.FREE_CELL )
						tileID = -1;
					
					if ( layerInx == -1 )
						room.setBlock( roomRow, roomCol, tileBrushMatrix.getTileAtBrushCoords(brushRow, brushCol) );
					else
						room.setBGTile( layerInx, roomRow, roomCol, tileBrushMatrix.getTileAtBrushCoords(brushRow, brushCol) );
				}
			}
			
			// Commit undo operation:
			int[][] newTileMatrix = Main.getLayerTileMatrix( room, layerInx );
			HistoryManager.addUndoOperation(
				new UndoImpl.TileDrawing(
					globalEditorModel,
					room,
					layerInx,
					oldTileMatrix,
					newTileMatrix ),
				"tile fill" );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	
	public void safeMouseReleased ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) ) {
			super.safeMouseReleased( evt );
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMouseDragged ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) || getKeyState( KeyEvent.VK_CONTROL ) ) {
			super.safeMouseDragged( evt );
		}
		else {
			safeMouseMoved( evt );
		}
	}
	
	
	
	
	public boolean safeDispatchKeyEvent ( KeyEvent evt ) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else {
			fireCursorChangedEvent();
			fireRepaintEvent();
		}
		
		return false;
	}
	
}
