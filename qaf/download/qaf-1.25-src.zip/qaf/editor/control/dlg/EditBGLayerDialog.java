package control.dlg;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import model.BGLayer;
import model.DecimalSpinnerModel;
import model.GlobalEditorModel;
import model.PositiveIntegerSpinnerModel;
import model.Room;
import control.Main;

/**
 * This is a JDialog created specifically for editing BGLayers. The recommended
 * strategy is to use the static methods createLayer() and editLayer() rather
 * than creating the dialog directly. 
 */
public class EditBGLayerDialog extends JDialog {
	static final long serialVersionUID = 0;
	
	/** Status values used by clients to determine which button in the dialog 
	 * was pressed. */
	public final static int STATUS_NONE   = 0,
	                        STATUS_OK     = 1,
	                        STATUS_CANCEL = 2;
	
	GlobalEditorModel globalEditorModel;
	
	/** Used to indicate which button was pressed by the user. */
	private int status = STATUS_NONE;
	
	/** The layer being edited. */
	private BGLayer bgLayer = new BGLayer( null, null, 32, 32, 1.0f, 1.0f, 0, 0 );
	
	// Storing the GUI components here lets me use them later for callbacks:
	private JButton     okButton,
	                    cancelButton;
	private JTextField  imagePathTxtField = new JTextField( 20 );
	private JLabel      imageSizeLabel    = new JLabel( "Image size:" );
	private JSpinner    parallaxXField,
	                    parallaxYField,
	                    tileWidthField,
	                    tileHeightField;
	private JScrollPane imagePreviewPane;
	private JPanel      imagePreviewPanel = new JPanel () {
		static final long serialVersionUID = 0;
		
		public void paint ( Graphics g ) {
			Main.clearBGWithHatches( g, getWidth(), getHeight() );
			
			// Draw the source image, if it is present:
			if ( bgLayer.getImage() != null ) {
				g.drawImage( bgLayer.getImage(), 0, 0, this );
				
				// Draw tile grid:
				Main.drawGrid(
					g,
					0, 0,
					bgLayer.getNumOfRows(), bgLayer.getNumOfCols(),
					bgLayer.getTileWidth(), bgLayer.getTileHeight(),
					Room.MAX_BGTILE_ID,
					Color.RED );
			}
		}
		
		public Dimension getPreferredSize () {
			return getMinimumSize();
		}
		
		public Dimension getMinimumSize () {
			if ( bgLayer.getImage() != null )
				return new Dimension(
					bgLayer.getImage().getWidth(this),
					bgLayer.getImage().getHeight(this) );
			else
				return new Dimension(0,0);
		}
	};
	
	
	/**
	 * Constructor: Receives the parent Frame and the layer being edited. Its
	 * data will be copied to initialize the editor's fields. (Passing a null
	 * argument will create a new layer.)
	 */
	private EditBGLayerDialog ( Frame parent, GlobalEditorModel _globalEditorModel, BGLayer _bgLayer ) {
		// Invoke the constructor from the JDialog superclass:
		// Bind it to the "parent" and define it as modal.
		super( parent, true );
		setResizable( false );
		
		this.globalEditorModel = _globalEditorModel;
		
		// Copy data from bgLayer
		if ( _bgLayer != null ) {
			bgLayer.setImage( _bgLayer.getImage(), _bgLayer.getImageFileName() );
			bgLayer.setParallax( _bgLayer.getParallaxX(), _bgLayer.getParallaxY() );
			bgLayer.setTileSize( _bgLayer.getTileWidth(), _bgLayer.getTileHeight() );
			bgLayer.setTranslation( _bgLayer.getTranslationX(), _bgLayer.getTranslationY() );
		}
		
		
		// Build BGEditor layout:
		//
		// +=============================================+
		// | Source image: [______________][ Browse... ] |
		// | +-----------------------------------------+ |
		// | |                                         | |
		// | | (Preview)                               | |
		// | |                                         | |
		// | |                                         | |
		// | |                                         | |
		// | +-----------------------------------------+ |
		// | Image size: 320 x 240 pixels
		// |                                             |
		// | Parallax factor: [___] x [___]              |
		// | Tile size: [___] x [___]      [Fit to image]|
		// |                                             |
		// |           [  OK  ]  [  Cancel  ]            |
		// +---------------------------------------------+
		//
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY( 0.0f );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
				
		// SOURCE IMAGE CHOOSER:
		imagePathTxtField.setEditable( false );
		if ( bgLayer.getImageFileName() != null ) 
			imagePathTxtField.setText( globalEditorModel.prependBasePath( bgLayer.getImageFileName() ) );
		Box imageChooserBox = Box.createHorizontalBox();
		imageChooserBox.setAlignmentX( 0.0f );
		imageChooserBox.add( new JLabel("Source image: ") );
		imageChooserBox.add( imagePathTxtField );
		
		JButton browseButton = new JButton( "Browse..." );
		browseButton.addActionListener( new ActionListener() { // Click the button, get an image file
			public void actionPerformed ( ActionEvent evt ) {
				JFileChooser fDlg = new JFileChooser( globalEditorModel.getBasePath() );
				fDlg.setFileSelectionMode(JFileChooser.FILES_ONLY);
				fDlg.setFileFilter( new FileFilter () {
					public boolean accept ( File f ) {
						String fName = f.getName().toLowerCase();
						return f.isDirectory()         ||
						       fName.endsWith(".jpg")  ||
						       fName.endsWith(".jpeg") ||
						       fName.endsWith(".png");
					}
					public String getDescription () {
						return "Image files (*.JPG, *.JPEG, *.PNG)";
					}
				} );
				fDlg.setAcceptAllFileFilterUsed( false );

				// Did the user choose a file or did he cancel?
				if ( fDlg.showOpenDialog( EditBGLayerDialog.this ) == JFileChooser.APPROVE_OPTION &&
					 fDlg.getSelectedFile() != null ) {
					// Check image path for validity:
					if ( !globalEditorModel.isInBasePath( fDlg.getSelectedFile().getAbsolutePath() ) ||
					     !fDlg.getSelectedFile().canRead() )
					     Main.showNotInBasePathDialog( EditBGLayerDialog.this, globalEditorModel.getBasePath() );
					else {
						String imagePath = Main.getCanonicalPath( fDlg.getSelectedFile() );
						
						// Load and preview image:
						imagePathTxtField.setText( imagePath );
						bgLayer.setImage(
							Main.createImage( imagePath ),
							globalEditorModel.stripBasePath( imagePath ) );
						imagePreviewPane.revalidate();
						imagePreviewPanel.repaint();
						imageSizeLabel.setText( "Image size: " + bgLayer.getImage().getWidth(Main.f) + " x " + bgLayer.getImage().getHeight(Main.f) );
					}
				}
			} } );
		imageChooserBox.add( browseButton );
				
		theBox.add( imageChooserBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// IMAGE PREVIEWER:
		imagePreviewPane = new JScrollPane( imagePreviewPanel );
		imagePreviewPane.setAlignmentX( JScrollPane.LEFT_ALIGNMENT );
		imagePreviewPane.setAlignmentY( JScrollPane.TOP_ALIGNMENT );
		imagePreviewPane.setPreferredSize( new Dimension(300, 300) );
		if ( bgLayer.getImage() != null )
			imageSizeLabel.setText( "Image size: " + bgLayer.getImage().getWidth(Main.f) + " x " + bgLayer.getImage().getHeight(Main.f) );
		
		theBox.add( imagePreviewPane );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		theBox.add( imageSizeLabel );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// PARALLAX FACTORS:
		parallaxXField = new JSpinner( new DecimalSpinnerModel( bgLayer.getParallaxX() ) );
		((JSpinner.DefaultEditor) parallaxXField.getEditor()).getTextField().setEditable( true );
		parallaxXField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.setParallaxX( ((DecimalSpinnerModel) ((JSpinner) evt.getSource()).getModel()).getFloatValue() );
			} } );
		parallaxYField = new JSpinner( new DecimalSpinnerModel( bgLayer.getParallaxY() ) );
		((JSpinner.DefaultEditor) parallaxYField.getEditor()).getTextField().setEditable( true );
		parallaxYField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.setParallaxY( ((DecimalSpinnerModel) ((JSpinner) evt.getSource()).getModel()).getFloatValue() );
			} } );
		Box parallaxBox = Box.createHorizontalBox();
		parallaxBox.setAlignmentX( 0.0f );
		parallaxBox.add( new JLabel("Parallax factor: ") );
		parallaxBox.add( parallaxXField );
		parallaxBox.add( new JLabel(" x ") );
		parallaxBox.add( parallaxYField );
		
		theBox.add( parallaxBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
				
		// TILE SIZE:
		tileWidthField = new JSpinner( new PositiveIntegerSpinnerModel( bgLayer.getTileWidth() ) );
		((JSpinner.DefaultEditor) tileWidthField.getEditor()).getTextField().setEditable( true );
		tileWidthField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.setTileWidth( ((PositiveIntegerSpinnerModel) ((JSpinner) evt.getSource()).getModel()).getIntValue() );
				imagePreviewPanel.repaint();
			} } );
		tileHeightField = new JSpinner( new PositiveIntegerSpinnerModel( bgLayer.getTileHeight() ) );
		((JSpinner.DefaultEditor) tileHeightField.getEditor()).getTextField().setEditable( true );
		tileHeightField.addChangeListener( new ChangeListener () {
			public void stateChanged ( ChangeEvent evt ) {
				// Every time the JSpinner changes, update the bgLayer:
				bgLayer.setTileHeight( ((PositiveIntegerSpinnerModel) ((JSpinner) evt.getSource()).getModel()).getIntValue() );
				imagePreviewPanel.repaint();
			} } );
		JButton fitToImageButton = new JButton( "Fit to image " );
		fitToImageButton.addActionListener( new ActionListener () {
			public void actionPerformed ( ActionEvent evt ) {
				if ( bgLayer.getImage() != null ) {
					tileWidthField.setValue( new Integer( bgLayer.getImage().getWidth(Main.f) ) );
					tileHeightField.setValue( new Integer( bgLayer.getImage().getHeight(Main.f) ) );
				}
			} } );
		Box tileSizeBox = Box.createHorizontalBox();
		tileSizeBox.setAlignmentX( 0.0f );
		tileSizeBox.add( new JLabel("Tile size: ") );
		tileSizeBox.add( tileWidthField );
		tileSizeBox.add( new JLabel(" x ") );
		tileSizeBox.add( tileHeightField );
		tileSizeBox.add( Box.createRigidArea( new Dimension(10, 0) ) );
		tileSizeBox.add( fitToImageButton );
		
		theBox.add( tileSizeBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
				
		// BUTTONS:
		// Upon being pressed, these will set the "status" field to the
		// appropriate value and close the dialog:
		okButton = new JButton( "OK" );
		okButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				// Validate source image:
				if ( bgLayer.getImageFileName() == null ) {
					JOptionPane.showMessageDialog(
						EditBGLayerDialog.this,             // parent dialog
						"You must specify a source image.", // message
						"Error",                            // title
						JOptionPane.ERROR_MESSAGE           // message type
					);
				}
				// Validate tile size: The tiles must fit within the image's
				// boundaries:
				else if ( bgLayer.getTileWidth()  > bgLayer.getImage().getWidth(Main.f)       ||
				          bgLayer.getTileHeight() > bgLayer.getImage().getHeight(Main.f)      ||
				          bgLayer.getImage().getWidth(Main.f)  % bgLayer.getTileWidth()  != 0 ||
				          bgLayer.getImage().getHeight(Main.f) % bgLayer.getTileHeight() != 0 ) {
					String[] message = {
						"Invalid tile size.",
						"The tiles must fit within the boundaries of the source image." };
					JOptionPane.showMessageDialog(
						EditBGLayerDialog.this,       // parent dialog
						message,                  // message
						"Error",                  // title
						JOptionPane.ERROR_MESSAGE // message type
					);
				}
				// OK!
				else {
					status = STATUS_OK;
					dispose();
				}
			} } );
		cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				status = STATUS_CANCEL;
				dispose();
			} } );
		
		theBox.add( new JSeparator() );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// Add the buttons to the dialog:
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.0f );
		buttonBox.add( Box.createGlue() );
		buttonBox.add( okButton );
		buttonBox.add( Box.createRigidArea( new Dimension(15, 0) ) );
		buttonBox.add( cancelButton );
		buttonBox.add( Box.createGlue() );
		theBox.add( buttonBox );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// Add fillers to the left and right of the box:
		Box filler = Box.createHorizontalBox();
		filler.setAlignmentX( 0.0f );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		filler.add( theBox );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		getContentPane().add( filler );
		
		// Layout done!
		
		// Set "OK" as the default button:
		getRootPane().setDefaultButton( okButton );
		
		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
		Action escapeAction = new AbstractAction() {
			final static long serialVersionUID = 0;
			public void actionPerformed(ActionEvent e) {
				cancelButton.doClick();
			} };
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", escapeAction);
		
	}
	
	
	
	
	
	/**
	 * Prompts the user for a new BGLayer.
	 * Returns true if the layer was created created, or false if the user
	 * canceled.
	 */
	public static boolean createLayer ( GlobalEditorModel globalEditorModel ) {
		// Pop up a window with the editor:
		EditBGLayerDialog editor = new EditBGLayerDialog( Main.f, globalEditorModel, null );
		editor.setTitle( "Create new BG layer" );
		editor.pack();
		editor.setLocationRelativeTo( null ); // Center on screen
		editor.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
		
		// Check status:
		// User cancelled or closed the window?
		if ( editor.status != STATUS_OK )
			return false;
		// User confirmed?
		else {
			globalEditorModel.getLoadedRoom().addBGLayer( editor.bgLayer );
			
			return true;
		}
	}
	
	
	/**
	 * Opens up a dialog to edit an existing layer.
	 * Returns false if the user canceled.
	 */
	public static boolean editLayer ( GlobalEditorModel globalEditorModel, BGLayer bgLayer ) {
		// Pop up a window with the editor:
		EditBGLayerDialog dlg = new EditBGLayerDialog( Main.f, globalEditorModel, bgLayer );
		dlg.setTitle( "Editing BG layer" );
		dlg.pack();
		dlg.setLocationRelativeTo( null ); // Center on screen
		dlg.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
	
		// Check status:
		// User cancelled or closed the window?
		if ( dlg.status != STATUS_OK )
			return false;
		// User confirmed?
		else {
			String[] message = {
					"Changing a layer's configuration will",
					"force its data matrix to be resized,",
					"which may cause some of its contents",
					"to be lost." };
	
			JOptionPane.showMessageDialog(
					Main.f,                           // parent dialog
					message,                          // message
					"Edit layer",                     // title
					JOptionPane.INFORMATION_MESSAGE); // message type
			
			// Copy the layer's data:
			bgLayer.setImage( dlg.bgLayer.getImage(), dlg.bgLayer.getImageFileName() );
			bgLayer.setParallax( dlg.bgLayer.getParallaxX(), dlg.bgLayer.getParallaxY() );
			bgLayer.setTileSize( dlg.bgLayer.getTileWidth(), dlg.bgLayer.getTileHeight() );
			bgLayer.setTranslation( dlg.bgLayer.getTranslationX(), dlg.bgLayer.getTranslationY() );
			
			return true;
		}
	}
	
}
