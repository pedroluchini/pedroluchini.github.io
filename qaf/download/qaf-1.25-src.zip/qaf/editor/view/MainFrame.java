package view;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.WindowConstants;

import model.GlobalEditorModel;
import model.Room;
import model.selection.SelectionSet;
import control.Main;
import control.MainMenuBar;
import control.RoomInfoBox;
import control.tool.Tool;
import control.tool.ToolBar;

public class MainFrame extends JFrame {
	final static long serialVersionUID = 0;
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {
		
		public void basePathChanged(GlobalEditorModel src) {}
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
		public void scrollChanged(GlobalEditorModel src) {}
		public void workingLayerChanged (GlobalEditorModel src) {}
		public void gridVisibilityChanged (GlobalEditorModel src) {}
		public void zoomChanged (GlobalEditorModel src) {}
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}

		private void updateTitle () {
			String strUS = (globalEditorModel.hasUnsavedChanges() ? " *" : "");
			
			if ( globalEditorModel.getLoadedRoomFileName() == null )
				setTitle( "Room Editor - " + "Untitled" + strUS );
			else
				setTitle( "Room Editor - " + globalEditorModel.getLoadedRoomFileName() + strUS);
		}
		
		public void unsavedChangesChanged (GlobalEditorModel src) {
			updateTitle();
		}
		
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldLoadedRoomFileName) {
			updateTitle();
		}
		
	}
	
	
	
	
	private class ToolListener implements Tool.Listener, ToolBar.Listener {
		MainMenuBar mainMenuBar;
		RoomPanel roomPanel;
		JLabel statusBar;
		Container toolPanelSpace;
		
		public ToolListener ( MainMenuBar menuBar, RoomPanel roomPanel, JLabel statusBar, Container toolPanelSpace ) {
			this.mainMenuBar = menuBar;
			this.roomPanel = roomPanel;
			this.statusBar = statusBar;
			this.toolPanelSpace = toolPanelSpace;
		}

		public void cursorChanged(Tool src) {
			roomPanel.setCursor( src.getCursor() );
		}

		public void repaint( Tool src ) {
			roomPanel.setCurrentTool( src );
			roomPanel.repaint();
		}

		public void statusBarChanged(Tool src) {
			statusBar.setText( src.getStatusBarText() );
		}
		
		public void toolChanged ( ToolBar src ) {
			Tool tool = src.getCurrentTool();
			
			cursorChanged( tool );
			statusBarChanged( tool );
			
			toolPanelSpace.removeAll();
			toolPanelSpace.add( tool.getToolBox() );
			toolPanelSpace.repaint();
		}
		
	}
	
	
	
	
	GlobalEditorModel globalEditorModel;
	ToolBar toolBar;
	RoomPanel roomPanel;
	GlobalEditorModel.Listener globalEditorModelListener = new GlobalEditorModelListener();
	
	
	
	
	public MainFrame ( GlobalEditorModel globalEditorModel ) {
		super( "Room Editor" );
		
		this.globalEditorModel = globalEditorModel;
		
		if ( globalEditorModel.getLoadedRoomFileName() == null )
			setTitle( "Room Editor - " + "Untitled" );
		else
			setTitle( "Room Editor - " + globalEditorModel.getLoadedRoomFileName() );
		
		globalEditorModel.addListener( globalEditorModelListener );
		
		// Override JFrame's standard behavior:
		setDefaultCloseOperation( WindowConstants.DO_NOTHING_ON_CLOSE );
		addWindowListener( 
			new WindowAdapter() {
				public void windowClosing ( WindowEvent evt ) {
					// Check if the user wants to save before closing:
					if ( Main.checkUnsavedChanges( MainFrame.this.globalEditorModel, toolBar ) ) {
						dispose();
						roomPanel.stopMarqueeStrokeTimer();
					}
				}
			} );
		
		// Create components I'll need soon...
		MainMenuBar mainMenuBar = new MainMenuBar( globalEditorModel );
		roomPanel = new RoomPanel( globalEditorModel );
		JLabel statusBar = new JLabel( " " );
		Box toolPanelSpace = Box.createHorizontalBox();
		
		// Set up menu bar:
		setJMenuBar( mainMenuBar );
		
		// Set up UI layout:
		//
		// +============================+
		// | ToolBar                    |
		// +----------------------------+
		// |           |                |
		// |  Toolbox  |   RoomPanel    |
		// |           |                |
		// +----------------------------+
		// | Status                     |
		// +----------------------------+
		//
		Box vBox = Box.createVerticalBox();
		{
			vBox.add( Box.createVerticalStrut( 5 ) );
			
			ToolListener toolListener = new ToolListener( mainMenuBar, roomPanel, statusBar, toolPanelSpace );
			Tool.Listener[] toolListeners = { toolListener };
			toolBar =
				new ToolBar(
					globalEditorModel,
					toolListeners,
					roomPanel,
					statusBar );
			toolBar.addListener( toolListener );
			toolListener.toolChanged( toolBar ); // Force cursor update
			mainMenuBar.setToolBar( toolBar );
			
			vBox.add( toolBar );
			
			vBox.add( Box.createVerticalStrut( 5 ) );
			
			Box hBox = Box.createHorizontalBox();
			hBox.setAlignmentX( 0 );
			{
				// Tool box:
				Box toolVBox = Box.createVerticalBox();
				toolVBox.setAlignmentX( 0 );
				toolVBox.setAlignmentY( 0 );
				toolVBox.add( new WorkingLayerTabbedPane( globalEditorModel, toolBar ) );
				toolVBox.add( toolPanelSpace );
				
				toolPanelSpace.removeAll();
				toolPanelSpace.add( toolBar.getCurrentTool().getToolBox() );
				
				JSplitPane toolBoxSplitPane =
					new JSplitPane(
							JSplitPane.VERTICAL_SPLIT,
							new JScrollPane(
								new RoomInfoBox( globalEditorModel ) ),
							toolVBox );
				toolBoxSplitPane.setContinuousLayout( true );
				
				// Room panel:
				roomPanel.setCurrentTool( toolBar.getCurrentTool() );
				JScrollPane roomPanelScrollPane =
					new JScrollPane(
						roomPanel );
				globalEditorModel.setViewport( roomPanelScrollPane.getViewport() ); // Store the viewport in the editor model:
				
				// Group 'em in a split pane:
				JSplitPane mainSpaceSplitPane = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT, toolBoxSplitPane, roomPanelScrollPane );
				mainSpaceSplitPane.setOneTouchExpandable( true );
				mainSpaceSplitPane.setContinuousLayout( true );
				mainSpaceSplitPane.setResizeWeight( 0.0 );
				toolBoxSplitPane.setMinimumSize( new Dimension(0, 0));
				roomPanelScrollPane.setMinimumSize( new Dimension(0, 0));
				
				hBox.add( mainSpaceSplitPane );
			}
			vBox.add( hBox );
			
			statusBar.setAlignmentX( 0 );
			vBox.add( statusBar );
		}
		getContentPane().add( vBox );
		
	}
	
}
