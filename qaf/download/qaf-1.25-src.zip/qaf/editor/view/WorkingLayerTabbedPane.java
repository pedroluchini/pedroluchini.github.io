package view;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import model.BGLayer;
import model.ColorTile;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.SelectionSet;
import control.HistoryManager;
import control.Main;
import control.UndoImpl;
import control.dlg.EditBGLayerDialog;
import control.tool.ToolBar;

public class WorkingLayerTabbedPane extends JTabbedPane {
	static final long serialVersionUID = 0;
	
	private class RoomListener implements Room.Listener {

		public void bgLayerAdded(Room src, int newLayerIndex) {
			recreateTabs();
		}

		public void bgLayerRemoved(Room src, int oldLayerIndex, BGLayer bgLayer, int[][] bgTileMatrix, ColorTile[][] bgTileColorMatrix) {
			recreateTabs();
		}

		public void bgLayerSwapped(Room src, int bgInx1, int bgInx2) {
			recreateTabs();
		}

		public void bgTileChanged(Room src, int layerIndex, int row, int col) {}
		public void bgTileColorChanged(Room src, int layerIndex, int row, int col) {}
		public void blockChanged(Room src, int row, int col) {}
		public void defaultObjLayerChanged(Room src) {}
		public void gameObjAdded(Room src, int newIndex) {}
		public void gameObjRemoved(Room src, int oldIndex, GameObj obj) {}
		public void gameObjSwapped(Room src, int i1, int i2) {}
		public void waterLevelChanged(Room src) {}
		
	}
	
	
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {

		public void basePathChanged(GlobalEditorModel src) {}
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
		public void gridVisibilityChanged(GlobalEditorModel src) {}
		public void zoomChanged(GlobalEditorModel src) {}
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
		
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {
			oldRoom.removeListener( roomListener );
			src.getLoadedRoom().addListener( roomListener );
			
			recreateTabs();
		}

		public void scrollChanged(GlobalEditorModel src) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		public void workingLayerChanged(GlobalEditorModel src) {
			if ( src.getWorkingLayer() + 1 != getSelectedIndex() )
				setSelectedIndex( src.getWorkingLayer() + 1 );
		}
		
	}
	
	
	
	GlobalEditorModel globalEditorModel;
	ToolBar toolBar;
	
	GlobalEditorModelListener globalEditorModelListener = new GlobalEditorModelListener();
	RoomListener roomListener = new RoomListener();
	
	
	
	
	public WorkingLayerTabbedPane ( GlobalEditorModel _globalEditorModel, ToolBar _toolBar ) {
		this.globalEditorModel = _globalEditorModel;
		this.toolBar = _toolBar;
		
		globalEditorModel.addListener( globalEditorModelListener );
		globalEditorModel.getLoadedRoom().addListener( roomListener );
		
		recreateTabs();
		
		this.addChangeListener(
			new ChangeListener () {
				public void stateChanged ( ChangeEvent evt ) {
					int workingLayerInx = globalEditorModel.getWorkingLayer();
					if ( getSelectedIndex() != workingLayerInx + 1 && getSelectedIndex() >= 0 ) {
						UndoImpl.Composite undoOp = new UndoImpl.Composite();
						
						// Unselect everything:
						if ( globalEditorModel.isSelectionFloating() ) {
							SelectionSet selection = globalEditorModel.getSelectionSet().clone();
							
							Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, workingLayerInx);
							globalEditorModel.defloatSelection();
							Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, workingLayerInx);
							
							undoOp.add(
								new UndoImpl.DefloatSelection(
									globalEditorModel,
									toolBar,
									ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
									workingLayerInx,
									oldState,
									newState,
									selection ) );
						}
						if ( globalEditorModel.getSelectionSet() != null &&
						     !globalEditorModel.getSelectionSet().survivesLayerChange( globalEditorModel, workingLayerInx, getSelectedIndex() - 1 ) ) {
							SelectionSet oldSelection = globalEditorModel.getSelectionSet();
							boolean oldFloating = globalEditorModel.isSelectionFloating();
							
							globalEditorModel.setSelectionSet(null, false);
							
							undoOp.add(
								new UndoImpl.SelectionSetChanged(
									globalEditorModel,
									toolBar,
									ToolBar.getSelectionToolIndex(oldSelection),
									workingLayerInx,
									oldSelection,
									globalEditorModel.getSelectionSet(),
									oldFloating,
									globalEditorModel.isSelectionFloating() ) );
						}
						
						// Commit undo operation:
						if ( undoOp.getCount() > 0 )
							HistoryManager.addUndoOperation(
								undoOp,
								"select none" );
						
						// Change the working layer:
						globalEditorModel.setWorkingLayer( getSelectedIndex() - 1 );
					}
				}
			} );
	}
	
	
	
	
	private void recreateTabs () {
		// Remove all tabs...
		this.setSelectedIndex( -1 );
		while ( this.getTabCount() > 0 ) {
			this.removeTabAt( 0 );
			// TODO: Remove BGLayerInfoPanel from BGLayer listeners
		}
		
		// Add as many tabs as there are BG layers... plus one for the obstacle
		// block layer:
		Room room = globalEditorModel.getLoadedRoom();
		for ( int i = -1; i < room.getNumOfBGLayers(); i++ ) {
			String tabTitle = ( i == -1 ? "Obst." : (" " + i + " "));
			String tipText = ( i == -1 ? "Obstacle blocks" : "Background layer " + i);
			
			Box bgInfoPanel = Box.createVerticalBox();
			if ( i == -1 ) {
				// +----------------------------+
				// |[ < ][ Edit ][ Delete ][ > ]|
				// |    <Three empty labels>    |
				// +----------------------------+
				Box hBox = Box.createHorizontalBox();
				hBox.setAlignmentX( 0 );
				hBox.setAlignmentY( 0 );
				{
					JButton btn;
					
					btn = new JButton( "<" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					btn.setEnabled( false );
					hBox.add( btn );
					
					hBox.add( Box.createHorizontalGlue() );
					
					btn = new JButton( "Edit" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					btn.setEnabled( false );
					hBox.add( btn );
					
					hBox.add( Box.createHorizontalGlue() );
					
					btn = new JButton( "Delete" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					btn.setEnabled( false );
					hBox.add( btn );
					
					hBox.add( Box.createHorizontalGlue() );
					
					btn = new JButton( ">" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					btn.setEnabled( false );
					hBox.add( btn );
				}
				bgInfoPanel.add( hBox );
				
				bgInfoPanel.add( Box.createVerticalStrut( 5 ) );
				
				bgInfoPanel.add( new JLabel( "  Block size: " + room.getBlockSize() + " x " + room.getBlockSize() ) );
				bgInfoPanel.add( new JLabel( " " ) );
				bgInfoPanel.add( new JLabel( " " ) );
				
				bgInfoPanel.add( Box.createVerticalStrut( 5 ) );
			}
			else {
				// +----------------------------+
				// |[ < ][ Edit ][ Delete ][ > ]|
				// |      BGLayerInfoPanel      |
				// +----------------------------+
				Box hBox = Box.createHorizontalBox();
				hBox.setAlignmentX( 0 );
				hBox.setAlignmentY( 0 );
				{
					JButton btn;
					
					btn = new JButton( "<" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					hBox.add( btn );
					if ( i == 0 )
						btn.setEnabled( false );
					else {
						btn.setActionCommand( Integer.toString(i) );
						btn.addActionListener(
							new ActionListener () {
								public void actionPerformed ( ActionEvent evt ) {
									UndoImpl.Composite undoOp = new UndoImpl.Composite();
									
									// Unselect everything:
									if ( globalEditorModel.isSelectionFloating() ) {
										int layerInx = globalEditorModel.getWorkingLayer();
										SelectionSet selection = globalEditorModel.getSelectionSet().clone();
										
										Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										globalEditorModel.defloatSelection();
										Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										
										undoOp.add(
											new UndoImpl.DefloatSelection(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
												globalEditorModel.getWorkingLayer(),
												oldState,
												newState,
												selection ));
									}
/*									if ( globalEditorModel.getSelectionSet() != null || !globalEditorModel.getSelectionSet().survivesLayerChange() ) {
										SelectionSet oldSelection = globalEditorModel.getSelectionSet();
										boolean oldFloating = globalEditorModel.isSelectionFloating();
										
										globalEditorModel.setSelectionSet(null, false);
										
										undoOp.add(
											new UndoImpl.SelectionSetChanged(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(oldSelection),
												globalEditorModel.getWorkingLayer(),
												oldSelection,
												globalEditorModel.getSelectionSet(),
												oldFloating,
												globalEditorModel.isSelectionFloating() ) );
									}*/
									
									// Swap layers:
									int layerInx = Integer.parseInt( evt.getActionCommand() );
									Room room = globalEditorModel.getLoadedRoom();
									
									room.swapBGLayers( layerInx, layerInx - 1 );
									
									undoOp.add(
										new UndoImpl.SwapBGLayerDepth(
											globalEditorModel,
											room,
											layerInx, layerInx - 1 ) );
									
									// Commit undo operation:
									HistoryManager.addUndoOperation(
										undoOp,
										"bring layer forward" );
									
									globalEditorModel.setUnsavedChanges( true );
									
									// Keep layer focused:
									setSelectedIndex( (layerInx + 1) - 1 );
								}
							} );
					}
					btn.setToolTipText( "Bring layer forward" );
					
					hBox.add( Box.createHorizontalGlue() );
					
					btn = new JButton( "Edit" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					hBox.add( btn );
					btn.setActionCommand( Integer.toString(i) );
					btn.addActionListener(
						new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								int layerInx = Integer.parseInt( evt.getActionCommand() );
								Room room = globalEditorModel.getLoadedRoom();
								BGLayer bgLayer = room.getBGLayer( layerInx );
								
								Image oldImage = bgLayer.getImage();
								String oldImageFileName = bgLayer.getImageFileName();
								int oldTileWidth = bgLayer.getTileWidth();
								int oldTileHeight = bgLayer.getTileHeight();
								float oldParallaxX = bgLayer.getParallaxX();
								float oldParallaxY = bgLayer.getParallaxY();
								int oldTranslationX = bgLayer.getTranslationX();
								int oldTranslationY = bgLayer.getTranslationY();
								int[][] oldBGTileMatrix = Main.getLayerTileMatrix( room, layerInx );
								ColorTile[][] oldBGTileColorMatrix = Main.getLayerTileColorMatrix( room, layerInx );
								
								if ( EditBGLayerDialog.editLayer( globalEditorModel, bgLayer ) ) {
									// User confirmed.
									UndoImpl.Composite undoOp = new UndoImpl.Composite();
									
									// Unselect everything:
									if ( globalEditorModel.isSelectionFloating() ) {
										SelectionSet selection = globalEditorModel.getSelectionSet().clone();
										
										Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										globalEditorModel.defloatSelection();
										Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										
										undoOp.add(
											new UndoImpl.DefloatSelection(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
												globalEditorModel.getWorkingLayer(),
												oldState,
												newState,
												selection ) );
									}
									if ( globalEditorModel.getSelectionSet() != null ) {
										SelectionSet oldSelection = globalEditorModel.getSelectionSet();
										boolean oldFloating = globalEditorModel.isSelectionFloating();
										
										globalEditorModel.setSelectionSet(null, false);
										
										undoOp.add(
											new UndoImpl.SelectionSetChanged(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(oldSelection),
												globalEditorModel.getWorkingLayer(),
												oldSelection,
												globalEditorModel.getSelectionSet(),
												oldFloating,
												globalEditorModel.isSelectionFloating() ) );
									}
									
									// Set the layer's new parameters:
									Image newImage = bgLayer.getImage();
									String newImageFileName = bgLayer.getImageFileName();
									int newTileWidth = bgLayer.getTileWidth();
									int newTileHeight = bgLayer.getTileHeight();
									float newParallaxX = bgLayer.getParallaxX();
									float newParallaxY = bgLayer.getParallaxY();
									int newTranslationX = bgLayer.getTranslationX();
									int newTranslationY = bgLayer.getTranslationY();
									int[][] newBGTileMatrix = Main.getLayerTileMatrix( room, layerInx );
									ColorTile[][] newBGTileColorMatrix = Main.getLayerTileColorMatrix( room, layerInx );
									
									undoOp.add(
										new UndoImpl.EditBGLayer(
											globalEditorModel,
											room,
											layerInx,
											bgLayer,
											oldImage, newImage,
											oldImageFileName, newImageFileName,
											oldTileWidth, newTileWidth,
											oldTileHeight, newTileHeight,
											oldParallaxX, newParallaxY,
											oldParallaxY, newParallaxX,
											oldTranslationX, newTranslationX,
											oldTranslationY, newTranslationY,
											oldBGTileMatrix, newBGTileMatrix,
											oldBGTileColorMatrix, newBGTileColorMatrix) );
									
									// Commit undo operation:
									HistoryManager.addUndoOperation(
										undoOp,
										"edit BG layer " + layerInx );
									
									globalEditorModel.setUnsavedChanges( true );
								}
							}
						} );
					btn.setToolTipText( "Edit background layer parameters" );
					
					hBox.add( Box.createHorizontalGlue() );
					
					btn = new JButton( "Delete" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					hBox.add( btn );
					btn.setActionCommand( Integer.toString(i) );
					btn.addActionListener(
						new ActionListener () {
							public void actionPerformed ( ActionEvent evt ) {
								int layerInx = Integer.parseInt( evt.getActionCommand() );
								
								int option = JOptionPane.showConfirmDialog(
									Main.f,                                // parent dialog
									"Are you sure?",                       // message
									"Delete background layer " + layerInx, // title
									JOptionPane.YES_NO_OPTION,             // option type
									JOptionPane.QUESTION_MESSAGE );        // message type
						
								if ( option == JOptionPane.YES_OPTION ) {
									// User confirmed.
									UndoImpl.Composite undoOp = new UndoImpl.Composite();
									
									// Unselect everything:
									if ( globalEditorModel.isSelectionFloating() ) {
										SelectionSet selection = globalEditorModel.getSelectionSet().clone();
										
										Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										globalEditorModel.defloatSelection();
										Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										
										undoOp.add(
											new UndoImpl.DefloatSelection(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
												globalEditorModel.getWorkingLayer(),
												oldState,
												newState,
												selection ) );
									}
									if ( globalEditorModel.getSelectionSet() != null ) {
										SelectionSet oldSelection = globalEditorModel.getSelectionSet();
										boolean oldFloating = globalEditorModel.isSelectionFloating();
										
										globalEditorModel.setSelectionSet(null, false);
										
										undoOp.add(
											new UndoImpl.SelectionSetChanged(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(oldSelection),
												globalEditorModel.getWorkingLayer(),
												oldSelection,
												globalEditorModel.getSelectionSet(),
												oldFloating,
												globalEditorModel.isSelectionFloating() ) );
									}
									
									// Delete the layer:
									Room room = globalEditorModel.getLoadedRoom();
									BGLayer bgLayer = room.getBGLayer( layerInx );
									int[][] oldBGTileMatrix = Main.getLayerTileMatrix( room, layerInx );
									ColorTile[][] oldBGTileColorMatrix = Main.getLayerTileColorMatrix( room, layerInx );
									int oldDefObjLayer = room.getDefaultObjLayer();
									
									room.removeBGLayer( layerInx );
									
									int newDefObjLayer = room.getDefaultObjLayer();
									
									undoOp.add(
										new UndoImpl.DeleteBGLayer(
											globalEditorModel,
											room,
											layerInx,
											bgLayer,
											oldBGTileMatrix,
											oldBGTileColorMatrix,
											oldDefObjLayer,
											newDefObjLayer ) );
									
									// Commit undo operation:
									HistoryManager.addUndoOperation(
										undoOp,
										"delete BG layer " + layerInx );
									
									globalEditorModel.setUnsavedChanges( true );
									
									if ( layerInx == room.getNumOfBGLayers() )
										globalEditorModel.setWorkingLayer( layerInx - 1 );
									else
										globalEditorModel.setWorkingLayer( layerInx );
								}
							}
						} );
					btn.setToolTipText( "Delete background layer" );
					
					hBox.add( Box.createHorizontalGlue() );
					
					btn = new JButton( ">" );
					btn.setAlignmentX( 0 );
					btn.setAlignmentY( 0 );
					hBox.add( btn );
					if ( i == room.getNumOfBGLayers() - 1 )
						btn.setEnabled( false );
					else {
						btn.setActionCommand( Integer.toString(i) );
						btn.addActionListener(
							new ActionListener () {
								public void actionPerformed ( ActionEvent evt ) {
									UndoImpl.Composite undoOp = new UndoImpl.Composite();
									
									// Unselect everything:
									if ( globalEditorModel.isSelectionFloating() ) {
										int layerInx = globalEditorModel.getWorkingLayer();
										SelectionSet selection = globalEditorModel.getSelectionSet().clone();
										
										Object oldState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										globalEditorModel.defloatSelection();
										Object newState = globalEditorModel.getSelectionSet().makeBackUpOfState(globalEditorModel, layerInx);
										
										undoOp.add(
											new UndoImpl.DefloatSelection(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(globalEditorModel.getSelectionSet()),
												layerInx,
												oldState,
												newState,
												selection ) );
									}
/*									if ( globalEditorModel.getSelectionSet() != null || !globalEditorModel.getSelectionSet().survivesLayerChange() ) {
										SelectionSet oldSelection = globalEditorModel.getSelectionSet();
										boolean oldFloating = globalEditorModel.isSelectionFloating();
										
										globalEditorModel.setSelectionSet(null, false);
										
										undoOp.add(
											new UndoImpl.SelectionSetChanged(
												globalEditorModel,
												toolBar,
												ToolBar.getSelectionToolIndex(oldSelection),
												globalEditorModel.getWorkingLayer(),
												oldSelection,
												globalEditorModel.getSelectionSet(),
												oldFloating,
												globalEditorModel.isSelectionFloating() ) );
									}*/
									
									// Swap layers:
									int layerInx = Integer.parseInt( evt.getActionCommand() );
									Room room = globalEditorModel.getLoadedRoom();
									
									room.swapBGLayers( layerInx, layerInx + 1 );
									
									undoOp.add(
										new UndoImpl.SwapBGLayerDepth(
											globalEditorModel,
											room,
											layerInx, layerInx + 1 ) );
									
									// Commit undo operation:
									HistoryManager.addUndoOperation(
										undoOp,
										"send layer backwards" );
									
									globalEditorModel.setUnsavedChanges( true );
									
									// Keep layer focused:
									setSelectedIndex( (layerInx + 1) + 1 );
								}
							} );
					}
					btn.setToolTipText( "Send layer backwards" );
				}
				bgInfoPanel.add( hBox );
				
				bgInfoPanel.add( new BGLayerInfoPanel( room.getBGLayer( i ) ) );
			}
			
			this.addTab(
				tabTitle,
				null,
				bgInfoPanel,
				tipText );
		}
		
		setSelectedIndex( globalEditorModel.getWorkingLayer() + 1 );
		
		this.setMaximumSize(
			new Dimension(
				Integer.MAX_VALUE,
				this.getPreferredSize().height ) );
		
	}
	
}
