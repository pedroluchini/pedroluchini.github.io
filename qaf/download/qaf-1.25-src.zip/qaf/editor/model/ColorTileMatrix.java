/*
 * Created on Jun 16, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package model;

import control.Main;

public class ColorTileMatrix implements AbstractTileMatrix {
	
	private ColorTile[][] tileMatrix = null;
	private int origRow, origCol;
	
	
	
	
	public ColorTileMatrix ( ColorTile[][] tileMatrix, int origRow, int origCol ) {
		this.origCol = origCol;
		this.origRow = origRow;
		
		if ( tileMatrix != null ) {
			int rows = tileMatrix.length;
			int cols = tileMatrix[0].length;
			
			this.tileMatrix = new ColorTile[rows][cols];
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ )
					this.tileMatrix[i][j] = tileMatrix[i][j];
		}
	}
	
	
	
	
	public int getNumOfRows () {
		if ( tileMatrix == null )
			return 0;
		else
			return tileMatrix.length;
	}
	
	
	
	
	public int getNumOfCols () {
		if ( tileMatrix == null )
			return 0;
		else
			return tileMatrix[0].length;
	}
	
	
	
	
	public int getOrigRow () {
		return origRow;
	}
	
	
	
	
	public int getOrigCol () {
		return origCol;
	}
	
	
	
	
	public ColorTile getTileAtBrushCoords ( int row, int col ) {
		return tileMatrix[row][col];
	}
	
	
	
	
	public ColorTile getTileAtGlobalCoords ( int row, int col ) {
		// Displace coords. so they're relative to the brush:
		row -= origRow;
		col -= origCol;
		
		if ( row < 0 || row >= getNumOfRows() ||
		     col < 0 || col >= getNumOfCols() )
			return null;
		else
			return tileMatrix[row][col];
	}
	
	
	
	
	public void setTileAtGlobalCoords ( int row, int col, ColorTile tile ) {
		// Unsetting a tile? 
		if ( tile == null ) {
			unsetTileAtGlobalCoords( row, col );
			return;
		}
		
		// The brush is empty?
		if ( tileMatrix == null ) {
			// Create new matrix, and that's it.
			tileMatrix = new ColorTile[1][1];
			tileMatrix[0][0] = tile;
			origRow = row;
			origCol = col;
			
			return;
		}
		
		// Brush needs to be extended?
		if ( row < origRow ) {
			// To the top...
			ColorTile[][] newTileMatrix = new ColorTile[(origRow - row) + getNumOfRows()][getNumOfCols()];
			Main.fillMatrix( newTileMatrix, null );
			
			Main.blitMatrix( newTileMatrix, tileMatrix, (origRow - row), 0 );
			
			tileMatrix = newTileMatrix;
			origRow = row;
		}
		else
		if ( row >= origRow + getNumOfRows() ) {
			// To the bottom...
			ColorTile[][] newTileMatrix = new ColorTile[row - origRow + 1][getNumOfCols()];
			Main.fillMatrix( newTileMatrix, null );
			
			Main.blitMatrix( newTileMatrix, tileMatrix, 0, 0 );
			
			tileMatrix = newTileMatrix;
		}
		
		if ( col < origCol ) {
			// To the left...
			ColorTile[][] newTileMatrix = new ColorTile[getNumOfRows()][(origCol - col) + getNumOfCols()];
			Main.fillMatrix( newTileMatrix, null );
			
			Main.blitMatrix( newTileMatrix, tileMatrix, 0, (origCol - col) );
			
			tileMatrix = newTileMatrix;
			origCol = col;
		}
		else
		if ( col >= origCol + getNumOfCols() ) {
			// To the right...
			ColorTile[][] newTileMatrix = new ColorTile[getNumOfRows()][col - origCol + 1];
			Main.fillMatrix( newTileMatrix, null );
			
			Main.blitMatrix( newTileMatrix, tileMatrix, 0, 0 );
			
			tileMatrix = newTileMatrix;
		}
		
		// Displace coords. so they're relative to the brush:
		row -= origRow;
		col -= origCol;
		
		tileMatrix[row][col] = tile;
	}
	
	
	
	
	public void setTileAtBrushCoords ( int row, int col, ColorTile tile ) {
		setTileAtGlobalCoords( row + origRow, col + origCol, tile );
	}
	
	
	
	
	public void unsetTileAtGlobalCoords ( int row, int col ) {
		// Ignore if coordinates outside of matrix:
		if ( row < origRow || row >= origRow + getNumOfRows() ||
		     col < origCol || col >= origCol + getNumOfCols() )
			return;
		
		// Displace coords. so they're relative to the brush:
		row -= origRow;
		col -= origCol;
		
		tileMatrix[row][col] = null;
		
		// Was that the last tile in the brush?
		boolean lastTile = true;
		for (int i = 0; i < tileMatrix.length; i++) {
			for (int j = 0; j < tileMatrix[0].length; j++) {
				if (tileMatrix[i][j] != null) {
					lastTile = false;
					break;
				}
			}
		}
		
		if (lastTile) {
			// We now have an amepty brush:
			tileMatrix = null;
			return;
		}
		
		
		// Brush needs to be shrunk?
		boolean leftmost = (col == 0),
		        rightmost = (col == tileMatrix[0].length - 1),
		        topmost = (row == 0),
		        bottmost = (row == tileMatrix.length - 1);
		
		if (leftmost) {
			int i, j;
LEFTMOST_LABEL:
			for (j = 0; j < tileMatrix[0].length; j++)
				for (i = 0; i < tileMatrix.length; i++)
					if (tileMatrix[i][j] != null)
						break LEFTMOST_LABEL;
			
			ColorTile[][] newBrush = new ColorTile[tileMatrix.length][tileMatrix[0].length - j];
			Main.blitMatrix(newBrush, tileMatrix, 0, -j);
			tileMatrix = newBrush;
			origCol += j;
		}
		else if (rightmost) {
			int i, j;
RIGHTMOST_LABEL:
			for (j = tileMatrix[0].length - 1; j >= 0; j--)
				for (i = 0; i < tileMatrix.length; i++)
					if (tileMatrix[i][j] != null)
						break RIGHTMOST_LABEL;
			
			ColorTile[][] newTileMatrix = new ColorTile[tileMatrix.length][j + 1];
			Main.blitMatrix(newTileMatrix, tileMatrix, 0, 0);
			tileMatrix = newTileMatrix;
		}
		
		if (topmost) {
			int i, j;
TOPMOST_LABEL:
			for (i = 0; i < tileMatrix.length; i++)
				for (j = 0; j < tileMatrix[0].length; j++)
					if (tileMatrix[i][j] != null)
						break TOPMOST_LABEL;
			
			ColorTile[][] newBrush =
				new ColorTile[tileMatrix.length - i][tileMatrix[0].length];
			Main.blitMatrix(newBrush, tileMatrix, -i, 0);
			tileMatrix = newBrush;
			origRow += i;
		}
		else if (bottmost) {
			int i, j;
BOTTMOST_LABEL:
			for (i = tileMatrix.length - 1; i >= 0; i--)
				for (j = 0; j < tileMatrix[0].length; j++)
					if (tileMatrix[i][j] != null)
						break BOTTMOST_LABEL;
			
			ColorTile[][] newTileMatrix = new ColorTile[i + 1][tileMatrix[0].length];
			Main.blitMatrix(newTileMatrix, tileMatrix, 0, 0);
			tileMatrix = newTileMatrix;
		}
	}
	
	
	
	
	public void unsetTileAtBrushCoords ( int row, int col ) {
		unsetTileAtGlobalCoords( row + origRow, col + origCol );
	}
	
	
	
	
	public void clearBrush () {
		tileMatrix = null;
		origCol = origRow = 0;
	}
	
	
	
	
	public void flip ( boolean horizontally, boolean vertically ) {
		if ( tileMatrix == null )
			return;
		
		// Build brush with the same size:
		ColorTile[][] newTileMatrix = new ColorTile[tileMatrix.length][tileMatrix[0].length];
		
		// Copy:
		for ( int i = 0; i < tileMatrix.length; i++ ) {
			for ( int j = 0; j < tileMatrix[i].length; j++ ) {
				int iInx = (vertically ? (tileMatrix.length    - i - 1) : i);
				int jInx = (horizontally ? (tileMatrix[i].length - j - 1) : j);
				
				ColorTile tileID = tileMatrix[iInx][jInx];
				
				// The tileID needs to be flipped?
				if ( tileID != null ) {
					tileID = tileID.makeFlippedClone( horizontally, vertically );
				}
				
				newTileMatrix[i][j] = tileID;
			}
		}
		
		// Done!
		tileMatrix = newTileMatrix;
	}
	
	
	
	
	public void setOrigin ( int origRow, int origCol ) {
		this.origRow = origRow;
		this.origCol = origCol;
	}
	
	
	
	
	public void setOrigRow ( int origRow ) {
		this.origRow = origRow;
	}
	
	
	
	
	public void setOrigCol ( int origCol ) {
		this.origCol = origCol;
	}
	
	
	
	
	public ColorTileMatrix clone () {
		return new ColorTileMatrix( this.tileMatrix, this.origRow, this.origCol );
	}
	
	
	
	
	public boolean isTileAtBrushCoordsSet ( int row, int col ) {
		return (getTileAtBrushCoords(row, col) != null);
	}
	
	public boolean isTileAtGlobalCoordsSet ( int row, int col ) {
		return (getTileAtGlobalCoords(row, col) != null);
	}
	
}
