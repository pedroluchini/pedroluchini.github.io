/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_OBJ_SPRITEPARTICLEOBJ_H
#define QAF_OBJ_SPRITEPARTICLEOBJ_H

#include "../qafGameObj.h"
#include <hgesprite.h>

namespace qaf {
	
	/**
	 * This is an object that renders itself as a sprite, with optional
	 * linear/angular speeds. Its size and color values are interpolated 
	 * linearly between the creation time and the <tt>lifetime</tt> parameter.
	 * 
	 * The <tt>size</tt> parameter is used to scale the sprite when rendered.
	 * If you want the sprite at its original size, use 1.0.
	 * 
	 * When its lifetime has expired, the object will remove itself from the
	 * <tt>Environment</tt>.
	 * 
	 * The <tt>sprite</tt> object is not deleted. You are responsible for
	 * managing that pointer.
	 * 
	 * @see qaf::AnimParticleObj
	 */
	class SpriteParticleObj : public GameObj {
		public:
			
			/**
			 * @param sprite       The sprite used to render this particle.
			 * @param x            The object's initial X position.
			 * @param y            The object's initial Y position.
			 * @param angle        The object's initial rotation.
			 * @param vx           The object's X speed (pixels/second).
			 * @param vy           The object's Y speed (pixels/second).
			 * @param vr           The object's angular speed (radians/second).
			 * @param ax           The object's X acceleration (pixels/second<sup>2</sup>).
			 * @param ay           The object's Y acceleration (pixels/second<sup>2</sup>).
			 * @param initialSize  The sprite's initial scale.
			 * @param finalSize    The sprite's scale when it is about to die.
			 * @param initialColor The sprite's initial color.
			 * @param finalColor   The sprite's color when it is about to die.
			 * @param blendMode    The blend mode used to render the sprite.
			 * @param lifetime     The object's lifetime, in seconds. 
			 */
			SpriteParticleObj (
				hgeSprite * sprite,
				float x, float y,
				float angle,
				float vx, float vy,
				float vr,
				float ax, float ay,
				float initialSize, float finalSize,
				DWORD initialColor, DWORD finalColor,
				DWORD blendMode,
				float lifetime );
			
			
			void update ( int objLayer, float dt );
			void render ( int objLayer, float scrollX, float scrollY );
			
		private:
			hgeSprite * sprite;
			float x, y, angle, vx, vy, vr, ax, ay, initialSize, finalSize, lifetime;
			int initialR, initialG, initialB, initialA;
			int deltaR, deltaG, deltaB, deltaA;
			DWORD blendMode;
			float timer;
	};
	
}



#endif

