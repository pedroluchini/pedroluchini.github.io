#include <hge.h>
#include <hgeresource.h>
#include <qafEnvironment.h>

using namespace qaf;

HGE * hge = NULL;
hgeResourceManager * pResManager = NULL;

#define SHIP_ACCEL         800.0f
#define SHIP_TOPSPEED      200.0f
#define SHIP_ANGSPEED        2.0f
#define MISSILE_SPEED      400.0f
#define MINE_ROTSPEED        2.0f


class SpaceMineObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Mine sprite
		Vector2D    m_pos;    // Mine position
		float       m_size;   // Mine scaling
		
	public:
		SpaceMineObj ( Vector2D pos, float size ) {
			m_pos = pos;
			m_size = size;
			m_sprite = pResManager->GetSprite( "sprMine" );
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Render the mine, slowly rotating...
			m_sprite->RenderEx(
				m_pos.x - scrollX, m_pos.y - scrollY,
				MINE_ROTSPEED * Environment::time,
				m_size, m_size );
		}
};



class MissileObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Missile sprite
		Vector2D    m_pos;    // Missile position
		Vector2D    m_vel;    // Missile velocity
	
	public:
		// Constructor:
		MissileObj ( Vector2D pos, Vector2D vel ) {
			m_pos = pos;
			m_vel = vel;
			m_sprite = pResManager->GetSprite( "sprMissile" );
		}
		
		void update ( int objLayer, float dt ) {
			// Move the missile:
			m_pos += m_vel * dt;
			
			// Check if the missile has left the room's area.
			Room * pRoom = Environment::getLoadedRoom();
			if ( m_pos.x < 0 || m_pos.x > pRoom->getPixelWidth() ||
			     m_pos.y < 0 || m_pos.y > pRoom->getPixelHeight() ) {
				// The missile has left the room!
				// We can remove it from the game and delete it permanently.
				Environment::removeGameObj( this, true );
			}
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Since the missile sprite is pointing upwards, let's get the
			// relative angle between the velocity and a vector pointing up.
			Vector2D vUp = Vector2D(0, -1);
			float rot = vUp.angle( m_vel );
			
			// Render it:
			m_sprite->RenderEx( m_pos.x - scrollX, m_pos.y - scrollY, rot );
		}
};



class ShipObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Ship sprite
		Vector2D    m_pos;    // Ship position
		Vector2D    m_vel;    // Ship velocity
		Vector2D    m_dir;    // Ship direction (unit vector)
	public:
		// Constructor:
		ShipObj ( Vector2D pos, Vector2D dir ) {
			m_pos = pos;
			m_vel = Vector2D(0, 0);
			m_dir = dir.unit(); // Make sure it's a unit vector!
			m_sprite = pResManager->GetSprite( "sprShip" );
		}
		
		void update ( int objLayer, float dt ) {
			// Calculate acceleration:
			Vector2D accel = Vector2D(0, 0);
			
			if ( hge->Input_GetKeyState( HGEK_UP ) )
				accel += m_dir * SHIP_ACCEL;
			
			if ( hge->Input_GetKeyState( HGEK_DOWN ) )
				accel -= m_dir * SHIP_ACCEL;
			
			// Move:
			m_pos += m_vel * dt + 0.5f * accel * dt * dt;
			
			// Update velocity:
			m_vel += accel * dt;
			
			if ( m_vel.length() > SHIP_TOPSPEED )
				m_vel = m_vel.unit() * SHIP_TOPSPEED;
			
			// Rotate clockwise?
			if ( hge->Input_GetKeyState( HGEK_RIGHT ) ) {
				m_dir = m_dir.rotate( SHIP_ANGSPEED * dt );
				m_dir.normalize(); // Prevent floating-point precision errors
			}
			
			// Rotate counter-clockwise?
			if ( hge->Input_GetKeyState( HGEK_LEFT ) ) {
				m_dir = m_dir.rotate( -SHIP_ANGSPEED * dt );
				m_dir.normalize(); // Prevent floating-point precision errors
			}
			
			// Check if the ship has left the playfield.
			Room * pRoom = Environment::getLoadedRoom();
			if ( m_pos.x < 50 ) {
				m_pos.x = 50.0f;
				m_vel.x = 0;
			}
			
			if ( m_pos.x > pRoom->getPixelWidth() - 50 ) {
				m_pos.x = (float) (pRoom->getPixelWidth() - 50);
				m_vel.x = 0;
			}
			
			if ( m_pos.y < 50 ) {
				m_pos.y = 50.0f;
				m_vel.y = 0;
			}
			
			if ( m_pos.y > pRoom->getPixelHeight() - 50 ) {
				m_pos.y = (float) (pRoom->getPixelHeight() - 50);
				m_vel.y = 0;
			}
			
			// Force scrolling to follow the ship:
			Environment::centerScrollingPoint( (int) m_pos.x, (int) m_pos.y );
			
			// Shoot a missile?
			if ( hge->Input_GetKey() == HGEK_SPACE ) {
				// Create a new missile object and put it in the Environment.
				Environment::addGameObj( new MissileObj( m_pos, m_dir * MISSILE_SPEED ) );
			}
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Since the ship sprite is pointing upwards, let's get the
			// relative angle between the direction and a vector pointing up.
			Vector2D vUp = Vector2D(0, -1);
			float rot = vUp.angle( m_dir );
			
			// Render it:
			m_sprite->RenderEx( m_pos.x - scrollX, m_pos.y - scrollY, rot );
		}
};



// Game object factory implementation:
class GameObjFactoryImpl : public GameObjFactory {
	public:
		GameObj * createObject ( std::string & objID, int objX, int objY, AttributeTable & attributes ) {
			// Which object ID?
			if ( objID == "ShipObj" ) {
				// Create ship at (objX, objY) coordinates, facing up:
				return new ShipObj( Vector2D(objX, objY), Vector2D(0, -1) );
			}
			else
			if ( objID == "SpaceMineObj" ) {
				// Get "size" attribute, and convert it to a floating point
				// number:
				float fSize = (float) atof( attributes["size"].c_str() );
				
				// Could not convert?
				if ( fSize == 0.0f )
					fSize = 1.0f;
				
				// Create mine at (objX, objY), scaled by fSize:
				return new SpaceMineObj( Vector2D(objX, objY), fSize );
			}
			else
				// Unknown ID:
				return NULL;
		}
};



// The frame function:
bool frameFunction () {
	// Output text:
	Environment::cout << hge->Timer_GetFPS() << " FPS\n";
	Environment::cout << "Use UP, DOWN, LEFT, RIGHT to move the ship. Press SPACE to shoot.\n";
	
	// Perform Qaf's game loop:
	Environment::update( hge->Timer_GetDelta() );
	
	if ( hge->Input_GetKeyState( HGEK_ESCAPE ) )
		return true;
	
	return false;
}




// Application entry point:
int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ) {
	
	// Set up HGE:
	hge = hgeCreate( HGE_VERSION );
	
	hge->System_SetState( HGE_FRAMEFUNC,     frameFunction );
	hge->System_SetState( HGE_FPS,           HGEFPS_UNLIMITED );
	hge->System_SetState( HGE_SCREENWIDTH,   640 );
	hge->System_SetState( HGE_SCREENHEIGHT,  480 );
	hge->System_SetState( HGE_WINDOWED,      true );
	
	if ( !hge->System_Initiate() )
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	
	// Load resources:
	pResManager = new hgeResourceManager( "tut04sprites.txt" );
	
	// Set up the environment:
	Environment::initialize( false, true );
	
	// Load the room:
	Environment::loadRoom( "tut04.qr" );
	
	// "Hey, Qaf, this is what you should use to create game objects":
	Environment::setGameObjFactory( new GameObjFactoryImpl() );
	
	// Start the game loop:
	if ( !hge->System_Start() ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	}
	
	// Shutdown:
	Environment::shutdown();
	hge->System_Shutdown();
	hge->Release();
	
	return 0;
}



/**
@page tutorial04 Tutorial 4 - Spawn Points and Factories

Continuing from \ref tutorial03, we will add space mines to the playfield.

@section tut04s01 The Mine Class

Let's start by programming the space mine class. (Note: I added a sprite,
called "sprMine," to the resource script.) If you followed the last tutorial,
there shouldn't be anything surprising here:

@code
#define MINE_ROTSPEED  2.0f
@endcode
@code
class SpaceMineObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Mine sprite
		Vector2D    m_pos;    // Mine position
		float       m_size;   // Mine scaling
		
	public:
		SpaceMineObj ( Vector2D pos, float size ) {
			m_pos = pos;
			m_size = size;
			m_sprite = pResManager->GetSprite( "sprMine" );
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Render the mine, slowly rotating...
			m_sprite->RenderEx(
				m_pos.x - scrollX, m_pos.y - scrollY,
				MINE_ROTSPEED * Environment::time,
				m_size, m_size );
		}
};
@endcode

It is possible to simply insert space mines into the playfield by using
<tt>Environment::addGameObj()</tt>, but that's tedious and error-prone.
Instead, we will use the Room Editor to tell Qaf where it should create
mines; that way, we'll know exactly where they will appear.

@section tut04s02 Object Spawn Points

Open the room from the last tutorial, <b>tut03.qr</b>, in the Room Editor.
From the <b>Room</b> menu, choose <b>New game object</b> and you should see
this dialog:

<center>
@image html tut04newobjdlg.png
</center>

Type "SpaceMineObj" in the <b>Object ID</b> field, then double-click on
<b>(New value...)</b> in the attribute table. Type "size" as the key and 
"1.0" as the value, then click <b>OK</b>.

<center>
@image html tut04objattributes.png
</center>

Click <b>OK</b> in the <b>New game object</b> dialog, and you'll see a small
red square attached to the mouse cursor. Left-click anywhere on the room to
release it. You've determined the first mine's spawn point!

Right-click on the red square, and choose <b>Clone game object</b> from the
pop-up menu. Place the cloned object and right-click on it, then choose
<b>Edit game object</b>. Double-click on the "size" attribute and change its
value to "2.5" so the second mine will appear bigger than the first.

Repeat the process as many times as you want, changing the value of "size"
so the playfield will have lots of mines with different sizes.

Now, go to <b>Room -> New game object</b> again, but this time type
"ShipObj" as the object's ID. Click <b>OK</b> and place the ship at the
center of the room.

<center>
@image html tut04roomfinished.png
</center>

Save it as <b>tut04.qr</b> and close the Room Editor.

Everything we've written so far is just a bunch of strings, which are
meaningless to Qaf. We'll have to somehow translate this data into actual
<tt>GameObj</tt> instances.

@section tut04s03 The Game Object Factory

<tt>qaf::GameObjFactory</tt> is an abstract class with just one method:

@code
qaf::GameObj* qaf::GameObjFactory::createObject ( std::string & objID,
                                                  int objX,
                                                  int objY,
                                                  qaf::AttributeTable & attributes );
@endcode

Its parameters include everything you defined in the Room Editor: ID,
position, and attributes. There's nothing Qaf can do with these values, so
it's up to us to decode them and create a <tt>GameObj</tt>.

@code
// Game object factory implementation:
class GameObjFactoryImpl : public GameObjFactory {
	public:
		GameObj * createObject ( std::string & objID, int objX, int objY, AttributeTable & attributes ) {
			// Which object ID?
			if ( objID == "ShipObj" ) {
				// Create ship at (objX, objY) coordinates, facing up:
				return new ShipObj( Vector2D(objX, objY), Vector2D(0, -1) );
			}
			else
			if ( objID == "SpaceMineObj" ) {
				// Get "size" attribute, and convert it to a floating point
				// number:
				float fSize = (float) atof( attributes["size"].c_str() );
				
				// Could not convert?
				if ( fSize == 0.0f )
					fSize = 1.0f;
				
				// Create mine at (objX, objY), scaled by fSize:
				return new SpaceMineObj( Vector2D(objX, objY), fSize );
			}
			else
				// Unknown ID:
				return NULL;
		}
};
@endcode

@section tut04s04 Bringing It All Together

Rather than creating the space ship through
<tt>Environment::addGameObj()</tt>, we will now let our factory take care of
object creation. In <tt>WinMain</tt>:

@code
	// Load the room:
	Environment::loadRoom( "tut04.qr" );
	
	// "Hey, Qaf, this is what you should use to create game objects":
	Environment::setGameObjFactory( new GameObjFactoryImpl() );
	
	// Start the game loop:
	if ( !hge->System_Start() ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	}
@endcode

See the full source code for this tutorial in the file: <b>tutorials/tutorial04.cpp</b>

*/
