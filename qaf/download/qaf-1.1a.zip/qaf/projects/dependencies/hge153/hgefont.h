/*
** Haaf's Game Engine 1.5
** Copyright (C) 2003-2004, Relish Games
** hge.relishgames.com
**
** hgeFont helper class header
*/


#ifndef HGEFONT_H
#define HGEFONT_H


#include "hge.h"
#include "hgesprite.h"


#define HGETEXT_LEFT	0
#define HGETEXT_RIGHT	1
#define HGETEXT_CENTER	2

/*
** HGE Font class
*/
class hgeFont
{
public:
	hgeFont(const char *filename);
	hgeFont(const hgeFont &fnt);
	~hgeFont();

	hgeFont&	operator= (const hgeFont &fnt);

	void		Render(float x, float y, const char *string, int align=HGETEXT_LEFT);
	void		printf(float x, float y, const char *format, ...);

	void		SetColor(DWORD col);
	void		SetZ(float z);
	void		SetBlendMode(int blend);
	void		SetScale(float scale) {fScale=scale;}
	void		SetRotation(float rot) {fRot=rot;}
	void		SetTracking(float tracking) {fTracking=tracking;}

	DWORD		GetColor() const {return dwCol;}
	float		GetZ() const {return fZ;}
	int			GetBlendMode() const {return nBlend;}
	float		GetScale() const {return fScale;}
	float		GetRotation() const {return fRot;}
	float		GetTracking() const {return fTracking;}

	hgeSprite*	GetSprite(char chr) const { return letters[chr]; }
	float		GetHeight() const { return fHeight; }
	float		GetStringWidth(const char *string) const;

private:
	hgeFont();
	char*		_skip_token(char *szStr);

	static HGE	*hge;

	HTEXTURE	hTexture;
	hgeSprite*	letters[256];
	float		fHeight;
	float		fScale, fRot;
	float		fTracking;

	DWORD		dwCol;
	float		fZ;
	int			nBlend;
};


#endif
