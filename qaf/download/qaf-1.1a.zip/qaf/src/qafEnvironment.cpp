/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <hge.h>
#include <hgedistort.h>
#include <hgefont.h>

#include <qafEnvironment.h>
#include <qafDef.h>
#include <qafutil/qafIntegerInputStream.h>


using namespace std;
using namespace qaf;


///////////////////////////////////////////////////////////////////////////////
// 
// Public members:
// 
///////////////////////////////////////////////////////////////////////////////

float Environment::time   = 0;
int   Environment::frames = 0;


///////////////////////////////////////////////////////////////////////////////
// 
// Private members:
// 
///////////////////////////////////////////////////////////////////////////////

Container<Container<GameObj *> *>                  Environment::gameObjLayers;
Container<Environment::AbstractObjDiscriminator *> Environment::objDiscriminators;
Container<Environment::AbstractCollisionHandler *> Environment::collisionHandlers;



///////////////////////////////////////////////////////////////////////////////
// 
// Global static variables:
// 
///////////////////////////////////////////////////////////////////////////////

// The HGE pointer:
static HGE * hge = 0;

// Debug data:
static bool      useDebug    = false;

// The font used to render the DebugConsole:
static hgeFont * consoleFont = NULL;

// Resources for rendering water effects:
static HTEXTURE            waterTexture = NULL;
static hgeQuad             waterQuad;
static hgeDistortionMesh * waterMesh    = NULL;

// The factory being used to spawn GameObjs.
static GameObjFactory * gameObjFactory = NULL;

// The Joystick system managed by the Environment:
static JoystickSystem * joystickSystem = NULL;

// Backbuffer data:
static bool     useBackBuffer = false;
static HTARGET  backBuffer    = NULL;
static hgeQuad  backQuad;

// The quick'n'dirty flags:
static bool     objUpdateEnabled = true;
static bool     renderEnabled    = true;

// Loaded room data:
static Room *      loadedRoom     = NULL;

// The scrolling point:
static int scrollingX = 0;
static int scrollingY = 0;

// Frame callbacks:
static void (*prologueCallback) () = NULL;
static void (*epilogueCallback) () = NULL;

// Temporary storage space for non-volatile objects, as they wait for
// re-insertion:
static Container<GameObj *> tempNonVolatileStorage;

// Operation buffers, as they wait for the next frame:
struct BufferedObjInfo {
	string id;
	int x, y;
	AttributeTable attributes;
};

struct BufferedOperation {
	enum {
		ADDGAMEOBJ,
		REMOVEGAMEOBJ,
		BRINGGAMEOBJTOFRONT,
		SENDGAMEOBJTOBACK,
		UNLOADROOM,
		LOADROOM,
	} type;
	
	union {
		struct {
			GameObj * obj;
			int layerInx;
			bool onTop;
		} addGameObjData;
		
		struct {
			GameObj * obj;
			bool deleteIt;
			int layerInx;
		} removeGameObjData;
		
		struct {
			GameObj * obj;
			int layerInx;
		} bringGameObjToFrontData;
		
		struct {
			GameObj * obj;
			int layerInx;
		} sendGameObjToBackData;
		
		struct {
		} unloadRoomData;
		
		struct {
			Room * room;
			Container<BufferedObjInfo *> * objs;
		} loadRoomData;
	} data;
};

static Container<BufferedOperation> operationBuffer;

// The BigTexture cache:
// Entries are stored in access-time-order, i.e., the most recently loaded is at
// the tail, and the least recently freed is at the head.
struct BTCacheEntry {
	BigTexture * tex;
	string       name;
	int          refCounter;
};

static Container<BTCacheEntry> bigTexCache;
static int bigTexCacheSize = QAF_DEFAULT_TEX_CACHE_SIZE;



///////////////////////////////////////////////////////////////////////////////
// 
// Public methods:
// 
///////////////////////////////////////////////////////////////////////////////

bool Environment::initialize ( bool _useBackBuffer, bool _useDebug ) {
	
	// Get an HGE pointer:
	hge = hgeCreate( HGE_VERSION );
	
	// Initialize the Environment with an empty GameObj layer:
	gameObjLayers.add( new Container<GameObj *> );
	
	// Create the backBuffer:
	enableBackBuffer( _useBackBuffer );
	
	// Create the necessary resources for drawing the water level:
	waterTexture = hge->Texture_Load( QAF_WATER_TEXTURE );
	
	waterQuad.tex   = waterTexture;
	waterQuad.blend = BLEND_COLORMUL | BLEND_ALPHABLEND | BLEND_NOZWRITE;
	
	waterMesh = new hgeDistortionMesh( QAF_REFRACTION_MESH_COLS, QAF_REFRACTION_MESH_ROWS );
	waterMesh->Clear();
	
	// Set the mesh's vertices' colors to white:
	for ( int i = 0; i < QAF_REFRACTION_MESH_ROWS; i++ ) {
		for ( int j = 0; j < QAF_REFRACTION_MESH_COLS; j++ ) {
			// Make the topmost row transparent (alpha = 0):
			if ( i == 0 )
				waterMesh->SetColor( j, i, ARGB(0, 255, 255, 255) );
			// Make all other rows opaque (alpha = 255):
			else
				waterMesh->SetColor( j, i, ARGB(255, 255, 255, 255) );
		}
	}
	
	
	// Initialize the joystick system:
	joystickSystem = new JoystickSystem();
	joystickSystem->initialize( (HWND) (hge->System_GetState( HGE_HWND ).int_value) );
	
	
	useDebug = _useDebug;
	if ( useDebug ) {
		// Create the font for the DebugConsole:
		if ( !consoleFont )
			consoleFont = new hgeFont( "qafCFont.fnt" );
	}
	
	
	// Initialization done!
	return true;
	
} // End of method: Environment::initialize




void Environment::shutdown () {
	// Unload the room:
	// This will take care of volatile objects.
	doUnloadRoom();
	
	// Delete any object layers that may have been left:
	while ( gameObjLayers.getCount() > 0 ) {
		delete gameObjLayers[0];
		gameObjLayers.remove( 0 );
	}
	
	// Delete whatever's left:
	for ( int i = 0; i < tempNonVolatileStorage.getCount(); i++ ) {
		delete tempNonVolatileStorage[i];
	}
	tempNonVolatileStorage.removeAll();
	
	// Delete all collision handlers:
	for ( int handlerInx = 0; handlerInx < collisionHandlers.getCount(); handlerInx++ )
		delete collisionHandlers[handlerInx];
	
	// Empty all object discriminators:
	for ( int discrInx = 0; discrInx < objDiscriminators.getCount(); discrInx++ )
		objDiscriminators[discrInx]->removeAll();
	
	// Delete the backbuffer:
	if ( backBuffer ) {
		hge->Target_Free( backBuffer );
		backBuffer = NULL;
	}
	
	// Delete water-related resources:
	delete waterMesh;
	waterMesh = NULL;
	
	hge->Texture_Free( waterTexture );
	waterTexture = NULL;
	
	// Release joysticks:
	delete joystickSystem;
	joystickSystem = NULL;
	
	// Remove any BigTextures left in the cache:
	for ( i = bigTexCache.getCount() - 1; i >= 0; i-- ) {
		delete bigTexCache[i].tex;
		bigTexCache.remove( i );
	}
	
	
	// Delete the font:
	if ( consoleFont ) {
		delete consoleFont;
		consoleFont = NULL;
	}
	
	// Release the HGE pointer:
	hge->Release();
	
} // End of method: Environment::shutdown





void Environment::update ( float dt ) {
	
	// 
	// OPERATION BUFFER:
	// 
	// Perform operations that were buffered since the last frame:
	doOpBuffer();
	
	
	// Update all joystick states:
	for ( int jInx = 0; jInx < joystickSystem->getNumberOfJoysticks(); jInx++ ) {
		if ( !joystickSystem->getJoystick( jInx )->poll() ) {
			// TODO: Joystick lost
		}
	}
	
	// Update environment time:
	time += dt;
	frames++;
	
	// 
	// COLLISIONS:
	// 
	if ( objUpdateEnabled ) {
		for ( int handlerInx = 0; handlerInx < collisionHandlers.getCount(); handlerInx++ )
			collisionHandlers[handlerInx]->checkCollisions();
	}
	
	
	// 
	// OPERATION BUFFER:
	// 
	// Perform operations that were buffered during collision handling:
	doOpBuffer();
	
	
	//
	// GAME OBJECTS:
	//
	// Call the update() method for every object in the Environment:
	if ( objUpdateEnabled ) {
		for ( int layerInx = gameObjLayers.getCount() - 1; layerInx >= 0; layerInx-- ) {
			for ( int i = gameObjLayers[layerInx]->getCount() - 1; i >= 0; i-- ) {
				gameObjLayers[layerInx]->elem( i )->update( layerInx, dt );
			}
		}
	}
	
	
	// 
	// OPERATION BUFFER:
	// 
	// Perform operations that were buffered during the frame's callbacks:
	doOpBuffer();
	
	
	//
	// RENDERING:
	//
	bool success;
	// Are we using a backBuffer?
	if ( backBuffer ) {
		// Render to the backBuffer first:
		success = hge->Gfx_BeginScene( backBuffer );
	}
	else {
		// Render directly to the screen:
		success = hge->Gfx_BeginScene();
	}
	
	if ( !success ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
		exit( 1 );
	}
	
	
	// Prologue, if it has been set:
	if ( prologueCallback ) {
		prologueCallback();
	}
	
	// Draw everything:
	if ( renderEnabled )
		render();
	
	
	// Epilogue, if it has been set:
	if ( epilogueCallback ) {
		epilogueCallback();
	}
	
	
	if ( useDebug ) {
		// Debug console:
		consoleFont->Render( 5, 5, const_cast<char *>(cout.getData()) );
		cout.clear();
		
		// Debug Vectors:
		for ( int i = 0; i < debugVectors.getCount(); i++ ) {
			debugVectors[i].render();
		}
		
		debugVectors.removeAll();	
	}
	
	// Do we need to swap buffers?
	if ( backBuffer ) {
		// End rendering to the backBuffer...
		hge->Gfx_EndScene();
		
		// ...and start rendering to screen:
		hge->Gfx_BeginScene();
		
		// Transfer the backBuffer's texture to a quad, and render it:
		backQuad.tex = hge->Target_GetTexture( backBuffer );
		hge->Gfx_RenderQuad( &backQuad );

		// End rendering to the screen:
		hge->Gfx_EndScene();
	}
	else
		hge->Gfx_EndScene();
	
		
} // End of method: Environment::frameFunc




void Environment::enableObjUpdate ( bool flag ) {
	objUpdateEnabled = flag;
} // End of method: Environment::enableObjUpdate




bool Environment::isObjUpdateEnabled () {
	return objUpdateEnabled;
} // End of method: Environment::objUpdateEnabled




void Environment::enableRender ( bool flag ) {
	renderEnabled = flag;
} // End of method: Environment::enableRender




bool Environment::isRenderEnabled () {
	return renderEnabled;
} // End of method: Environment::isRenderEnabled




void Environment::enableBackBuffer ( bool flag ) {
	useBackBuffer = flag;
	
	if ( !flag ) {
		// Delete the render target:
		if ( backBuffer != NULL ) {
			hge->Target_Free( backBuffer );
			backBuffer = NULL;
		}
	}
	else {
		// Create the render target:
		if ( backBuffer == NULL ) {
			int screenWidth  = hge->System_GetState( HGE_SCREENWIDTH ).int_value;
			int screenHeight = hge->System_GetState( HGE_SCREENHEIGHT ).int_value;
			
			backBuffer = hge->Target_Create( screenWidth, screenHeight, false ); // No Z-buffer
			
			if ( !backBuffer )
				return;
			
			backQuad.blend = BLEND_DEFAULT;
			
			// Top-left:
			backQuad.v[0].x = 0;
			backQuad.v[0].y = 0;
			backQuad.v[0].col = 0xFFFFFFFF;
			backQuad.v[0].tx = 0;
			backQuad.v[0].ty = 0;
			// Top-right:
			backQuad.v[1].x = (float) screenWidth;
			backQuad.v[1].y = 0;
			backQuad.v[1].col = 0xFFFFFFFF;
			backQuad.v[1].tx = (float) screenWidth / hge->Texture_GetWidth( hge->Target_GetTexture( backBuffer) );
			backQuad.v[1].ty = 0;
			// Bott-right:
			backQuad.v[2].x = (float) screenWidth;
			backQuad.v[2].y = (float) screenHeight;
			backQuad.v[2].col = 0xFFFFFFFF;
			backQuad.v[2].tx = (float) screenWidth  / hge->Texture_GetWidth( hge->Target_GetTexture( backBuffer) );
			backQuad.v[2].ty = (float) screenHeight / hge->Texture_GetHeight( hge->Target_GetTexture( backBuffer) );
			// Bott-left:
			backQuad.v[3].x = 0;
			backQuad.v[3].y = (float) screenHeight;
			backQuad.v[3].col = 0xFFFFFFFF;
			backQuad.v[3].tx = 0;
			backQuad.v[3].ty = (float) screenHeight / hge->Texture_GetHeight( hge->Target_GetTexture( backBuffer) );
			
		}
	}
} // End of method: Environment::enableBackBuffer




bool Environment::isBackBufferEnabled () {
	return useBackBuffer;
} // End of method: Environment::isBackBufferEnabled




unsigned long Environment::getBackBuffer () {
	if ( backBuffer )
		return hge->Target_GetTexture( backBuffer );
	else
		return NULL;
} // End of method: Environment::getBackBuffer




void Environment::setGameObjFactory ( GameObjFactory * _gameObjFactory ) {
	gameObjFactory = _gameObjFactory;
} // End of method: Environment::setGameObjFactory




GameObjFactory * Environment::getGameObjFactory () {
	return gameObjFactory;
} // End of method: Environment::getGameObjFactory




void Environment::setPrologueCallback ( void (*cb) () ) {
	prologueCallback = cb;
} // End of method: Environment::setPrologueCallback




void Environment::setEpilogueCallback ( void (*cb) () ) {
	epilogueCallback = cb;
} // End of method: Environment::setEpilogueCallback




bool Environment::loadRoom ( string filename ) {
	// Start by opening the file:
	IntegerInputStream file = IntegerInputStream( filename.c_str() );
	
	if ( !file.canRead() ) {
		// File not found:
		return false;
	}
	
	// Begin assembling the room:
	BufferedOperation op;
	op.type = BufferedOperation::LOADROOM;
	op.data.loadRoomData.room = NULL;
	op.data.loadRoomData.objs = new Container<BufferedObjInfo *>;
	
	try {
		// VERSION NUMBER:
		float versionNo = (float) atof( file.readNullTerminatedString().c_str() );
		if ( versionNo > QAF_VERSION ) {
			throw versionNo;
		}
		
		// ROOM HEADER:
		int blockSize       = file.readInt();
		int screenWidth     = file.readInt();
		int screenHeight    = file.readInt();
		int roomWidth       = file.readInt();
		int roomHeight      = file.readInt();
		int waterLevel      = file.readInt();
		int defaultObjLayer = file.readInt();
		int numOfGameObj    = file.readInt();
		int numOfBGLayers   = file.readInt();
		
		op.data.loadRoomData.room = new Room( blockSize, screenWidth, screenHeight, roomWidth, roomHeight, waterLevel, defaultObjLayer );
		
		// GAME OBJECTS:
		for ( int objInx = 0; objInx < numOfGameObj; objInx++ ) {
			string id = file.readNullTerminatedString();
			int x     = file.readInt();
			int y     = file.readInt();
			int numOfAttributes = file.readInt();
			
			// Read attribute table:
			AttributeTable attributes;
			for ( int attrInx = 0; attrInx < numOfAttributes; attrInx++ ) {
				string key   = file.readNullTerminatedString();
				string value = file.readNullTerminatedString();
				
				attributes[key] = value;
			}
			
			// Add this to the object info list:
			BufferedObjInfo * objInfo = new BufferedObjInfo();
			objInfo->attributes = attributes;
			objInfo->id = id;
			objInfo->x = x;
			objInfo->y = y;
			
			op.data.loadRoomData.objs->add( objInfo );
		}
		
		// OBSTACLE MATRIX:
		{
			int rows = file.readInt();
			int cols = file.readInt();
			
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ )
					op.data.loadRoomData.room->obstacleLayer.cell(i, j) = (ObstacleBlock) file.readInt(); 
		}
		
		// BG LAYERS:
		for ( int layerInx = 0; layerInx < numOfBGLayers; layerInx++ ) {
			string sourceImagePath = file.readNullTerminatedString();
			float  parallaxFactorX, parallaxFactorY;
			if ( versionNo >= 1.1f ) {
				parallaxFactorX = (float) atof( file.readNullTerminatedString().c_str() );
				parallaxFactorY = (float) atof( file.readNullTerminatedString().c_str() );
			}
			else {
				parallaxFactorX = (float) atof( file.readNullTerminatedString().c_str() );
				parallaxFactorY = parallaxFactorX;
			}
			int    tileWidth       = file.readInt();
			int    tileHeight      = file.readInt();
			int    translateX      = file.readInt();
			int    translateY      = file.readInt();
			int    rows            = file.readInt();
			int    cols            = file.readInt();
			
			BGLayer * newBGLayer = new BGLayer(
				sourceImagePath,
				tileWidth, tileHeight,
				parallaxFactorX, parallaxFactorY,
				translateX, translateY,
				rows, cols );
			
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ )
					newBGLayer->bgData.cell(i, j) = file.readInt();

			op.data.loadRoomData.room->bgLayers.add( newBGLayer );
		}
		
		// END OF FILE!
		if ( file.canRead() )
			throw IntegerInputStream::EncodingException();
		
	}
	catch ( float ) {
		// Version mismatch:
		// Delete everything...
		if ( op.data.loadRoomData.room )
			delete op.data.loadRoomData.room;
		
		for ( int i = 0; i < op.data.loadRoomData.objs->getCount(); i++ )
			delete op.data.loadRoomData.objs->elem( i );
		delete op.data.loadRoomData.objs;
		
		// Failed:
		return false;
	}
	catch ( IntegerInputStream::EncodingException ) {
		// Error loading the room:
		// Delete everything...
		if ( op.data.loadRoomData.room )
			delete op.data.loadRoomData.room;
		
		for ( int i = 0; i < op.data.loadRoomData.objs->getCount(); i++ )
			delete op.data.loadRoomData.objs->elem( i );
		delete op.data.loadRoomData.objs;
		
		// Failed:
		return false;
	}
	catch ( IntegerInputStream::EndOfFileException ) {
		// Error loading the room:
		// Delete everything...
		if ( op.data.loadRoomData.room )
			delete op.data.loadRoomData.room;
		
		for ( int i = 0; i < op.data.loadRoomData.objs->getCount(); i++ )
			delete op.data.loadRoomData.objs->elem( i );
		delete op.data.loadRoomData.objs;
		
		// Failed:
		return false;
	}
	
	operationBuffer.add( op );
	
	// Success!
	return true;
	
} // End of method: Environment::loadRoom




Room * Environment::getLoadedRoom () {
	return loadedRoom;
} // End of method: Environment::getLoadedRoom




void Environment::unloadRoom () {
	// Add this operation to the buffer:
	BufferedOperation op;
	op.type = BufferedOperation::UNLOADROOM;
	
	operationBuffer.add( op );
}




void Environment::setScrollingPoint( int x, int y ) {
	scrollingX = x;
	scrollingY = y;

	// Clamp the results to prevent the screen from showing off-room areas:
	int leftLimit, rightLimit, topLimit, bottLimit;
	if ( loadedRoom ) {
		leftLimit  = 0;
		rightLimit = loadedRoom->getPixelWidth() - loadedRoom->getScreenPixelWidth();
		topLimit   = 0;
		bottLimit  = loadedRoom->getPixelHeight() - loadedRoom->getScreenPixelHeight();
	}
	else {
		leftLimit = rightLimit = topLimit = bottLimit = 0;
	}

	if ( scrollingX < leftLimit )
		scrollingX = leftLimit;
	else if ( scrollingX > rightLimit )
		scrollingX = rightLimit;
	
	if ( scrollingY < topLimit )
		scrollingY = topLimit;
	else if ( scrollingY > bottLimit )
		scrollingY = bottLimit;
	
} // End of method: Environment::setScrollingPoint




void Environment::moveScrollingPoint ( int dx, int dy ) {
	setScrollingPoint( scrollingX + dx, scrollingY + dy );
} // End of method: Environment::moveScrollingPoint




void Environment::centerScrollingPoint ( int x, int y ) {
	if ( loadedRoom )
		setScrollingPoint(
			x - loadedRoom->getScreenPixelWidth() /2,
			y - loadedRoom->getScreenPixelHeight()/2 );
} // End of method: Environment::centerScrollingPoint




int Environment::getScrollingX () {
	return scrollingX;
} // End of method: Environment::getScrollingX




int Environment::getScrollingY () {
	return scrollingY;
} // End of method: Environment::getScrollingY




int Environment::getScreenWidth () {
	if ( loadedRoom )
		return loadedRoom->getScreenPixelWidth();
	else
		return hge->System_GetState( HGE_SCREENWIDTH ).int_value;
} // End of method: Environment::getScreenWidth




int Environment::getScreenHeight () {
	if ( loadedRoom )
		return loadedRoom->getScreenPixelHeight();
	else
		return hge->System_GetState( HGE_SCREENHEIGHT ).int_value;
} // End of method: Environment::getScreenHeight




void Environment::addGameObj ( GameObj * obj, int layer, bool onTop ) {
	// Add this operation to the buffer:
	BufferedOperation op;
	op.type = BufferedOperation::ADDGAMEOBJ;
	op.data.addGameObjData.layerInx = layer;
	op.data.addGameObjData.obj      = obj;
	op.data.addGameObjData.onTop    = onTop;
	
	operationBuffer.add( op );
	
} // End of method: Environment::addGameObj





int Environment::findGameObj ( GameObj * obj, int * index ) {
	// For every layer...
	for ( int layerInx = 0; layerInx < gameObjLayers.getCount(); layerInx++ ) {
		// Look for the object in this layer:
		int searchResult = gameObjLayers[layerInx]->indexOf( obj );
		
		// If the object was found...
		if ( searchResult != -1 ) {
			// Store its index, if possible:
			if ( index )
				*index = searchResult;
			
			// Return the layer where the object was found:
			return layerInx;
		}
	}
	
	// Object not found.
	return -1;
	
} // End of method: Environment::findGameObj





void Environment::removeGameObj ( GameObj * obj, bool deleteIt, int srcLayer ) {
	// Add this operation to the buffer:
	BufferedOperation op;
	op.type = BufferedOperation::REMOVEGAMEOBJ;
	op.data.removeGameObjData.layerInx = srcLayer;
	op.data.removeGameObjData.deleteIt = deleteIt;
	op.data.removeGameObjData.obj      = obj;
	
	operationBuffer.add( op );
	
} // End of method: Environment::removeGameObj





void Environment::moveGameObj ( GameObj * obj, int destLayer, int srcLayer ) {
	// Remove the object from its layer...
	removeGameObj( obj, false, srcLayer );
	
	// ...And add it to the destination layer:
	addGameObj( obj, destLayer );
	
} // End of method: Environment::moveGameObj




void Environment::bringGameObjToFront ( GameObj * obj, int srcLayer ) {
	// Add this operation to the buffer:
	BufferedOperation op;
	op.type = BufferedOperation::BRINGGAMEOBJTOFRONT;
	op.data.bringGameObjToFrontData.layerInx = srcLayer;
	op.data.bringGameObjToFrontData.obj      = obj;
	
	operationBuffer.add( op );
	
} // End of method: Environment::bringGameObjToFront




void Environment::sendGameObjToBack ( GameObj * obj, int srcLayer ) {
	// Add this operation to the buffer:
	BufferedOperation op;
	op.type = BufferedOperation::SENDGAMEOBJTOBACK;
	op.data.sendGameObjToBackData.layerInx = srcLayer;
	op.data.sendGameObjToBackData.obj      = obj;
	
	operationBuffer.add( op );
	
} // End of method: Environment::sendGameObjToBack




int Environment::getNumberOfJoysticks () {
	return joystickSystem->getNumberOfJoysticks();
} // End of method: Environment::getNumberOfJoysticks




Joystick * Environment::getJoystick ( int i ) {
	return joystickSystem->getJoystick( i );
} // End of method: Environment::getJoystick




const BigTexture * Environment::loadBigTexture ( const char * filename ) {
	
	// First, check if the texture has already been loaded:
	int index = -1;
	for ( int i = 0; i < bigTexCache.getCount(); i++ ) {
		// Is this the texture you're looking for?
		if ( bigTexCache[i].name == filename ) {
			// Store its index and stop the loop.
			index = i;
			break;
		}
	}
	
	// The texture was found?
	if ( index != -1 ) {
		// Get the pointer:
		BigTexture * tex = bigTexCache[index].tex;
		
		// Increment its reference counter...
		bigTexCache[index].refCounter++;
		
		// Move this texture to the tail of the cache's Container:
		bigTexCache.toEnd( index );
		
		// Return the pointer:
		return tex;
	}
	else {
		// The texture was not found.
		// Load it!
		BigTexture * tex = new BigTexture( filename );
		
		// Now... Insert it into the cache.
		BTCacheEntry entry;
		entry.tex = tex;
		entry.name = filename;
		entry.refCounter = 1;
		bigTexCache.add( entry );
		
		// After all is done... Enforce the cache size:
		enforceBigTexCacheSize();
		
		// And finally, return the texture:
		return tex;
	}
	
} // End of method: Environment::loadBigTexture




void Environment::freeBigTexture ( const BigTexture * tex ) {
	
	// Look for this texture in the cache:
	int index = -1;
	for ( int i = 0; i < bigTexCache.getCount(); i++ ) {
		if ( bigTexCache[i].tex == tex ) {
			// Found it!
			index = i;
			break;
		}
	}
	
	// Found the texture?
	if ( index != -1 ) {
		// Decrement its reference counter:
		bigTexCache[index].refCounter--;
		
		// Move it to the head of the container:
		bigTexCache.toBeginning( index );
	}
	
} // End of method: Environment::freeBigTexture




void Environment::setBigTextureCacheSize ( int size ) {
	if ( size > 0 ) {
		bigTexCacheSize = size;
		
		enforceBigTexCacheSize();
	}
} // End of method: Environment::setBigTextureCacheSize




///////////////////////////////////////////////////////////////////////////////
// 
// Private methods:
// 
///////////////////////////////////////////////////////////////////////////////

void Environment::render () {
	// First, render the "furthest" object layer. This one will always be
	// present.
	int furthestLayer = gameObjLayers.getCount() - 1;
	for ( int i = gameObjLayers[furthestLayer]->getCount() - 1; i >= 0 ; i-- )
		gameObjLayers[furthestLayer]->elem( i )->render( furthestLayer, (float) scrollingX, (float) scrollingY );
		
	if ( loadedRoom ) {
		int screenWidth  = loadedRoom->getScreenPixelWidth();
		int screenHeight = loadedRoom->getScreenPixelHeight();

		// A few variables used to render the water level...
		// How much the screen's center is displaced relative to the waterLevel:
		int delta = loadedRoom->waterLevel - scrollingY - (screenHeight/2);
		// Set the water quad's texture:
		waterQuad.tex = waterTexture; // This will be unset later to draw the blue rectangle.
		
		
		// DRAW LAYERS:
		
		// Iterate over the loaded room's layers.
		// If a water level is visible in the room, it must be drawn inbetween the
		// BGLayers.
		
		// (In reverse order; lower-index layers must appear in front!)
		for ( int layerInx = loadedRoom->bgLayers.getCount() - 1; layerInx >= 0; layerInx-- ) {
			int backLayerInx = layerInx + 1;
			
			// Render the layer:
			BGLayer * bgLayer = loadedRoom->bgLayers[layerInx];
			bgLayer->render( -scrollingX, -scrollingY );
			
			// Render GameObjs in front of this layer:
			for ( int i = gameObjLayers[layerInx]->getCount() - 1; i >= 0 ; i-- )
				gameObjLayers[layerInx]->elem( i )->render( layerInx, (float) scrollingX, (float) scrollingY );
			
			
			// WATER LEVEL:
			if ( loadedRoom->waterLevel >= 0 && loadedRoom->waterLevel <= loadedRoom->getPixelHeight() ) {
				// Calculate the height at which the water level must be drawn:
				// The water level will be drawn "between" two layers -- the 
				// front layer (lower index) and the back layer (higher index).
				// When I reach the frontmost layer, I should stop, but I won't;
				// instead, I'll simulate an additional layer of water to make
				// the water level "fade" as it nears the "camera."
				float backLayerParallaxX, backLayerParallaxY;
				float frontLayerParallaxX, frontLayerParallaxY;
				if ( layerInx > 0 ) {
					backLayerParallaxX  = bgLayer->parallaxFactorX;
					backLayerParallaxY  = bgLayer->parallaxFactorY;
					frontLayerParallaxX = loadedRoom->bgLayers[layerInx - 1]->parallaxFactorX;
					frontLayerParallaxY = loadedRoom->bgLayers[layerInx - 1]->parallaxFactorY;
				}
				else {
					// At the frontmost layer.
					// Use the frontmost layer's parallax + 0.5 for the
					// "virtual layer."
					backLayerParallaxX  = bgLayer->parallaxFactorX;
					backLayerParallaxY  = bgLayer->parallaxFactorY;
					frontLayerParallaxX = backLayerParallaxX + 0.5f;
					frontLayerParallaxY = backLayerParallaxY + 0.5f;
				}
				
				float backLayerLevel  = delta * backLayerParallaxY  + (screenHeight/2);
				float frontLayerLevel = delta * frontLayerParallaxY + (screenHeight/2);
				
				// Assign the quad's coordinates:
				// Y-wise, the coordinates calculated above will be used.
				waterQuad.v[0].y = backLayerLevel;
				waterQuad.v[1].y = backLayerLevel;
				waterQuad.v[2].y = frontLayerLevel;
				waterQuad.v[3].y = frontLayerLevel;
				
				// Now, X-wise coordinates. The quad needs to be stretched across the
				// entire "virtual width" of each layer -- that is to say, its width
				// must be adjusted to the layers' parallaxes.
				float backLayerWidth  = screenWidth + backLayerParallaxX  * (loadedRoom->getPixelWidth() - screenWidth);
				float frontLayerWidth = screenWidth + frontLayerParallaxX * (loadedRoom->getPixelWidth() - screenWidth);
				
				waterQuad.v[0].x = (-scrollingX) * backLayerParallaxX;
				waterQuad.v[1].x = (-scrollingX) * backLayerParallaxX  + backLayerWidth ;
				waterQuad.v[2].x = (-scrollingX) * frontLayerParallaxX + frontLayerWidth;
				waterQuad.v[3].x = (-scrollingX) * frontLayerParallaxX;
				
				// Finally, setting the texture coordinates.
				float texWidth = (float) loadedRoom->roomWidth;
				
				// A few trigonometric functions will achieve a nice wavy effect:
				float backPhaseL  = time * QAF_WAVE_FREQUENCY + (0 + backLayerInx) / 2;
				float backPhaseR  = time * QAF_WAVE_FREQUENCY + (1 + backLayerInx) / 2;
				float frontPhaseL = time * QAF_WAVE_FREQUENCY + (0 + layerInx    ) / 2;
				float frontPhaseR = time * QAF_WAVE_FREQUENCY + (1 + layerInx    ) / 2;
				
				float backAmpl  = backLayerParallaxX  * QAF_WAVE_AMPLITUDE_X / loadedRoom->roomWidth;
				float frontAmpl = frontLayerParallaxX * QAF_WAVE_AMPLITUDE_X / loadedRoom->roomWidth;
				waterQuad.v[0].tx = texWidth * backAmpl  * cosf( backPhaseL  );
				waterQuad.v[1].tx = texWidth * backAmpl  * cosf( backPhaseR  ) + 1;
				waterQuad.v[2].tx = texWidth * frontAmpl * cosf( frontPhaseR ) + 1;
				waterQuad.v[3].tx = texWidth * frontAmpl * cosf( frontPhaseL );
				
				// Ensure the layer at parallax 1.0 will display the full
				// texture, width-wise.
				waterQuad.v[0].tx *= loadedRoom->roomWidth;
				waterQuad.v[1].tx *= loadedRoom->roomWidth;
				waterQuad.v[2].tx *= loadedRoom->roomWidth;
				waterQuad.v[3].tx *= loadedRoom->roomWidth;
				
				// Y texture coordinates:
				backAmpl  = backLayerParallaxY  * QAF_WAVE_AMPLITUDE_Y;
				frontAmpl = frontLayerParallaxY * QAF_WAVE_AMPLITUDE_Y;
				waterQuad.v[0].ty = backAmpl  * sinf( backPhaseL  );
				waterQuad.v[1].ty = backAmpl  * sinf( backPhaseR  );
				waterQuad.v[2].ty = frontAmpl * sinf( frontPhaseL ) + 1;
				waterQuad.v[3].ty = frontAmpl * sinf( frontPhaseR ) + 1;
				
				// Water current:
				waterQuad.v[0].tx += time * QAF_WAVE_CURRENT_X / loadedRoom->roomWidth;
				waterQuad.v[0].ty += time * QAF_WAVE_CURRENT_Y;
				waterQuad.v[1].tx += time * QAF_WAVE_CURRENT_X / loadedRoom->roomWidth;
				waterQuad.v[1].ty += time * QAF_WAVE_CURRENT_Y;
				waterQuad.v[2].tx += time * QAF_WAVE_CURRENT_X / loadedRoom->roomWidth;
				waterQuad.v[2].ty += time * QAF_WAVE_CURRENT_Y;
				waterQuad.v[3].tx += time * QAF_WAVE_CURRENT_X / loadedRoom->roomWidth;
				waterQuad.v[3].ty += time * QAF_WAVE_CURRENT_Y;
				
				// The farther away the waves are, the less visible they should appear:
				unsigned char backLayerAlpha  = (unsigned char) MAX( 0.0f, MIN( 255.0f, 255.0f * (backLayerParallaxX + backLayerParallaxY)/2 ) );
				unsigned char frontLayerAlpha = (unsigned char) MAX( 0.0f, MIN( 255.0f, 255.0f * (frontLayerParallaxX + frontLayerParallaxY)/2 ) );
				
				// The "virtual layer" (remember that?) should have an alpha of
				// zero, so the waves appear to fade as they near the camera.
				if ( layerInx == 0 )
					frontLayerAlpha = 0;
				
				waterQuad.v[0].col = waterQuad.v[1].col = ARGB( backLayerAlpha,  255, 255, 255 );
				waterQuad.v[2].col = waterQuad.v[3].col = ARGB( frontLayerAlpha, 255, 255, 255 );
				
				hge->Gfx_RenderQuad( &waterQuad );
			}
		}
		
		//
		// UNDERWATER EFFECTS:
		//
		float frontMostLayerParallaxY = ( loadedRoom->bgLayers.getCount() > 0 ? loadedRoom->bgLayers[0]->parallaxFactorY : 1.0f );
		// There are two water levels that interest me:
		//  - The level of the frontmost layer
		//  - The level of the "virtual layer"
		float waterLevelOnScreen1 = delta * frontMostLayerParallaxY          + (screenHeight/2);
		float waterLevelOnScreen2 = delta * (frontMostLayerParallaxY + 0.5f) + (screenHeight/2);
		
		// These will be used to make the water's blue rectangle fade as it
		// approaches the water level. For this to work, I need waterLevel1 to
		// always be above waterLevel2:
		if ( waterLevelOnScreen1 > waterLevelOnScreen2 ) {
			// Swap!
			float tmp = waterLevelOnScreen1;
			waterLevelOnScreen1 = waterLevelOnScreen2;
			waterLevelOnScreen2 = tmp;
		}
		
		if ( waterLevelOnScreen1 <= screenHeight ) {
			// After all BGLayers are drawn...
			// Fill a translucent blue quad in front of the BGLayers,
			// representing the underwater portions of the room.
			// Can't just render one quad, as that would make an extremely
			// ugly "blue rectangle" appear in front of the room.
			// Instead, I'll break it up into two quads: One that "fades"
			// close to the water level, and another that's all one color.
			waterQuad.tex = NULL;
			
			// First quad: Top vertices fully trasparent, bottom vertices with
			// some alpha:
			waterQuad.v[0].col =
			waterQuad.v[1].col = ARGB(0, QAF_WATER_COLOR_R, QAF_WATER_COLOR_G, QAF_WATER_COLOR_B);
			waterQuad.v[2].col =
			waterQuad.v[3].col = ARGB(QAF_WATER_COLOR_A, QAF_WATER_COLOR_R, QAF_WATER_COLOR_G, QAF_WATER_COLOR_B);
			
			// Quad's coordinates: All across the X axis, water level on the Y
			// axis.
			waterQuad.v[0].x = waterQuad.v[3].x = 0;
			waterQuad.v[1].x = waterQuad.v[2].x = (float) screenWidth;
			
			waterQuad.v[0].y = waterQuad.v[1].y = waterLevelOnScreen1;
			waterQuad.v[2].y = waterQuad.v[3].y = waterLevelOnScreen2;
			
			hge->Gfx_RenderQuad( &waterQuad );
			
			// Second quad: All vertices with some alpha:
			waterQuad.v[0].col =
			waterQuad.v[1].col = 
			waterQuad.v[2].col =
			waterQuad.v[3].col = ARGB(QAF_WATER_COLOR_A, QAF_WATER_COLOR_R, QAF_WATER_COLOR_G, QAF_WATER_COLOR_B);
			
			// Quad's coordinates: All across the X axis, water level on the Y
			// axis. Extends all the way to the bottom:
			waterQuad.v[0].x = waterQuad.v[3].x = 0;
			waterQuad.v[1].x = waterQuad.v[2].x = (float) screenWidth;
			
			waterQuad.v[0].y = waterQuad.v[1].y = waterLevelOnScreen2;
			waterQuad.v[2].y = waterQuad.v[3].y = (float) screenHeight;
			
			hge->Gfx_RenderQuad( &waterQuad );
		}
		
		//
		// REFRACTION EFFECT WHEN UNDERWATER:
		//
		// I'm going to render the backBuffer onto itself, but distorting
		// it so it appears to be undulating.
		if ( backBuffer ) {
			
			if ( waterLevelOnScreen1 <= screenHeight ) {
				// Get the backBuffer's texture and set it as the distortion mesh's:
				HTEXTURE backTex = hge->Target_GetTexture( backBuffer );
				int backWidth  = hge->Texture_GetWidth( backTex );
				int backHeight = hge->Texture_GetHeight( backTex );
				
				waterMesh->SetTexture( backTex );
				waterMesh->SetTextureRect(
					0,                                       // x
					MAX( 0.0f, waterLevelOnScreen1 - 1.0f ), // y
					(float) screenWidth,                     // w
					(float) screenHeight );                  // h
				
				// Wave distortion:
				for ( int i = 0; i < QAF_REFRACTION_MESH_ROWS; i++ )
					for ( int j = 0; j < QAF_REFRACTION_MESH_COLS; j++ )
						waterMesh->SetDisplacement(
							j, i, // col, row
							QAF_REFRACTION_AMPLITUDE * cosf( time * QAF_REFRACTION_FREQUENCY + (i + j) / 2 ), // dx
							QAF_REFRACTION_AMPLITUDE * sinf( time * QAF_REFRACTION_FREQUENCY + (i + j) / 2 ), // dy 
							HGEDISP_NODE ); // ref
				
				waterMesh->Render( 0, MAX( 0.0f, waterLevelOnScreen1 - 1.0f ) );
			}
		}
	}
	
	
} // End of method: Environment::render




void Environment::doOpBuffer () {
	// Make a copy of the buffer, to prevent it from being corrupted by
	// operations performed during the loop:
	static Container<BufferedOperation> contTmpBuffer;
	contTmpBuffer = operationBuffer;
	operationBuffer.removeAll();
	
	while ( contTmpBuffer.getCount() > 0 ) {
		// Get next operation:
		BufferedOperation op = contTmpBuffer[0];
		contTmpBuffer.remove( 0 );
		
		switch ( op.type ) {
			case BufferedOperation::ADDGAMEOBJ: {
				int       layerInx = op.data.addGameObjData.layerInx;
				GameObj * obj      = op.data.addGameObjData.obj;
				bool      onTop    = op.data.addGameObjData.onTop;
				
				// Invalid layer was specified?
				if ( layerInx < 0 || layerInx >= gameObjLayers.getCount() ) {
					// Use the room's default layer, or zero if there's no loaded room.
					if ( loadedRoom )
						layerInx = loadedRoom->defaultObjLayer;
					else
						layerInx = 0;
				}
				
				// Clamp the layer to a valid index:
				if ( layerInx >= gameObjLayers.getCount() )
					layerInx = gameObjLayers.getCount() - 1;
				else if ( layerInx < 0 )
					layerInx = 0;
				
				// Insert the object:
				if ( onTop )
					gameObjLayers[layerInx]->add( 0, obj );
				else
					gameObjLayers[layerInx]->add( obj );
				
				// Register the object with any active object discriminators:
				for ( int discrInx = 0; discrInx < objDiscriminators.getCount(); discrInx++ )
					objDiscriminators[discrInx]->addGameObj( obj );
				
				break;
			}
			
			case BufferedOperation::REMOVEGAMEOBJ: {
				int       srcLayer  = op.data.removeGameObjData.layerInx;
				bool      deleteIt  = op.data.removeGameObjData.deleteIt;
				GameObj * obj       = op.data.removeGameObjData.obj;
				
				// The object's layer and in-layer position:
				int layerInx = -1, objIndex = -1;
				
				// Invalid source layer was specified?
				if ( srcLayer < 0 || srcLayer >= gameObjLayers.getCount() )
					// Look for the object in all layers:
					layerInx = findGameObj( obj, &objIndex );
				else {
					// Look for the object in the source layer:
					layerInx = srcLayer;
					objIndex = gameObjLayers[layerInx]->indexOf( obj );
				}
				
				// Object not found?
				if ( objIndex == -1 )
					break;
				
				// Remove it from its layer:
				gameObjLayers[layerInx]->remove( objIndex );
				
				// Unregister the object from any active object discriminators:
				for ( int discrInx = 0; discrInx < objDiscriminators.getCount(); discrInx++ )
					objDiscriminators[discrInx]->removeGameObj( obj );
				
				// Delete it:
				if ( deleteIt )
					delete obj;
				
				break;
			}
			
			case BufferedOperation::BRINGGAMEOBJTOFRONT: {
				int       srcLayer  = op.data.bringGameObjToFrontData.layerInx;
				GameObj * obj       = op.data.bringGameObjToFrontData.obj;
				
				// The object's layer and in-layer position:
				int layerInx = -1, objIndex = -1;
				
				// Invalid source layer was specified?
				if ( srcLayer < 0 || srcLayer >= gameObjLayers.getCount() )
					// Look for the object in all layers:
					layerInx = findGameObj( obj, &objIndex );
				else {
					// Look for the object in the source layer:
					layerInx = srcLayer;
					objIndex = gameObjLayers[layerInx]->indexOf( obj );
				}
				
				// Object not found?
				if ( objIndex == -1 )
					break;
				
				// Move it to the front:
				gameObjLayers[layerInx]->toBeginning( objIndex );
				
				break;
			}
			
			case BufferedOperation::SENDGAMEOBJTOBACK: {
				int       srcLayer  = op.data.sendGameObjToBackData.layerInx;
				GameObj * obj       = op.data.sendGameObjToBackData.obj;
				
				// The object's layer and in-layer position:
				int layerInx = -1, objIndex = -1;
				
				// Invalid source layer was specified?
				if ( srcLayer < 0 || srcLayer >= gameObjLayers.getCount() )
					// Look for the object in all layers:
					layerInx = findGameObj( obj, &objIndex );
				else {
					// Look for the object in the source layer:
					layerInx = srcLayer;
					objIndex = gameObjLayers[layerInx]->indexOf( obj );
				}
				
				// Object not found?
				if ( objIndex == -1 )
					break;
				
				// Move it to the back:
				gameObjLayers[layerInx]->toEnd( objIndex );
				
				break;
			}
			
			case BufferedOperation::LOADROOM: {
				doLoadRoom( op.data.loadRoomData.room, op.data.loadRoomData.objs );
				break;
			}
			
			case BufferedOperation::UNLOADROOM: {
				doUnloadRoom();
				break;
			}
		}
	}
	
} // End of method: Environment::doOpBuffer




void Environment::doLoadRoom ( Room * newRoom, void * pObjInfo ) {
	// Cast the objInfo to the correct type:
	Container<BufferedObjInfo *> * objInfo = (Container<BufferedObjInfo *> *) pObjInfo;
	
	// First, get rid of the old room:
	doUnloadRoom();
	
	// Set this as the new loaded room:
	loadedRoom = newRoom;
	
	// GAME OBJECTS:
	// The number of object layers will be numOfBGLayers + 1, since
	// doUnloadRoom() leaves one empty object layer.
	for ( int layerInx = 0; layerInx < newRoom->bgLayers.getCount(); layerInx++ )
		gameObjLayers.add( new Container<GameObj *> );
	
	// Pass the object info to the GameObjFactory and spawn new objects:
	if ( gameObjFactory != NULL ) {
		for ( int objInx = 0; objInx < objInfo->getCount(); objInx++ ) {
			GameObj * obj = gameObjFactory->createObject(
									objInfo->elem(objInx)->id,
									objInfo->elem(objInx)->x,
									objInfo->elem(objInx)->y,
									objInfo->elem(objInx)->attributes );
			
			if ( obj != NULL ) {
				// Objects will be kept here until the loading process is
				// over:
				tempNonVolatileStorage.add( obj );
			}
		}
	}
		
	// Move non-volatile objects into the default object layer:
	while ( tempNonVolatileStorage.getCount() > 0 ) {
		GameObj * obj = tempNonVolatileStorage[0];
		
		tempNonVolatileStorage.remove( 0 );
		
		if ( newRoom->defaultObjLayer < gameObjLayers.getCount() )
			gameObjLayers[newRoom->defaultObjLayer]->add( obj );
		else
			gameObjLayers[0]->add( obj );
		
		// Register this object back into all active object discriminators:
		for ( int discrInx = 0; discrInx < objDiscriminators.getCount(); discrInx++ )
			objDiscriminators[discrInx]->addGameObj( obj );
	}
	
	// Delete temporary object info storage:
	for ( int objInx = 0; objInx < objInfo->getCount(); objInx++ ) {
		delete objInfo->elem( objInx );
	}
	delete objInfo;
	
	// Initialize objects:
	for ( int inxLayer = 0; inxLayer < gameObjLayers.getCount(); inxLayer++ ) {
		for ( int inxObj = 0; inxObj < gameObjLayers[inxLayer]->getCount(); inxObj++ ) {
			gameObjLayers[inxLayer]->elem( inxObj )->initialize();
		}
	}
	
} // End of method: Environment::doLoadRoom




void Environment::doUnloadRoom () {
	// Remove all object layers, storing non-volatile objects for later
	// re-insertion:
	for ( int layerInx = 0; layerInx < gameObjLayers.getCount(); layerInx++ ) {
		// I'll be removing all objects...
		while ( gameObjLayers[layerInx]->getCount() > 0 ) {
			// Dequeue the next object:
			GameObj * obj = gameObjLayers[layerInx]->elem( 0 );
			gameObjLayers[layerInx]->remove( 0 );
		
			// Unregister this object from any active object discriminators:
			for ( int discrInx = 0; discrInx < objDiscriminators.getCount(); discrInx++ )
				objDiscriminators[discrInx]->removeGameObj( obj );
			
			if ( obj->isVolatile() )
				// If it is volatile, delete it:
				delete obj;
			else
				// Non-volatile objects are kept in temporary storage:
				tempNonVolatileStorage.add( obj );
			
		}
	}

	// Remove all layers:
	while ( gameObjLayers.getCount() > 0 ) {
		delete gameObjLayers[0];
		gameObjLayers.remove( 0 );
	}
	
	// If there was a loaded room, delete it:
	if ( loadedRoom ) {
		delete loadedRoom;
		loadedRoom = NULL;
	}

	// The Environment shouldn't be left without a GameObj layer:
	gameObjLayers.add( new Container<GameObj *> );
	
	// Set the scrolling point to (0, 0):
	scrollingX = 0;
	scrollingY = 0;
	
} // End of method: Environment::doUnloadRoom



void Environment::enforceBigTexCacheSize () {
	
	// Is the cache full?
	while ( bigTexCache.getCount() > bigTexCacheSize ) {
		// Search the cache for "dead" textures.
		
		// The least recently freed textures are at the lower indices...
		// I'll run through the list and stop when I find a dead texture.
		int deadIndex;
		for ( deadIndex = 0; deadIndex < bigTexCache.getCount(); deadIndex++ ) {
			if ( bigTexCache[deadIndex].refCounter == 0 ) {
				// Found a dead texture!
				break;
			}
		}
		
		// Found a dead texture?
		if ( deadIndex < bigTexCache.getCount() ) {
			// Delete that texture:
			delete bigTexCache[deadIndex].tex;
			
			// Remove the entry from the cache:
			bigTexCache.remove( deadIndex );
		}
		else {
			// If no dead textures were found, stop the process. There's nothing
			// I can do, even if the cache is larger than the allowed size.
			break;
		}
	}
	
} // End of method: Environment::enforceBigTexCacheSize




///////////////////////////////////////////////////////////////////////////////
// 
// Debug resources:
// 
///////////////////////////////////////////////////////////////////////////////

Environment::DebugConsole           Environment::cout;
Container<Environment::DebugVector> Environment::debugVectors;




Environment::DebugVector::DebugVector ( Vector2D & _p1, Vector2D & _p2, DWORD _color ) {
	p1 = _p1;
	p2 = _p2;
	color = _color;
}



void Environment::DebugVector::render () {
	int sX = Environment::getScrollingX(), sY = Environment::getScrollingY();
	
	// The vector itself:
	hge->Gfx_RenderLine( p1.x - sX, p1.y - sY, p2.x - sX, p2.y - sY, color );
	
	// And the arrow point:
	Vector2D arrowTip = p1 - p2;
	arrowTip.normalize();
	arrowTip *= 5;
	
	arrowTip = arrowTip.rotate( M_PI/4 );
	hge->Gfx_RenderLine( p2.x - sX, p2.y - sY, p2.x + arrowTip.x - sX, p2.y + arrowTip.y - sY, color );
	
	arrowTip = arrowTip.rotate( -M_PI/2 );
	hge->Gfx_RenderLine( p2.x - sX, p2.y - sY, p2.x + arrowTip.x - sX, p2.y + arrowTip.y - sY, color );
}
