/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafCollisionStruct.h>

#include <hge.h>
#include <qafDef.h>
#include <qafutil/qafGeom.h>

using namespace qaf;




CollisionStruct::~CollisionStruct () {}




///////////////////////////////////////////////////////////////////////////////
// 
// BOX COLLISION STUCTURE:
// 
///////////////////////////////////////////////////////////////////////////////

CollisionStruct::Box::Box ( float _x, float _y, float _w, float _h ) {
	x = _x;
	y = _y;
	w = _w;
	h = _h;
}




CollisionStruct::Box::Box () {
	x = 0;
	y = 0;
	w = 0;
	h = 0;
}




bool CollisionStruct::Box::collidesWith ( CollisionStruct * otherStruct ) {
	
	if ( !otherStruct )
		return false;
	
	// What kind of struct is that?
	CollisionStruct::Box     * otherBox     = NULL;
	CollisionStruct::Circle  * otherCircle  = NULL;
	CollisionStruct::Polygon * otherPolygon = NULL;
	
	if ( (otherBox = dynamic_cast<CollisionStruct::Box*>( otherStruct )) ) {
		// Box with box... easiest of all:
		
		float top   = MIN( y, y + h );
		float bott  = MAX( y, y + h );
		float left  = MIN( x, x + w );
		float right = MAX( x, x + w );
		
		float otherTop   = MIN( otherBox->y, otherBox->y + otherBox->h );
		float otherBott  = MAX( otherBox->y, otherBox->y + otherBox->h );
		float otherLeft  = MIN( otherBox->x, otherBox->x + otherBox->w );
		float otherRight = MAX( otherBox->x, otherBox->x + otherBox->w );
		
		return !(right < otherLeft  ||
		         left  > otherRight ||
		         bott  < otherTop   ||
		         top   > otherBott);
	}
	else if ( (otherCircle = dynamic_cast<CollisionStruct::Circle*>( otherStruct )) ) {
		// Box with circle:
		return CollisionStruct::collide_Box_Circle( this, otherCircle );
	}
	else if ( (otherPolygon = dynamic_cast<CollisionStruct::Polygon*>( otherStruct )) ) {
		// Box with polygon:
		return CollisionStruct::collide_Box_Polygon( this, otherPolygon );
	}
	else {
		// Unknown type...
		return false;
	}
	
}




bool CollisionStruct::Box::hasPoint ( float _x, float _y ) {
	return ((_x >= x) && (_x <= x + w) && (_y >= y) && (_y <= y + h));
}




void CollisionStruct::Box::render ( float scrollX, float scrollY, unsigned long color ) {
	// Get an HGE interface:
	HGE * hge = hgeCreate( HGE_VERSION );
	
	// Render lines:
	hge->Gfx_RenderLine( x     - scrollX, y     - scrollY, x + w - scrollX, y     - scrollY, color );
	hge->Gfx_RenderLine( x + w - scrollX, y     - scrollY, x + w - scrollX, y + h - scrollY, color );
	hge->Gfx_RenderLine( x + w - scrollX, y + h - scrollY, x     - scrollX, y + h - scrollY, color );
	hge->Gfx_RenderLine( x     - scrollX, y + h - scrollY, x     - scrollX, y     - scrollY, color );
	
	hge->Release();
}




///////////////////////////////////////////////////////////////////////////////
// 
// CIRCLE COLLISION STUCTURE:
// 
///////////////////////////////////////////////////////////////////////////////

CollisionStruct::Circle::Circle ( float _xCenter, float _yCenter, float _radius ) {
	xCenter = _xCenter;
	yCenter = _yCenter;
	radius = _radius;
}




CollisionStruct::Circle::Circle () {
	xCenter = 0;
	yCenter = 0;
	radius = 0;
}




bool CollisionStruct::Circle::collidesWith ( CollisionStruct * otherStruct ) {
	
	if ( !otherStruct )
		return false;
	
	// What kind of struct is that?
	CollisionStruct::Box     * otherBox     = NULL;
	CollisionStruct::Circle  * otherCircle  = NULL;
	CollisionStruct::Polygon * otherPolygon = NULL;
	
	if ( (otherBox = dynamic_cast<CollisionStruct::Box*>( otherStruct )) ) {
		// Box with circle:
		return CollisionStruct::collide_Box_Circle( otherBox, this );
	}
	else if ( (otherCircle = dynamic_cast<CollisionStruct::Circle*>( otherStruct )) ) {
		// Circle with circle:
		// Distance between centers must be less than sum of radii:
		float dx = xCenter - otherCircle->xCenter;
		float dy = yCenter - otherCircle->yCenter;
		
		return (sqrtf(dx * dx + dy * dy) <= (radius + otherCircle->radius));
	}
	else if ( (otherPolygon = dynamic_cast<CollisionStruct::Polygon*>( otherStruct )) ) {
		// Circle with polygon:
		return CollisionStruct::collide_Circle_Polygon( this, otherPolygon );
	}
	else {
		// Unknown type...
		return false;
	}
	
}




bool CollisionStruct::Circle::hasPoint ( float x, float y ) {
	float dx = xCenter - x;
	float dy = yCenter - y;
	
	return (sqrtf(dx * dx + dy * dy) <= radius);
}




void CollisionStruct::Circle::render ( float scrollX, float scrollY, unsigned long color ) {
	Geom::renderCircle( xCenter - scrollX, yCenter - scrollY, radius, color );
}




///////////////////////////////////////////////////////////////////////////////
// 
// POLYGON COLLISION STUCTURE:
// 
///////////////////////////////////////////////////////////////////////////////

CollisionStruct::Polygon::Polygon () {
	// Set translation to zero:
	pos.x = 0;
	pos.y = 0;
	
	// Set rotation to zero:
	rotation = 0;
	
	// Set scaling to 100%:
	scale = 1;
}




CollisionStruct::Polygon::Polygon ( const Container<Vector2D> & _points )
: userPoints( _points ), realPoints( _points )
{
	// Set translation to zero:
	pos.x = 0;
	pos.y = 0;
	
	// Set rotation to zero:
	rotation = 0;
	
	// Set scaling to 100%:
	scale = 1;
}




CollisionStruct::Polygon::Polygon ( const Vector2D * _points, int nPoints )
: userPoints( _points, nPoints ), realPoints( _points, nPoints )
{
	// Set translation to zero:
	pos.x = 0;
	pos.y = 0;
	
	// Set rotation to zero:
	rotation = 0;
	
	// Set scaling to 100%:
	scale = 1;
}




CollisionStruct::Polygon::Polygon ( const hgeSprite * pSprite ) {
	// Initialize points:
	float fHotX, fHotY;
	pSprite->GetHotSpot( &fHotX, &fHotY );
	Vector2D avCorners[] = {
		Vector2D(-fHotX,                       -fHotY),
		Vector2D(-fHotX + pSprite->GetWidth(), -fHotY),
		Vector2D(-fHotX + pSprite->GetWidth(), -fHotY + pSprite->GetHeight()),
		Vector2D(-fHotX,                       -fHotY + pSprite->GetHeight()) };
	
	for ( int i = 0; i < 4; i++ ) {
		userPoints.add( avCorners[i] );
		realPoints.add( avCorners[i] );
	}
	
	// Set translation to zero:
	pos.x = 0;
	pos.y = 0;
	
	// Set rotation to zero:
	rotation = 0;
	
	// Set scaling to 100%:
	scale = 1;
}




void CollisionStruct::Polygon::render ( float scrollX, float scrollY, unsigned long color ) {
	// Ask the "Geom" module to render the polygon:
	Geom::renderPolygon(
		realPoints,
		(float) -scrollX,
		(float) -scrollY,
		color );
	
}




void CollisionStruct::Polygon::setPoints( const Vector2D * points, int nPoints ) {
	// Copy all points to the userPoints container... 
	userPoints.removeAll();
	
	for ( int i = 0; i < nPoints; i++ )
		userPoints.add( points[i] );
	
	// Now, recalculate the real points:
	updateRealPoints();
}




void CollisionStruct::Polygon::setPosition ( float x, float y ) {
	// Set the position:
	pos.x = x;
	pos.y = y;
	
	// Update real points:
	updateRealPoints();
}




void CollisionStruct::Polygon::getPosition ( float * x, float * y ) {
	*x = pos.x;
	*y = pos.y;
}




void CollisionStruct::Polygon::setRotation ( float radians ) {
	// Set the rotation:
	rotation = radians;
	
	// Update real points:
	updateRealPoints();
}




float CollisionStruct::Polygon::getRotation () {
	return rotation;
}




bool CollisionStruct::Polygon::collidesWith ( CollisionStruct * otherStruct ) {
	
	if ( !otherStruct )
		return false;
	
	// What kind of struct is that?
	CollisionStruct::Box     * otherBox     = NULL;
	CollisionStruct::Circle  * otherCircle  = NULL;
	CollisionStruct::Polygon * otherPolygon = NULL;
	
	if ( (otherBox = dynamic_cast<CollisionStruct::Box*>( otherStruct )) ) {
		// Box with polygon:
		return CollisionStruct::collide_Box_Polygon( otherBox, this );
	}
	else if ( (otherCircle = dynamic_cast<CollisionStruct::Circle*>( otherStruct )) ) {
		// Box with circle:
		return CollisionStruct::collide_Circle_Polygon( otherCircle, this );
	}
	else if ( (otherPolygon = dynamic_cast<CollisionStruct::Polygon*>( otherStruct )) ) {
		// Test polygon-polygon intersection:
		return CollisionStruct::collide_PolyPoints(
			realPoints.getData(), realPoints.getCount(),
			otherPolygon->realPoints.getData(), otherPolygon->realPoints.getCount() );
	}
	else {
		// Unknown type...
		return false;
	}
}




bool CollisionStruct::Polygon::hasPoint ( float x, float y ) {
	return Geom::insidePolygon( Vector2D(x, y), realPoints );
}




void CollisionStruct::Polygon::updateRealPoints () {
	realPoints.removeAll();
	
	for ( int i = 0; i < userPoints.getCount(); i++ )
		realPoints.add( scale * userPoints[i].rotate( rotation ) + pos );
}




///////////////////////////////////////////////////////////////////////////////
// 
// Static methods:
// 
///////////////////////////////////////////////////////////////////////////////

bool CollisionStruct::collide_PolyPoints ( const Vector2D * p1, int n1, const Vector2D * p2, int n2 ) {
	// Here's the strategy:
	// - For every point in p2, test if it is contained in p1.
	// - If that fails: For every point in p2, test if it is contained in p2.
	// - If that fails: For every two segments (one from each polygon), test if
	//   they intersect.
	for ( int i2 = 0; i2 < n2; i2++ )
		if ( Geom::insidePolygon( p2[i2], p1, n1 ) )
			// Collision!
			return true;
	
	for ( int i1 = 0; i1 < n1; i1++ )
		if ( Geom::insidePolygon( p1[i1], p2, n2 ) )
			// Collision!
			return true;
	
	for ( i1 = 0; i1 < n1; i1++ ) {
		Vector2D v1 = p1[i1];
		Vector2D v1Next = p1[((i1 + 1) % n1)];
		
		for ( i2 = 0; i2 < n2; i2++ ) {
			Vector2D v2 = p2[i2];
			Vector2D v2Next = p2[((i2 + 1) % n2)];
			
			if ( Geom::segmentIntersection(
					v1.x, v1.y,
					v1Next.x, v1Next.y,
					v2.x, v2.y, 
					v2Next.x, v2Next.y,
					NULL ) )
				// Collision!
				return true;
		}
	}
	
	// No collision!
	return false;
}




bool CollisionStruct::collide_Box_Circle ( Box *pBox, Circle *pCirc ) {
	// Here's the strategy:
	// - Test if the circle's center is contained in the box.
	// - For every corner of the box, test if it is contained in the circle.
	// - For every segment of the box, test if it intersects the circle.
	
	// Circle center in box?
	if ( pCirc->xCenter >= pBox->x &&
	     pCirc->xCenter <= pBox->x + pBox->w &&
	     pCirc->yCenter >= pBox->y &&
	     pCirc->yCenter <= pBox->y + pBox->h )
		return true;
	
	// Box corners in circle?
	// Top-left:
	float dx = pBox->x - pCirc->xCenter;
	float dy = pBox->y - pCirc->yCenter;
	if ( sqrtf( dx * dx + dy * dy ) <= pCirc->radius )
		return true;
	// Top-right:
	dx += pBox->w;
	if ( sqrtf( dx * dx + dy * dy ) <= pCirc->radius )
		return true;
	// Bottom-right:
	dy += pBox->h;
	if ( sqrtf( dx * dx + dy * dy ) <= pCirc->radius )
		return true;
	// Bottom-left:
	dx -= pBox->w;
	if ( sqrtf( dx * dx + dy * dy ) <= pCirc->radius )
		return true;
	
	// Box segments intersect circle?
	// Top:
	if ( Geom::segmentCircleIntersection(
			pCirc->xCenter, pCirc->yCenter, pCirc->radius,  
			pBox->x,           pBox->y,
			pBox->x + pBox->w, pBox->y ) )
		return true;
	// Bottom:
	if ( Geom::segmentCircleIntersection(
			pCirc->xCenter, pCirc->yCenter, pCirc->radius,  
			pBox->x,           pBox->y + pBox->h,
			pBox->x + pBox->w, pBox->y + pBox->h ) )
		return true;
	// Left:
	if ( Geom::segmentCircleIntersection(
			pCirc->xCenter, pCirc->yCenter, pCirc->radius,  
			pBox->x, pBox->y,
			pBox->x, pBox->y + pBox->h ) )
		return true;
	// Right:
	if ( Geom::segmentCircleIntersection(
			pCirc->xCenter, pCirc->yCenter, pCirc->radius,  
			pBox->x + pBox->w, pBox->y,
			pBox->x + pBox->w, pBox->y + pBox->h ) )
		return true;
	
	// Not colliding!
	return false;
}




bool CollisionStruct::collide_Box_Polygon ( Box *pBox, Polygon *pPoly ) {
	// Here's the strategy:
	// Test the box as if it were a polygon.
	Vector2D avCorners[4];
	avCorners[0].x = pBox->x;           avCorners[0].y = pBox->y;
	avCorners[1].x = pBox->x + pBox->w; avCorners[1].y = pBox->y;
	avCorners[2].x = pBox->x + pBox->w; avCorners[2].y = pBox->y + pBox->h;
	avCorners[3].x = pBox->x;           avCorners[3].y = pBox->y + pBox->h;
	
	return collide_PolyPoints(
		avCorners, 4,
		pPoly->realPoints.getData(), pPoly->realPoints.getCount() );
}




bool CollisionStruct::collide_Circle_Polygon ( Circle *pCirc, Polygon *pPoly ) {
	// Here's the strategy:
	// - Test if the circle's center is contained in the polygon.
	// - For vertex corner of the polygon, test if it is contained in the circle.
	// - For every segment of the polygon, test if it intersects the circle.
	
	// Circle center in polygon?
	if ( Geom::insidePolygon( Vector2D(pCirc->xCenter, pCirc->yCenter), pPoly->realPoints ) )
		return true;
	
	// Polygon vertices in circle?
	int i;
	for ( i = 0; i < pPoly->realPoints.getCount(); i++ ) {
		// Vertex-to-center distance less than circle radius?
		float dx = pPoly->realPoints[i].x - pCirc->xCenter;
		float dy = pPoly->realPoints[i].y - pCirc->yCenter;
		
		if ( sqrtf( dx * dx + dy * dy ) < pCirc->radius )
			return true;
	}
	
	// Polygon segments against circle?
	for ( i = 0; i < pPoly->realPoints.getCount(); i++ ) {
		Vector2D v1 = pPoly->realPoints[i];
		Vector2D v2 = pPoly->realPoints[(i + 1) % pPoly->realPoints.getCount()];
		
		if ( Geom::segmentCircleIntersection(
				pCirc->xCenter, pCirc->yCenter, pCirc->radius,
				v1.x, v1.y,
				v2.x, v2.y ) )
			return true;
	}
	
	// Not colliding!
	return false;
}



