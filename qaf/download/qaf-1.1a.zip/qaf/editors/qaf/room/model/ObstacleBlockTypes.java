package qaf.room.model;

import java.awt.Color;
import java.awt.Graphics;

public class ObstacleBlockTypes {
	/** Obstacle color, when viewed: */
	public static final Color OBSTACLE_COLOR  = new Color( 255, 255, 255, 180 );
	
	/** Thin-floor color, when viewed: */
	public static final Color THINFLOOR_COLOR = new Color( 255, 255, 0 );
	
	
	// +-------+
	// |       |
	// |       |
	// |       |
	// +-------+
	public static final int EMPTY         = -1;
	
	// +-------+
	// |       |
	// |   .---|
	// |   |///|
	// +-------+
	public static final int SE_BLOCK      = 0;

	// +-------+
	// |       |
	// |-------|
	// |///////|
	// +-------+
	public static final int W_E_BOTTOM    = 1;

	// +-------+
	// |       |
	// |---.   |
	// |///|   |
	// +-------+
	public static final int SW_BLOCK      = 2;

	// +-------+
	// |   |///|
	// |---'///|
	// |///////|
	// +-------+
	public static final int NW_MISSING    = 3;

	// +-------+
	// |///|   |
	// |///'---|
	// |///////|
	// +-------+
	public static final int NE_MISSING    = 4;

	// +-------+
	// |    _-�|
	// |  _-///|
	// |_-/////|
	// +-------+
	public static final int SW_NE_BOTTOM  = 5;

	// +-------+
	// |�-_    |
	// |///-_  |
	// |/////-_|
	// +-------+
	public static final int NW_SE_BOTTOM  = 6;

	// +-------+
	// |       |
	// |   __--|
	// |_--////|
	// +-------+
	public static final int SW_E_BOTTOM   = 7;
	
	// +-------+
	// |  __--�|
	// |--/////|
	// |///////|
	// +-------+
	public static final int W_NE_BOTTOM   = 8;

	// +-------+
	// |�--__  |
	// |/////--|
	// |///////|
	// +-------+
	public static final int NW_E_BOTTOM   = 9;

	// +-------+
	// |       |
	// |--__   |
	// |////--_|
	// +-------+
	public static final int W_SE_BOTTOM   = 10;


	// +-------+
	// |   |///|
	// |   |///|
	// |   |///|
	// +-------+
	public static final int N_S_RIGHT     = 11;

	// +-------+
	// |///////|
	// |///////|
	// |///////|
	// +-------+
	public static final int FULL          = 12;

	// +-------+
	// |///|   |
	// |///|   |
	// |///|   |
	// +-------+
	public static final int N_S_LEFT      = 13;
	
	// +-------+
	// |///////|
	// |---.///|
	// |   |///|
	// +-------+
	public static final int SW_MISSING    = 14;
	
	// +-------+
	// |///////|
	// |///.---|
	// |///|   |
	// +-------+
	public static final int SE_MISSING    = 15;

	// +-------+
	// |�-/////|
	// |  �-///|
	// |    �-_|
	// +-------+
	public static final int NW_SE_TOP     = 16;

	// +-------+
	// |/////-�|
	// |///-�  |
	// |_-�    |
	// +-------+
	public static final int SW_NE_TOP     = 17;

	// +-------+
	// |�--////|
	// |   ��--|
	// |       |
	// +-------+
	public static final int NW_E_TOP      = 18;

	// +-------+
	// |///////|
	// |--/////|
	// |  ��--_|
	// +-------+
	public static final int W_SE_TOP      = 19;

	// +-------+
	// |///////|
	// |///__--|
	// |_--    |
	// +-------+
	public static final int SW_E_TOP      = 20;	
	
	// +-------+
	// |////--�|
	// |--��   |
	// |       |
	// +-------+
	public static final int W_NE_TOP      = 21;


	// +-------+
	// |   |///|
	// |   '---|
	// |       |
	// +-------+
	public static final int NE_BLOCK      = 22;

	// +-------+
	// |///////|
	// |-------|
	// |       |
	// +-------+
	public static final int W_E_TOP       = 23;

	// +-------+
	// |///|   |
	// |---'   |
	// |       |
	// +-------+
	public static final int NW_BLOCK      = 24;

	// +-------+
	// |       |
	// |     _-|
	// |   _-//|
	// +-------+
	public static final int S_E_BOTTOM    = 25;

	// +-------+
	// | _-�///|
	// |-//////|
	// |///////|
	// +-------+
	public static final int W_N_BOTTOM    = 26;

	// +-------+
	// |///�-_ |
	// |//////-|
	// |///////|
	// +-------+
	public static final int N_E_BOTTOM    = 27;

	// +-------+
	// |       |
	// |-_     |
	// |//-_   |
	// +-------+
	public static final int W_S_BOTTOM    = 28;

	// +-------+
	// |   �-//|
	// |     �-|
	// |       |
	// +-------+
	public static final int N_E_TOP       = 29;
	
	// +-------+
	// |///////|
	// |-//////|
	// | �-_///|
	// +-------+
	public static final int W_S_TOP       = 30;

	// +-------+
	// |///////|
	// |//////-|
	// |///_-� |
	// +-------+
	public static final int S_E_TOP       = 31;

	// +-------+
	// |//-�   |
	// |-�     |
	// |       |
	// +-------+
	public static final int W_N_TOP       = 32;

	// +-------+
	// |�������|
	// |       |
	// |       |
	// +-------+
	public static final int THINFLOOR_HI  = 33;

	// +-------+
	// |       |
	// |=======|
	// |       |
	// +-------+
	public static final int THINFLOOR_MID = 34;
	
	public static int MAX_BLOCK_TYPES     = 34;
	
	
	static int[] xPoints = new int[5];
	static int[] yPoints = new int[5];
	
	public static void drawBlock ( int type, int x, int y, int blockSize, Graphics g ) {
		int nw_X = x,                          nw_Y = y,
		    n_X  = nw_X + (blockSize/2), n_Y  = nw_Y,
		    ne_X = nw_X + blockSize,     ne_Y = nw_Y,
		    e_X  = nw_X + blockSize,     e_Y  = nw_Y + (blockSize/2),
		    se_X = nw_X + blockSize,     se_Y = nw_Y + blockSize,
		    s_X  = nw_X + (blockSize/2), s_Y  = nw_Y + blockSize,
		    sw_X = nw_X,                 sw_Y = nw_Y + blockSize,
		    w_X  = nw_X,                 w_Y  = nw_Y + (blockSize/2);
		
		g.setColor( OBSTACLE_COLOR );
		switch ( type ) {
			case FULL:
				g.fillRect( nw_X, nw_Y, blockSize, blockSize );
				break;
			
			case W_E_BOTTOM:
				g.fillRect( w_X, w_Y, blockSize, (blockSize/2) );
				break;
			case W_E_TOP:
				g.fillRect( nw_X, nw_Y, blockSize, (blockSize/2) );
				break;
			
			case N_S_LEFT:
				g.fillRect( nw_X, nw_Y, (blockSize/2), blockSize );
				break;
			case N_S_RIGHT:
				g.fillRect( n_X, n_Y, (blockSize/2), blockSize );
				break;
			
			case SW_E_BOTTOM:
				xPoints[0] = sw_X; yPoints[0] = sw_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = se_X; yPoints[2] = se_Y; 
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			case SW_E_TOP:
				xPoints[0] = sw_X; yPoints[0] = sw_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y; 
				xPoints[3] = nw_X; yPoints[3] = nw_Y;
				g.fillPolygon( xPoints, yPoints, 4 );
				break;
			
			case W_NE_BOTTOM:
				xPoints[0] = sw_X; yPoints[0] = sw_Y; 
				xPoints[1] = se_X; yPoints[1] = se_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y; 
				xPoints[3] = w_X;  yPoints[3] = w_Y;
				g.fillPolygon( xPoints, yPoints, 4 );
				break;
			case W_NE_TOP:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = ne_X; yPoints[1] = ne_Y;      
				xPoints[2] = nw_X; yPoints[2] = nw_Y; 
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			
			case W_SE_BOTTOM:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = se_X; yPoints[1] = se_Y;      
				xPoints[2] = sw_X; yPoints[2] = sw_Y; 
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			case W_SE_TOP:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = se_X; yPoints[1] = se_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y;
				xPoints[3] = nw_X; yPoints[3] = nw_Y;
				g.fillPolygon( xPoints, yPoints, 4 );
				break;
			
			case NW_E_BOTTOM:
				xPoints[0] = nw_X; yPoints[0] = nw_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = se_X; yPoints[2] = se_Y;
				xPoints[3] = sw_X; yPoints[3] = sw_Y;
				g.fillPolygon( xPoints, yPoints, 4 );
				break;
			case NW_E_TOP:
				xPoints[0] = nw_X; yPoints[0] = nw_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			
			case SW_NE_BOTTOM:
				xPoints[0] = sw_X; yPoints[0] = sw_Y; 
				xPoints[1] = ne_X; yPoints[1] = ne_Y;      
				xPoints[2] = se_X; yPoints[2] = se_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			case SW_NE_TOP:
				xPoints[0] = sw_X; yPoints[0] = sw_Y; 
				xPoints[1] = ne_X; yPoints[1] = ne_Y;      
				xPoints[2] = nw_X; yPoints[2] = nw_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			
			case W_N_BOTTOM:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = n_X;  yPoints[1] = n_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y;
				xPoints[3] = se_X; yPoints[3] = se_Y;
				xPoints[4] = sw_X; yPoints[4] = sw_Y;
				g.fillPolygon( xPoints, yPoints, 5 );
				break;
			case W_N_TOP:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = n_X;  yPoints[1] = n_Y;      
				xPoints[2] = nw_X; yPoints[2] = nw_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			
			case S_E_BOTTOM:
				xPoints[0] = s_X;  yPoints[0] = s_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = se_X; yPoints[2] = se_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			case S_E_TOP:
				xPoints[0] = s_X;  yPoints[0] = s_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y;
				xPoints[3] = nw_X; yPoints[3] = nw_Y;
				xPoints[4] = sw_X; yPoints[4] = sw_Y;
				g.fillPolygon( xPoints, yPoints, 5 );
				break;
			
			
			case NW_SE_BOTTOM:
				xPoints[0] = nw_X; yPoints[0] = nw_Y; 
				xPoints[1] = se_X; yPoints[1] = se_Y;      
				xPoints[2] = sw_X; yPoints[2] = sw_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			case NW_SE_TOP:
				xPoints[0] = nw_X; yPoints[0] = nw_Y; 
				xPoints[1] = se_X; yPoints[1] = se_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			
			case N_E_BOTTOM:
				xPoints[0] = n_X;  yPoints[0] = n_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = se_X; yPoints[2] = se_Y;
				xPoints[3] = sw_X; yPoints[3] = sw_Y;
				xPoints[4] = nw_X; yPoints[4] = nw_Y;
				g.fillPolygon( xPoints, yPoints, 5 );
				break;
			case N_E_TOP:
				xPoints[0] = n_X;  yPoints[0] = n_Y; 
				xPoints[1] = e_X;  yPoints[1] = e_Y;      
				xPoints[2] = ne_X; yPoints[2] = ne_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			
			case W_S_BOTTOM:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = s_X;  yPoints[1] = s_Y;      
				xPoints[2] = sw_X; yPoints[2] = sw_Y;
				g.fillPolygon( xPoints, yPoints, 3 );
				break;
			case W_S_TOP:
				xPoints[0] = w_X;  yPoints[0] = w_Y; 
				xPoints[1] = s_X;  yPoints[1] = s_Y;      
				xPoints[2] = se_X; yPoints[2] = se_Y;
				xPoints[3] = ne_X; yPoints[3] = ne_Y;
				xPoints[4] = nw_X; yPoints[4] = nw_Y;
				g.fillPolygon( xPoints, yPoints, 5 );
				break;
			
			case NW_BLOCK:
				g.fillRect( w_X, n_Y, blockSize/2, blockSize/2 );
				break;
			case NE_BLOCK:
				g.fillRect( n_X, n_Y, blockSize/2, blockSize/2 );
				break;
			case SE_BLOCK:
				g.fillRect( n_X, w_Y, blockSize/2, blockSize/2 );
				break;
			case SW_BLOCK:
				g.fillRect( w_X, w_Y, blockSize/2, blockSize/2 );
				break;

			case NW_MISSING:
				g.fillRect( n_X, n_Y, blockSize/2, blockSize/2 );
				g.fillRect( w_X, w_Y, blockSize,   blockSize/2 );
				break;
			case NE_MISSING:
				g.fillRect( w_X, n_Y, blockSize/2, blockSize/2 );
				g.fillRect( w_X, w_Y, blockSize,   blockSize/2 );
				break;
			case SE_MISSING:
				g.fillRect( w_X, n_Y, blockSize,   blockSize/2 );
				g.fillRect( w_X, w_Y, blockSize/2, blockSize/2 );
				break;
			case SW_MISSING:
				g.fillRect( w_X, n_Y, blockSize,   blockSize/2 );
				g.fillRect( n_X, w_Y, blockSize/2, blockSize/2 );
				break;
				
				//,
			case THINFLOOR_MID:
				g.setColor( THINFLOOR_COLOR );
				g.drawLine( w_X, w_Y, e_X, e_Y );
				g.drawLine( w_X, w_Y + 1, e_X, e_Y + 1 );
				break;
			
			case THINFLOOR_HI:
				g.setColor( THINFLOOR_COLOR );
				g.drawLine( nw_X, nw_Y, ne_X, ne_Y );
				g.drawLine( nw_X, nw_Y + 1, ne_X, ne_Y + 1 );
				break;
		}
	}
}
