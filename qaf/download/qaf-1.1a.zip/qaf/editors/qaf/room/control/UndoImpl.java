package qaf.room.control;

import java.awt.Point;

import qaf.room.model.BGLayer;
import qaf.room.model.GameObj;
import qaf.room.view.MainLayout;
import qaf.room.view.RoomPanel;

/**
 * Contains implementations of all UndoOperations the aplications needs.
 */
public abstract class UndoImpl {
	
	/**
	 * Represents a change made to the base path. Undoing this operation will
	 * restore the base path's former value. 
	 */
	public static class ChangeBasePathOperation implements UndoOperation {
		String oldValue, newValue;
		
		public ChangeBasePathOperation ( String oldValue, String newValue ) {
			this.oldValue = oldValue;
			this.newValue = newValue;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new:
			return new ChangeBasePathOperation( newValue, oldValue );
		}
		
		public void perform () {
			Main.setBasePath( oldValue );
		}
	}
	
	
	
	/**
	 * Represents "drawing" operations on the BGLayers' tiles (including the
	 * obstacle layer). Undoing this operation will restore the layer's data
	 * to its previous state.
	 */
	public static class BGLayerDrawingOperation implements UndoOperation {
		int layer;
		int[][] oldState;
		int[][] newState;
		
		public BGLayerDrawingOperation ( int layer, int[][] oldState, int[][] newState ) {
			this.layer = layer;
			this.oldState = Main.cloneArray( oldState );
			this.newState = Main.cloneArray( newState );
		}
		
		public UndoOperation getInverse() {
			// Reverse oldState and newState:
			return new BGLayerDrawingOperation( layer, newState, oldState );
		}
		
		public void perform() {
			int[][] bgData = Main.loadedRoom.getBGData( layer );
			Main.copyArray( bgData, oldState );
			
			Main.unsavedChanges = true;
			
			MainLayout.canvas.repaint();
		}
	}
	
	
	
	/**
	 * Represents the creation of a BGLayer. Undoing this operation will
	 * REMOVE the BGLayer from the loaded room.
	 */
	public static class CreateBGLayerOperation implements UndoOperation {
		int     layerInx;
		BGLayer bgLayer;
		int[][] bgData;
		
		public CreateBGLayerOperation ( int layerInx, BGLayer bgLayer, int[][] bgData ) {
			this.layerInx = layerInx;
			this.bgLayer  = new BGLayer( bgLayer.sourceImagePath, bgLayer.data, bgLayer.tileWidth, bgLayer.tileHeight, bgLayer.parallaxFactorX, bgLayer.parallaxFactorY, bgLayer.translateX, bgLayer.translateY );
			this.bgData   = Main.cloneArray( bgData );
		}
		
		
		public UndoOperation getInverse() {
			return new DeleteBGLayerOperation( layerInx, bgLayer, bgData );
		}

		public void perform() {
			Main.loadedRoom.removeBGLayer( layerInx );
			
			Main.unsavedChanges = true;
			
			MainLayout.rebuildUI();
		}

	}
	
	
	
	/**
	 * Represents the removal of a BGLayer. Undoing this operation will
	 * INSERT the BGLayer into the loaded room.
	 */
	public static class DeleteBGLayerOperation implements UndoOperation {
		int     layerInx;
		BGLayer bgLayer;
		int[][] bgData;
		
		public DeleteBGLayerOperation ( int layerInx, BGLayer bgLayer, int[][] bgData ) {
			this.layerInx = layerInx;
			this.bgLayer  = new BGLayer( bgLayer.sourceImagePath, bgLayer.data, bgLayer.tileWidth, bgLayer.tileHeight, bgLayer.parallaxFactorX, bgLayer.parallaxFactorY, bgLayer.translateX, bgLayer.translateY );
			this.bgData   = Main.cloneArray( bgData );
		}
		
		
		public UndoOperation getInverse() {
			return new CreateBGLayerOperation( layerInx, bgLayer, bgData );
		}

		public void perform() {
			Main.loadedRoom.addBGLayer( layerInx, bgLayer );
			
			int[][] bgData = Main.loadedRoom.getBGData( layerInx );
			Main.copyArray( bgData, this.bgData );
			
			Main.unsavedChanges = true;
			
			MainLayout.rebuildUI();
			MainLayout.setWorkingLayer( layerInx );
		}

	}
	
	
	
	/**
	 * Represents a swap of layer positions in the Room's layer order. Undoing 
	 * this operation will un-swap the layers.
	 * 
	 * The operation assumes layer1 was selected before the swap.
	 */
	public static class SwapBGLayerDepthOperation implements UndoOperation {
		int layer1, layer2;
		
		public SwapBGLayerDepthOperation ( int layer1, int layer2 ) {
			this.layer1 = layer1;
			this.layer2 = layer2;
		}
		
		public UndoOperation getInverse() {
			// Swap layer indices:
			return new SwapBGLayerDepthOperation( layer2, layer1 );
		}

		public void perform() {
			Main.loadedRoom.swapLayers( layer1, layer2 );
			
			Main.unsavedChanges = true;
			
			MainLayout.rebuildUI();
			MainLayout.setWorkingLayer( layer1 );
		}
	}
	
	
	
	/**
	 * Represents changes made to a BGLayer via the "Edit" button. Undoing this
	 * operation will restore the BGLayer's parameters and its bgData matrix. 
	 */
	public static class EditBGLayerOperation implements UndoOperation {
		int layerInx;
		BGLayer oldBGLayer, newBGLayer;
		int[][] oldBGData,  newBGData;
		
		public EditBGLayerOperation ( int layerInx, BGLayer oldBGLayer, int[][] oldBGData, BGLayer newBGLayer, int[][] newBGData ) {
			this.layerInx = layerInx;
			
			this.oldBGLayer = new BGLayer( oldBGLayer.sourceImagePath, oldBGLayer.data, oldBGLayer.tileWidth, oldBGLayer.tileHeight, oldBGLayer.parallaxFactorX, oldBGLayer.parallaxFactorY, oldBGLayer.translateX, oldBGLayer.translateY );
			this.newBGLayer = new BGLayer( newBGLayer.sourceImagePath, newBGLayer.data, newBGLayer.tileWidth, newBGLayer.tileHeight, newBGLayer.parallaxFactorX, newBGLayer.parallaxFactorY, newBGLayer.translateX, newBGLayer.translateY );
			
			this.oldBGData  = Main.cloneArray( oldBGData );
			this.newBGData  = Main.cloneArray( newBGData );
		}
		
		public UndoOperation getInverse() {
			// Swap "old" and "new" data:
			return new EditBGLayerOperation( layerInx, newBGLayer, newBGData, oldBGLayer, oldBGData );
		}
		
		public void perform() {
			Main.loadedRoom.setBGLayer( layerInx, oldBGLayer );
			int[][] bgData = Main.loadedRoom.getBGData( layerInx );
			Main.copyArray( bgData, this.oldBGData );
			
			Main.unsavedChanges = true;
			
			MainLayout.rebuildUI();
			MainLayout.setWorkingLayer( layerInx );
		}
	}
	
	
	/**
	 * Represents changes made to a BGLayer's translation coordinates. Undoing
	 * this operation will restore the BGLayer's previous parameters. 
	 */
	public static class TranslateBGLayerOperation implements UndoOperation {
		int layerInx;
		Point oldTrans;
		Point newTrans;
		
		public TranslateBGLayerOperation ( int layerInx, Point oldTrans, Point newTrans ) {
			this.layerInx = layerInx;
			this.oldTrans = oldTrans;
			this.newTrans = newTrans;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new:
			return new TranslateBGLayerOperation( layerInx, newTrans, oldTrans );
		}
		
		public void perform () {
			// Restore the BGLayer's old translation:
			BGLayer bgLayer = Main.loadedRoom.getBGLayer( layerInx );
			bgLayer.translateX = oldTrans.x;
			bgLayer.translateY = oldTrans.y;
			
			Main.unsavedChanges = true;
			
			MainLayout.updateBGPanels();
			MainLayout.canvas.repaint();
		}
	}
	
	
	
	
	/**
	 * Represents the insertion of an object in the Room. Undoing the operation
	 * will REMOVE the object.
	 */
	public static class CreateObjectOperation implements UndoOperation {
		int inx;
		GameObj obj;
		
		public CreateObjectOperation ( int inx, GameObj obj ) {
			this.inx = inx;
			this.obj = obj;
		}
		
		public UndoOperation getInverse () {
			return new DeleteObjectOperation( inx, obj );
		}
		
		public void perform () {
			Main.loadedRoom.gameObjects.remove( inx );
			
			MainLayout.canvas.state = RoomPanel.STATE_NORMAL;
			if ( MainLayout.canvas.selectedObj != null ) {
				MainLayout.canvas.selectedObj.highlighted = false;
				MainLayout.canvas.selectedObj = null;
			}
			
			Main.unsavedChanges = true;
			
			MainLayout.updateBGPanels();
			MainLayout.canvas.repaint();	
		}
	}
	
	
	
	/**
	 * Represents the removal of an object in the Room. Undoing the operation
	 * will INSERT the object.
	 */
	public static class DeleteObjectOperation implements UndoOperation {
		int inx;
		GameObj obj;
			
		public DeleteObjectOperation ( int inx, GameObj obj ) {
			this.inx = inx;
			this.obj = obj;
		}
	
		public UndoOperation getInverse () {
			return new CreateObjectOperation( inx, obj );
		}
	
		public void perform () {
			Main.loadedRoom.gameObjects.add( inx, obj );
		
			MainLayout.canvas.state = RoomPanel.STATE_NORMAL;
			if ( MainLayout.canvas.selectedObj != null ) {
				MainLayout.canvas.selectedObj.highlighted = false;
				MainLayout.canvas.selectedObj = null;
			}
			
			Main.unsavedChanges = true;
			
			MainLayout.updateBGPanels();
			MainLayout.canvas.repaint();	
		}
	}	
	
	
	
	/**
	 * Represents an object's change of position. Undoing this operation will
	 * place the object in its previous position.
	 */
	public static class MoveObjectOperation implements UndoOperation {
		GameObj obj;
		Point oldPos;
		Point newPos;
		
		public MoveObjectOperation ( GameObj obj, Point oldPos, Point newPos ) {
			this.obj = obj;
			this.oldPos = new Point( oldPos );
			this.newPos = new Point( newPos );
		}
		
		public UndoOperation getInverse () {
			// Swap old and new positions:
			return new MoveObjectOperation( obj, newPos, oldPos );
		}
		
		public void perform () {
			obj.x = oldPos.x;
			obj.y = oldPos.y;
			
			// Release dragged object:
			if ( MainLayout.canvas.selectedObj != null ) {
				MainLayout.canvas.selectedObj.highlighted = false;
				MainLayout.canvas.selectedObj = null;
			}
			MainLayout.canvas.state = RoomPanel.STATE_NORMAL;
			
			Main.unsavedChanges = true;
			
			MainLayout.canvas.repaint();
		}
	}
	
	
	
	/**
	 * Represents a change in the object's parameters. Undoing this operation
	 * will restore the object's previous parameters.
	 */
	public static class EditObjectOperation implements UndoOperation {
		GameObj newObj, oldObj;
		
		public EditObjectOperation ( GameObj oldObj, GameObj newObj ) {
			this.oldObj = oldObj;
			this.newObj = newObj;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new parameters:
			return new EditObjectOperation( newObj, oldObj );
		}
		
		public void perform () {
			// Look for the object's index:
			int index = Main.loadedRoom.gameObjects.indexOf( newObj );
			
			// Replace:
			Main.loadedRoom.gameObjects.set( index, oldObj );
			
			// Release dragged object:
			if ( MainLayout.canvas.selectedObj != null ) {
				MainLayout.canvas.selectedObj.highlighted = false;
				MainLayout.canvas.selectedObj = null;
			}
			MainLayout.canvas.state = RoomPanel.STATE_NORMAL;
			
			Main.unsavedChanges = true;
			
			MainLayout.canvas.repaint();
		}
	}
	
	
	
	/**
	 * Represents a "to front" or "to back" operation on a game object.
	 * Undoing it will place the object in its previous depth. 
	 */
	public static class ChangeObjectDepthOperation implements UndoOperation {
		int oldPos;
		int newPos;
		
		public ChangeObjectDepthOperation ( int oldPos, int newPos ) {
			this.oldPos = oldPos;
			this.newPos = newPos;
		}
		
		public UndoOperation getInverse () {
			// Swap old and new:
			return new ChangeObjectDepthOperation( newPos, oldPos ); 
		}
		
		public void perform () {
			Object obj = Main.loadedRoom.gameObjects.remove( newPos );
			Main.loadedRoom.gameObjects.add( oldPos, obj );
			
			Main.unsavedChanges = true;
			
			MainLayout.canvas.repaint();
		}
	}
	
	
	
}
