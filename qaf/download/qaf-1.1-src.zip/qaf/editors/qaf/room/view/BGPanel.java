package qaf.room.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.event.MouseInputAdapter;

import qaf.room.control.HistoryManager;
import qaf.room.control.Main;
import qaf.room.control.UndoImpl;
import qaf.room.control.UndoOperation;
import qaf.room.model.BGLayer;
import qaf.room.model.ObstacleBlockTypes;

/**
 * Objects of this class may be associated with a BGLayer or the obstacle
 * layer (if the "layer" field is -1).
 */
public class BGPanel extends Box {

	/** Used to draw the grid on this panel's BG tiles. */
	public static final Color GRID_COLOR = new Color(200, 0, 0, 150);

	/** Used to highlight the selected tile. */
	public static final Color SELECTED_TILE_COLOR = Color.RED;

	/** Used to render a string indicative of the blank tile. */
	public static final Image BLANK_STR =
		Toolkit.getDefaultToolkit().createImage(System.getenv("QAF_PATH") + "img/blankStr.png");

	/** Used to indicate a free cell in the brush matrix. */
	public static final int BRUSH_FREE_CELL_ID = -2;

	/** The layer monitored by this component: */
	int layerInx;

	/** The currently selected tile brush.
	 * To allow free-form selections, I will adopt the following convention:
	 *  - Valid places in the matrix are marked with their corresponding tile
	 *    IDs;
	 *  - Unoccupied places in the matrix are marked with the value
	 *    BRUSH_FREE_CELL_ID. */
	int[][] brush = { { -1 } };
	
	/** Indicates whether the last selection took place by clicking on this
	 * panel or Ctrl + clicking on the room panel. */
	boolean lastSelectionOnPanel = true;
	
	/** If lastSelectionOnPanel is false, these coordinates indicate the
	 * brush's position relative to the layer's data matrix. */
	int brushStartRow = 0, brushStartCol = 0;

	/** JLabel used to display the BGLayer's data (gameObjects or
	 * parallaxFactor). */
	JLabel infoLabel = new JLabel();

	JLabel tileSizeLabel = new JLabel(), translateLabel = new JLabel();

	/** Show/hide this layer. */
	JCheckBox hideCheckBox = new JCheckBox("Hide", false);
	
	/** Flip tiles in this layer's picker. */
	JCheckBox flipXCheckBox = new JCheckBox("Flip X", false),
	          flipYCheckBox = new JCheckBox("Flip Y", false);

	/** Buttons to alter layer order. */
	JButton toFrontButton = new JButton("<"), toBackButton = new JButton(">");
	
	/** A scroll pane that contains the bgPicker. */
	JScrollPane bgPickerPane;
	
	/** A JPanel that displays this background layer's tiles. */
	JPanel bgPicker = new JPanel() {
		public void paint(Graphics g) {
			BGLayer bgLayer = Main.loadedRoom.getBGLayer(layerInx);
			
			MainLayout.clearBGWithHatches(g, getWidth(), getHeight());
			
			// Flip status:
			int srcX1 = (!flipXCheckBox.isSelected() ? 0 : bgLayer.data.getWidth(Main.f));
			int srcY1 = (!flipYCheckBox.isSelected() ? 0 : bgLayer.data.getHeight(Main.f));
			int srcX2 = bgLayer.data.getWidth(Main.f)  - srcX1;
			int srcY2 = bgLayer.data.getHeight(Main.f) - srcY1;
			
			// Draw the BG image:
			// The first "row" will display a blank rectangle, denoting ID -1
			// (or the "blank tile").
			g.drawImage(
				BLANK_STR,
				getWidth() / 2 - BLANK_STR.getWidth(Main.f) / 2,
				Main.loadedRoom.blockSize / 2 - BLANK_STR.getHeight(Main.f) / 2,
				Main.f);
			
			// Thus, the image will be drawn on the second "row."
			int dstX1 = 1;
			int dstY1 = Main.loadedRoom.blockSize + 1;
			int dstX2 = dstX1 + bgLayer.data.getWidth(Main.f);
			int dstY2 = dstY1 + bgLayer.data.getHeight(Main.f);
			
			g.drawImage(bgLayer.data, dstX1, dstY1, dstX2, dstY2, srcX1, srcY1, srcX2, srcY2, Main.f);
			
			// Draw grid:
			MainLayout.drawGrid(
				g,
				1,
				1 + Main.loadedRoom.blockSize,
				bgLayer.getRows(),
				bgLayer.getCols(),
				bgLayer.tileWidth,
				bgLayer.tileHeight,
				bgLayer.getNumberOfTiles(),
				GRID_COLOR);
			
			if (lastSelectionOnPanel) {
				// Draw rectangles around the tiles in the brush:
				g.setColor(SELECTED_TILE_COLOR);
				((Graphics2D) g).setStroke( StrokeTimer.getCurrent() );
				
				for (int i = 0; i < brush.length; i++) {
					for (int j = 0; j < brush[i].length; j++) {
						int tileID = brush[i][j];
						if (tileID == -1) {
							g.drawRect(
								1,
								1,
								bgLayer.data.getWidth(Main.f),
								Main.loadedRoom.blockSize);
						}
						else {
							// Calculate unflipped tile ID:
							int plainTileID = tileID;
							plainTileID &= (~BGLayer.TILE_FLIPPED_X);
							plainTileID &= (~BGLayer.TILE_FLIPPED_Y);
							
							// Calculate unflipped tile's position in the BG image:
							int topLeftX =
								(plainTileID * bgLayer.tileWidth) % bgLayer.data.getWidth(Main.f);
							int topLeftY =
								((plainTileID * bgLayer.tileWidth) / bgLayer.data.getWidth(Main.f)) * bgLayer.tileHeight;
							
							// Adjust for flip status:
							if(flipXCheckBox.isSelected())
								topLeftX = (bgLayer.data.getWidth(Main.f))  - bgLayer.tileWidth  - topLeftX;
							if(flipYCheckBox.isSelected())
								topLeftY = (bgLayer.data.getHeight(Main.f)) - bgLayer.tileHeight - topLeftY;
							
							// Adjust Y position due to the blank tile:
							topLeftY += Main.loadedRoom.blockSize;
							
							// Draw lines:
							if ( j == 0 || brush[i][j - 1] == BRUSH_FREE_CELL_ID )
								g.drawLine(
									1 + topLeftX, 1 - 1 + topLeftY,
									1 + topLeftX, 1 + 1 + topLeftY + bgLayer.tileHeight );
							if ( j == brush[i].length - 1 || brush[i][j + 1] == BRUSH_FREE_CELL_ID )
								g.drawLine(
									1 + topLeftX + bgLayer.tileWidth, 1 - 1 + topLeftY,
									1 + topLeftX + bgLayer.tileWidth, 1 + 1 + topLeftY + bgLayer.tileHeight );
							if ( i == 0 || brush[i - 1][j] == BRUSH_FREE_CELL_ID )
								g.drawLine(
									1 - 1 + topLeftX,                     1 + topLeftY,
									1 + 1 + topLeftX + bgLayer.tileWidth, 1 + topLeftY );
							if ( i == brush.length - 1 || brush[i + 1][j] == BRUSH_FREE_CELL_ID )
								g.drawLine(
									1 - 1 + topLeftX,                     1 + topLeftY + bgLayer.tileHeight,
									1 + 1 + topLeftX + bgLayer.tileWidth, 1 + topLeftY + bgLayer.tileHeight );
							
						}
					}
				}
			}
		}
		
		public Dimension getPreferredSize() {
			BGLayer bgLayer = Main.loadedRoom.getBGLayer(layerInx);
			return new Dimension(
				bgLayer.data.getWidth(Main.f) + 2,
				bgLayer.data.getHeight(Main.f) + 2 + Main.loadedRoom.blockSize);
		}
		
		public Dimension getMinimumSize() {
			BGLayer bgLayer = Main.loadedRoom.getBGLayer(layerInx);
			return new Dimension(
				bgLayer.data.getWidth(Main.f) + 2,
				bgLayer.data.getHeight(Main.f) + 2 + Main.loadedRoom.blockSize);
		}
	};
	
	/**
	 * Constructor:
	 * Builds the layout within this JScrollPane.
	 */
	public BGPanel(int _layer) {
		super(BoxLayout.Y_AXIS);
		setAlignmentX(Box.LEFT_ALIGNMENT);
		setAlignmentY(Box.TOP_ALIGNMENT);

		// Store this BGPanel's referred layer index:
		this.layerInx = _layer;

		BGLayer bgLayer = Main.loadedRoom.getBGLayer(layerInx);
		
		// A MouseInputListener will detect user clicks/movements on the
		// bgPicker:
		MouseInputAdapter mia = new MouseInputAdapter() {
			int prevX, prevY;
			
			public void mousePressed(MouseEvent evt) {
				if (evt.getButton() == MouseEvent.BUTTON1)
					handleMouseEvent(evt);
				
				prevX = evt.getX();
				prevY = evt.getY();
			}
			
			public void mouseDragged(MouseEvent evt) {
				// Dragging with the right mouse button?
				if ((evt.getModifiersEx() & MouseEvent.BUTTON3_DOWN_MASK) != 0) {
					int dx = evt.getX() - prevX;
					int dy = evt.getY() - prevY;
					
					JScrollBar hScroll = bgPickerPane.getHorizontalScrollBar();
					JScrollBar vScroll = bgPickerPane.getVerticalScrollBar();
					
					hScroll.setValue(hScroll.getValue() - dx);
					vScroll.setValue(vScroll.getValue() - dy);
					
					evt.translatePoint(-dx, -dy);
				}
				// Dragging with the left mouse button?
				if ((evt.getModifiersEx() & MouseEvent.BUTTON1_DOWN_MASK) != 0)
					handleMouseEvent(evt);
				
				prevX = evt.getX();
				prevY = evt.getY();
			}
		};
		
		bgPicker.addMouseListener(mia);
		bgPicker.addMouseMotionListener(mia);
		
		// Picker cursor:
		bgPicker.setCursor( Main.eyedropCursor );

		// BGPanel layout:

		// Settings box:
		//
		// +------------------------------------+
		// | [ ] Hide                           |
		// |------------------------------------|
		// | Parallax/game objects              |
		// |------------------------------------|
		// | Tile size                          |
		// |--------------+---------------------|
		// | Translation  | [ ] FlipX [ ] FlipY | <-- Absent if layer == -1
		// +--------------+---------------------+
		//
		Box settingsBox = Box.createVerticalBox();
		settingsBox.setAlignmentX(Box.LEFT_ALIGNMENT);
		settingsBox.setAlignmentY(Box.TOP_ALIGNMENT);

		// "Hide" checkbox:
		hideCheckBox.setSelected(bgLayer.isHidden);
		hideCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				Main.loadedRoom.getBGLayer(layerInx).isHidden =
					hideCheckBox.isSelected();
				MainLayout.canvas.repaint();
			}
		});
		settingsBox.add(hideCheckBox);

		// Obstacle layer...?
		if (layerInx == -1)
			infoLabel.setText("No game objects in this room.");
		// ...or "normal" layer?
		else
			infoLabel.setText("Parallax factor: " + bgLayer.parallaxFactorX + ", " + bgLayer.parallaxFactorY);

		settingsBox.add(infoLabel);
		settingsBox.add(Box.createRigidArea(new Dimension(0, 5)));

		// "Tile size" box:
		tileSizeLabel.setText(
			"Tile size: " + bgLayer.tileWidth + "x" + bgLayer.tileHeight);
		settingsBox.add(tileSizeLabel);
		settingsBox.add(Box.createRigidArea(new Dimension(0, 5)));

		// "Translation"/"Flip" box:
		if (layerInx != -1) {
			Box b = Box.createHorizontalBox();
			b.setAlignmentX(Box.LEFT_ALIGNMENT);
			b.setAlignmentY(Box.TOP_ALIGNMENT);
			translateLabel.setText(
				"Translation: "
					+ bgLayer.translateX
					+ " X, "
					+ bgLayer.translateY
					+ " Y");
			b.add(translateLabel);
			b.add(Box.createHorizontalGlue());
			b.add(flipXCheckBox);
			b.add(Box.createRigidArea(new Dimension(5, 0)));
			b.add(flipYCheckBox);
			
			flipXCheckBox.addActionListener(
				new ActionListener() {
					public void actionPerformed ( ActionEvent evt ) {
						flipBrush(true, false);
						bgPicker.repaint();
					} } );
			flipYCheckBox.addActionListener(
				new ActionListener() {
					public void actionPerformed ( ActionEvent evt ) {
						flipBrush(false, true);
						bgPicker.repaint();
					} } );
			
			settingsBox.add(b);
			settingsBox.add(Box.createRigidArea(new Dimension(0, 5)));
		}

		add(settingsBox);
		
		// Wrap the bgPicker inside a JScrollPane:
		bgPickerPane = new JScrollPane(bgPicker);
		bgPickerPane.setAlignmentX(JScrollPane.LEFT_ALIGNMENT);
		bgPickerPane.setAlignmentY(JScrollPane.TOP_ALIGNMENT);
		bgPickerPane.setPreferredSize(
			new Dimension(
				bgLayer.data.getWidth(Main.f) + 5,
				bgLayer.data.getHeight(Main.f) + 5));
		// TODO: Isn't there a more elegant solution for the scrollBar problem?
		add(bgPickerPane);

		// Control box:
		// 
		// +----------------------------------+
		// |[ < ] [ Edit... ] [ Delete ] [ > ]|
		// +----------------------------------+
		// 
		if (layerInx != -1) {
			JButton editButton = new JButton("Edit...");
			editButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					// Show edit dialog:
					BGLayer newLayer =
						EditBGLayerDialog.editLayer(Main.loadedRoom, layerInx);

					// User confirmed?
					if (newLayer != null) {
						String[] message =
							{
								"Changing a layer's configuration will",
								"force its data matrix to be resized,",
								"which may cause some of its contents",
								"to be lost." };

						JOptionPane.showMessageDialog(Main.f, // parent dialog
						message, // message
						"Edit layer", // title
						JOptionPane.INFORMATION_MESSAGE); // message type

						// Store old values for the UndoOperation...
						BGLayer oldBGLayer =
							Main.loadedRoom.getBGLayer(layerInx);
						int[][] oldBGData =
							Main.cloneArray(
								Main.loadedRoom.getBGData(layerInx));

						// Change...
						Main.loadedRoom.setBGLayer(layerInx, newLayer);
						MainLayout.rebuildUI();
						MainLayout.setWorkingLayer(layerInx);

						Main.unsavedChanges = true;

						// Commit UndoOperation
						UndoOperation op =
							new UndoImpl.EditBGLayerOperation(
								layerInx,
								oldBGLayer,
								oldBGData,
								newLayer,
								Main.cloneArray(
									Main.loadedRoom.getBGData(layerInx)));
						HistoryManager.addUndoOperation(
							op,
							"edit layer " + layerInx);
					}
				}
			});

			JButton deleteButton = new JButton("Delete");
			deleteButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					// Store old data for the UndoOperation:
					BGLayer oldBGLayer = Main.loadedRoom.getBGLayer(layerInx);
					int[][] oldBGData =
						Main.cloneArray(Main.loadedRoom.getBGData(layerInx));

					// Remove layer and update the UI:
					Main.loadedRoom.removeBGLayer(layerInx);
					MainLayout.rebuildUI();

					Main.unsavedChanges = true;

					// Commit UndoOperation:
					UndoOperation op =
						new UndoImpl.DeleteBGLayerOperation(
							layerInx,
							oldBGLayer,
							oldBGData);
					HistoryManager.addUndoOperation(
						op,
						"delete layer " + layerInx);
				}
			});

			toFrontButton.setToolTipText("Bring this layer one step forward");
			if (layerInx > 0)
				toFrontButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					// Swap this layer's position with the one before it:
					Main.loadedRoom.swapLayers(layerInx, layerInx - 1);
					MainLayout.rebuildUI();
					MainLayout.setWorkingLayer(layerInx - 1);

					Main.unsavedChanges = true;

					// Commit UndoOperation:
					UndoOperation op =
						new UndoImpl.SwapBGLayerDepthOperation(
							layerInx,
							layerInx - 1);
					HistoryManager.addUndoOperation(op, "bring layer to front");
				}
			});
			else
				toFrontButton.setEnabled(false);

			toBackButton.setToolTipText("Send this layer one step backwards");
			if (layerInx < Main.loadedRoom.getNumberOfBGLayers() - 1)
				toBackButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					// Swap this layer's position with the one after it:
					Main.loadedRoom.swapLayers(layerInx, layerInx + 1);
					MainLayout.rebuildUI();
					MainLayout.setWorkingLayer(layerInx + 1);

					Main.unsavedChanges = true;

					// Commit UndoOperation:
					UndoOperation op =
						new UndoImpl.SwapBGLayerDepthOperation(
							layerInx,
							layerInx + 1);
					HistoryManager.addUndoOperation(op, "send layer to back");
				}
			});
			else
				toBackButton.setEnabled(false);

			Box controlBox = Box.createHorizontalBox();
			controlBox.setAlignmentX(0.0f);
			controlBox.add(toFrontButton);
			controlBox.add(Box.createHorizontalGlue());
			controlBox.add(editButton);
			controlBox.add(Box.createHorizontalGlue());
			controlBox.add(deleteButton);
			controlBox.add(Box.createHorizontalGlue());
			controlBox.add(toBackButton);

			add(controlBox);
		}
		
	}

	/**
	 * Updates all UI components in this BGPanel.
	 */
	public void updateLayerParameters() {
		BGLayer bgLayer = Main.loadedRoom.getBGLayer(layerInx);

		hideCheckBox.setSelected(bgLayer.isHidden);

		if (layerInx == -1)
			infoLabel.setText(Main.loadedRoom.getGameObjDescription());
		else
			infoLabel.setText("Parallax factor: " + bgLayer.parallaxFactorX + ", " + bgLayer.parallaxFactorY);

		tileSizeLabel.setText(
			"Tile size: " + bgLayer.tileWidth + "x" + bgLayer.tileHeight);

		if (layerInx != -1)
			translateLabel.setText(
				"Translation: "
					+ bgLayer.translateX
					+ " X, "
					+ bgLayer.translateY
					+ " Y");

		bgPicker.repaint();
	}

	/**
	 * Extends the brush as needed.
	 */
	public void setTileInBrush(int tileID, int row, int col) {
		int orgRow = -1, newRows = brush.length, tileRowInBrush = -1;
		int orgCol = -1, newCols = brush[0].length, tileColInBrush = -1;
		boolean brushResized = false;

		// Row-related stuff:
		if (row < 0) {
			// Extend to the top:
			orgRow = -row;
			newRows = brush.length + (-row);
			tileRowInBrush = 0;
			brushStartRow += row;
			brushResized = true;
		}
		else if (row >= brush.length) {
			// Extend to the bottom:
			orgRow = 0;
			newRows = row + 1;
			tileRowInBrush = row;
			brushResized = true;
		}
		else {
			orgRow = 0;
			tileRowInBrush = row;
		}

		// Column-related stuff:
		if (col < 0) {
			// Extend to the left:
			orgCol = -col;
			newCols = brush[0].length + (-col);
			tileColInBrush = 0;
			brushStartCol += col;
			brushResized = true;
		}
		else if (col >= brush[0].length) {
			// Extend to the bottom:
			orgCol = 0;
			newCols = col + 1;
			tileColInBrush = col;
			brushResized = true;
		}
		else {
			orgCol = 0;
			tileColInBrush = col;
		}

		// The brush's size needs to be changed?
		if (brushResized) {
			// Create empty brush:
			int[][] newBrush = new int[newRows][newCols];
			for (int i = 0; i < newRows; i++)
				for (int j = 0; j < newCols; j++)
					newBrush[i][j] = BRUSH_FREE_CELL_ID;

			// Blit the old brush onto this one:
			Main.blitMatrix(newBrush, brush, orgRow, orgCol);

			brush = newBrush;
		}

		// Place the new tile:
		brush[tileRowInBrush][tileColInBrush] = tileID;
	}
	
	/**
	 * Shrinks the brush as needed.
	 */
	public void unsetTileInBrush(int row, int col) {
		// Ignore if coordinates outside of matrix:
		if (row < 0 || row >= brush.length ||
		    col < 0 || col >= brush[0].length)
			return;
		
		// Store the tile ID in that cell:
		int oldTileID = brush[row][col];
		
		// Remove it:
		brush[row][col] = BRUSH_FREE_CELL_ID;

		// Was that the last tile in the brush?
		boolean lastTile = true;
		for (int i = 0; i < brush.length; i++)
			for (int j = 0; j < brush[0].length; j++)
				if (brush[i][j] != BRUSH_FREE_CELL_ID) {
					lastTile = false;
					break;
				}
		if (lastTile)
			// Ignore. Can't have an empty brush!
			brush[row][col] = oldTileID;
		else {
			// Brush needs to be shrunk?
			boolean leftmost = (col == 0),
				rightmost = (col == brush[0].length - 1),
				topmost = (col == 0),
				bottmost = (row == brush.length - 1);

			if (leftmost) {
				int i, j;
LEFTMOST_LABEL:
				for (j = 0; j < brush[0].length; j++)
					for (i = 0; i < brush.length; i++)
						if (brush[i][j] != BRUSH_FREE_CELL_ID)
							break LEFTMOST_LABEL;

				int[][] newBrush =
					new int[brush.length][brush[0].length - j];
				Main.blitMatrix(newBrush, brush, 0, -j);
				brush = newBrush;
			}
			else if (rightmost) {
				int i, j;
RIGHTMOST_LABEL:
				for (
					j = brush[0].length - 1; j >= 0; j--)
					for (i = 0; i < brush.length; i++)
						if (brush[i][j] != BRUSH_FREE_CELL_ID)
							break RIGHTMOST_LABEL;

				int[][] newBrush = new int[brush.length][j + 1];
				Main.blitMatrix(newBrush, brush, 0, 0);
				brush = newBrush;
			}

			if (topmost) {
				int i, j;
TOPMOST_LABEL:
				for (i = 0; i < brush.length; i++)
					for (j = 0; j < brush[0].length; j++)
						if (brush[i][j] != BRUSH_FREE_CELL_ID)
							break TOPMOST_LABEL;

				int[][] newBrush =
					new int[brush.length - i][brush[0].length];
				Main.blitMatrix(newBrush, brush, -i, 0);
				brush = newBrush;
			}
			else if (bottmost) {
				int i, j;
BOTTMOST_LABEL:
				for (i = brush.length - 1; i >= 0; i--)
					for (j = 0; j < brush[0].length; j++)
						if (brush[i][j] != BRUSH_FREE_CELL_ID)
							break BOTTMOST_LABEL;

				int[][] newBrush = new int[i + 1][brush[0].length];
				Main.blitMatrix(newBrush, brush, 0, 0);
				brush = newBrush;
			}
		}	
	}
	
	private int rowOf(int tileID) {
		if (tileID == -1)
			return -1;
		else
			return tileID / (Main.loadedRoom.getBGLayer(layerInx).getCols());
	}

	private int columnOf(int tileID) {
		if (tileID == -1)
			return 0;
		else
			return tileID % (Main.loadedRoom.getBGLayer(layerInx).getCols());
	}
	
	/**
	 * Mirrors the brush horizontally and/or vertically.
	 */
	private void flipBrush ( boolean flipX, boolean flipY ) {
		// Build brush with the same size:
		int[][] newBrush = new int[brush.length][brush[0].length];
		
		// Copy:
		for ( int i = 0; i < brush.length; i++ ) {
			for ( int j = 0; j < brush[i].length; j++ ) {
				int iInx = (flipY ? (brush.length    - i - 1) : i);
				int jInx = (flipX ? (brush[i].length - j - 1) : j);
				
				int tileID = brush[iInx][jInx];
				
				// The tileID needs to be flipped?
				if ( tileID != -1 && tileID != BRUSH_FREE_CELL_ID ) {
					if ( flipX )
						tileID ^= BGLayer.TILE_FLIPPED_X;
					
					if ( flipY )
						tileID ^= BGLayer.TILE_FLIPPED_Y;
				}
				
				newBrush[i][j] = tileID;
			}
		}
		
		// Done!
		brush = newBrush;
	}
	
	
	/**
	 * All mouse functions are very similar, so I'm concentrating all this
	 * stuff in a single method.
	 */
	private void handleMouseEvent(MouseEvent evt) {
		BGLayer bgLayer = Main.loadedRoom.getBGLayer(layerInx);
		
		// "Slide" these coordinates so they are relative to the
		// image's top-left corner:
		int x = evt.getX() + 1;
		int y = evt.getY() + 1 - Main.loadedRoom.blockSize;
		
		// Flip as needed:
		if (flipXCheckBox.isSelected())
			x = bgLayer.data.getWidth(Main.f) - x;
		if (flipYCheckBox.isSelected() && y > 0)
			y = bgLayer.data.getHeight(Main.f) - y;
		
		// Ignore if click was outside the image:
		if (x > bgLayer.data.getWidth(Main.f)
			|| y > bgLayer.data.getHeight(Main.f))
			return;

		// Get which tile was clicked on:
		int tileID;

		// Upper "row": Blank tile
		if (y < 0)
			tileID = -1;
		else {
			// Row and column clicked:
			int row = (y - 1) / bgLayer.tileHeight;
			int col = (x - 1) / bgLayer.tileWidth;

			// Tiles per row:
			int tilesPerRow = bgLayer.data.getWidth(Main.f) / bgLayer.tileWidth;

			// For each row, add tilesPerRow to the column.
			// At the end of the loop, col will hold the tile ID.
			for (; row > 0; row--)
				col += tilesPerRow;

			// Ignore click if the selected tile is an invalid
			// value:
			if (layerInx == -1) {
				if (col > ObstacleBlockTypes.MAX_BLOCK_TYPES)
					return;
			} else {
				if (col > BGLayer.MAX_TILE_ID)
					return;
			}

			tileID = col;
		}
		// Clicked tile ID has been determined!

		// Starting a new selection?
		if (!lastSelectionOnPanel || (!evt.isShiftDown() && !evt.isAltDown())) {
			if (brush.length != 1 || brush[0].length != 1)
				brush = new int[1][1];
			brush[0][0] = tileID;
			flipBrush(flipXCheckBox.isSelected(), flipYCheckBox.isSelected());
		}
		// Extending the existing selection:
		else {
			// Temporarily unflip the brush so the tile can be added without
			// too much hassle:
			flipBrush(flipXCheckBox.isSelected(), flipYCheckBox.isSelected());
			
			// Calculate row and column of the brush's top-left cell:
			int topLeftRow = rowOf(brush[0][0]);
			int topLeftCol = columnOf(brush[0][0]);
			
			if (brush[0][0] == BRUSH_FREE_CELL_ID) {
				// Look for occupied cell:
				int i = -1, j = -1;
				label0 : for (i = 0; i < brush.length; i++)
					for (j = 0; j < brush[0].length; j++)
						if (brush[i][j] != BRUSH_FREE_CELL_ID)
							break label0;
				
				// Use it as a base for the top-left cell:
				topLeftRow = rowOf(brush[i][j]) - i;
				topLeftCol = columnOf(brush[i][j]) - j;
			}
			
			// Calculate tile's position:
			int tileRow = rowOf(tileID);
			int tileCol = columnOf(tileID);
			
			// Set/unset the tile:
			if (!evt.isAltDown())
				setTileInBrush(tileID, tileRow - topLeftRow, tileCol - topLeftCol);
			else
				unsetTileInBrush(tileRow - topLeftRow, tileCol - topLeftCol);
			
			// Flip it back:
			flipBrush(flipXCheckBox.isSelected(), flipYCheckBox.isSelected());
		}

		lastSelectionOnPanel = true;

		// Repaint to show the change in the brush:
		bgPicker.repaint();
		MainLayout.canvas.repaint();
	}
	
	
	/**
	 * Sets the correct cursor on the BG picker based on the Shift and Alt
	 * status read from the Main class.
	 */
	public void updateCursor () {
		if ( Main.altDown )
			bgPicker.setCursor( Main.eyedropMinusCursor );
		else if ( Main.shiftDown )
			bgPicker.setCursor( Main.eyedropPlusCursor );
		else
			bgPicker.setCursor( Main.eyedropCursor );
	}
	
}
