package qaf.room.view;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import qaf.room.control.Main;
import qaf.room.model.GameObj;


// TODO: Is this class needed?
/**
 * A JSpinner that accepts integer values.
 *
class IntegerSpinnerModel implements SpinnerModel {
	Vector changeListeners = new Vector();
	int value;

	public IntegerSpinnerModel ( int initialValue ) {
		value = initialValue;
	}

	public void addChangeListener(ChangeListener c) {
		changeListeners.add( c );
	}
	public void removeChangeListener(ChangeListener c) {
		changeListeners.remove( c );
	}

	public Object getNextValue() {
		return new Integer(value + 1);
	}
	public Object getPreviousValue() {
		return new Integer( value - 1 );
	}

	public Object getValue() {
		return new Integer( value );
	}
	public void setValue(Object obj) {
		try {
			int newValue = Integer.parseInt( obj.toString() );
		
			value = newValue;
			
			ChangeEvent evt = new ChangeEvent( this );
			for ( int i = 0; i < changeListeners.size(); i++ )
				((ChangeListener) changeListeners.get( i )).stateChanged( evt );
		}
		catch ( NumberFormatException exc ) {
			throw new IllegalArgumentException();
		}
	}
}
*/


/**
 * A TableModel for the object's attribute table.
 */
class AttributeTableModel implements TableModel {
	// The object being edited.
	private GameObj obj;
	
	// TableModelListeners:
	Vector tableModelListeners = new Vector();
	
	/**
	 * The constructor receives the "target object" that is being edited. 
	 */
	public AttributeTableModel ( GameObj _obj ) {
		obj = _obj;
	}
	
	public void addTableModelListener ( TableModelListener l ) {
		tableModelListeners.add( l );
	}
	public void removeTableModelListener ( TableModelListener l ) {
		tableModelListeners.remove( l );
	}

		
	public Class getColumnClass ( int columnIndex ) {
		return String.class;
	}

	public int getColumnCount() {
		return 2;
	}

	public String getColumnName ( int columnIndex ) {
		switch ( columnIndex ) {
			case 0:
				return "Key";
			case 1:
				return "Value";
			default:
				return null;
		}
	}

	public int getRowCount () {
		// One additional row for the "New value..." cell:
		return obj.attributeTable.size() + 1;
	}

	public Object getValueAt ( int rowIndex, int columnIndex ) {
		if ( rowIndex < obj.attributeTable.size() ) {
			switch ( columnIndex ) {
				case 0:
					return obj.attributeTable.getKey( rowIndex );
				case 1:
					return obj.attributeTable.getValue( rowIndex );
				default:
					return null;
			}
		}
		else {
			// "New value..."
			switch ( columnIndex ) {
				case 0:
					return "";
				case 1:
					return "(New value...)";
				default:
					return null;
			}
		}
	}

	public boolean isCellEditable ( int rowIndex, int columnIndex ) {
		return false;
	}

	public void setValueAt ( Object aValue, int rowIndex, int columnIndex ) {}

}




/**
 * A dialog that serves no purpose other than edit the attribute table's
 * values.
 */
class EditKeyValueDialog extends JDialog {
	/** Status values used by clients to determine which button in the dialog 
	 * was pressed. */
	public final static int STATUS_NONE   = 0,
	                        STATUS_OK     = 1,
	                        STATUS_CANCEL = 2;
	
	/** Used to indicate which button was pressed by the user. */
	private int status = STATUS_NONE;
	
	// Storing the GUI components here lets me use them later for callbacks:
	private JButton     okButton,
	                    cancelButton;
	private JTextField  keyTxtField;
	private JTextArea   valueTxtField;
	
	/**
	 * Constructor: Receives the parent Frame and the Strings that will be
	 * copied to initialize the editor's fields.
	 */
	private EditKeyValueDialog ( JDialog parent, String key, String value, boolean isKeyEditable ) {
		// Invoke the constructor from the JDialog superclass:
		// Bind it to the "parent" and define it as modal.
		super( parent, true );
		setResizable( false );
		
		// Initialize text fields:
		keyTxtField = new JTextField( key );
		keyTxtField.setEditable( isKeyEditable );
		valueTxtField = new JTextArea( value );
		
		// Build dialog layout:
		// 
		// +=====================+
		// | Key:                |
		// | [_________________] |
		// |                     |
		// | Value:              |
		// | +-----------------+ |
		// | |               |^| |
		// | |               | | |
		// | |               |v| |
		// | +-----------------+ |
		// |                     |
		// | [  OK  ] [ Cancel ] |
		// +---------------------+
		// 
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY( 0.0f );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// KEY:
		theBox.add( new JLabel("Key:") );
		theBox.add( keyTxtField );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// VALUE:
		theBox.add( new JLabel("Value:") );
		JScrollPane valueScrollPane = new JScrollPane( valueTxtField );
		valueScrollPane.setAlignmentX( 0.0f );
		valueScrollPane.setAlignmentY( 0.0f );
		valueScrollPane.setPreferredSize( new Dimension( 350, 150 ) );
		theBox.add( valueScrollPane );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// BUTTONS:
		// Upon being pressed, these will set the "status" field to the
		// appropriate value and close the dialog:
		okButton = new JButton( "OK" );
		okButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				// Validate key/value:
				// No key?
				if ( keyTxtField.getText().equals( "" ) ) {
					JOptionPane.showMessageDialog(
						EditKeyValueDialog.this.getParent(),      // parent
						"You must specify a key for this value.", // message
						"Error",                                  // title
						JOptionPane.ERROR_MESSAGE );              // messageType
				}
				else {
					// OK!
					status = STATUS_OK;
					dispose();
				}
			} } );
		cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				status = STATUS_CANCEL;
				dispose();
			} } );
		
		theBox.add( new JSeparator() );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// Add the buttons to the dialog:
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.0f );
		buttonBox.add( Box.createGlue() );
		buttonBox.add( okButton );
		buttonBox.add( Box.createRigidArea( new Dimension(15, 0) ) );
		buttonBox.add( cancelButton );
		buttonBox.add( Box.createGlue() );
		theBox.add( buttonBox );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// Add fillers to the left and right of the box:
		Box filler = Box.createHorizontalBox();
		filler.setAlignmentX( 0.0f );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		filler.add( theBox );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		getContentPane().add( filler );
		
		// Layout done!
		
		// Set "OK" as the default button:
		getRootPane().setDefaultButton( okButton );
		
		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
		Action escapeAction = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				cancelButton.doClick();
			} };
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", escapeAction);
	}
	
	
	
	/**
	 * Pops up a dialog asking for a key/value pair.
	 * The dialog will display the key and value supplied in the arguments in
	 * the dialog's text fields when it appears.
	 * Returns the pair as a String array, or null if the user canceled.
	 */
	public static String[] getKeyValuePair ( JDialog parent, String key, String value, boolean isKeyEditable ) {
		EditKeyValueDialog editor = new EditKeyValueDialog( parent, key, value, isKeyEditable );
		editor.setTitle( "Edit key/value pair" );
		editor.pack();
		editor.setLocationRelativeTo( null ); // Center on screen
		editor.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
		
		// Check status:
		// User cancelled or closed the window?
		if ( editor.status != STATUS_OK )
			return null;
		// User confirmed?
		else {
			String[] returnValue = new String[2];
			returnValue[0] = editor.keyTxtField.getText();
			returnValue[1] = editor.valueTxtField.getText();
			
			return returnValue;
		}
		
	}
	
}





/**
 * This is a JDialog created specifically for editing GameObjs. The recommended
 * strategy is to use the static methods createGameObj() and editGameObj()
 * rather than creating the dialog directly. 
 */
public class EditGameObjDialog extends JDialog {
	/** Status values used by clients to determine which button in the dialog 
	 * was pressed. */
	public final static int STATUS_NONE   = 0,
	                        STATUS_OK     = 1,
	                        STATUS_CANCEL = 2;
	
	
	/** Used to indicate which button was pressed by the user. */
	private int status = STATUS_NONE;
	
	/** The GameObj being edited. */
	private GameObj obj = null;
	
	// Storing the GUI components here lets me use them later for callbacks:
	private JButton     okButton,
	                    cancelButton;
	private JTextField  objIdTxt;
	private JTable      attributeTable;
	
	/**
	 * Constructor: Receives the parent Frame and the object being edited. Its
	 * data will be copied to initialize the editor's fields. (Passing a null
	 * argument will create a new object.)
	 */
	private EditGameObjDialog ( Frame parent, GameObj _obj ) {
		// Invoke the constructor from the JDialog superclass:
		// Bind it to the "parent" and define it as modal.
		super( parent, true );
		
		// Copy data from gameObj:
		if ( _obj != null ) {
			obj = new GameObj( _obj.id );
			obj.x = _obj.x;
			obj.y = _obj.y;
			
			for ( int i = 0; i < _obj.attributeTable.size(); i++ ) {
				obj.attributeTable.putPair( 
					_obj.attributeTable.getKey( i ),
					_obj.attributeTable.getValue( i ) );
			}
		}
		else {
			// Create new object:
			obj = new GameObj( "" );
		}
		
		
		// Build dialog layout:
		// 
		// +====================================+
		// | Object ID: [_________________]     |
		// |                                    |
		// | Attribute table:                   |
		// | +--------------------------------+ |
		// | |                              |^| |
		// | |                              | | |
		// | |                              |v| |
		// | +--------------------------------+ |
		// |                                    |
		// |       [  OK  ]    [ Cancel ]       |
		// +------------------------------------+
		// 
		Box theBox = Box.createVerticalBox();
		theBox.setAlignmentY( 0.0f );
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
				
		// OBJECT ID:
		objIdTxt = new JTextField( obj.id );
		Box idBox = Box.createHorizontalBox();
		idBox.setAlignmentX( 0.0f );
		idBox.add( new JLabel("Object ID: ") );
		idBox.add( objIdTxt );
		
		theBox.add( idBox );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		
		// ATTRIBUTE TABLE:
		theBox.add( new JLabel("Attribute table: ") );
		
		attributeTable = new JTable( new AttributeTableModel ( obj ) );
		attributeTable.getTableHeader().setReorderingAllowed( false );
		//attributeTable.setCellSelectionEnabled( false );
		attributeTable.setRowSelectionAllowed( true );
		attributeTable.setColumnSelectionAllowed( false ); 
		
		attributeTable.setToolTipText( "Double-click to add/edit a value." );
		
		// A MouseListener will fire the EditKeyValueDialog to edit the table's
		// contents:
		attributeTable.addMouseListener( new MouseAdapter () {
			public void mouseClicked ( MouseEvent evt ) {
				// Double click on a cell?
				if ( evt.getButton() == MouseEvent.BUTTON1 && evt.getClickCount() == 2 ) {
					int row = attributeTable.rowAtPoint( evt.getPoint() );
					int col = attributeTable.columnAtPoint( evt.getPoint() );
					
					// Valid indices?
					if ( row != -1 && col != -1 ) {
						String[] newPair;
						
						// Creating a new value?
						if ( row >= obj.attributeTable.size() ) {
							newPair = EditKeyValueDialog.getKeyValuePair( EditGameObjDialog.this, "", "", true );
						}
						// Editing existing value:
						else {
							newPair = EditKeyValueDialog.getKeyValuePair(
								EditGameObjDialog.this,
								obj.attributeTable.getKey( row ),
								obj.attributeTable.getValue( row ),
								false );
						}
						
						// User confirmed?
						if ( newPair != null ) {
							// Store the new pair:
							obj.attributeTable.putPair( newPair[0], newPair[1] );
							
							attributeTable.tableChanged(
								new TableModelEvent ( attributeTable.getModel() ) );
						}
					}
				}
				// Right-click on a cell?
				else if ( evt.getButton() == MouseEvent.BUTTON3 ) {
					final Point clickPoint;
					clickPoint = evt.getPoint();
					int row = attributeTable.rowAtPoint( clickPoint );
					
					// Valid row?
					if ( row < obj.attributeTable.size() )  {
						// Highlight this row:
						attributeTable.setRowSelectionInterval( row, row );
						
						// Show a pop-up menu:
						JPopupMenu menu = new JPopupMenu();
						
						JMenuItem item = new JMenuItem( "Delete this key/value" );
						item.addActionListener( new ActionListener () {
								public void actionPerformed ( ActionEvent evt ) {
									int row = attributeTable.rowAtPoint( clickPoint );
									int col = attributeTable.columnAtPoint( clickPoint );
									
									// Valid indices?
									if ( row != -1 && col != -1 ) {
										// Get key at that row:
										String key = obj.attributeTable.getKey( row );
										
										if ( key != null ) {
											// Put null at that key. This will remove it.
											obj.attributeTable.putPair( key, null );
											
											// Refresh the JTable:
											attributeTable.tableChanged(
												new TableModelEvent ( attributeTable.getModel() ) );
										}
									}
								}
							} );
						menu.add( item );
						
						// Show the menu on the mouse's coordinates:
						menu.show( attributeTable, evt.getX(), evt.getY() );
					}
				}
			}
		} );
		
		JScrollPane attrScrollPane = new JScrollPane( attributeTable );
		attrScrollPane.setAlignmentX( 0.0f );
		attrScrollPane.setAlignmentY( 0.0f );
		theBox.add( attrScrollPane );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		
		// BUTTONS:
		// Upon being pressed, these will set the "status" field to the
		// appropriate value and close the dialog:
		okButton = new JButton( "OK" );
		okButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				// Copy the object ID:
				obj.id = objIdTxt.getText();
				
				status = STATUS_OK;
				dispose();
			} } );
		cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( new ActionListener () {
			public void actionPerformed( ActionEvent evt ) {
				status = STATUS_CANCEL;
				dispose();
			} } );
		
		theBox.add( new JSeparator() );
		theBox.add( Box.createRigidArea( new Dimension(0, 10) ) );
		
		// Add the buttons to the dialog:
		Box buttonBox = Box.createHorizontalBox();
		buttonBox.setAlignmentX( 0.0f );
		buttonBox.add( Box.createGlue() );
		buttonBox.add( okButton );
		buttonBox.add( Box.createRigidArea( new Dimension(15, 0) ) );
		buttonBox.add( cancelButton );
		buttonBox.add( Box.createGlue() );
		theBox.add( buttonBox );
		
		theBox.add( Box.createRigidArea( new Dimension(0, 5) ) );
		
		// Add fillers to the left and right of the box:
		Box filler = Box.createHorizontalBox();
		filler.setAlignmentX( 0.0f );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		filler.add( theBox );
		filler.add( Box.createRigidArea( new Dimension(5, 0) ) );
		getContentPane().add( filler );
		
		// Layout done!
		
		// Set "OK" as the default button:
		getRootPane().setDefaultButton( okButton );
		
		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
		Action escapeAction = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				cancelButton.doClick();
			} };
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", escapeAction);
	}
	
	
	
	/**
	 * Prompts the user for a new GameObj.
	 * Returns the GameObj created, or null if the user canceled.
	 */
	public static GameObj createGameObj () {
		// Pop up a window with the editor:
		EditGameObjDialog editor = new EditGameObjDialog( Main.f, null );
		editor.setTitle( "New game object" );
		editor.pack();
		editor.setLocationRelativeTo( null ); // Center on screen
		editor.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
		
		// Check status:
		// User cancelled or closed the window?
		if ( editor.status != STATUS_OK )
			return null;
		// User confirmed?
		else
			return editor.obj;
	}
	
	
	/**
	 * Prompts the user for the new GameObj's parameters.
	 * Returns a new GameObj, with its updated parameters, or null if the user
	 * canceled.
	 */
	public static GameObj editGameObj ( GameObj obj ) {
		// Pop up a window with the editor:
		EditGameObjDialog editor = new EditGameObjDialog( Main.f, obj );
		editor.setTitle( "Edit game object" );
		editor.pack();
		editor.setLocationRelativeTo( null ); // Center on screen
		editor.setVisible( true ); // Thread will block here, waiting for the JDialog to be closed
		
		// Check status:
		// User cancelled or closed the window?
		if ( editor.status != STATUS_OK )
			return null;
		// User confirmed?
		else
			return editor.obj;
	}
}


