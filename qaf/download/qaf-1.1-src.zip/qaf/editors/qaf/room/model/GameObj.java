package qaf.room.model;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Stroke;



public class GameObj {
	public static final Font   LABEL_FONT           = new Font( "Courier New", Font.PLAIN, 11 );
	public static final Color  LABEL_COLOR          = Color.WHITE;
	public static final Color  LABEL_OUTLINE_COLOR  = Color.BLACK;
	public static final int    MARKER_SIZE          = 9;
	public static final Color  MARKER_COLOR         = Color.RED;
	public static final Color  MARKER_OUTLINE_COLOR = Color.BLACK;
	public static final Stroke MARKER_STROKE        = new BasicStroke( 2.0f );
	public static final Stroke HIGHLIGHTED_STROKE   = new BasicStroke( 4.0f );
	public static final Color  HIGHLIGHTED_COLOR    = Color.ORANGE;
	
	
	
	/** Positioning of the object, in pixels, relative to the screen's top-left
	 * corner. */
	public int x, y;
	
	/** The object's attributes are stored as a list of String pairs (i.e.,
	 * arrays with two elements each), where index 0 is the "key" and index 1
	 * is the "value" -- sort of like a hashtable, but keeping them in this
	 * format here makes it easier to edit them. */
	public AttributeTable attributeTable = new AttributeTable();
	
	/** Identifies which type of object will spawn at this point. */
	public String id;
	
	/**
	 * Constructor:
	 */
	public GameObj ( String id ) {
		this.id = id;
	}
	
	
	/** Tied to the "view" package. */
	public boolean highlighted = false; 
	
	/**
	 * Tests whether the point (x, y) is contained within this object's marker.
	 */
	public boolean hasPoint ( int x, int y ) {
		return x > this.x - MARKER_SIZE/2 && x < this.x + MARKER_SIZE/2 &&
		       y > this.y - MARKER_SIZE/2 && y < this.y + MARKER_SIZE/2;
	}
	
	/**
	 * Displays this object's marker and label.
	 */
	public void draw ( Graphics2D g, int scrollX, int scrollY ) {
		// Marker:
		// First the outline...
		g.setColor( MARKER_OUTLINE_COLOR );
		g.drawRect(
			scrollX + x - MARKER_SIZE/2 - 2, scrollY + y - MARKER_SIZE/2 - 2, 
			MARKER_SIZE + 3, MARKER_SIZE + 3 );
		
		g.setColor( (highlighted ? HIGHLIGHTED_COLOR : MARKER_COLOR ) );
		// Place a dot on the object's location...
		g.drawLine( scrollX + x, scrollY + y, scrollX + x, scrollY + y );
		
		// Draw a rectangle around the object:
		Stroke previousStroke = g.getStroke();
		g.setStroke( (highlighted ? HIGHLIGHTED_STROKE : MARKER_STROKE ) );
		g.drawRect(
			scrollX + x - MARKER_SIZE/2, scrollY + y - MARKER_SIZE/2, 
			MARKER_SIZE, MARKER_SIZE );
		g.setStroke( previousStroke );
		
		// Draw label:
		g.setFont( LABEL_FONT );
		// First its outline...
		g.setColor( LABEL_OUTLINE_COLOR );
		g.drawString( id,	scrollX + x + MARKER_SIZE/2 - 1, scrollY + y - MARKER_SIZE/2     );
		g.drawString( id,	scrollX + x + MARKER_SIZE/2    , scrollY + y - MARKER_SIZE/2 - 1 );
		g.drawString( id,	scrollX + x + MARKER_SIZE/2 + 1, scrollY + y - MARKER_SIZE/2     );
		g.drawString( id,	scrollX + x + MARKER_SIZE/2    , scrollY + y - MARKER_SIZE/2 + 1 );
		
		// Then the string itself:
		g.setColor( LABEL_COLOR );
		g.drawString( id,	scrollX + x + MARKER_SIZE/2, scrollY + y - MARKER_SIZE/2 );
	}
	 
}
