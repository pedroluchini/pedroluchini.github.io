package qaf.room.model;

import java.awt.Graphics;
import java.awt.Image;

import qaf.room.control.Main;
import qaf.room.view.MainLayout;


/**
 * NOTE: Tile IDs start at 0; ID -1 is reserved for a "blank" tile.
 */
public class BGLayer {
	/** The highest possible ID a normal BGLayer can have: */
	public final static int MAX_TILE_ID = 0x3FFFFFFF;
	
	/** Masks indicating that the tile is flipped. */
	public final static int TILE_FLIPPED_X = 0x80000000,
	                        TILE_FLIPPED_Y = 0x40000000;
	
	/** The source image, where tiles are stored. This is the path RELATIVE TO
	 * THE BASE PATH. */
	public String sourceImagePath;
	
	/** The loaded image, from which tiles are drawn. */
	public Image data = null;
	
	/** Less than 1 = background; greater than 1 = foreground */
	public float parallaxFactorX, parallaxFactorY;
	
	/** Tile size; used to break up the image into tiles. */
	public int tileWidth, tileHeight;
	
	/** Used to correct the layer's positioning. The tiles will be "translated"
	 * by these values before being drawn.
	 * 
	 * Valid values are:
	 *    -tileWidth  <= translateX <= 0
	 *    -tileHeight <= translateY <= 0 */
	public int translateX, translateY;
	
	/** Tied to the view package: Indicates whether this layer should be drawn
	 * in the room. */
	public boolean isHidden = false;
	
	/**
	 * Constructor: 
	 */
	public BGLayer ( String sourceImagePath, Image data, int tileWidth, int tileHeight, float parallaxFactorX, float parallaxFactorY, int translateX, int translateY ) {
		this.sourceImagePath = sourceImagePath;
		this.data            = data;
		this.tileWidth       = tileWidth;
		this.tileHeight      = tileHeight;
		this.parallaxFactorX = parallaxFactorX;
		this.parallaxFactorY = parallaxFactorY;
		this.translateX      = translateX;
		this.translateY      = translateY;
	}
	
	
	/** 
	 * Draws a tile from this BGLayer's data at the specified coordinates.
	 * (This method does not consider scrolling or parallax, but does consider
	 * traslation.) 
	 */
	public void drawTile ( int tileID, int x, int y, Graphics g ) {
		// ID -1 is a blank tile:
		if ( tileID == -1 )
			return;
		
		// Calculate the tile's texture coordinates:
		int texX = (tileID * tileWidth) % data.getWidth(Main.f);
		int texY = tileHeight * ((tileID * tileWidth) / data.getWidth(Main.f));
		int texW = tileWidth;
		int texH = tileHeight;
		
		// Tile is flipped?
		if ( (tileID & TILE_FLIPPED_X) != 0 ) {
			texX += tileWidth;
			texW *= -1;
		}
		if ( (tileID & TILE_FLIPPED_Y) != 0 ) {
			texY += tileHeight;
			texH *= -1;
		}
		
		g.drawImage(
			data,
			x + translateX, y + translateY, x + translateX + tileWidth, y + translateY + tileHeight, // Destination coordinates
			texX,           texY,           texX + texW,                texY + texH,                 // Source coordinates
			Main.f );
	}
	
	
	/**
	 * Returns the rows in this BGLayer's source image, given its current
	 * tile height. 
	 */
	public int getRows() {
		return data.getHeight(Main.f) / tileHeight;
	}
	
	/**
	 * Returns the columns in this BGLayer's source image, given its current
	 * tile width.
	 */
	public int getCols() {
		return data.getWidth(Main.f) / tileWidth;
	}
	
	
	/**
	 * Returns the number of tiles this layer could hold, given its source
	 * image size and tile size. (This value could be larger than MAX_TILE_ID.)
	 */
	public int getNumberOfTiles () {
		return getRows() * getCols();
	}
	
	
	
	/**
	 * Creates a "fake" BGLayer, that represents the obstacle layer's data.
	 * The blockSize parameter will determine the layer's tile size.
	 */
	public static BGLayer createFakeObstacleLayer ( int blockSize ) {
		// The obstacle layer's image is a 11x4 grid. Create an "empty" image
		// where the blocks can fit:
		Image img = Main.f.createImage( blockSize * 11, blockSize * 4 );
		
		// Get the image's Graphics object so I can draw on it:
		Graphics g = img.getGraphics();
		
		// Fill the image with a gray hatched pattern:
		MainLayout.clearBGWithHatches( g, blockSize * 11, blockSize * 4 );
		
		// Draw the tiles onto the image:
		for ( int blockID = 0; blockID <= ObstacleBlockTypes.MAX_BLOCK_TYPES; blockID++ ) {
			// Row and column of this tile:
			int i = blockID / 11;
			int j = blockID % (11);
			
			// Draw the block:
			ObstacleBlockTypes.drawBlock( blockID, j * blockSize, i * blockSize, blockSize, g );
		}
		
		// Image done! Make a BGLayer out of it:
		return new BGLayer( null, img, blockSize, blockSize, 1.0f, 1.0f, 0, 0 ) {
			// Override the getNumberOfTiles method, so the BGPanel will draw a
			// smaller grid on this layer:
			public int getNumberOfTiles () {
				return ObstacleBlockTypes.MAX_BLOCK_TYPES + 1;
			}
		};
	}
	
}
