package qaf.room.control;

import java.util.Vector;

import qaf.room.view.MainLayout;

/**
 * Controls the history of Undos and Redos.
 */
public abstract class HistoryManager {
	/** Size of the history buffer. */
	public final static int HISTORY_BUFFER_SIZE = 50;
	
	private static Vector undoBuffer = new Vector();
	private static Vector redoBuffer = new Vector();
	
	private static Vector undoDescr  = new Vector();
	private static Vector redoDescr  = new Vector();
	
	
	/**
	 * Enqueues the specified operation in the buffer.
	 * This will clear the "redo" buffer.
	 */
	public static void addUndoOperation ( UndoOperation op, String description ) {
		undoBuffer.add( op );
		undoDescr.add( description );
		
		while ( undoBuffer.size() > HISTORY_BUFFER_SIZE ) {
			undoBuffer.remove( 0 );
			undoDescr.remove( 0 );
		}
		
		redoBuffer.removeAllElements();
		redoDescr.removeAllElements();
		
		MainLayout.undoMenuItem.setText( "Undo " + nextUndoDescription() );
		MainLayout.undoMenuItem.setEnabled( true );
		
		MainLayout.redoMenuItem.setText( "Redo" );
		MainLayout.redoMenuItem.setEnabled( false );
	}
	
	/**
	 * Performs the last UndoOperation in the undoBuffer, adding its inverse to
	 * the redoBuffer.
	 */
	public static void undo () {
		UndoOperation op    = (UndoOperation) undoBuffer.lastElement();
		String        descr = (String)        undoDescr.lastElement();
		
		undoBuffer.remove( undoBuffer.size() - 1 );
		undoDescr.remove( undoDescr.size() - 1 );
		
		redoBuffer.add( op.getInverse() );
		redoDescr.add( descr );
		
		op.perform();
	}
	
	/**
	 * Performs the last UndoOperation in the redoBuffer, adding its inverse to
	 * the undoBuffer.
	 */
	public static void redo () {
		UndoOperation op    = (UndoOperation) redoBuffer.lastElement();
		String        descr = (String)        redoDescr.lastElement();
		
		redoBuffer.remove( redoBuffer.size() - 1 );
		redoDescr.remove( redoDescr.size() - 1 );
		
		undoBuffer.add( op.getInverse() );
		undoDescr.add( descr );
		
		op.perform();
	}
	
	
	/**
	 * Returns the description for the next Undo available, or null if there
	 * are no more operations.
	 */
	public static String nextUndoDescription () {
		if ( undoDescr.size() > 0 )
			return (String) undoDescr.lastElement();
		else
			return null;
	}
	
	/**
	 * Returns the description for the next Redo available, or null if there
	 * are no more operations.
	 */
	public static String nextRedoDescription () {
		if ( redoDescr.size() > 0 )
			return (String) redoDescr.lastElement();
		else
			return null;
	}
	
	/**
	 * Clears both buffers (undo and redo), disabling their corresponding menu
	 * items.
	 */
	public static void clear () {
		undoBuffer.removeAllElements();
		undoDescr.removeAllElements();
		redoBuffer.removeAllElements();
		redoDescr.removeAllElements();
		
		MainLayout.undoMenuItem.setText( "Undo" );
		MainLayout.undoMenuItem.setEnabled( false );
		MainLayout.redoMenuItem.setText( "Redo" );
		MainLayout.redoMenuItem.setEnabled( false );
	}
	
}
