/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafobj/qafAnimParticleObj.h>

#include <qafEnvironment.h>

using namespace qaf;


AnimParticleObj::AnimParticleObj (	const hgeAnimation * _anim,
									float _x, float _y,
									float _angle,
									float _vx, float _vy,
									float _vr,
									float _ax, float _ay,
									float _size,
									DWORD _color,
									DWORD _blendMode )
: anim(*_anim)
{
	// Initialize parameters:
	x = _x;
	y = _y;
	angle = _angle;
	vx = _vx;
	vy = _vy;
	vr = _vr;
	ax = _ax;
	ay = _ay;
	size = _size;
	
	anim.SetColor( _color );
	anim.SetBlendMode( _blendMode );
	
	anim.Play();
}




void AnimParticleObj::update ( int objLayer, float dt ) {
	// Move:
	x += vx * dt + 0.5f * ax * dt * dt;
	y += vy * dt + 0.5f * ay * dt * dt;
	vx += ax * dt;
	vy += ay * dt;
	angle += vr * dt;
	
	// Age:
	anim.Update( dt );
	
	// Dead?
	if ( !anim.IsPlaying() )
		// Kill:
		Environment::removeGameObj( this, true, objLayer );
	
}




void AnimParticleObj::render ( int objLayer, float scrollX, float scrollY ) {
	// Render:
	anim.RenderEx( x - scrollX, y - scrollY, angle, size, size );
}
