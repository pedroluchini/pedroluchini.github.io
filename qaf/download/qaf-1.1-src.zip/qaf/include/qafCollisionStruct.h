/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_COLLISIONSTRUCT_H
#define QAF_COLLISIONSTRUCT_H	

#include <hgesprite.h>
#include "qafutil/qafContainer.h"
#include "qafutil/qafVector2D.h"


namespace qaf {
	
	/**
	 * Represents a geometric boundary for use in collision tests.
	 * 
	 * <tt>CollisionStruct</tt> is an abstract class that represents generic
	 * boundaries. In your <tt>GameObj</tt>s, you should return one of the
	 * available subclasses:
	 *  - <tt>CollisionStruct::Box</tt>
	 *  - <tt>CollisionStruct::Circle</tt>
	 *  - <tt>CollisionStruct::Polygon</tt>.
	 * 
	 * @warning
	 * Do <em>not</em> derive from this class to implement your own collision
	 * tests.
	 * 
	 * @see GameObj::getCollisionStruct()
	 */
	class CollisionStruct {
		public:
			
			/**
			 * @return true if this struct is colliding against the supplied
			 *         pointer.
			 */
			virtual bool collidesWith ( CollisionStruct * otherStruct ) = 0;
			
			/**
			 * @return true if the point lies inside the structure's
			 * boundaries.
			 */
			virtual bool hasPoint ( float x, float y ) = 0;
			
			/**
			 * For debug purposes, this will render the current collision
			 * boundaries as a set of lines.
			 */
			virtual void render ( float scrollX, float scrollY, unsigned long color ) = 0;
			
			virtual ~CollisionStruct ();
			
			class Box;
			class Circle;
			class Polygon;
		
		private:
			static bool collide_Box_Circle     ( Box    *pBox,  Circle  *pCirc );
			static bool collide_Box_Polygon    ( Box    *pBox,  Polygon *pPoly );
			static bool collide_Circle_Polygon ( Circle *pCirc, Polygon *pPoly );
			
			static bool collide_PolyPoints ( const Vector2D * points1, int nPoints1, const Vector2D * points2, int nPoints2 );
	};
	
	
	
	
	/**
	 * Represents rectangular collision boundaries.
	 */
	class CollisionStruct::Box : public CollisionStruct {
		public:
			/**
			 * Initializes the box's boundaries.
			 */
			Box ( float x, float y, float w, float h );
			
			/**
			 * Initializes the box's boundaries to (0, 0, 0, 0)
			 */
			Box ();
			
			
			inline void setX ( float _x ) {
				x = _x;
			}
			inline void setY ( float _y ) {
				y = _y;
			}
			inline void setWidth ( float _w ) {
				w = _w;
			}
			inline void setHeight ( float _h ) {
				h = _h;
			}
			
			inline float getX () {
				return x;
			}
			inline float getY () {
				return y;
			}
			inline float getWidth () {
				return w;
			}
			inline float getHeight () {
				return h;
			}
			
			void render ( float scrollX, float scrollY, unsigned long color );
			bool collidesWith ( CollisionStruct * otherStruct );
			bool hasPoint ( float x, float y );
		
		private:
			float x, y, w, h;
			
			friend CollisionStruct;
			
	};
	
	
	
	
	/**
	 * Represents circular collision boundaries.
	 */
	class CollisionStruct::Circle : public CollisionStruct {
		public:
			/**
			 * Initializes the circle's parameters.
			 */
			Circle ( float xCenter, float yCenter, float radius );
			
			/**
			 * Initializes the circle to (0, 0) and radius 0.
			 */
			Circle ();
			
			inline void setXCenter ( float x ) {
				xCenter = x;
			}
			inline void setYCenter ( float y ) {
				yCenter = y;
			}
			inline void setRadius ( float r ) {
				radius = r;
			}
			
			inline float getXCenter () {
				return xCenter;
			}
			inline float getYCenter () {
				return yCenter;
			}
			inline float getRadius () {
				return radius;
			}
			
			void render ( float scrollX, float scrollY, unsigned long color );
			bool collidesWith ( CollisionStruct * otherStruct );
			bool hasPoint ( float x, float y );
			
		private:
			float xCenter, yCenter, radius;
			
			friend CollisionStruct;
	};
	
	
	
	
	/**
	 * Represents a polygonal collision boundary.
	 * 
	 * The polygon may be concave and its edges may intersect. You could hardly
	 * ask for anything more generic than this, although it is much less
	 * efficient than other collision structures.
	 * 
	 * The polygon defined by <tt>points</tt> is assumed to be the
	 * "untranslated" version of the collision boundary. If this were an
	 * <tt>hgeSprite</tt>, think of the point (0, 0) as the polygon's hot spot.
	 * 
	 * Typically, you would specify the object's polygon points relative to its
	 * sprite's hot spot, and then update the polygon's position to the
	 * object's position once per frame.
	 */
	class CollisionStruct::Polygon : public CollisionStruct {
		public:
			/// @{
			/**
			 * The constructor receives a series of points that represent the
			 * polygon's outline. The polygon is always assumed to be closed
			 * (i.e., the last point will be "linked" with the first point).
			 */
			Polygon ( const Vector2D * points, int nPoints );
			Polygon ( const Container<Vector2D> & points );
			/// @}
			
			/**
			 * This constructor will create a polygon based on a sprite's
			 * width, height, and hotspot. You can then use it as the bounding
			 * box to represent the sprite, even when it's rotated/scaled.
			 */
			Polygon ( const hgeSprite * pSprite );
			
			/**
			 * Default constructor, that creates an "empty" polygon.
			 */
			Polygon ();
			
			
			/// @{
			/**
			 * Redefines the points that represent the polygon's outline.
			 */
			void setPoints( const Vector2D * points, int nPoints );
			
			inline void setPoints( const Container<Vector2D> & points ) {
				setPoints( points.getData(), points.getCount() );
			}
			/// @}
			
			/**
			 * Sets the object's displacement relative to (0, 0).
			 */
			void setPosition ( float x, float y );
			
			/**
			 * Gets the object displacement relative to (0, 0).
			 */
			void getPosition ( float * x, float * py );
			
			/**
			 * Sets the object's rotation around its hot spot.
			 */
			void setRotation ( float radians );
			
			/**
			 * Gets the object's rotation around its hot spot.
			 */
			float getRotation ();
			
			/**
			 * Sets the object's scale.
			 */
			void setScale ( float s );
			
			/**
			 * Gets the object's current scale.
			 */
			void getScale ();
			 
			
			
			void render ( float scrollX, float scrollY, unsigned long color );
			bool collidesWith ( CollisionStruct * otherStruct );
			bool hasPoint ( float x, float y );
			
		private:
			Container<Vector2D> userPoints, realPoints;
			Vector2D pos;
			float rotation, scale;
			
			void updateRealPoints ();
			
			friend CollisionStruct;
	};
	
	
	
}


#endif
