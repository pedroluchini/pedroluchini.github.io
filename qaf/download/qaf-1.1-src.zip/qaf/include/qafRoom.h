/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef ROOM_H
#define ROOM_H

#include "qafBGLayer.h"
#include "qafutil/qafContainer.h"
#include "qafutil/qafGeom.h"
#include "qafutil/qafMatrix.h"


namespace qaf {
	
	/**
	 * A Room's "obstacle layer" is stored as a matrix of integers, which
	 * represent the different block types that compose the room's layout.
	 */
	enum ObstacleBlock {
		/** @code
		// +-------+
		// |       |
		// |       |
		// |       |
		// +-------+
		@endcode */
		QAFBLK_EMPTY         = -1,
		
		/** @code
		// +-------+
		// |       |
		// |   .---|
		// |   |///|
		// +-------+
		@endcode */
		QAFBLK_SE_BLOCK      = 0,
		
		/** @code
		// +-------+
		// |       |
		// |-------|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_W_E_BOTTOM    = 1,
		
		/** @code
		// +-------+
		// |       |
		// |---.   |
		// |///|   |
		// +-------+
		@endcode */
		QAFBLK_SW_BLOCK      = 2,
		
		/** @code
		// +-------+
		// |   |///|
		// |---'///|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_NW_MISSING    = 3,
		
		/** @code
		// +-------+
		// |///|   |
		// |///'---|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_NE_MISSING    = 4,
		
		/** @code
		// +-------+
		// |    _-�|
		// |  _-///|
		// |_-/////|
		// +-------+
		@endcode */
		QAFBLK_SW_NE_BOTTOM  = 5,
		
		/** @code
		// +-------+
		// |�-_    |
		// |///-_  |
		// |/////-_|
		// +-------+
		@endcode */
		QAFBLK_NW_SE_BOTTOM  = 6,
		
		/** @code
		// +-------+
		// |       |
		// |   __--|
		// |_--////|
		// +-------+
		@endcode */
		QAFBLK_SW_E_BOTTOM   = 7,
		
		/** @code
		// +-------+
		// |  __--�|
		// |--/////|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_W_NE_BOTTOM   = 8,
		
		/** @code
		// +-------+
		// |�--__  |
		// |/////--|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_NW_E_BOTTOM   = 9,
		
		/** @code
		// +-------+
		// |       |
		// |--__   |
		// |////--_|
		// +-------+
		@endcode */
		QAFBLK_W_SE_BOTTOM   = 10,
		
		
		/** @code
		// +-------+
		// |   |///|
		// |   |///|
		// |   |///|
		// +-------+
		@endcode */
		QAFBLK_N_S_RIGHT     = 11,
		
		/** @code
		// +-------+
		// |///////|
		// |///////|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_FULL          = 12,
		
		/** @code
		// +-------+
		// |///|   |
		// |///|   |
		// |///|   |
		// +-------+
		@endcode */
		QAFBLK_N_S_LEFT      = 13,
		
		/** @code
		// +-------+
		// |///////|
		// |---.///|
		// |   |///|
		// +-------+
		@endcode */
		QAFBLK_SW_MISSING    = 14,
		
		/** @code
		// +-------+
		// |///////|
		// |///.---|
		// |///|   |
		// +-------+
		@endcode */
		QAFBLK_SE_MISSING    = 15,
		
		/** @code
		// +-------+
		// |�-/////|
		// |  �-///|
		// |    �-_|
		// +-------+
		@endcode */
		QAFBLK_NW_SE_TOP     = 16,
		
		/** @code
		// +-------+
		// |/////-�|
		// |///-�  |
		// |_-�    |
		// +-------+
		@endcode */
		QAFBLK_SW_NE_TOP     = 17,
		
		/** @code
		// +-------+
		// |�--////|
		// |   ��--|
		// |       |
		// +-------+
		@endcode */
		QAFBLK_NW_E_TOP      = 18,
		
		/** @code
		// +-------+
		// |///////|
		// |--/////|
		// |  ��--_|
		// +-------+
		@endcode */
		QAFBLK_W_SE_TOP      = 19,
		
		/** @code
		// +-------+
		// |///////|
		// |///__--|
		// |_--    |
		// +-------+
		@endcode */
		QAFBLK_SW_E_TOP      = 20,	
		
		/** @code
		// +-------+
		// |////--�|
		// |--��   |
		// |       |
		// +-------+
		@endcode */
		QAFBLK_W_NE_TOP      = 21,
		
		
		/** @code
		// +-------+
		// |   |///|
		// |   '---|
		// |       |
		// +-------+
		@endcode */
		QAFBLK_NE_BLOCK      = 22,
		
		/** @code
		// +-------+
		// |///////|
		// |-------|
		// |       |
		// +-------+
		@endcode */
		QAFBLK_W_E_TOP       = 23,
		
		/** @code
		// +-------+
		// |///|   |
		// |---'   |
		// |       |
		// +-------+
		@endcode */
		QAFBLK_NW_BLOCK      = 24,
		
		/** @code
		// +-------+
		// |       |
		// |     _-|
		// |   _-//|
		// +-------+
		@endcode */
		QAFBLK_S_E_BOTTOM    = 25,
		
		/** @code
		// +-------+
		// | _-�///|
		// |-//////|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_W_N_BOTTOM    = 26,
		
		/** @code
		// +-------+
		// |///�-_ |
		// |//////-|
		// |///////|
		// +-------+
		@endcode */
		QAFBLK_N_E_BOTTOM    = 27,
		
		/** @code
		// +-------+
		// |       |
		// |-_     |
		// |//-_   |
		// +-------+
		@endcode */
		QAFBLK_W_S_BOTTOM    = 28,
		
		/** @code
		// +-------+
		// |   �-//|
		// |     �-|
		// |       |
		// +-------+
		@endcode */
		QAFBLK_N_E_TOP       = 29,
		
		/** @code
		// +-------+
		// |///////|
		// |-//////|
		// | �-_///|
		// +-------+
		@endcode */
		QAFBLK_W_S_TOP       = 30,
		
		/** @code
		// +-------+
		// |///////|
		// |//////-|
		// |///_-� |
		// +-------+
		@endcode */
		QAFBLK_S_E_TOP       = 31,
		
		/** @code
		// +-------+
		// |//-�   |
		// |-�     |
		// |       |
		// +-------+
		@endcode */
		QAFBLK_W_N_TOP       = 32,
		
		/** @code
		// +-------+
		// |�������|
		// |       |
		// |       |
		// +-------+
		@endcode */
		QAFBLK_THINFLOOR_HI  = 33,
		
		/** @code
		// +-------+
		// |       |
		// |=======|
		// |       |
		// +-------+
		@endcode */
		QAFBLK_THINFLOOR_MID = 34
		
	};
	
	
	
	
	#ifndef QAF_ENVIRONMENT_H
	class Environment;
	#endif
	
	/**
	 * Represents the game's static environment -- obstacles and backgrounds.
	 * 
	 * %Room sizes are measured in "screens" (one screen corresponds to the
	 * game window's dimensions).
	 * 
	 * The best way to undertands a <tt>Room</tt>'s attributes is to use Qaf's
	 * %Room Editor.
	 * 
	 * @see Environment::loadRoom()
	 */
	class Room {
	public:
		/** This room's obstacle block size, in pixels. */
		const int blockSize;
		
		/** This room's screen size, in "blocks." */
		const int screenWidth, screenHeight;
		
		/** This room's size, in "screens." */
		const int roomWidth, roomHeight;
		
		/** The room's background layers; the frontmost layer is stored at
		* index 0. */
		Container<BGLayer *> bgLayers;
		
		/** The room's water level, measured in pixels from the room's top. A
		 * water level greater than the room's pixel height indicates no water
		 * at all; a negative water level indicates the entire room is filled
		 * with water. */
		int waterLevel;
		
		/** The default layer where objects are inserted upon creation. Index 0
		 * indicates they will be inserted in front of BG layer 0, and so on. */
		const int defaultObjLayer;
		
		/** The room's obstacle matrix. Each cell represents a "block."
		 */
		Matrix<ObstacleBlock> obstacleLayer;
		
		
		/**
		 * @return This room's width, in pixels.
		 */
		inline int getPixelWidth () {
			return obstacleLayer.columns * blockSize;
		}

		/**
		 * @return This room's height, in pixels.
		 */
		inline int getPixelHeight () {
			return obstacleLayer.rows * blockSize;
		}
		
		/**
		 * @return The width of one screen in this room, in pixels.
		 */
		inline int getScreenPixelWidth () {
			return screenWidth * blockSize;
		}
		
		/**
		 * @return The height of one screen in this room, in pixels.
		 */
		inline int getScreenPixelHeight () {
			return screenHeight * blockSize;
		}
		
		
		/**
		 * Tests the collision of a single point against the obstacle layer.
		 * 
		 * @return true if the specified point is colliding against the
		 *         obstacle layer.
		 *         The collision of a single point against "thin floors" is
		 *         undefined, and therefore is not detected by this method.
		 */
		bool pointCollision ( float x, float y );
		
		/**
		 * Tests the collision of a <em>moving</em> point against the obstacle
		 * layer. Thus, (<tt>x1</tt>, <tt>y1</tt>) is the point's previous
		 * position, and (<tt>x2</tt>, <tt>y2</tt>) is the point's current
		 * position.
		 * 
		 * If a collision is detected between point1 and point2, its parameters
		 * will be stored in the pointers <tt>contact</tt> (representing where
		 * the point touched the obstacle layer) and <tt>normal</tt> (a unit
		 * vector pointing away from the collision surface).
		 * 
		 * If <tt>touchThinFloor</tt> is false, thin floors will be ignored.
		 * 
		 * @return true if a collision occurred between point1 and point2.
		 */
		bool pointCollision ( float x1, float y1, float x2, float y2, bool touchThinFloor,
		                      Vector2D * contact, Vector2D * normal );
		
		
		/**
		 * Tests the collision of a static segment against the obstacle layer.
		 * 
		 * The <tt>touchThinFloor</tt> parameter indicates whether "thin-floor"
		 * blocks should be tested.
		 * 
		 * @return true If the segment is colliding is touching the obstacle
		 *         layer.
		 */
		bool segmentCollision ( float x1, float y1, float x2, float y2, bool touchThinFloor );
		
		/**
		 * Tests the collision of a moving segment against the obstacle layer.
		 * The segment is specified by the pair of points ((x1, y1), (x2, y2)),
		 * and is considered to have moved in the direction of the vector
		 * defined by (dx, dy).
		 * 
		 * If <tt>touchThinFloor</tt> is false, any collisions against "thin
		 * floors" will be ignored.
		 *
		 * Should a collision be detected in the movement, several parameters
		 * are "returned" in the pointers:
		 * - The contact points, which represent the points where the segment
		 *   touched the obstacle layer.
		 * - The corresponding normals, which represent the direction facing
		 *   away from the planes of contact.
		 * - The valid displacement, which indicates how much the segment can
		 *   move in the specified direction before it collides.
		 * 
		 * Any of those may be <tt>NULL</tt>, indicating there is no need to
		 * store it. (All of them will be calculated, however, as this is
		 * needed for the method's execution.)
		 *
		 * The <tt>Container</tt>s will be emptied by invoking their
		 * <tt>removeAll()</tt> method before any parameters are inserted.
		 * 
		 * @return true if a collision was detected.
		 */
		bool segmentCollision ( float x1, float y1, float x2, float y2, float dx, float dy, bool touchThinFloor,
		                        Container<Vector2D> * contacts, Container<Vector2D> * normals, Vector2D * validDisplacement );
			
		
	private:
		friend class Environment;
		
		// Constructor: Creates an empty room.
		// Water level is placed right below the room's lower border; object layer
		// position is set to 0.
		//
		Room ( int blockSize, int screenWidth, int screenHeight, int roomWidth, int roomHeight, int waterLevel, int defaultObjLayer );
		
		// Destructor: Deletes all BGLayers in this room.
		virtual ~Room ();
		
	};

}


#endif
