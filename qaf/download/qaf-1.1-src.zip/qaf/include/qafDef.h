/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <math.h>

/** @namespace qaf
 * Everything defined by the Qaf library is placed in the <tt>qaf</tt>
 * namespace.
 */

#ifndef QAF_DEF_H
#define QAF_DEF_H


/**
 * The library's version.
 */
#define QAF_VERSION 1.1f


/**
 * Source image for the water texture. The image's width and height must be
 * powers of 2.
 */
#define QAF_WATER_TEXTURE "qafWater.png"


/// @{
/**
 * Color to be applied to the water.
 */
#define QAF_WATER_COLOR_R 0
#define QAF_WATER_COLOR_G 150
#define QAF_WATER_COLOR_B 255
#define QAF_WATER_COLOR_A 30
/// @}


/// @{
/**
 * Default parameters for water level undulation and current.
 */
#define QAF_WAVE_FREQUENCY   0.6f
#define QAF_WAVE_AMPLITUDE_X 0.003f
#define QAF_WAVE_AMPLITUDE_Y 0.04f
#define QAF_WAVE_CURRENT_X   0.015f
#define QAF_WAVE_CURRENT_Y   0
/// @}


/// @{
/**
 * Distortion mesh size for the underwater refraction effect:
 */
#define QAF_REFRACTION_AMPLITUDE 1.0f
#define QAF_REFRACTION_FREQUENCY  3
#define QAF_REFRACTION_MESH_ROWS 40
#define QAF_REFRACTION_MESH_COLS 15
/// @}


/**
 * The initial <tt>BigTexture</tt> cache size.
 */
#define QAF_DEFAULT_TEX_CACHE_SIZE 7


/// @{
/**
 * Just because it's useful.
 */
template<typename T>
inline T MIN ( const T & x, const T & y ) {
	 if ( x < y )
		return x;
	else
		return y;
}

template<typename T>
inline T MAX ( const T & x, const T & y ) {
	 if ( x > y )
		return x;
	else
		return y;
}

template<typename T>
inline T ABS ( const T & x )  {
	if ( x > 0 )
		return x;
	else
		return -(x);
}

inline float round ( float x ) {
	if ( fmodf(x, 1.0f) < 0.5f )
		return floorf( x );
	else
		return ceilf( x );
}
/// @}

#endif