#include <hge.h>
#include <qafEnvironment.h>

using namespace qaf;

HGE * hge = NULL;

// The frame function:
bool frameFunction () {
	// Perform Qaf's game loop:
	Environment::update( hge->Timer_GetDelta() );
	
	if ( hge->Input_GetKeyState( HGEK_ESCAPE ) )
		return true;
	
	return false;
}



// The prologue function:
// This will be the first callback invoked after hge->Gfx_BeginScene().
void prologueFunc () {
	// Clear the screen:
	hge->Gfx_Clear( 0 );
	
	// Output text:
	Environment::cout << "Hello, world!\n";
	Environment::cout << hge->Timer_GetFPS() << " FPS\n";
}



// Application entry point:
int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ) {
	
	// Set up HGE:
	hge = hgeCreate( HGE_VERSION );
	
	hge->System_SetState( HGE_FRAMEFUNC,     frameFunction );
	hge->System_SetState( HGE_FPS,           HGEFPS_UNLIMITED );
	hge->System_SetState( HGE_SCREENWIDTH,   640 );
	hge->System_SetState( HGE_SCREENHEIGHT,  480 );
	hge->System_SetState( HGE_WINDOWED,      true );
	
	if ( !hge->System_Initiate() )
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	
	// Set up the environment:
	Environment::initialize( false, true );
	
	// Set the prologue function:
	Environment::setPrologueCallback( prologueFunc );
	
	// Start the game loop:
	if ( !hge->System_Start() ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	}
	
	// Shutdown:
	Environment::shutdown();
	hge->System_Shutdown();
	hge->Release();
	
	return 0;
}



/**
@page tutorial01 Tutorial 1 - Basic Qaf Setup

This tutorial will cover the essential setup you'll have to do every time a
Qaf project is started.

@section tut01s01 Project and Resource Files

Open Microsoft Visual Studio and choose to create an empty Win32 application
project (<i>not</i> console).

The first thing you'll need to do before setting up your project is download
the HGE library. Take some time to analyze its licensing options and then
get the binaries, arranging them in the directory structure of your
preference. This tutorial will follow the structure below:

@code
project
 +- Debug
 +- lib
     +- hge
     |   +- include
     |   +- lib
     |       +- bc
     |       +- gcc
     |       +- vc
     +- qaf
         +- include
         +- lib
             +- vc7
@endcode

You will now need to configure the project properties.

A common source of confusion and frustration comes from the misplacement of
resource files in respect to the working directory, so you might as well get
that out of the way right now. Click on <b>Debugging</b>, then change the
<b>Working Directory</b> field to <tt>\$(OutDir)</tt>. This will make MS Visual
Studio look for resource files in the same folder as the executable.

Under the
<b>C/C++</b> folder, click on <b>General</b>. Add the include paths to HGE
and Qaf in the <b>Additional Include Directories</b> field. Now click on
<b>Language</b> and change the <b>Enable Run-Time Type Info</b> field to
<tt>Yes</tt>.

Now open the <b>Linker</b> folder and click on <b>General</b>. Under
<b>Additional Library Directories</b>, add the <tt>vc</tt> directory from
HGE and the <tt>vc7</tt> directory from Qaf. Click on <b>Input</b> and in
the <b>Additional Dependencies</b> field, add the following items:
 - <tt>hge.lib</tt>
 - <tt>hgehelp.lib</tt>
 - <tt>qafd.lib</tt> for the debug version of Qaf, <tt>qaf.lib</tt> for the release version 
 - <tt>d3dx8.lib</tt>
 - <tt>dinput8.lib</tt>
 - <tt>dxguid.lib</tt>
 - <tt>dxerr8.lib</tt>

The Direct3DX library has a weird requirement: In the <b>Ignore Specific
Library</b> field, add <tt>libci.lib</tt>; if you don't do that, the program
will fail to compile.

That's all. Click OK in the project properties dialog.

You now need to copy the necessary DLLs into the game's working directory.
Look for the following files and place them inside <tt>Debug</tt>:
 - <tt>hge.dll</tt>
 - <tt>bass.dll</tt>

Finally, you need to copy a few Qaf resources into the game's working
directory. Look in the main Qaf directory for the following files:
 - <tt>qafCFont.fnt</tt>
 - <tt>qafCFont.png</tt>
 - <tt>qafWater.png</tt>

Copy all of them into the <tt>Debug</tt> directory of your project.

With the directory structure set up, it's time to write some code.

@section tut01s02 Basic Qaf Application

It is assumed that you have some experience with the HGE library, and this
tutorial will skip some of the more basic stuff.

The first thing to do is to bring the Qaf namespace into the global scope:

@code
using namespace qaf;
@endcode

In the frame function, we'll just invoke Qaf's game loop:

@code
HGE * hge = NULL;

// The frame function:
bool frameFunction () {
	// Perform Qaf's game loop:
	Environment::update( hge->Timer_GetDelta() );
	
	if ( hge->Input_GetKeyState( HGEK_ESCAPE ) )
		return true;
	
	return false;
}
@endcode

The "prologue function" is a callback used to notify your program that Qaf
is about to begin its rendering operations. Here, we're just going to clear 
the screen and print some text with the debug console:

@code
void prologueFunc () {
	// Clear the screen:
	hge->Gfx_Clear( 0 );
	
	// Output text:
	Environment::cout << "Hello, world!\n";
	Environment::cout << hge->Timer_GetFPS() << " FPS\n";
}

@endcode

In the main function, you must first set up HGE...
@code
// Application entry point:
int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ) {
	hge = hgeCreate( HGE_VERSION );
	
	hge->System_SetState( HGE_FRAMEFUNC,     frameFunction );
	hge->System_SetState( HGE_FPS,           HGEFPS_UNLIMITED );
	hge->System_SetState( HGE_SCREENWIDTH,   640 );
	hge->System_SetState( HGE_SCREENHEIGHT,  480 );
	hge->System_SetState( HGE_WINDOWED,      true );
	
	if ( !hge->System_Initiate() )
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
@endcode

...And then initialize Qaf:
@code
	Environment::initialize( false, true );
@endcode

Here, we're telling Qaf not to create a backbuffer (the first parameter) and
that we need to use the debug facilities (the second parameter). Don't worry
too much about these; they will be explained in more detail in other
tutorials.

Then we tell Qaf which function it should use as the prologue callback:
@code
	// Set the prologue function:
	Environment::setPrologueCallback( prologueFunc );
@endcode

When that's done, just start the game loop:
@code
	if ( !hge->System_Start() ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	}
@endcode

After the game loop is finished, you simply shut down Qaf and HGE:
@code
	Environment::shutdown();
	hge->System_Shutdown();
	hge->Release();
	
	return 0;
}
@endcode


See the full source code for this tutorial in the file: <b>tutorials/tutorial01.cpp</b>

*/
