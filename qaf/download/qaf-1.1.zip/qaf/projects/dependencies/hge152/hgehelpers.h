/*
** Haaf's Game Engine 1.5
** Copyright (C) 2003-2004, Relish Games
** hge.relishgames.com
**
** Common helper classes header
*/


#ifndef HGEHELPERS_H
#define HGEHELPERS_H


#include "hge.h"

extern HGE *hge;


#endif
