package qaf.room.view;

import java.awt.BasicStroke;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class StrokeTimer {
	private static Stroke[] strokes = { null, null, null, null };
	private static int currStroke = 0;
	
	public static Timer t = new Timer( 250, new ActionListener() {
		public void actionPerformed ( ActionEvent evt ) {
			currStroke++;
			if ( currStroke >= strokes.length )
				currStroke = 0;
			
			// Repaint the appropriate canvas
			BGPanel bgPanel = (BGPanel) MainLayout.bgLayers.getComponentAt( MainLayout.getWorkingLayer() + 1 ); 
			if ( bgPanel.lastSelectionOnPanel )
				bgPanel.bgPicker.repaint();
			else
				MainLayout.canvas.repaint();
		}
	} );
	
	static {
		float dash[] = {4.0f, 4.0f};
		strokes[0] = new BasicStroke( 3.0f, 0, 0, 1.0f, dash, 0.0f );
		strokes[1] = new BasicStroke( 3.0f, 0, 0, 1.0f, dash, 2.0f );
		strokes[2] = new BasicStroke( 3.0f, 0, 0, 1.0f, dash, 4.0f );
		strokes[3] = new BasicStroke( 3.0f, 0, 0, 1.0f, dash, 6.0f );
	}
	
	public static Stroke getCurrent() {
		return strokes[currStroke];
	}
	
}
