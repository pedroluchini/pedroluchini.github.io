/* 
** Qaf Framework 1.1
** April 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafobj/qafSpriteParticleObj.h>

#include <qafEnvironment.h>

using namespace qaf;


SpriteParticleObj::SpriteParticleObj (	hgeSprite * _sprite,
										float _x, float _y,
										float _angle,
										float _vx, float _vy,
										float _vr,
										float _ax, float _ay,
										float _initialSize, float _finalSize,
										DWORD _initialColor, DWORD _finalColor,
										DWORD _blendMode,
										float _lifeTime ) {
	// Initialize parameters:
	sprite = _sprite;
	x = _x;
	y = _y;
	angle = _angle;
	vx = _vx;
	vy = _vy;
	vr = _vr;
	ax = _ax;
	ay = _ay;
	initialSize = _initialSize;
	finalSize = _finalSize;
	initialR = GETR( _initialColor );
	initialG = GETG( _initialColor );
	initialB = GETB( _initialColor );
	initialA = GETA( _initialColor );
	deltaR = GETR( _finalColor ) - initialR;
	deltaG = GETG( _finalColor ) - initialG;
	deltaB = GETB( _finalColor ) - initialB;
	deltaA = GETA( _finalColor ) - initialA;
	blendMode =_blendMode;
	lifetime = _lifeTime;
	
	timer = 0;
}




void SpriteParticleObj::update ( int objLayer, float dt ) {
	// Move:
	x += vx * dt + 0.5f * ax * dt * dt;
	y += vy * dt + 0.5f * ay * dt * dt;
	vx += ax * dt;
	vy += ay * dt;
	angle += vr * dt;
	
	// Age:
	timer += dt;
	
	// Dead?
	if ( timer >= lifetime )
		// Kill:
		Environment::removeGameObj( this, true, objLayer );
	
}




void SpriteParticleObj::render ( int objLayer, float scrollX, float scrollY ) {
	// Get old sprite parameters:
	DWORD oldColor = sprite->GetColor();
	DWORD oldBlend = sprite->GetBlendMode();
	
	float timeRatio = (timer/lifetime);
	
	// Interpolate color:
	int newR = initialR + (int) (timeRatio * deltaR);
	int newG = initialG + (int) (timeRatio * deltaG);
	int newB = initialB + (int) (timeRatio * deltaB);
	int newA = initialA + (int) (timeRatio * deltaA);
	
	// Interpolate size:
	float newSize = initialSize + (int) (timeRatio * (finalSize - initialSize));
	
	// Set parameters:
	sprite->SetColor( ARGB( newA, newR, newG, newB ) );
	sprite->SetBlendMode( blendMode );
	
	// Render:
	sprite->RenderEx( x - scrollX, y - scrollY, angle, newSize, newSize );
	
	// Restore old parameters:
	sprite->SetColor( oldColor );
	sprite->SetBlendMode( oldBlend );
}
