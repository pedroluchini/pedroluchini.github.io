/**
@mainpage

<center>
  @image html qafLogo.png
</center>

Qaf is a "game logic framework" tailored for 2D side-scrollers/platformers
written in C++. It provides classes, templates, and tools designed to
organize the resources and orchestrate the behavior of such projects.

Qaf is an extension to Haaf's Game Engine (see Requirements, below).

@section Features
 - Object-oriented (OO) design: Your class hierarchy can be easily applied
   to the game logic by using template-based collision functions and
   iterators.
 - Background collision tests and helper classes provide a framework for
   side-scroller game mechanics.
 - Debug facilities: A console similar to the C++ <tt>cout</tt> can be used
   to quickly output data to the screen.
 - Rendering of arbitrary-sized textures with the <tt>BigTexture</tt> class.
 - Texture cache: <tt>BigTexture</tt>s are managed by a LRU (least recently
   used) algorithm, reducing load times when switching back-and-forth between
   game sections.
 - Extends HGE's input capabilities by adding joystick functions.

@section License
Qaf itself is free for use in any project, commercial or otherwise (a.k.a.
the Free Lunch License). The required libraries (see below), however, have
different licenses that need to be observed.

@section Download
 - <a href="http://www.arcticgeckostudios.com/pedro/qaf/download/qaf-1.21.zip">
   Full package</a>, containing source code, VS.NET and Eclipse project files,
   binaries, tutorials, and documentation.
 - <a href="http://www.arcticgeckostudios.com/pedro/qaf/download/qaf-1.21-bin.zip">
   Binaries</a>, if you just need the libraries and tutorials.
 - <a href="http://www.arcticgeckostudios.com/pedro/qaf/download/qaf-1.21-src.zip">
   Source code</a>, containing C++ and Java files. This also includes VS.NET
   and Eclipse project files you can use to rebuild the library.

See the \ref changelog if you're upgrading from a previous version.

@section devreq Requirements for Development
 - <a href="http://hge.relishgames.com">Haaf's Game Engine</a>,
   <a href="http://sourceforge.net/projects/hge">version 1.54</a> \n
   Qaf uses HGE for all its low-level resource management and event handling.
   Your application needs to be linked with the core library (<b>hge.lib</b>)
   and the helper classes (<b>hgehelp.lib</b>). Make sure <b>hge.dll</b> is
   in the same folder as your application's when it is run.

 - DirectX 8.1 SDK \n
   This should be installed along with MS Visual Studio .NET. \n
   Make sure you are also linking with <b>d3dx8.lib</b>, <b>dinput8.lib</b>,
   <b>dxguid.lib</b>, and <b>dxerr8.lib</b> (these are required for joystick
   support and image loading).

 - Run-Time Type Info \n
   You will need an RTTI-capable compiler to use Qaf. (In Visual Studio, you
   will need to activate it under Project Settings -> C/C++ -> Language.)

 - Java Runtime Environment, version 1.5 \n
   The Room Editor is a Java application, which requires the proper runtime
   environment.

@section Architecture
Qaf assumes the developers are familiar with HGE and its functions. This
framework does not "encapsulate" the engine, and you will have to use HGE
functions directly on several occasions.

The Room Editor is an external application where the level designer is able
to build and visualize the game's backgrounds. The resulting elements,
called "rooms," are stored in resource files that can be loaded with 
functions in the Qaf C++ library.

<center>
@image html architecture.png
</center>

@section Tutorials
 - \ref tutorial01 \n
   A simple program that renders the frame rate on top of a black background.

 - \ref tutorial02 \n
   Demonstrates how to load a room file created with the Room Editor.

 - \ref tutorial03 \n
   A simple spaceship and its projectiles.

 - \ref tutorial04 \n
   Space mines! They're like mines, but in space.
 
 - \ref tutorial05 \n
   Blow up mines with guided missiles.

*/


/**
@page changelog Change Log and History

@section v1_2 Version 1.2 
<b>Misc.</b>
- The Room Editor has been rewritten from scratch. It sports a more streamlined
  interface, a toolbar, and native GUI widgets.
- Added support for tinted/blended tiles. Check out the <i>Color Brush</i> and
  <i>Color Fill</i> tools in the Room Editor.
- The Room Editor launcher has been replaced with an executable file:
  <b>qaf\\editor\\RoomEditor.exe</b>
- Added a black border around the console font for improved readability; update
  <b>qafCFont.fnt</b> and <b>qafCFont.png</b> in your projects.

<b>Library</b>
- Render free-form geometry with <tt>qaf::BigTexture::renderTriple()</tt> and
  <tt>qaf::BigTexture::renderQuad()</tt>.
- New collision structure: <tt>qaf::CollisionStruct::Composite</tt>
- New method to test for moving point intersection:
  <tt>qaf::CollisionStruct::pointIntersection()</tt>.
- Separate X/Y scale factors in <tt>qaf::SpriteParticleObj</tt> and
  <tt>qaf::AnimParticleObj</tt>. The two classes also have several new methods
  to get their properties (current position, color, size, etc.).
- Improved camera tracking for <tt>qaf::PlatformerObj</tt>.
- Corrected a bug that could cause objects to "vanish" after a room was loaded.
- <tt>qaf::Environment::DebugVector</tt> has become <tt>qaf::DebugVector</tt>.
- Fixed bug in <tt>qaf::Joystick::setAxesParameters()</tt>: deadzone and
  saturation were not being configured properly.

<b>Upgrading from 1.1</b>
- <b>Warning</b>: <tt>qaf::SpriteParticleObj</tt> and
  <tt>qaf::AnimParticleObj</tt>'s constructors now have different argument
  lists. Your old code might compile without errors, but it will behave
  differently!
- <tt>qaf::PlatformerObj</tt>'s position and velocity have been made private.
  Use <tt>getPos()</tt>/<tt>setPos()</tt> and
  <tt>getVel()</tt>/<tt>setVel()</tt> to access them.
- <tt>qaf::PlatformerObj::CAMERA_ACCELERATION</tt> and
  <tt>qaf::PlatformerObj::CAMERA_INV_DRAG</tt> have been eliminated. Use
  <tt>qaf::PlatformerObj::CAMERA_STICKINESS</tt> instead.
- If you used the <tt>DebugVector</tt> class, remove <tt>Environment::</tt>
  from their names. They are now part of the main <tt>qaf</tt> namespace.

@section v1_1 Version 1.1 
<b>Room Editor</b>
- Fixed classpath issue with the Room Editor batch file.
- Select multiple tiles by Shift + clicking on the tile panel.
- Fixed bug that would let you drag objects when the obstacle layer is hidden.

<b>Library</b>
- <tt>qaf::GameObj::render(int, int, int)</tt> has been changed to
  <tt>qaf::GameObj::render(int, float, float)</tt>.
- Removed <tt>IndexOutOfBoundsExceptions</tt>. <tt>qaf::Container</tt> and
  <tt>qaf::Matrix</tt> now throw <tt>std::out_of_range</tt> instead.
- Framerate-independent movement for all objects.
- New helper class: <tt>qaf::AnimParticleObj</tt>
- New collision structure: <tt>qaf::CollisionStruct::Circle</tt>
- Added optional parameter <tt>onTop</tt> to
  <tt>qaf::Environment::addGameObj()</tt>.
- The enumeration <tt>qaf::ObstacleBlockTypes</tt> has been renamed to
  <tt>qaf::ObstacleBlock</tt>, and its members now have <tt>QAFBLK_</tt>
  prepended to their names. This is to avoid naming conflicts with other
  variables.

<b>Misc.</b>
- Separate parallax factors for X and Y.
- Tiles can be flipped horizontally and vertically.
- Three new tutorials:
  - \ref tutorial03
  - \ref tutorial04
  - \ref tutorial05

*/
