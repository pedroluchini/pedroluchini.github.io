package model.selection;

import java.awt.Rectangle;

import model.AbstractTileMatrix;
import model.GlobalEditorModel;
import model.ObstacleBlockTypes;
import model.Room;
import model.TileBrushMatrix;
import control.Main;

public class BlockSelectionSet extends TileBrushMatrix implements SelectionSet, AbstractTileMatrix {
	
	private int blockSize;
	
	
	
	
	public String toString () {
		return "[BlockSelectionSet: orig=(" + getOrigRow() + ", " + getOrigCol() + "); size=(" + getNumOfRows() + ", " + getNumOfCols() + ")]";
	}
	
	
	
	
	public BlockSelectionSet ( int blockSize ) {
		super( null, 0, 0 );
		this.blockSize = blockSize;
	}
	
	
	
	
	public int getBlockSize () {
		return blockSize;
	}
	
	
	
	
	public void flip(boolean horizontally, boolean vertically) {
		// Flip the brush...
		super.flip(horizontally, vertically);
		
		// Now, replace tiles with their mirrored equivalents:
		for ( int i = 0; i < getNumOfRows(); i++ ) {
			for ( int j = 0; j < getNumOfCols(); j++ ) {
				int tileID = getTileAtBrushCoords(i, j);
				
				if ( tileID != TileBrushMatrix.FREE_CELL ) {
					// Clear flip flags:
					if ( tileID != -1 ) {
						tileID &= ~Room.FLIPPED_TILE_X_MASK;
						tileID &= ~Room.FLIPPED_TILE_Y_MASK;
					}
					
					if ( horizontally )
						tileID = ObstacleBlockTypes.flipHorizontally( tileID );
					if ( vertically )
						tileID = ObstacleBlockTypes.flipVertically( tileID );
				}
				
				setTileAtBrushCoords(i, j, tileID);
			}
		}
	}
	
	
	
	
	public boolean canPaste ( GlobalEditorModel gem ) {
		return (gem.getWorkingLayer() == -1 && gem.getLoadedRoom().getBlockSize() == blockSize);
	}




	public void move ( int horiz, int vert ) {
		int origCol = getOrigCol();
		int origRow = getOrigRow();
		
		origCol += horiz;
		origRow += vert;
		
		setOrigin( origRow, origCol );
	}
	
	
	
	
	public SelectionSet clone () {
		BlockSelectionSet that = new BlockSelectionSet(this.blockSize);
		for ( int i = this.getOrigRow(); i <= this.getOrigRow() + this.getNumOfRows(); i++ )
			for ( int j = this.getOrigCol(); j <= this.getOrigCol() + this.getNumOfCols(); j++ )
				that.setTileAtGlobalCoords( i, j, this.getTileAtGlobalCoords(i, j) );
		return that;
	}
	
	
	
	
	public Object makeBackUpOfState ( GlobalEditorModel globalEditorModel, int layerInx ) {
		Room room = globalEditorModel.getLoadedRoom();
		int[][] backUp = Main.getLayerTileMatrix( room, -1 );
		return backUp;
	}




	public void restoreState(GlobalEditorModel globalEditorModel, int layerInx, Object _backUp) {
		Room room = globalEditorModel.getLoadedRoom();
		int[][] backUp = (int[][]) _backUp;
		
		for ( int i = 0; i < room.getBlockMatrixRows(); i++ )
			for ( int j = 0; j < room.getBlockMatrixCols(); j++ )
				room.setBlock( i, j, backUp[i][j] );
	}
	
	
	
	
	public void centerOnScreen ( GlobalEditorModel globalEditorModel, int layerInx ) {
		// Get the viewport's center:
		Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
		int centerPanelX = viewRect.x + viewRect.width/2;
		int centerPanelY = viewRect.y + viewRect.height/2;
		
		// Get the row/column of the screen's center:
		int centerRow = globalEditorModel.tileRowFromPanelY( centerPanelY, -1 );
		int centerCol = globalEditorModel.tileColFromPanelX( centerPanelX, -1 );
		
		// Calculate how much the selection needs to be displaced so it will
		// be centered on that row/col:
		int newOrigRow = centerRow - getNumOfRows() + getNumOfRows()/2;
		int newOrigCol = centerCol - getNumOfCols() + getNumOfCols()/2;
		
		// Center it:
		setOrigin( newOrigRow, newOrigCol );
	}
	
	
	
	
	public boolean isFloatable () {
		return true;
	}
	
	
	
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof BlockSelectionSet ) {
			BlockSelectionSet that = (BlockSelectionSet) obj;
			
			if ( this.blockSize           != that.blockSize           ||
			     this.getOrigCol()        != that.getOrigCol()        ||
			     this.getOrigRow()        != that.getOrigRow()        ||
			     this.getNumOfCols() != that.getNumOfCols() ||
			     this.getNumOfRows() != that.getNumOfRows() )
				return false;
			
			for ( int i = 0; i < getNumOfRows(); i++ )
				for ( int j = 0; j < getNumOfCols(); j++ )
					if ( this.getTileAtBrushCoords(i, j) != that.getTileAtBrushCoords(i, j) )
						return false;
			
			return true;
		}
		else
			return false;
	}
	
	public boolean equals ( SelectionSet that ) {
		return equals( (Object) that );
	}
	
	
	
	
	public boolean survivesLayerChange ( GlobalEditorModel globalEditorModel, int fromLayerInx, int toLayerInx ) {
		if ( toLayerInx != -1 )
			return false;
		else
			return true;
	}
	
	
	
	
	public SelectionSet getPasteableClone () {
		return this.clone();
	}
	
}
