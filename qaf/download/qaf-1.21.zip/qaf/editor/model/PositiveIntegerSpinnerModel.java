package model;

import java.util.Vector;

import javax.swing.SpinnerModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class PositiveIntegerSpinnerModel implements SpinnerModel {
	Vector<ChangeListener> changeListeners = new Vector<ChangeListener>();
	private int value;

	public PositiveIntegerSpinnerModel ( int initialValue ) {
		value = initialValue;
	}

	public void addChangeListener(ChangeListener c) {
		changeListeners.add( c );
	}
	public void removeChangeListener(ChangeListener c) {
		changeListeners.remove( c );
	}

	public Object getNextValue() {
		return new Integer(value + 1);
	}
	public Object getPreviousValue() {
		if ( value > 1 )
			return new Integer( value - 1 );
		else
			return null;
	}

	public Object getValue() {
		return new Integer( value );
	}
	public void setValue(Object obj) {
		try {
			int newValue = Integer.parseInt( obj.toString() );
		
			if ( newValue >= 1 ) {
				value = newValue;
			
				ChangeEvent evt = new ChangeEvent( this );
				for ( int i = 0; i < changeListeners.size(); i++ )
					changeListeners.get( i ).stateChanged( evt );
			}
			else
				throw new IllegalArgumentException();
		}
		catch ( NumberFormatException exc ) {
			throw new IllegalArgumentException();
		}
	}
	
	public int getIntValue() {
		return value;
	}
}
