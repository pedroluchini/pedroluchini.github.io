package control.tool;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.ColorTile;
import model.GlobalEditorModel;
import model.Room;
import model.selection.BGTileColorSelectionSet;
import control.HistoryManager;
import control.Main;
import control.UndoImpl;

public class ColorFillTool extends ColorBrushTool {
	
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	
	
	
	
	public ColorFillTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super( globalEditorModel, toolBar );
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
	}
	
	

	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getCursor();
		else
		if ( globalEditorModel.getWorkingLayer() == -1 )
			return Cursor.getDefaultCursor();
		else
			return Main.fillCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBar.getColorToolBox();
	}
	
	
	
	
	public String getToolDescription() {
		return "Apply color/blending effects to large areas.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/colorFill.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Color fill";
	}
	
	
	
	
	public void paintOverlay(Graphics g) {
		super.paintOverlay( g );
	}
	
	
	
	
	public void safeMouseEntered(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseExited(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseExited( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			super.safeMouseMoved( evt );
		}
	}
	
	
	
	
	public void safeMousePressed ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMousePressed( evt );
			fireCursorChangedEvent();
		}
		else
		if ( globalEditorModel.getWorkingLayer() == -1 ) {}
		else
		if ( getCurrMouseButton() == MouseEvent.BUTTON1 ) {
			final Point currRowAndCol = new Point();
			int layerInx = globalEditorModel.getWorkingLayer();
			Room room = globalEditorModel.getLoadedRoom();
			
			// Back up layer state:
			ColorTile[][] oldTileColorMatrix = Main.getLayerTileColorMatrix( room, layerInx );
			
			// Calculate current row and column:
			currRowAndCol.x = globalEditorModel.tileColFromPanelX( evt.getX(), globalEditorModel.getWorkingLayer() );
			currRowAndCol.y = globalEditorModel.tileRowFromPanelY( evt.getY(), globalEditorModel.getWorkingLayer() );
			
			ColorTile colorTile = toolBar.getColorToolBox().getSelectedTileColor();
			
			// Fill whole matrix:
			int lastRow, lastCol;
			lastRow = room.getBGTileMatrixRows( layerInx ) - 1;
			lastCol = room.getBGTileMatrixCols( layerInx ) - 1;
			
			for ( int roomRow = 0; roomRow <= lastRow; roomRow++ ) {
				for ( int roomCol = 0; roomCol <= lastCol; roomCol++ ) {
					ColorTile tmpColorTile = colorTile;
					// If there's a color selection...
					if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet ) {
						BGTileColorSelectionSet selectionSet = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
						
						// Restrict drawn tiles to the selected tiles.
						if ( selectionSet.getTileAtGlobalCoords(roomRow, roomCol) == null )
							continue;
						
						// Stretch fill gradient?
						if ( toolBar.getColorToolBox().isStretchFillChecked() )
							tmpColorTile = selectionSet.interpolateAtGlobalCoords( roomRow, roomCol, colorTile );
					}
					
					// Set it:
					room.setBGTileColor( layerInx, roomRow, roomCol, tmpColorTile );
				}
			}
			
			// Commit undo operation:
			ColorTile[][] newTileColorMatrix = Main.getLayerTileColorMatrix( room, layerInx );
			HistoryManager.addUndoOperation(
				new UndoImpl.TileColorDrawing(
					globalEditorModel,
					room,
					layerInx,
					oldTileColorMatrix,
					newTileColorMatrix ),
				"color fill" );
			
			globalEditorModel.setUnsavedChanges( true );
		}
	}
	
	
	
	
	public void safeMouseReleased ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseReleased( evt );
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMouseDragged ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseDragged( evt );
		}
		else {
			safeMouseMoved( evt );
		}
	}
	
	
	
	
	public boolean safeDispatchKeyEvent ( KeyEvent evt ) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else {
			fireCursorChangedEvent();
			fireRepaintEvent();
		}
		
		return false;
	}
	
}
