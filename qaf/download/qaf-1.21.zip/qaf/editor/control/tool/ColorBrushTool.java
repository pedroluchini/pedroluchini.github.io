package control.tool;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.BGLayer;
import model.ColorTile;
import model.GlobalEditorModel;
import model.Room;
import model.selection.BGTileColorSelectionSet;
import model.selection.SelectionSet;
import control.HistoryManager;
import control.Main;
import control.UndoImpl;

public class ColorBrushTool extends ScrollTool {
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {

		public void basePathChanged(GlobalEditorModel src) {}
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
		public void gridVisibilityChanged(GlobalEditorModel src) {}
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {}
		public void scrollChanged(GlobalEditorModel src) {}
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		public void zoomChanged(GlobalEditorModel src) {}
		
		public void workingLayerChanged(GlobalEditorModel src) {
			fireCursorChangedEvent();
			
			if ( src.getWorkingLayer() == -1 )
				toolBar.getColorToolBox().setEnabled( false );
			else
				toolBar.getColorToolBox().setEnabled( true );
		}
		
	}
	
	
	
	
	private Point lastRowAndCol = null;
	private ColorTile[][] oldTileMatrix = null;
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	private GlobalEditorModelListener globalEditorModelListener = new GlobalEditorModelListener();
	
	
	
	
	public ColorBrushTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super( globalEditorModel, toolBar );
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
		
		globalEditorModel.addListener( globalEditorModelListener );
		globalEditorModelListener.workingLayerChanged( globalEditorModel );
	}
	
	
	
	
	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getCursor();
		else
		if ( globalEditorModel.getWorkingLayer() != -1 ) {
			if ( getKeyState( KeyEvent.VK_CONTROL ) )
				return Main.eyedropCursor;
			else
			if ( getCurrMouseButton() == MouseEvent.BUTTON3 )
				return Main.eraserCursor;
			else
				return Main.brushCursor;
		}
		else
			return Cursor.getDefaultCursor();
	}
	
	
	
	
	public String getStatusBarText() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getStatusBarText();
		else
			return Main.makeStatusBarText( globalEditorModel, getCurrMousePoint(), true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBar.getColorToolBox();
	}
	
	
	
	
	public String getToolDescription() {
		return "Apply color/blending effects to tiles in the current layer.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/colorBrush.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Color brush";
	}
	
	
	
	
	public void paintOverlay(Graphics g) {
		Point mousePos = getCurrMousePoint();
		if ( mousePos == null )
			return;
		
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.paintOverlay( g );
		else
		if ( globalEditorModel.getWorkingLayer() != -1 ) {
			// Render single tile overlay:
			int layerInx = globalEditorModel.getWorkingLayer();
			
			int tileWidth, tileHeight;
			Room room = globalEditorModel.getLoadedRoom();
			if ( layerInx == -1 ) {
				tileWidth = tileHeight = room.getBlockSize();
			}
			else {
				BGLayer bgLayer = room.getBGLayer( layerInx );
				tileWidth = bgLayer.getTileWidth();
				tileHeight = bgLayer.getTileHeight();
			}
			tileWidth *= globalEditorModel.getZoom();
			tileHeight *= globalEditorModel.getZoom();
			
			// Calculate top-left:
			int x = globalEditorModel.panelXFromTileCol(
				globalEditorModel.tileColFromPanelX(
					mousePos.x,
					layerInx),
				layerInx );
			int y = globalEditorModel.panelYFromTileRow(
				globalEditorModel.tileRowFromPanelY(
					mousePos.y,
					layerInx),
				layerInx );
			
			g.setColor( TileBrushTool.BRUSH_FILL_OVERLAY_COLOR );
			g.fillRect( x, y, tileWidth, tileHeight );
		}
	}
	
	
	
	
	public boolean safeDispatchKeyEvent(KeyEvent evt) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeDispatchKeyEvent( evt );
		
		fireRepaintEvent();
		fireCursorChangedEvent();
		fireStatusBarChangedEvent();
		
		return false;
	}
	
	
	
	
	public void safeMouseDragged(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeMouseDragged( evt );
		else
		if ( globalEditorModel.getWorkingLayer() != -1 ) {
			if ( (getCurrMouseButton() == MouseEvent.BUTTON1 || getCurrMouseButton() == MouseEvent.BUTTON3) ) {
				final Point currRowAndCol = new Point();
				int layerInx = globalEditorModel.getWorkingLayer();
				Room room = globalEditorModel.getLoadedRoom();
				
				// Calculate current row and column:
				currRowAndCol.x = globalEditorModel.tileColFromPanelX( evt.getX(), globalEditorModel.getWorkingLayer() );
				currRowAndCol.y = globalEditorModel.tileRowFromPanelY( evt.getY(), globalEditorModel.getWorkingLayer() );
				
				// Left click:
				if ( getCurrMouseButton() == MouseEvent.BUTTON1 ) {
					// Ctrl?
					if ( getKeyState( KeyEvent.VK_CONTROL ) ) {
						// Pick tile:
						try {
							ColorTile tileColor = room.getBGTileColor( layerInx, currRowAndCol.y, currRowAndCol.x );
							if ( tileColor == null )
								tileColor = ColorTile.DEFAULT;
							
							toolBar.getColorToolBox().setSelectedTileColor( tileColor );
						}
						catch ( ArrayIndexOutOfBoundsException exc ) {}
					}
					// No modifiers:
					else {
						ColorTile colorTile = toolBar.getColorToolBox().getSelectedTileColor();
						
						// Interpolate:
						Point[] interpolation = Main.createInterpolationSequence( lastRowAndCol, currRowAndCol );
						
						// For each point in the sequence...
						for ( int iPoint = 0; iPoint < interpolation.length; iPoint++ ) {
							ColorTile tmpColorTile = colorTile;
							int i = interpolation[iPoint].y;
							int j = interpolation[iPoint].x;
							
							// If there's a color selection...
							if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet ) {
								BGTileColorSelectionSet selectionSet = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
								
								// Restrict drawn tiles to the selected tiles.
								if ( selectionSet.getTileAtGlobalCoords(i, j) == null )
									continue;
								
								// Stretch fill gradient?
								if ( toolBar.getColorToolBox().isStretchFillChecked() )
									tmpColorTile = selectionSet.interpolateAtGlobalCoords( i, j, colorTile );
							}
							
							try {
								room.setBGTileColor( layerInx, i, j, tmpColorTile );
							}
							catch ( ArrayIndexOutOfBoundsException exc ) {}
						}
					}
				}
				else
				// Right click:
				if ( getCurrMouseButton() == MouseEvent.BUTTON3 ) {
					// No modifiers?
					if ( !getKeyState( KeyEvent.VK_CONTROL ) ) {
						// Interpolate:
						Point[] interpolation = Main.createInterpolationSequence( lastRowAndCol, currRowAndCol );
						
						// For each point in the sequence...
						for ( int iPoint = 0; iPoint < interpolation.length; iPoint++ ) {
							int i = interpolation[iPoint].y;
							int j = interpolation[iPoint].x;
							
							// If there's a tile selection, restrict drawn
							// tiles to the selected tiles.
							if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet ) {
								BGTileColorSelectionSet selectionSet = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
								if ( selectionSet.getTileAtGlobalCoords(i, j) == null )
									continue;
							}
							
							try {
								room.setBGTileColor( layerInx, i, j, null );
							}
							catch ( ArrayIndexOutOfBoundsException exc ) {}
						}
					}
				}
			}
			
			// Update lastRowAndCol and repaint if necessary.
			safeMouseMoved(evt);
		}
		
		fireStatusBarChangedEvent();
	}
	
	
	
	
	public void safeMouseEntered(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeMouseEntered( evt );
		else
			safeMouseMoved( evt );
	}
	
	
	
	
	public void safeMouseExited(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeMouseExited( evt );
		else
			safeMouseMoved( evt );
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeMouseMoved( evt );
		else
		if ( globalEditorModel.getWorkingLayer() != -1 ) {
			// Calculate cursor's row and column:
			Point currRowAndCol = getCurrMousePoint();
			if ( currRowAndCol != null ) {
				currRowAndCol.x = globalEditorModel.tileColFromPanelX( currRowAndCol.x, globalEditorModel.getWorkingLayer() );
				currRowAndCol.y = globalEditorModel.tileRowFromPanelY( currRowAndCol.y, globalEditorModel.getWorkingLayer() );
			}
			
			// Repaint if the row or column changed since the last movement:
			if ( lastRowAndCol == null && currRowAndCol != null ) {
				fireRepaintEvent();
			}
			else
			if ( lastRowAndCol != null && currRowAndCol == null ) {
				fireRepaintEvent();
			}
			else
			if ( !lastRowAndCol.equals( currRowAndCol ) ) {
				fireRepaintEvent();
			}
			
			lastRowAndCol = currRowAndCol;
		}
		
		fireStatusBarChangedEvent();
	}
	
	
	
	
	public void safeMousePressed(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeMousePressed( evt );
		else
		if ( globalEditorModel.getWorkingLayer() != -1 ) {
			if ( getCurrMouseButton() == MouseEvent.BUTTON1 || getCurrMouseButton() == MouseEvent.BUTTON3 ) {
				int layerInx = globalEditorModel.getWorkingLayer();
				Room room = globalEditorModel.getLoadedRoom();
				
				// Store old tile matrix:
				oldTileMatrix = Main.getLayerTileColorMatrix( room, layerInx );
				
				// Let mousedragged handle this:
				safeMouseDragged( evt );
			}
		}
		
		fireCursorChangedEvent();
	}
	
	
	
	
	public void safeMouseReleased(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			super.safeMouseReleased( evt );
		else
		if ( globalEditorModel.getWorkingLayer() != -1 ) {
			if ( getKeyState( KeyEvent.VK_CONTROL ) ) {
/*
				final Point currRowAndCol = new Point();
				int layerInx = globalEditorModel.getWorkingLayer();
				Room room = globalEditorModel.getLoadedRoom();
				
				// Calculate current row and column:
				currRowAndCol.x = globalEditorModel.tileColFromPanelX( evt.getX(), globalEditorModel.getWorkingLayer() );
				currRowAndCol.y = globalEditorModel.tileRowFromPanelY( evt.getY(), globalEditorModel.getWorkingLayer() );
				
				// "Picked" a blank tile?
				try {
					ColorTile tileColor = room.getBGTileColor( layerInx, currRowAndCol.y, currRowAndCol.x );
					
					if ( tileColor == null || tileColor.equals(ColorTile.DEFAULT) ) {
						// Switch to eraser tool:
						toolBar.setCurrentTool( ToolBar.COLORERASER_TOOL_INX );
					}
				}
				catch ( ArrayIndexOutOfBoundsException exc ) {}
*/
			}
			else
			if ( (evt.getButton() == MouseEvent.BUTTON1 || evt.getButton() == MouseEvent.BUTTON3) ) {
				int layerInx = globalEditorModel.getWorkingLayer();
				Room room = globalEditorModel.getLoadedRoom();
				ColorTile[][] newTileMatrix = Main.getLayerTileColorMatrix( room, layerInx );
				
				// Commit undo operation:
				HistoryManager.addUndoOperation(
					new UndoImpl.TileColorDrawing(
						globalEditorModel,
						room,
						layerInx,
						oldTileMatrix,
						newTileMatrix ),
					"color brush" );
				
				globalEditorModel.setUnsavedChanges( true );
			}
			
			// Restore cursor:
			fireCursorChangedEvent();
		}
	}
	
}
