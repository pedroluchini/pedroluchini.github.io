/*
 * Created on Jun 14, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package control.tool;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import model.AttributeTable;
import model.GameObj;
import model.GlobalEditorModel;
import model.Room;
import model.selection.GameObjSelectionSet;
import model.selection.SelectionSet;
import control.HistoryManager;
import control.Main;
import control.UndoImpl;
import control.dlg.EditGameObjDialog;

class KeyValuePair {
	public String key, value;
	
	public KeyValuePair ( String key, String value ) {
		this.key = key;
		this.value = value;
	}
}

class _TreeModel implements TreeModel, GlobalEditorModel.Listener, GameObj.Listener {
	
	private Vector<TreeModelListener> listeners = new Vector<TreeModelListener>();
	private GlobalEditorModel globalEditorModel;
	private JTree tree;
	
	public _TreeModel ( GlobalEditorModel globalEditorModel, JTree tree ) {
		this.globalEditorModel = globalEditorModel;
		this.tree = tree;
		
		globalEditorModel.addListener( this );
	}
	
	public void setTree ( JTree tree ) {
		this.tree = tree;
	}
	
	public void addTreeModelListener(TreeModelListener l) {
		listeners.add( l );
	}
	
	public Object getChild(Object parent, int index) {
		if ( parent instanceof GameObjSelectionSet )
			return ((GameObjSelectionSet) parent).getObj(index);
		else
		if ( parent instanceof GameObj )
			return new KeyValuePair(
				((GameObj) parent).getAttributeKey( index ),
				((GameObj) parent).getAttributeValue( index ) );
		else
			return null;
	}
	
	public int getChildCount(Object parent) {
		if ( parent instanceof GameObjSelectionSet )
			return ((GameObjSelectionSet) parent).getNumOfObjs();
		else
		if ( parent instanceof GameObj )
			return ((GameObj) parent).getNumOfAttributes();
		else
			return 0;
	}
	
	public int getIndexOfChild(Object parent, Object child) {
		if ( parent instanceof GameObjSelectionSet )
			return ((GameObjSelectionSet) parent).indexOfObj( (GameObj) child );
		else
		if ( parent instanceof GameObj )
			return ((GameObj) parent).indexOfAttrKey( ((KeyValuePair) child).key );
		else
			return -1;
	}
	
	public Object getRoot() {
		if ( globalEditorModel.getSelectionSet() instanceof GameObjSelectionSet )
			return globalEditorModel.getSelectionSet();
		else
			return new GameObjSelectionSet();
	}
	
	public boolean isLeaf(Object node) {
		return (node instanceof KeyValuePair);
	}
	
	public void removeTreeModelListener(TreeModelListener l) {
		listeners.remove( l );
	}
	
	public void attributeChanged(GameObj src, String attrKey) {
		fireTreeStructureChanged();
	}
	
	public void idChanged(GameObj src) {
		fireTreeStructureChanged();
	}
	
	public void positionChanged(GameObj src) {
		fireTreeStructureChanged();
	}
	
	public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {
		if ( oldSelection instanceof GameObjSelectionSet ) {
			GameObjSelectionSet objSelectionSet = (GameObjSelectionSet) oldSelection;
			for ( int i = 0; i < objSelectionSet.getNumOfObjs(); i++ )
				objSelectionSet.getObj(i).removeListener( this );
		}
		
		if ( src.getSelectionSet() instanceof GameObjSelectionSet ) {
			GameObjSelectionSet objSelectionSet = (GameObjSelectionSet) src.getSelectionSet();
			for ( int i = 0; i < objSelectionSet.getNumOfObjs(); i++ )
				objSelectionSet.getObj(i).addListener( this );
		}
		
		fireTreeStructureChanged();
	}
	
	private void fireTreeStructureChanged () {
		Object[] rootPath = { globalEditorModel.getSelectionSet() };
		
		if ( !(rootPath[0] instanceof GameObjSelectionSet) )
			rootPath[0] = new GameObjSelectionSet();
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get(i).treeStructureChanged(
				new TreeModelEvent(
					this,
					rootPath ) );
		
		// Expand all nodes:
		if ( globalEditorModel.getSelectionSet() instanceof GameObjSelectionSet ) {
			GameObjSelectionSet objSelectionSet = (GameObjSelectionSet) globalEditorModel.getSelectionSet();
			Object[] expPath = { objSelectionSet, null };
			for ( int i = 0; i < objSelectionSet.getNumOfObjs(); i++ ) {
				expPath[1] = objSelectionSet.getObj(i);
				tree.expandPath( new TreePath(expPath) );
			}
		}
	}
	
	public void valueForPathChanged(TreePath path, Object newValue) {}
	public void basePathChanged(GlobalEditorModel src) {}
	public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
	public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
	public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
	public void gridVisibilityChanged(GlobalEditorModel src) {}
	public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {}
	public void scrollChanged(GlobalEditorModel src) {}
	public void unsavedChangesChanged(GlobalEditorModel src) {}
	public void workingLayerChanged(GlobalEditorModel src) {}
	public void zoomChanged(GlobalEditorModel src) {}
}




class _TreeCellRenderer implements TreeCellRenderer {
	
	private static final ImageIcon selectionIcon = new ImageIcon(Main.qafPath + "img/treeSelIcon.png"); 
	private static final ImageIcon gameObjIcon   = new ImageIcon(Main.qafPath + "img/treeObjIcon.png"); 
	private static final ImageIcon keyIcon       = new ImageIcon(Main.qafPath + "img/treeKeyIcon.png"); 
	
	public Component getTreeCellRendererComponent(JTree tree, Object node, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
		if ( node instanceof GameObj ) {
			GameObj obj = (GameObj) node;
			return new JLabel(
				obj.getID() + " @ (" + obj.getX() + " px, " + obj.getY() + " px)",
				gameObjIcon,
				SwingConstants.LEFT );
		}
		else
		if ( node instanceof KeyValuePair ) {
			String key = ((KeyValuePair) node).key;
			String value = ((KeyValuePair) node).value;
			
			if ( value.length() > 30 )
				value = value.substring(0, 27) + "...";
			
			return new JLabel(
				key + " = " + value,
				keyIcon,
				SwingConstants.LEFT );
		}
		else {
			return new JLabel(
				"Selection",
				selectionIcon,
				SwingConstants.LEFT );
		}
	}
}




public class GameObjSelectionToolBox extends Box {
	
	final static long serialVersionUID = 0;
	
	private class GlobalEditorModelListener implements GlobalEditorModel.Listener {

		public void basePathChanged(GlobalEditorModel src) {}
		public void bgLayerVisibilityChanged(GlobalEditorModel src, int layerInx) {}
		public void blockLayerVisibilityChanged(GlobalEditorModel src) {}
		public void clipboardChanged(GlobalEditorModel src, SelectionSet oldClipboard) {}
		public void gridVisibilityChanged(GlobalEditorModel src) {}
		public void loadedRoomChanged(GlobalEditorModel src, Room oldRoom, String oldRoomFileName) {}
		public void scrollChanged(GlobalEditorModel src) {}
		public void unsavedChangesChanged(GlobalEditorModel src) {}
		public void workingLayerChanged(GlobalEditorModel src) {}
		public void zoomChanged(GlobalEditorModel src) {}
		
		public void selectionChanged(GlobalEditorModel src, SelectionSet oldSelection) {
			if ( src.getSelectionSet() instanceof GameObjSelectionSet )
				editButton.setEnabled( true );
			else
				editButton.setEnabled( false );
		}
		
	}
	
	private GlobalEditorModel globalEditorModel;
	private JCheckBox snapToGridCheckBox = new JCheckBox( "Snap to grid", false );
	private JButton editButton = new JButton( "Edit selected objects" );
	
	
	
	
	public GameObjSelectionToolBox ( GlobalEditorModel _globalEditorModel ) {
		super( BoxLayout.Y_AXIS );
		setAlignmentX( 0 );
		setAlignmentY( 0 );
		
		this.globalEditorModel = _globalEditorModel;
		
		globalEditorModel.addListener( new GlobalEditorModelListener() );
		
		// +-----------------------------------------+
		// | +-------------------------------------+ |
		// | |+ (1) ObjID                          | |
		// | || + Attr1                            | |
		// | |+ (2) ObjID                          | |
		// | |  + Attr1                            | |
		// | |  + Attr2                            | |
		// | |                                     | |
		// | +-------------------------------------+ |
		// | [ ] Snap to grid      [ Edit selected ] |
		// +-----------------------------------------+
		
		JTree selectionTree = new JTree( new _TreeModel( globalEditorModel, null ) );
		((_TreeModel) selectionTree.getModel()).setTree( selectionTree );
		selectionTree.setAlignmentX( 0 );
		selectionTree.setAlignmentY( 0 );
		selectionTree.setCellEditor( null );
		selectionTree.setCellRenderer( new _TreeCellRenderer() );
		selectionTree.setEditable( false );
		selectionTree.setRootVisible( true );
		selectionTree.setScrollsOnExpand( true );
		selectionTree.setSelectionModel( null );
		selectionTree.setShowsRootHandles( true );
		
		JScrollPane scrollPane = new JScrollPane( selectionTree );
		scrollPane.setAlignmentX( 0 );
		scrollPane.setAlignmentY( 0 );
		add( scrollPane );
		
		add( Box.createVerticalStrut( 5 ) );
		
		Box hBox = Box.createHorizontalBox();
		hBox.setAlignmentX( 0 );
		hBox.setAlignmentY( 0 );
		{
			hBox.add( Box.createHorizontalStrut( 5 ) );
			
			snapToGridCheckBox.setAlignmentX( 0 );
			snapToGridCheckBox.setAlignmentY( 0 );
			hBox.add( snapToGridCheckBox );
			
			hBox.add( Box.createHorizontalGlue() );
			
			editButton.setAlignmentX( 0 );
			editButton.setAlignmentY( 0 );
			hBox.add( editButton );
			editButton.setEnabled( false );
			editButton.addActionListener(
				new ActionListener() {
					public void actionPerformed ( ActionEvent evt ) {
						// Get the first game object in the selection, and
						// store its values.
						GameObjSelectionSet selectionSet = (GameObjSelectionSet) globalEditorModel.getSelectionSet();
						GameObj modelObj = selectionSet.getObj(0);
						String oldModelObjID = modelObj.getID();
						Point oldModelObjPos = new Point( modelObj.getX(), modelObj.getY() );
						AttributeTable oldModelObjAttr = modelObj.getAttributeTable();
						
						// Warn user:
						if ( selectionSet.getNumOfObjs() > 1 ) {
							JOptionPane.showMessageDialog(
								Main.f,
								new String[] {
									"You are about to edit " + selectionSet.getNumOfObjs() + " objects.",
									"All objects in the selection will be modified." },
								"Edit multiple game objects",
								JOptionPane.WARNING_MESSAGE );
						}
						
						if ( EditGameObjDialog.editGameObj( modelObj ) ) {
							// User confirmed.
							UndoImpl.Composite undoOp = new UndoImpl.Composite();
							
							// Store model object's params:
							undoOp.add(
								new UndoImpl.EditObject(
									globalEditorModel,
									modelObj,
									oldModelObjID,   modelObj.getID(),
									oldModelObjPos,  new Point( modelObj.getX(), modelObj.getY() ),
									oldModelObjAttr, modelObj.getAttributeTable() ) );
							
							// If the selection had more than one item, copy changes.
							if ( selectionSet.getNumOfObjs() > 1 ) {
								AttributeTable modelAttr = modelObj.getAttributeTable();
								for ( int i = 0; i < selectionSet.getNumOfObjs(); i++ ) {
									GameObj obj = selectionSet.getObj(i);
									if ( obj != modelObj ) {
										String oldID = obj.getID();
										Point oldPos = new Point( obj.getX(), obj.getY() );
										AttributeTable oldAttr = obj.getAttributeTable();
										
										obj.setID( modelObj.getID() );
										obj.setAttributeTable( modelAttr );
										
										undoOp.add(
											new UndoImpl.EditObject(
												globalEditorModel,
												obj,
												oldID, obj.getID(),
												oldPos, new Point(obj.getX(), obj.getY()),
												oldAttr, obj.getAttributeTable() ) );
									}
								}
							}
							
							// Commit undo operation:
							HistoryManager.addUndoOperation( undoOp, "edit game object" + (undoOp.getCount() > 1 ? "s" : "") );
							
							globalEditorModel.setUnsavedChanges( true );
						}
					}
				} );
			
			hBox.add( Box.createHorizontalStrut( 5 ) );
		}
		add( hBox );
		
		add( Box.createVerticalStrut( 5 ) );
	}
	
	
	
	
	public boolean isSnapToGridEnabled () {
		return snapToGridCheckBox.isSelected();
	}
	
	
	

}
