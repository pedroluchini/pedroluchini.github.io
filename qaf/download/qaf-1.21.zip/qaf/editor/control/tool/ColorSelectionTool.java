package control.tool;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import model.BGLayer;
import model.ColorTile;
import model.ColorTileMatrix;
import model.GlobalEditorModel;
import model.Room;
import model.selection.BGTileColorSelectionSet;
import control.Main;

public class ColorSelectionTool extends ScrollTool {
	
	public final static Color  DRAGBOX_FILL_COLOR      = TileSelectionTool.DRAGBOX_FILL_COLOR;
	public final static Color  DRAGBOX_OUTLINE_COLOR   = TileSelectionTool.DRAGBOX_OUTLINE_COLOR;
	public final static Stroke DRAGBOX_OUTLINE_STROKE  = TileSelectionTool.DRAGBOX_OUTLINE_STROKE;
	public final static int    DRAG_IGNORE_AREA        = TileSelectionTool.DRAG_IGNORE_AREA;
	public final static Color  DRAGMOVE_OUTLINE_COLOR  = TileSelectionTool.DRAGMOVE_OUTLINE_COLOR;
	public final static Stroke DRAGMOVE_OUTLINE_STROKE = TileSelectionTool.DRAGMOVE_OUTLINE_STROKE;
	
	
	
	
	private GlobalEditorModel globalEditorModel;
	private ToolBar toolBar;
	private boolean lastPressOnSelection = false;
	
	
	
	
	public ColorSelectionTool ( GlobalEditorModel globalEditorModel, ToolBar toolBar ) {
		super( globalEditorModel, toolBar );
		
		this.globalEditorModel = globalEditorModel;
		this.toolBar = toolBar;
	}
	
	
	
	
	public Cursor getCursor() {
		if ( getKeyState( KeyEvent.VK_SPACE ) )
			return super.getCursor();
		else
		if ( globalEditorModel.getWorkingLayer() == -1 )
			return Cursor.getDefaultCursor();
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) && getKeyState( KeyEvent.VK_SHIFT ) )
			return Main.wandPlusCursor;
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) && getKeyState( KeyEvent.VK_ALT ) )
			return Main.wandMinusCursor;
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) )
			return Main.wandCursor;
		else
		if ( getKeyState( KeyEvent.VK_SHIFT ) )
			return Main.selectionPlusCursor;
		else
		if ( getKeyState( KeyEvent.VK_ALT ) )
			return Main.selectionMinusCursor;
		else
		if ( (getCurrMouseButton() == MouseEvent.NOBUTTON && mouseOverTileColorSelection()) || lastPressOnSelection )
			return Cursor.getPredefinedCursor( Cursor.MOVE_CURSOR );
		else
			return Main.selectionCursor;
	}
	
	
	
	
	public String getStatusBarText() {
		Point mousePoint = getCurrMousePoint();
		return Main.makeStatusBarText( globalEditorModel, mousePoint, true );
	}
	
	
	
	
	public Component getToolBox() {
		return toolBar.getColorToolBox();
	}
	
	
	
	
	public String getToolDescription() {
		return "Select, copy, move and delete color/blending effects.";
	}
	
	
	
	
	public Icon getToolIcon() {
		return new ImageIcon( Main.qafPath + "img/colorSelection.png" );
	}
	
	
	
	
	public String getToolName() {
		return "Color selection";
	}
	
	
	
	
	public void paintOverlay(Graphics g) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.paintOverlay( g );
		}
		else
		if ( globalEditorModel.getWorkingLayer() == -1 ) {}
		else
		if ( !getKeyState( KeyEvent.VK_CONTROL ) ) {
			// Paint selection overlay:
			
			// Dragging a new box?
			Point lastPressPoint = getLastPressPoint();
			Point currMousePoint = getCurrMousePoint();
			if ( !lastPressOnSelection && lastPressPoint != null && getCurrMouseButton() == MouseEvent.BUTTON1 ) {
				int layerInx = globalEditorModel.getWorkingLayer();
				
				if ( Math.abs(lastPressPoint.x - currMousePoint.x) < DRAG_IGNORE_AREA ||
				     Math.abs(lastPressPoint.y - currMousePoint.y) < DRAG_IGNORE_AREA )
					return;
				
				int col1 = globalEditorModel.tileColFromPanelX(currMousePoint.x, layerInx);
				int row1 = globalEditorModel.tileRowFromPanelY(currMousePoint.y, layerInx);
				int col2 = globalEditorModel.tileColFromPanelX(lastPressPoint.x, layerInx);
				int row2 = globalEditorModel.tileRowFromPanelY(lastPressPoint.y, layerInx);
				
				if ( row2 < row1 ) {
					int tmp = row1;
					row1 = row2;
					row2 = tmp;
				}
				if ( col2 < col1 ) {
					int tmp = col1;
					col1 = col2;
					col2 = tmp;
				}
				
				row2++; col2++;
				
				// Draw a rectangle covering the area, adjusted to the tiles.
				int x1 = globalEditorModel.panelXFromTileCol( col1, layerInx );
				int y1 = globalEditorModel.panelYFromTileRow( row1, layerInx );
				int x2 = globalEditorModel.panelXFromTileCol( col2, layerInx );
				int y2 = globalEditorModel.panelYFromTileRow( row2, layerInx );
				
				g.setColor( DRAGBOX_FILL_COLOR );
				g.fillRect( x1, y1, (x2 - x1), (y2 - y1) );
				
				g.setColor( DRAGBOX_OUTLINE_COLOR );
				Graphics2D g2D = (Graphics2D) g;
				Stroke oldStroke = g2D.getStroke();
				g2D.setStroke( DRAGBOX_OUTLINE_STROKE );
				
				g2D.drawRect( x1, y1, (x2 - x1), (y2 - y1) );
				
				g2D.setStroke( oldStroke );
			}
			// Dragging objects?
			else
			if ( lastPressOnSelection ) {
				globalEditorModel.roomPtFromPanelPt( lastPressPoint );
				globalEditorModel.roomPtFromPanelPt( currMousePoint );
				
				int dx = currMousePoint.x - lastPressPoint.x;
				int dy = currMousePoint.y - lastPressPoint.y;
				
				int tileW, tileH;
				if ( globalEditorModel.getWorkingLayer() == -1 ) {
					throw new IllegalStateException("Can't use color selections in the obstacle layer.");
				}
				else {
					int layerInx = globalEditorModel.getWorkingLayer();
					BGLayer bgLayer = globalEditorModel.getLoadedRoom().getBGLayer( layerInx );
					tileW = bgLayer.getTileWidth();
					tileH = bgLayer.getTileHeight();
				}
				
				dx /= tileW;
				dy /= tileH;
				
				// Draw tile outlines:
				Stroke oldStroke = ((Graphics2D) g).getStroke();
				((Graphics2D) g).setStroke( DRAGMOVE_OUTLINE_STROKE );
				g.setColor( DRAGMOVE_OUTLINE_COLOR );
				
				BGTileColorSelectionSet selection = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
				Point tl = new Point();
				Point tr = new Point();
				Point br = new Point();
				Point bl = new Point();
				int layerInx = globalEditorModel.getWorkingLayer();
				
				for ( int i = selection.getOrigRow(); i <= selection.getOrigRow() + selection.getNumOfRows(); i++ ) {
					for ( int j = selection.getOrigCol(); j <= selection.getOrigCol() + selection.getNumOfCols(); j++ ) {
						ColorTile tileColor = selection.getTileAtGlobalCoords(i, j);
						
						if ( tileColor == null )
							continue;
						
						tl.x = globalEditorModel.panelXFromTileCol( j + dx,     layerInx );
						tl.y = globalEditorModel.panelYFromTileRow( i + dy,     layerInx );
						tr.x = globalEditorModel.panelXFromTileCol( j + dx + 1, layerInx );
						tr.y = globalEditorModel.panelYFromTileRow( i + dy,     layerInx );
						br.x = globalEditorModel.panelXFromTileCol( j + dx + 1, layerInx );
						br.y = globalEditorModel.panelYFromTileRow( i + dy + 1, layerInx );
						bl.x = globalEditorModel.panelXFromTileCol( j + dx,     layerInx );
						bl.y = globalEditorModel.panelYFromTileRow( i + dy + 1, layerInx );
						
						// Left:
						if ( selection.getTileAtGlobalCoords(i, j - 1) == null ) {
							g.drawLine(tl.x, tl.y, bl.x, bl.y);
						}	
						// Right:
						if ( selection.getTileAtGlobalCoords(i, j + 1) == null ) {
							g.drawLine(tr.x, tr.y, br.x, br.y);
						}
						// Top:
						if ( selection.getTileAtGlobalCoords(i - 1, j) == null ) {
							g.drawLine(tl.x, tl.y, tr.x, tr.y);
						}
						// Bottom:
						if ( selection.getTileAtGlobalCoords(i + 1, j) == null ) {
							g.drawLine(bl.x, bl.y, br.x, br.y);
						}
					}
				}
				((Graphics2D) g).setStroke( oldStroke );
			}
		}
	}
	
	
	
	
	public boolean safeDispatchKeyEvent(KeyEvent evt) {
		if ( Main.processSelectionKeyEvent( globalEditorModel, toolBar, evt ) ) {}
		else {
			fireCursorChangedEvent();
		}
		
		return false;
	}
	
	
	
	
	public void safeMouseEntered ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseExited ( MouseEvent evt ) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseExited( evt );
		}
		else {
			safeMouseMoved(evt);
		}
	}
	
	
	
	
	public void safeMouseDragged(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseDragged( evt );
		}
		else {
			fireRepaintEvent();
			fireStatusBarChangedEvent();
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMouseMoved(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseMoved( evt );
		}
		else {
			fireStatusBarChangedEvent();
			fireCursorChangedEvent();
		}
	}
	
	
	
	
	public void safeMousePressed(MouseEvent evt) {
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMousePressed( evt );
			fireCursorChangedEvent();
		}
		else
		if ( globalEditorModel.getWorkingLayer() == -1 ) {}
		else
		if ( getKeyState( KeyEvent.VK_CONTROL ) ) {
			// Magic wand: Select similar adjacent tiles.
			int layerInx = globalEditorModel.getWorkingLayer();
			
			ColorTileMatrix selectionSet = null;
			if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet )
				selectionSet = ((BGTileColorSelectionSet) globalEditorModel.getSelectionSet()).cloneMatrix();
			
			if ( selectionSet == null ) {
				if ( layerInx == -1 )
					throw new IllegalStateException("Can't use color selections in the obstacle layer.");
				else {
					selectionSet = new ColorTileMatrix( null, 0, 0 );
				}	
			}
			
			Point currMousePoint = getCurrMousePoint();
			int col = globalEditorModel.tileColFromPanelX(currMousePoint.x, layerInx);
			int row = globalEditorModel.tileRowFromPanelY(currMousePoint.y, layerInx);
			
			// Build tile matrix of clicked area:
			Room room = globalEditorModel.getLoadedRoom();
			ColorTile tileColor;
			tileColor = room.getBGTileColor( layerInx, row, col );
			ColorTileMatrix clickedArea = makeTileArea( null, row, col, tileColor, layerInx );
			int row1 = clickedArea.getOrigRow();
			int row2 = clickedArea.getOrigRow() + clickedArea.getNumOfRows() - 1;
			int col1 = clickedArea.getOrigCol();
			int col2 = clickedArea.getOrigCol() + clickedArea.getNumOfCols() - 1;
			
			// Which modifier key?
			if ( getKeyState( KeyEvent.VK_SHIFT ) ) {
				// Shift: Add tiles to selection.
				for ( int i = row1; i <= row2; i++ )
					for ( int j = col1; j <= col2; j++ )
						if ( clickedArea.getTileAtGlobalCoords( i, j ) != null )
							selectionSet.setTileAtGlobalCoords( i, j, ColorTile.DEFAULT );
			}
			else
			if ( getKeyState( KeyEvent.VK_ALT ) ) {
				// Alt: Remove tiles from selection.
				for ( int i = row1; i <= row2; i++ )
					for ( int j = col1; j <= col2; j++ )
						if ( clickedArea.getTileAtGlobalCoords( i, j ) != null )
							selectionSet.unsetTileAtGlobalCoords( i, j );
			}
			else {
				// Start new selection... or clear existing one.
				selectionSet.clearBrush();
				for ( int i = row1; i <= row2; i++ )
					for ( int j = col1; j <= col2; j++ )
						if ( clickedArea.getTileAtGlobalCoords( i, j ) != null )
							selectionSet.setTileAtGlobalCoords( i, j, ColorTile.DEFAULT );
			}
			
			// Set the new set:
			if ( selectionSet.getNumOfCols() == 0 || selectionSet.getNumOfRows() == 0 )
				Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.COLORSELECTION_TOOL_INX, null );
			else {
				int tileW = room.getBGLayer( layerInx ).getTileWidth();
				int tileH = room.getBGLayer( layerInx ).getTileHeight();
				Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.COLORSELECTION_TOOL_INX, new BGTileColorSelectionSet( tileW, tileH, selectionSet ) );
			}
		}
		else {
			if ( !getKeyState( KeyEvent.VK_ALT ) && !getKeyState( KeyEvent.VK_SHIFT ) )
				lastPressOnSelection = mouseOverTileColorSelection();
			else
				lastPressOnSelection = false;
			
			safeMouseDragged( evt );
		}
	}
	
	
	
	
	public void safeMouseReleased(MouseEvent evt) {
		Room room = globalEditorModel.getLoadedRoom();
		
		if ( getKeyState( KeyEvent.VK_SPACE ) ) {
			super.safeMouseReleased( evt );
			fireCursorChangedEvent();
		}
		else
		if ( globalEditorModel.getWorkingLayer() == -1 ) {}
		else
		if ( !getKeyState( KeyEvent.VK_CONTROL ) ) {
			if ( evt.getButton() == MouseEvent.BUTTON1 ) {
				// Dragging a new box?
				if ( !lastPressOnSelection ) {
					Point lastPressPoint = getLastPressPoint();
					int layerInx = globalEditorModel.getWorkingLayer();
					
					Point currMousePoint = getCurrMousePoint();
					
					int col1 = globalEditorModel.tileColFromPanelX(currMousePoint.x, layerInx);
					int row1 = globalEditorModel.tileRowFromPanelY(currMousePoint.y, layerInx);
					int col2 = globalEditorModel.tileColFromPanelX(lastPressPoint.x, layerInx);
					int row2 = globalEditorModel.tileRowFromPanelY(lastPressPoint.y, layerInx);
					
					if ( row2 < row1 ) {
						int tmp = row1;
						row1 = row2;
						row2 = tmp;
					}
					if ( col2 < col1 ) {
						int tmp = col1;
						col1 = col2;
						col2 = tmp;
					}
					
					// Constrain to matrix:
					int numRows, numCols;
					numRows = room.getBGTileMatrixRows( layerInx );
					numCols = room.getBGTileMatrixCols( layerInx );
					
					if ( col1 < 0 ) col1 = 0;
					if ( row1 < 0 ) row1 = 0;
					if ( col2 >= numCols ) col2 = numCols - 1;
					if ( row2 >= numRows ) row2 = numRows - 1;
					
					ColorTileMatrix selectionSet = null;
					if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet )
						selectionSet = ((BGTileColorSelectionSet) globalEditorModel.getSelectionSet()).cloneMatrix();
					
					if ( selectionSet == null ) {
						selectionSet = new ColorTileMatrix( null, 0, 0 );	
					}
					
					// Which modifier key?
					if ( getKeyState( KeyEvent.VK_SHIFT ) ) {
						// Shift: Add tiles to selection.
						if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
						     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
							for ( int i = row1; i <= row2; i++ )
								for ( int j = col1; j <= col2; j++ ) {
									selectionSet.setTileAtGlobalCoords( i, j, ColorTile.DEFAULT );
								}
						}
					}
					else
					if ( getKeyState( KeyEvent.VK_ALT ) ) {
						// Alt: Remove tiles from selection.
						if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
						     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
							for ( int i = row1; i <= row2; i++ )
								for ( int j = col1; j <= col2; j++ )
									selectionSet.unsetTileAtGlobalCoords( i, j );
						}
					}
					else {
						// Start new selection... or clear existing one.
						selectionSet.clearBrush();
						if ( Math.abs(lastPressPoint.x - currMousePoint.x) >= DRAG_IGNORE_AREA &&
						     Math.abs(lastPressPoint.y - currMousePoint.y) >= DRAG_IGNORE_AREA ) {
							for ( int i = row1; i <= row2; i++ )
								for ( int j = col1; j <= col2; j++ ) {
									selectionSet.setTileAtGlobalCoords( i, j, ColorTile.DEFAULT );
								}
						}
					}
					
					// Set the new set:
					if ( selectionSet.getNumOfCols() == 0 || selectionSet.getNumOfRows() == 0 )
						Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.COLORSELECTION_TOOL_INX, null );
					else {
						int tileW = room.getBGLayer( layerInx ).getTileWidth();
						int tileH = room.getBGLayer( layerInx ).getTileHeight();
						Main.setSelectionSet( globalEditorModel, toolBar, ToolBar.COLORSELECTION_TOOL_INX, new BGTileColorSelectionSet( tileW, tileH, selectionSet ) );
					}
				}
				else {
					// Drag the selected tiles (lastPressOnSelection == true).
					Point lastPressPoint = getLastPressPoint();
					Point currMousePoint = getCurrMousePoint();
					globalEditorModel.roomPtFromPanelPt( lastPressPoint );
					globalEditorModel.roomPtFromPanelPt( currMousePoint );
					
					int dx = currMousePoint.x - lastPressPoint.x;
					int dy = currMousePoint.y - lastPressPoint.y;
					
					int tileW, tileH;
					if ( globalEditorModel.getWorkingLayer() == -1 ) {
						throw new IllegalStateException("Can't use color selections in the obstacle layer.");
					}
					else {
						int layerInx = globalEditorModel.getWorkingLayer();
						BGLayer bgLayer = globalEditorModel.getLoadedRoom().getBGLayer( layerInx );
						tileW = bgLayer.getTileWidth();
						tileH = bgLayer.getTileHeight();
					}
					
					dx /= tileW;
					dy /= tileH;
					
					// Move tiles:
					Main.moveSelection(
						globalEditorModel,
						toolBar,
						dx, dy );
				}
				
				fireRepaintEvent();
			}
		}
		
		fireCursorChangedEvent();
		lastPressOnSelection = false;
	}
	
	
	
	
	private boolean mouseOverTileColorSelection () {
		Point currMousePoint = getCurrMousePoint();
		if ( globalEditorModel.getSelectionSet() instanceof BGTileColorSelectionSet &&
		     currMousePoint != null ) {
			int layerInx = globalEditorModel.getWorkingLayer();
			int mouseRow = globalEditorModel.tileRowFromPanelY( currMousePoint.y, layerInx );
			int mouseCol = globalEditorModel.tileColFromPanelX( currMousePoint.x, layerInx );
			
			BGTileColorSelectionSet selectionSet = (BGTileColorSelectionSet) globalEditorModel.getSelectionSet();
			
			if ( selectionSet.getTileAtGlobalCoords( mouseRow, mouseCol ) != null ) {
				return true;
			}
		}
		
		return false;
	}
	
	
	
	
	public ColorTileMatrix makeTileArea ( ColorTileMatrix ctm, int row, int col, ColorTile equalToTileColor, int layerInx ) {
		if ( ctm == null )
			ctm = new ColorTileMatrix(null, 0, 0);
		
		Room room = globalEditorModel.getLoadedRoom();
		
		// Current tile outside of matrix?
		if ( row < 0 || row >= room.getBGTileMatrixRows( layerInx ) ||
		     col < 0 || col >= room.getBGTileMatrixCols( layerInx ) )
			return ctm;
		
		// Current tile is already set?
		if ( ctm.getTileAtGlobalCoords( row, col ) != null )
			return ctm;
		
		// Start by adding the current tile:
		ColorTile tileColor = room.getBGTileColor( layerInx, row, col );
		
		// Found a different tile?
		if ( !ColorTile.testEquality(tileColor, equalToTileColor) )
			return ctm;
		
		ctm.setTileAtGlobalCoords( row, col, ColorTile.DEFAULT );
		
		// Expand:
		makeTileArea( ctm, row - 1, col,     equalToTileColor, layerInx );
		makeTileArea( ctm, row - 1, col + 1, equalToTileColor, layerInx );
		makeTileArea( ctm, row,     col + 1, equalToTileColor, layerInx );
		makeTileArea( ctm, row + 1, col + 1, equalToTileColor, layerInx );
		makeTileArea( ctm, row + 1, col,     equalToTileColor, layerInx );
		makeTileArea( ctm, row + 1, col - 1, equalToTileColor, layerInx );
		makeTileArea( ctm, row,     col - 1, equalToTileColor, layerInx );
		makeTileArea( ctm, row - 1, col - 1, equalToTileColor, layerInx );
		
		return ctm;
	}
	
}
