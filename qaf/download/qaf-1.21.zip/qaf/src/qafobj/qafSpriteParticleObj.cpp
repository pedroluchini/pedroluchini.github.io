/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafobj/qafSpriteParticleObj.h>

#include <qafEnvironment.h>

using namespace qaf;


SpriteParticleObj::SpriteParticleObj (	const hgeSprite * _sprite,
										float _x, float _y,
										float _angle,
										float _vx, float _vy,
										float _vr,
										float _ax, float _ay,
										float _initialSizeX, float _initialSizeY,
										float _finalSizeX, float _finalSizeY,
										DWORD _initialColor, DWORD _finalColor,
										DWORD _blendMode,
										float _lifeTime )
: sprite(*_sprite)
{
	// Initialize parameters:
	x = _x;
	y = _y;
	angle = _angle;
	vx = _vx;
	vy = _vy;
	vr = _vr;
	ax = _ax;
	ay = _ay;
	initialSizeX = _initialSizeX;
	initialSizeY = _initialSizeY;
	finalSizeX = _finalSizeX;
	finalSizeY = _finalSizeY;
	initialR = GETR( _initialColor );
	initialG = GETG( _initialColor );
	initialB = GETB( _initialColor );
	initialA = GETA( _initialColor );
	deltaR = GETR( _finalColor ) - initialR;
	deltaG = GETG( _finalColor ) - initialG;
	deltaB = GETB( _finalColor ) - initialB;
	deltaA = GETA( _finalColor ) - initialA;
	blendMode =_blendMode;
	lifetime = _lifeTime;
	
	timer = 0;
}




void SpriteParticleObj::update ( int objLayer, float dt ) {
	// Move:
	x += vx * dt + 0.5f * ax * dt * dt;
	y += vy * dt + 0.5f * ay * dt * dt;
	vx += ax * dt;
	vy += ay * dt;
	angle += vr * dt;
	
	// Age:
	timer += dt;
	
	// Dead?
	if ( timer >= lifetime )
		// Kill:
		Environment::removeGameObj( this, true, objLayer );
	
}




void SpriteParticleObj::render ( int objLayer, float scrollX, float scrollY ) {
	// Set parameters:
	sprite.SetColor( getColor() );
	sprite.SetBlendMode( blendMode );
	float xScale, yScale;
	getSize( &xScale, &yScale );
	
	// Render:
	sprite.RenderEx( x - scrollX, y - scrollY, angle, xScale, yScale );
}
