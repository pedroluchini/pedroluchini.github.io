/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafutil/qafBigTexture.h>

#include <d3d8.h>
#include <d3dx8tex.h>
#include <dxerr8.h>
#include <hge.h>
#include <math.h>
#include <qafEnvironment.h>
#include <qafutil/qafGeom.h>
#include <qafutil/qafContainer.h>
#include <qafutil/qafMatrix.h>
#include <qafutil/qafVector2D.h>

using namespace qaf;


#define hge ((HGE *) pHGE)

#ifndef MAX
	#define MAX(a, b)  ((a) > (b) ? (a) : (b))
	#define MIN(a, b)  ((a) < (b) ? (a) : (b))
#endif

///////////////////////////////////////////////////////////////////////////////
// 
// AUXILIARY FUNCTIONS/STRUCTURES
// 
///////////////////////////////////////////////////////////////////////////////

static float triangleArea ( const Vector2D & v0, const Vector2D & v1, const Vector2D & v2 ) {
	Vector2D v0To1 = Vector2D(v1.x - v0.x, v1.y - v0.y);
	Vector2D v0To2 = Vector2D(v2.x - v0.x, v2.y - v0.y);
	
	// Determinant of:
	// |    i      j     k |
	// | v0To1.x v0To1.y 0 |
	// | v0To2.x v0To2.y 0 |
	return fabs((v0To1.x * v0To2.y) - (v0To1.y * v0To2.x)) / 2;
}




struct BaryCoords {
	float c0, c1, c2;
	
	float interpolate ( float v0, float v1, float v2 ) {
		return (c0 * v0) + (c1 * v1) + (c2 * v2);
	}
	
	DWORD interpolateColor( DWORD col0, DWORD col1, DWORD col2 ) {
		unsigned char a = (unsigned char) ((GETA(col0) * c0) + (GETA(col1) * c1) + (GETA(col2) * c2));
		unsigned char r = (unsigned char) ((GETR(col0) * c0) + (GETR(col1) * c1) + (GETR(col2) * c2));
		unsigned char g = (unsigned char) ((GETG(col0) * c0) + (GETG(col1) * c1) + (GETG(col2) * c2));
		unsigned char b = (unsigned char) ((GETB(col0) * c0) + (GETB(col1) * c1) + (GETB(col2) * c2));
		return ARGB(a, r, g, b);
	}
};




///////////////////////////////////////////////////////////////////////////////
// 
// PUBLIC MEMBERS
// 
///////////////////////////////////////////////////////////////////////////////

BigTexture::BigTexture ( const char * sourceImage )
 : subTextures(NULL),
   rows(0),
   cols(0),
   imageWidth(0),
   imageHeight(0) {
	// Temp. variable declarations here:
	HTEXTURE tmpTex = NULL;
	LPDIRECT3DSURFACE8 imgSurface = NULL;
	LPDIRECT3DDEVICE8  pD3DDevice = NULL;
	HRESULT hres;
	
	// Get an HGE interface:
	pHGE = hgeCreate( HGE_VERSION );
	
	// Load the file's data:
	DWORD imgFileSize = 0;
	void * imgFile = hge->Resource_Load( (char *) sourceImage, &imgFileSize );
	
	// Failed?
	if ( imgFile == NULL )
		goto BT_CTOR_FAILED;
	
	// 
	// Load the image into a surface.
	// 
	// I'm going to need a Direct3D device for that.
	// Using Haaf's D3D hack...
	tmpTex = hge->Texture_Create(2,2); 
	hres = (reinterpret_cast<LPDIRECT3DTEXTURE8>(tmpTex))->GetSurfaceLevel( 0, &imgSurface );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	hres = imgSurface->GetDevice( &pD3DDevice );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// Got the device!
	
	imgSurface->Release();
	imgSurface = NULL;
	hge->Texture_Free( tmpTex );
	tmpTex = NULL;
	
	// There. Now, I need to know the image size in order to create the surface
	// that will hold it...
	D3DXIMAGE_INFO imgInfo;
	hres = D3DXGetImageInfoFromFileInMemory( imgFile,     // LPCVOID pSrcData,
	                                         imgFileSize, // UINT SrcDataSize,
	                                         &imgInfo );  // D3DXIMAGE_INFO* pSrcInfo
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// Store image dimensions:
	imageWidth  = imgInfo.Width;
	imageHeight = imgInfo.Height;
	
	// Now, I can create my surface to hold the image:
	hres = pD3DDevice->CreateImageSurface( imageWidth,
	                                       imageHeight,
	                                       D3DFMT_A8R8G8B8,
	                                       &imgSurface );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// ...And load the image:
	hres = D3DXLoadSurfaceFromFileInMemory( imgSurface,       // LPDIRECT3DSURFACE8 pDestSurface,
	                                        NULL,             // CONST PALETTEENTRY* pDestPalette,
	                                        NULL,             // CONST RECT* pDestRect,
	                                        imgFile,          // LPCVOID pSrcData,
	                                        imgFileSize,      // UINT SrcData,
	                                        NULL,             // CONST RECT* pSrcRect,
	                                        D3DX_FILTER_NONE, // DWORD Filter,
	                                        0,                // D3DCOLOR ColorKey,
	                                        &imgInfo );       // D3DXIMAGE_INFO* pSrcInfo
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// The file is no longer needed.
	hge->Resource_Free( imgFile );
	imgFile = NULL;
	
	// Lock the surface so I can read its pixels:
	D3DLOCKED_RECT lockRect;
	hres = imgSurface->LockRect( &lockRect, NULL, D3DLOCK_READONLY );
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
	// IMAGE LOADED!
	
	// For all I know right now, the image *could* fit in a single texture...
	rows = cols = 1;
	
	// Try and create it as a single texture.
	// This is just to test the video card's capabilities; I won't need the
	// created texture right now.
	tmpTex = hge->Texture_Create( imageWidth, imageHeight );
	
	int tmpTexWidth = hge->Texture_GetWidth( tmpTex );
	int tmpTexHeight = hge->Texture_GetHeight( tmpTex );
	hge->Texture_Free( tmpTex );
	
	// Image was too big for the video card?
	if ( tmpTexWidth < imageWidth )
		cols = (int) ceil( (float) imageWidth / tmpTexWidth );
	
	if ( tmpTexHeight < imageHeight )
		rows = (int) ceil( (float) imageHeight / tmpTexHeight );
	
	// Allocate the sub-texture matrix:
	subTextures = new SubTexture[rows * cols];
	
	// How many pixels were already transferred from the image to the
	// sub-textures:
	int pixelsX = 0, pixelsY = 0;
	
	for ( int i = 0; i < rows; i++ ) {
		for ( int j = 0; j < cols; j++ ) {
			
			// Create the sub-texture at position (i, j) in the matrix.
			// Try to create it so it will be able to store whatever's left in
			// the image:
			tmpTex = hge->Texture_Create( tmpTexWidth, tmpTexHeight );
			
			// Lock the texture so I can fill it with pixel data:
			DWORD * tmpTexData = hge->Texture_Lock( tmpTex, false );
			
			for ( int x = 0; x < tmpTexWidth; x++ ) {
				for ( int y = 0; y < tmpTexHeight; y++ ) {
					// Look up the pixel's components:
					// Out of image bounds?
					if ( pixelsY + y >= imageHeight || pixelsX + x >= imageWidth )
						tmpTexData[y * tmpTexWidth + x] = 0; // Use a transparent black -- doesn't matter
					else {
						// Row offset:
						DWORD * row = (DWORD *) ((unsigned char *) lockRect.pBits + lockRect.Pitch * (pixelsY + y));
						
						tmpTexData[y * tmpTexWidth + x] = row[pixelsX + x];
					}
				}
			}
			
			// This sub-texture is done.
			hge->Texture_Unlock( tmpTex );
			
			// Store it:
			subTextures[i * cols + j].tex    = tmpTex;
			subTextures[i * cols + j].width  = tmpTexWidth;
			subTextures[i * cols + j].height = tmpTexHeight;
			
			// Done with this texture:
			tmpTex = NULL;
			
			// Advance the amount of pixels read.
			pixelsX += tmpTexWidth;
			
			// This row finished?
			if ( pixelsX >= imageWidth ) {
				// Go to the beginning of the next row:
				pixelsX = 0;
				pixelsY += tmpTexHeight;
			}
		}
	}
	
	// Done!
	
	// Unlock the surface now:
	hres = imgSurface->UnlockRect(); // TODO: Is it possible to fail here?!
	if ( FAILED(hres) ) {
		hge->System_Log( "%s (%s, line %d)", DXGetErrorString8( hres ), __FILE__, __LINE__ );
		goto BT_CTOR_FAILED;
	}
	
BT_CTOR_FAILED:
	// Clean up!
	if ( tmpTex ) {
		hge->Texture_Free( tmpTex );
		tmpTex = NULL;
	}
	
	if ( imgSurface ) {
		imgSurface->Release();
		imgSurface = NULL;
	}
	
	if ( pD3DDevice ) {
		pD3DDevice->Release();
		pD3DDevice = NULL;
	}
	
	if ( imgFile ) {
		hge->Resource_Free( imgFile );
		imgFile = NULL;
	}
	
	return;
	
} // End of method: BigTexture::BigTexture




BigTexture::~BigTexture () {
	// Release the sub-texture matrix:
	if ( subTextures ) {
		for ( int i = 0; i < rows; i++ )
			for ( int j = 0; j < cols; j++ )
				hge->Texture_Free( subTextures[i * cols + j].tex );
		
		delete[] subTextures;
	}
	
	// Release the HGE pointer:
	hge->Release();
	
} // End of method: BigTexture::~BigTexture




void BigTexture::renderRectangle ( int x0, int y0, int tx, int ty, int width, int height, unsigned long color, unsigned long blend, bool flipX, bool flipY ) const {
	// Width/height negative?
	if ( width <= 0 )
		width = imageWidth;
	
	if ( height <= 0 )
		height = imageHeight;
	
	// Clamp Bounds:
	{
		int xLeft = tx, xRight = tx + width;
		int yTop  = ty, yBott  = ty + height;
		
		if ( xLeft < 0 ) {
			x0 -= xLeft;
			xLeft = 0;
		}
		else if ( xLeft > imageWidth )
			return;
		
		if ( xRight > imageWidth )
			xRight = imageWidth;
		else if ( xRight < 0 )
			return;
		
		if ( yTop < 0 ) {
			y0 -= yTop;
			yTop = 0;
		}
		else if ( yTop > imageHeight )
			return;
		
		if ( yBott > imageHeight )
			yBott = imageHeight;
		else if ( yBott < 0 )
			return;
		
		// Recalculate...
		tx     = xLeft;
		ty     = yTop;
		width  = xRight - xLeft;
		height = yBott - yTop;
	}
	
	// Which sub-textures are covered by this rectangle?
	int iInit = ty / subTextures[0].height;
	int jInit = tx / subTextures[0].width;
	
	int iFinal = (ty + height - 1) / subTextures[0].height;
	int jFinal = (tx + width  - 1) / subTextures[0].width;
	
	// Draw several hgeQuads:
	int yTop   = y0;
	int yBott  = y0 + MIN( MIN( height, subTextures[0].height ), (subTextures[0].height - (ty % subTextures[0].height) <= 0 ? 0x7FFFFFFF : subTextures[0].height - (ty % subTextures[0].height)) );
	int tyTop  = ty;
	int tyBott = ty  + MIN( MIN( height, subTextures[0].height ), (subTextures[0].height - (ty % subTextures[0].height) <= 0 ? 0x7FFFFFFF : subTextures[0].height - (ty % subTextures[0].height)) );
	
	for ( int i = iInit; i <= iFinal; i++ ) {
		int xLeft   = x0;
		int xRight  = x0 + MIN( MIN( width, subTextures[0].width ), (subTextures[0].width - (tx % subTextures[0].width) <= 0 ? 0x7FFFFFFF : subTextures[0].width - (tx % subTextures[0].width)) );
		int txLeft  = tx;
		int txRight = tx  + MIN( MIN( width, subTextures[0].width ), (subTextures[0].width - (tx % subTextures[0].width) <= 0 ? 0x7FFFFFFF : subTextures[0].width - (tx % subTextures[0].width)) );
		
		for ( int j = jInit; j <= jFinal; j++ ) {
			static hgeQuad q = {
				{
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 },
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 },
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 },
					{ 0, 0, 0, 0xFFFFFFFF, 0, 0 }
				}, 
				NULL,
				0
			};
			
			// The matrix index for the current sub-texture:
			int mInx = i * cols + j;
			
			q.blend = blend;
			q.tex   = subTextures[mInx].tex;
			q.v[0].col = q.v[1].col = q.v[2].col = q.v[3].col = color;
			
			// Left:
			q.v[0].x  = q.v[3].x  = (float) (flipX ? (x0 + width - (xLeft - x0)) : xLeft);
			q.v[0].tx = q.v[3].tx = ((float) txLeft / subTextures[mInx].width);
			
			// Right:
			q.v[1].x  = q.v[2].x  = (float) (flipX ? (x0 + width - (xRight - x0)) : xRight);
			q.v[1].tx = q.v[2].tx = ((float) txRight / subTextures[mInx].width);
			
			// Top:
			q.v[0].y  = q.v[1].y  = (float) (flipY ? (y0 + height - (yTop - y0)) : yTop);
			q.v[0].ty = q.v[1].ty = ((float) tyTop / subTextures[mInx].height);
			
			// Bottom:
			q.v[2].y  = q.v[3].y  = (float) (flipY ? (y0 + height - (yBott - y0)) : yBott);
			q.v[2].ty = q.v[3].ty = ((float) tyBott / subTextures[mInx].height);
			
			// Render it!
			hge->Gfx_RenderQuad( &q );
			
			// Next sub-texture (to the right):
			txLeft  = txRight;
			txRight += MIN( x0 + width - xRight, subTextures[0].width ); // This *must* come before the screen coordinates are updated!
			xLeft   = xRight;
			xRight  += MIN( x0 + width - xRight, subTextures[0].width );
		}
		
		// Next sub-texture (to the bottom):
		tyTop  = tyBott;
		tyBott += MIN( y0 + height - yBott, subTextures[0].height ); // This *must* come before the screen coordinates are updated!
		yTop   = yBott;
		yBott  += MIN( y0 + height - yBott, subTextures[0].height );
	}
	
} // End of method: BigTexture::renderRectangle




void BigTexture::renderTriple ( const hgeTriple * _a_triple ) const {
	static hgeTriple a_triple;
	a_triple = *_a_triple;
	
	// Adjust texture coordinates for padding at the image's right/bottom:
	int totalWidth = cols * subTextures[0].width;
	int totalHeight = rows * subTextures[0].height;
	for ( int i = 0; i < 3; i++ ) {
		a_triple.v[i].tx *= (float) imageWidth / totalWidth;
		a_triple.v[i].ty *= (float) imageHeight / totalHeight;
	}
	
	// All of the vertices fit within a single subtexture?
	int subTexCol0 = (int) (a_triple.v[0].tx * cols);
	int subTexRow0 = (int) (a_triple.v[0].ty * rows);
	int subTexCol1 = (int) (a_triple.v[1].tx * cols);
	int subTexRow1 = (int) (a_triple.v[1].ty * rows);
	int subTexCol2 = (int) (a_triple.v[2].tx * cols);
	int subTexRow2 = (int) (a_triple.v[2].ty * rows);
	
	if ( subTexCol0 == subTexCol1 && subTexCol1 == subTexCol2 &&
	     subTexRow0 == subTexRow1 && subTexRow1 == subTexRow2 &&
	     subTexCol0 >= 0 && subTexCol0 < cols &&
	     subTexRow0 >= 0 && subTexRow0 < rows ) {
		
		// Adjust texture coordinates:
		a_triple.v[0].tx = (a_triple.v[0].tx - (float) subTexCol0 / cols) * cols;
		a_triple.v[0].ty = (a_triple.v[0].ty - (float) subTexRow0 / rows) * rows;
		a_triple.v[1].tx = (a_triple.v[1].tx - (float) subTexCol0 / cols) * cols;
		a_triple.v[1].ty = (a_triple.v[1].ty - (float) subTexRow0 / rows) * rows;
		a_triple.v[2].tx = (a_triple.v[2].tx - (float) subTexCol0 / cols) * cols;
		a_triple.v[2].ty = (a_triple.v[2].ty - (float) subTexRow0 / rows) * rows;
		a_triple.tex = subTextures[cols * subTexRow0 + subTexCol0].tex;
		// Just render it:
		hge->Gfx_RenderTriple( &a_triple );
		return;
	}
	
	
	// Calculate a triangle with vertices in the image's texel space.
	static Container<Vector2D> texelSpaceOrigTriangle;
	texelSpaceOrigTriangle.removeAll();
	texelSpaceOrigTriangle.add( Vector2D(a_triple.v[0].tx * totalWidth, a_triple.v[0].ty * totalHeight) );
	texelSpaceOrigTriangle.add( Vector2D(a_triple.v[1].tx * totalWidth, a_triple.v[1].ty * totalHeight) );
	texelSpaceOrigTriangle.add( Vector2D(a_triple.v[2].tx * totalWidth, a_triple.v[2].ty * totalHeight) );
	
	// Clip the triangle so it will be contained within the image:
	static Container<Vector2D> texelSpaceOrigPoly;
	texelSpaceOrigPoly = texelSpaceOrigTriangle;
	Vector2D planeP, planeN;
	bool needsClippingL = false,
	     needsClippingR = false,
	     needsClippingT = false,
	     needsClippingB = false;
	for ( int i = 0; i < 3; i++ ) {
		if ( a_triple.v[i].tx < 0 )
			needsClippingL = true;
		if ( a_triple.v[i].tx > 1 )
			needsClippingR = true;
		if ( a_triple.v[i].ty < 0 )
			needsClippingT = true;
		if ( a_triple.v[i].ty > 1 )
			needsClippingB = true;
	}
	// Left:
	if ( needsClippingL ) {
		planeP.x = 0; planeP.y = 0;
		planeN.x = 1; planeN.y = 0;
		Geom::clipPolygon( &texelSpaceOrigPoly, planeP, planeN );
	}
	// Right:
	if ( needsClippingR ) {
		planeP.x = (float) totalWidth; planeP.y = 0;
		planeN.x = -1; planeN.y = 0;
		Geom::clipPolygon( &texelSpaceOrigPoly, planeP, planeN );
	}
	// Top:
	if ( needsClippingT ) {
		planeP.x = 0; planeP.y = 0;
		planeN.x = 0; planeN.y = 1;
		Geom::clipPolygon( &texelSpaceOrigPoly, planeP, planeN );
	}
	// Bottom:
	if ( needsClippingB ) {
		planeP.x = 0; planeP.y = (float) totalHeight;
		planeN.x = 0; planeN.y = -1;
		Geom::clipPolygon( &texelSpaceOrigPoly, planeP, planeN );
	}
	
	// No longer a triangle!
	
	// Anyway, are there any vertices left?
	if ( texelSpaceOrigPoly.getCount() < 3 )
		// Triangle completely outside of image. Do nothing!
		return;
	
	// Now, I'm going to determine which sub-textures will have to be rendered.
	int colSubTexLeft = 0;
	int colSubTexRight = this->cols;
	int rowSubTexTop = 0;
	int rowSubTexBott = this->rows;
	
	// For each sub-texture...
	for ( int i = rowSubTexTop; i < rowSubTexBott; i++ ) {
		for ( int j = colSubTexLeft; j < colSubTexRight; j++ ) {
			SubTexture * pSubTex = subTextures + (i * cols + j);
			
			// Clip original render polygon to this texture's texel space:
			static Container<Vector2D> texelSpaceSubPoly;
			texelSpaceSubPoly = texelSpaceOrigPoly;
			
			planeP.x = (float) (j * subTextures[0].width);
			planeP.y = (float) (i * subTextures[0].height);
			// Left:
			planeN.x = 1; planeN.y = 0;
			Geom::clipPolygon( &texelSpaceSubPoly, planeP, planeN );
			// Top:
			planeN.x = 0; planeN.y = 1;
			Geom::clipPolygon( &texelSpaceSubPoly, planeP, planeN );
			
			planeP.x += pSubTex->width;
			planeP.y += pSubTex->height;
			// Right:
			planeN.x = -1; planeN.y = 0;
			Geom::clipPolygon( &texelSpaceSubPoly, planeP, planeN );
			// Bottom:
			planeN.x = 0; planeN.y = -1;
			Geom::clipPolygon( &texelSpaceSubPoly, planeP, planeN );
			
			// Calculate barycentric coordinates of each vertex:
			static Container<BaryCoords> baryCoordsSubPoly;
			baryCoordsSubPoly.removeAll();
			float totalTriangleArea = triangleArea( texelSpaceOrigTriangle[0],
			                                        texelSpaceOrigTriangle[1],
			                                        texelSpaceOrigTriangle[2] );
			
			for ( int iVx = 0; iVx < texelSpaceSubPoly.getCount(); iVx++ ) {
				BaryCoords baryVx;
				
				float area0 = triangleArea(texelSpaceSubPoly[iVx],
				                           texelSpaceOrigTriangle[1],
				                           texelSpaceOrigTriangle[2]);
				float area1 = triangleArea(texelSpaceSubPoly[iVx],
				                           texelSpaceOrigTriangle[0],
				                           texelSpaceOrigTriangle[2]);
				float area2 = triangleArea(texelSpaceSubPoly[iVx],
				                           texelSpaceOrigTriangle[0],
				                           texelSpaceOrigTriangle[1]);
				
				baryVx.c0 = area0 / totalTriangleArea;
				baryVx.c1 = area1 / totalTriangleArea;
				baryVx.c2 = area2 / totalTriangleArea;
				baryCoordsSubPoly.add( baryVx );
			}
			
			// OK, so now I've got the barycentric coordinates of each vertex of the
			// subpolygon.
			// ...Or do I?
			if ( baryCoordsSubPoly.getCount() > 0 ) {
				// I'm going to render the polygon as a triangle fan.
				
				hgeTriple t;
				t.blend = a_triple.blend;
				t.tex = pSubTex->tex;
				
				// Use the first vertex in the subpolygon as the fan's pivot:
				t.v[0].x  = baryCoordsSubPoly[0].interpolate(a_triple.v[0].x,  a_triple.v[1].x,  a_triple.v[2].x);
				t.v[0].y  = baryCoordsSubPoly[0].interpolate(a_triple.v[0].y,  a_triple.v[1].y,  a_triple.v[2].y);
				t.v[0].z  = baryCoordsSubPoly[0].interpolate(a_triple.v[0].z,  a_triple.v[1].z,  a_triple.v[2].z);
				t.v[0].tx = baryCoordsSubPoly[0].interpolate(a_triple.v[0].tx, a_triple.v[1].tx, a_triple.v[2].tx);
				t.v[0].ty = baryCoordsSubPoly[0].interpolate(a_triple.v[0].ty, a_triple.v[1].ty, a_triple.v[2].ty);
				t.v[0].col = baryCoordsSubPoly[0].interpolateColor(a_triple.v[0].col, a_triple.v[1].col, a_triple.v[2].col);
				
				t.v[0].tx = (t.v[0].tx - (float) j / cols) * cols;
				t.v[0].ty = (t.v[0].ty - (float) i / rows) * rows;
				
				// Use the second vertex as the starting point...
				t.v[1].x  = baryCoordsSubPoly[1].interpolate(a_triple.v[0].x,  a_triple.v[1].x,  a_triple.v[2].x);
				t.v[1].y  = baryCoordsSubPoly[1].interpolate(a_triple.v[0].y,  a_triple.v[1].y,  a_triple.v[2].y);
				t.v[1].z  = baryCoordsSubPoly[1].interpolate(a_triple.v[0].z,  a_triple.v[1].z,  a_triple.v[2].z);
				t.v[1].tx = baryCoordsSubPoly[1].interpolate(a_triple.v[0].tx, a_triple.v[1].tx, a_triple.v[2].tx);
				t.v[1].ty = baryCoordsSubPoly[1].interpolate(a_triple.v[0].ty, a_triple.v[1].ty, a_triple.v[2].ty);
				t.v[1].col = baryCoordsSubPoly[1].interpolateColor(a_triple.v[0].col, a_triple.v[1].col, a_triple.v[2].col);
				
				t.v[1].tx = (t.v[1].tx - (float) j / cols) * cols;
				t.v[1].ty = (t.v[1].ty - (float) i / rows) * rows;
				
				// For each vertex...
				for ( int iVx = 2; iVx < texelSpaceSubPoly.getCount(); iVx++ ) {
					// Interpolate data:
					t.v[2].x   = baryCoordsSubPoly[iVx].interpolate(a_triple.v[0].x,  a_triple.v[1].x,  a_triple.v[2].x);
					t.v[2].y   = baryCoordsSubPoly[iVx].interpolate(a_triple.v[0].y,  a_triple.v[1].y,  a_triple.v[2].y);
					t.v[2].z   = baryCoordsSubPoly[iVx].interpolate(a_triple.v[0].z,  a_triple.v[1].z,  a_triple.v[2].z);
					t.v[2].tx  = baryCoordsSubPoly[iVx].interpolate(a_triple.v[0].tx, a_triple.v[1].tx, a_triple.v[2].tx);
					t.v[2].ty  = baryCoordsSubPoly[iVx].interpolate(a_triple.v[0].ty, a_triple.v[1].ty, a_triple.v[2].ty);
					t.v[2].col = baryCoordsSubPoly[iVx].interpolateColor(a_triple.v[0].col, a_triple.v[1].col, a_triple.v[2].col);
					
					t.v[2].tx = (t.v[2].tx - (float) j / cols) * cols;
					t.v[2].ty = (t.v[2].ty - (float) i / rows) * rows;
					
					// Render it!
					hge->Gfx_RenderTriple( &t );
					
					// Transfer data from vertex 2 to vertex 1, in preparation for
					// the next step:
					t.v[1] = t.v[2];
				}
			}
		}
	}
}




void BigTexture::renderQuad ( const hgeQuad * q ) const {
	static hgeTriple t;
	
	t.blend = q->blend;
	
	// First triple: Vertices 0, 1, 2
	t.v[0] = q->v[0];
	t.v[1] = q->v[1];
	t.v[2] = q->v[2];
	renderTriple( &t );
	
	// Second triple: Vertices 0, 2, 3
	t.v[0] = q->v[0];
	t.v[1] = q->v[2];
	t.v[2] = q->v[3];
	renderTriple( &t );
	
}
