package control.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.ObstacleBlockTypes;
import model.Room;
import model.TileBrushMatrix;
import view.RoomPanel;
import control.Main;

public class BlockPicker extends Box {
	final static long serialVersionUID = 0;
	
	public final static Color TILE_GRID_COLOR = Color.RED;
	public final static int BLOCKS_PER_ROW = 11;
	
	
	
	
	private class TilePickerArea extends JPanel {
		static final long serialVersionUID = 0;
		
		SmartInputAdapter inputAdapter = new SmartInputAdapter() {
			public void safeMousePressed(MouseEvent evt) {
				// Calculate row, column, and tileID:
				int x = evt.getX();
				int y = evt.getY();
				
				// Ignore if click was outside the image:
				if (x > (blockSize * getNumOfCols()) || y > (blockSize * getNumOfRows()))
					return;
		
				// Get which tile was clicked on:
				int tileID;
				
				// Row and column clicked:
				int row = (y - 1) / blockSize;
				int col = (x - 1) / blockSize;
	
				tileID = getNumOfCols() * row + col;
				
				// Ignore click if the selected tile is an invalid
				// value:
				if (tileID > ObstacleBlockTypes.MAX_BLOCK_TYPES)
					return;
				
				if ( getKeyState( KeyEvent.VK_SHIFT ) )
					// Shift: Add tiles to selection
					tileBrushMatrix.setTileAtGlobalCoords( row, col, tileID );
				else
				if ( getKeyState( KeyEvent.VK_ALT ) ) {
					// Alt: Remove tiles from selection, if the brush won't
					// become empty as a result.
					if ( tileBrushMatrix.getNumOfCols() > 1 || tileBrushMatrix.getNumOfRows() > 1 )
						tileBrushMatrix.unsetTileAtGlobalCoords( row, col );
				}
				else {
					// No modifiers: Set new brush
					tileBrushMatrix.clearBrush();
					tileBrushMatrix.setTileAtGlobalCoords( row, col, tileID );
				}
				
				// Display changes:
				repaint();
			}
			
			public void safeMouseDragged(MouseEvent evt) {
				safeMousePressed(evt);
			}
	
			public boolean safeDispatchKeyEvent(KeyEvent evt) {
				if ( getKeyState( KeyEvent.VK_SHIFT ) )
					setCursor( Main.eyedropPlusCursor );
				else
				if ( getKeyState( KeyEvent.VK_ALT ) )
					setCursor( Main.eyedropMinusCursor );
				else
					setCursor( Main.eyedropCursor );
				
				return false;
			}
		};
		
		public TilePickerArea () {
			super();
			setCursor( Main.eyedropCursor );
			
			addMouseListener( inputAdapter );
			addMouseMotionListener( inputAdapter );
			KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher( inputAdapter );
			// TODO: Remove the inputAdapter when the tilepicker is deleted.
		}
		
		public Dimension getPreferredSize () {
			return new Dimension( (getNumOfCols() * blockSize) + 1, (getNumOfRows() * blockSize) + 1 );
		}
		
		public Dimension getMinimumSize () {
			return getPreferredSize();
		}
		
		public void paint ( Graphics g ) {
			Main.clearBGWithHatches( g, getWidth(), getHeight() );
			
			for ( int blockID = 0; blockID <= ObstacleBlockTypes.MAX_BLOCK_TYPES; blockID++ )
				ObstacleBlockTypes.drawBlock(
					blockID,
					blockID % getNumOfCols() * blockSize,
					blockID / getNumOfCols() * blockSize,
					blockSize,
					g );
			
			Main.drawGrid(
				g,
				0, 0,
				getNumOfRows(), getNumOfCols(),
				blockSize, blockSize,
				ObstacleBlockTypes.MAX_BLOCK_TYPES + 1,
				RoomPanel.TILE_GRID_COLOR );
			
			// Tile brush overlay:
			int topRow   = tileBrushMatrix.getOrigRow();
			int bottRow  = tileBrushMatrix.getOrigRow() + tileBrushMatrix.getNumOfRows() - 1;
			int leftCol  = tileBrushMatrix.getOrigCol();
			int rightCol = tileBrushMatrix.getOrigCol() + tileBrushMatrix.getNumOfCols() - 1;
			
			g.setColor( TILE_GRID_COLOR );
			for ( int row = topRow; row <= bottRow; row++ ) {
				for ( int col = leftCol; col <= rightCol; col++ ) {
					// Ignore if a free cell is set at these coords.:
					if ( tileBrushMatrix.getTileAtGlobalCoords( row, col ) != TileBrushMatrix.FREE_CELL ) {
						// Left line, if no cell on the left:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row, col - 1 ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( blockSize * col - 1, blockSize * row - 1, 3, blockSize + 2 );
						// Right line, if no cell on the right:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row, col + 1 ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( blockSize * (col + 1) - 1, blockSize * row - 1, 3, blockSize + 2 );
						// Top line, if no cell above:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row - 1, col ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( blockSize * col - 1, blockSize * row - 1, blockSize + 2, 3 );
						// Bottom line, if no cell below:
						if ( tileBrushMatrix.getTileAtGlobalCoords( row + 1, col ) == TileBrushMatrix.FREE_CELL )
							g.fillRect( blockSize * col - 1, blockSize * (row + 1) - 1, blockSize + 2, 3 );
						
					}
				}
			}
		}
		
	}
	
	
	
	
	private int blockSize;
	private TilePickerArea tilePickerArea = new TilePickerArea();
	public TileBrushMatrix tileBrushMatrix;
	
	
	
	
	public BlockPicker ( int _blockSize ) {
		super( BoxLayout.Y_AXIS );
		setAlignmentX( 0.5f );
		setAlignmentY( 0.5f );
		
		this.blockSize = _blockSize;
		
		int[][] brushMatrix = { { 0 } };
		this.tileBrushMatrix = new TileBrushMatrix( brushMatrix, 0, 0 );
		
		// +-----------------------------+
		// |+---------------------------+|
		// ||                           ||
		// ||     TilePickerArea        ||
		// ||                           ||
		// |+---------------------------+|
		// +-----------------------------+
		
		tilePickerArea.setAlignmentX( 0.5f );
		tilePickerArea.setAlignmentY( 0.5f );
		add( new JScrollPane( tilePickerArea ) );
		
		this.setPreferredSize(
			new Dimension(
				BLOCKS_PER_ROW * blockSize + 1,
				getPreferredSize().height ) );
	}




	public void setSelectedBlock ( int tileID ) {
		int pureTileID = tileID & Room.PURE_BGTILE_MASK;
		
		// Reset brush
		int[][] brushMatrix = { { pureTileID } };
		this.tileBrushMatrix =
			new TileBrushMatrix(
				brushMatrix,
				pureTileID / getNumOfCols(),
				pureTileID % getNumOfCols() );
		
		tilePickerArea.repaint();
	}
	
	
	
	
	private int getNumOfRows () {
		return (1 + ObstacleBlockTypes.MAX_BLOCK_TYPES / BLOCKS_PER_ROW);
	}
	
	
	
	
	private int getNumOfCols () {
		return BLOCKS_PER_ROW;
	}
	
}
