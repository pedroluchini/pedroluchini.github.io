/*
 * Created on Jun 16, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package control.dlg;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import control.Main;

public class ColorChooserDialog extends JDialog {
	final static long serialVersionUID = 0;
	
	private static final int STATUS_CANCEL = 0;
	private static final int STATUS_OK     = 1;
	
	private Color color = null;
	private int status = STATUS_CANCEL;
	private JSlider aSlider = new JSlider( JSlider.HORIZONTAL, 0, 255, 0 ),
	                rSlider = new JSlider( JSlider.HORIZONTAL, 0, 255, 0 ),
	                gSlider = new JSlider( JSlider.HORIZONTAL, 0, 255, 0 ),
	                bSlider = new JSlider( JSlider.HORIZONTAL, 0, 255, 0 );
	private JLabel  aLabel  = new JLabel(),
	                rLabel  = new JLabel(),
	                gLabel  = new JLabel(),
	                bLabel  = new JLabel();
	private JPanel displayPanel = 
		new JPanel() {
			static final long serialVersionUID = 0;
			
			public void paint ( Graphics g ) {
				Main.clearBGWithCheckers( g, getWidth(), getHeight() );
				g.setColor( color );
				g.fillRect( 0, 0, getWidth(), getHeight() );
			}
		};
	private JButton okBtn = new JButton( "OK" ),
	                cancelBtn = new JButton( "Cancel" );
	
	
	
	
	
	private ColorChooserDialog ( Frame parent, Color initialColor ) {
		super( parent, "Choose a color", true );
		this.color = initialColor;
		
		// +-----------------------------------------+
		// | Alpha: =======[]======= 127  +--------+ |
		// | Red:   ============[]== 200  |        | |
		// | Green: =======[]======= 127  |        | |
		// | Blue:  []==============   0  |        | |
		// |                              +--------+ |
		// |                                         |
		// |         [   OK   ] [ Cancel ]           |
		// +-----------------------------------------+
		
		this.setLayout( new GridBagLayout() );
		
		add( new JLabel("Alpha:"), new GridBagConstraints(0, 0, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(10,10,0,5), 0, 0) );
		add( new JLabel("Red:"),   new GridBagConstraints(0, 1, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,10,0,5), 0, 0) );
		add( new JLabel("Green:"), new GridBagConstraints(0, 2, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,10,0,5), 0, 0) );
		add( new JLabel("Blue:"),  new GridBagConstraints(0, 3, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,10,0,5), 0, 0) );
		
		add( aSlider, new GridBagConstraints(1, 0, 1, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10,0,0,0), 0, 0) );
		add( rSlider, new GridBagConstraints(1, 1, 1, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0,0,0,0), 0, 0) );
		add( gSlider, new GridBagConstraints(1, 2, 1, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0,0,0,0), 0, 0) );
		add( bSlider, new GridBagConstraints(1, 3, 1, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0,0,0,0), 0, 0) );
		
		add( aLabel, new GridBagConstraints(2, 0, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(10,5,0,5), 0, 0) );
		add( rLabel, new GridBagConstraints(2, 1, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,5,0,5), 0, 0) );
		add( gLabel, new GridBagConstraints(2, 2, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,5,0,5), 0, 0) );
		add( bLabel, new GridBagConstraints(2, 3, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,5,0,5), 0, 0) );
		add( new JLabel("          "), new GridBagConstraints(2, 4, 1, 1, 0, 0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,5,0,5), 0, 0) );
		
		displayPanel.setMinimumSize( new Dimension(100, 100) );
		displayPanel.setMaximumSize( displayPanel.getMinimumSize() );
		displayPanel.setPreferredSize( displayPanel.getMinimumSize() );
		add( displayPanel, new GridBagConstraints(3, 0, 1, 4, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10,10,0,10), 0, 0 ) );
		
		Box hBox = Box.createHorizontalBox();
		{
			hBox.add( Box.createGlue() );
			
			hBox.add( okBtn );
			
			hBox.add( Box.createHorizontalStrut( 15 ) );
			
			hBox.add( cancelBtn );
			
			hBox.add( Box.createGlue() );
		}
		add( hBox, new GridBagConstraints(0, 5, 4, 1, 0, 0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0,0,10,0), 0, 0) );
		
		// Done!
		aSlider.setValue( color.getAlpha() );
		rSlider.setValue( color.getRed() );
		gSlider.setValue( color.getGreen() );
		bSlider.setValue( color.getBlue() );
		
		aLabel.setText( Integer.toString( aSlider.getValue() ) );
		rLabel.setText( Integer.toString( rSlider.getValue() ) );
		gLabel.setText( Integer.toString( gSlider.getValue() ) );
		bLabel.setText( Integer.toString( bSlider.getValue() ) );
		
		// Listeners must be added last.
		aSlider.addChangeListener( new ChangeListener() {
			public void stateChanged ( ChangeEvent evt ) {
				aLabel.setText( Integer.toString( aSlider.getValue() ) );
				color = new Color( rSlider.getValue(), gSlider.getValue(), bSlider.getValue(), aSlider.getValue() );
				displayPanel.repaint();
			} } );
		rSlider.addChangeListener( new ChangeListener() {
			public void stateChanged ( ChangeEvent evt ) {
				rLabel.setText( Integer.toString( rSlider.getValue() ) );
				color = new Color( rSlider.getValue(), gSlider.getValue(), bSlider.getValue(), aSlider.getValue() );
				displayPanel.repaint();
			} } );
		gSlider.addChangeListener( new ChangeListener() {
			public void stateChanged ( ChangeEvent evt ) {
				gLabel.setText( Integer.toString( gSlider.getValue() ) );
				color = new Color( rSlider.getValue(), gSlider.getValue(), bSlider.getValue(), aSlider.getValue() );
				displayPanel.repaint();
			} } );
		bSlider.addChangeListener( new ChangeListener() {
			public void stateChanged ( ChangeEvent evt ) {
				bLabel.setText( Integer.toString( bSlider.getValue() ) );
				color = new Color( rSlider.getValue(), gSlider.getValue(), bSlider.getValue(), aSlider.getValue() );
				displayPanel.repaint();
			} } );
		
		okBtn.addActionListener(
			new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					status = STATUS_OK;
					dispose();
				}
			} );
		
		cancelBtn.addActionListener(
			new ActionListener () {
				public void actionPerformed ( ActionEvent evt ) {
					status = STATUS_CANCEL;
					dispose();
				}
			} );
		
		// Set "OK" as the default button:
		getRootPane().setDefaultButton( okBtn );
		
		// Handle escape key to simulate clicking on "Cancel"
		KeyStroke escape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false); // Pressing ESC, no modifiers, as soon as it's pressed
		Action escapeAction = new AbstractAction() {
			final static long serialVersionUID = 0;
			public void actionPerformed(ActionEvent e) {
				cancelBtn.doClick();
			} };
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escape, "ESCAPE");
		getRootPane().getActionMap().put("ESCAPE", escapeAction);
	}
	
	
	
	
	public static Color getColor ( Color initialColor ) {
		ColorChooserDialog dlg = new ColorChooserDialog( Main.f, initialColor );
		dlg.pack();
		dlg.setLocationRelativeTo( null );
		dlg.setResizable( false );
		dlg.setVisible( true );
		
		if ( dlg.status == STATUS_CANCEL )
			return null;
		else
			return dlg.color;
	}

}
