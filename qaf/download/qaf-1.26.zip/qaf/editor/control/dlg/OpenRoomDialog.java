package control.dlg;

import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import model.BGLayer;
import model.GlobalEditorModel;
import model.Room;
import model.RoomIO;
import control.Main;
import control.RoomFileFilter;

/**
 * This class handles dialogs to load an existing room from the filesystem. The
 * recommended strategy is to use the static method loadRoom() rather than
 * creating the dialogs directly. 
 */
public abstract class OpenRoomDialog {
	
	/**
	 * Loads a Room from the file system. If the supplied path is null, a
	 * dialog will be opened so the user can pick a file. Returns false if,
	 * for whatever reason, the operation ddn't conclude.
	 */
	public static boolean openRoom ( GlobalEditorModel globalEditorModel, File path ) {
		if ( path == null ) {
			JFileChooser fDlg = new JFileChooser( globalEditorModel.getBasePath() );
			fDlg.setFileSelectionMode( JFileChooser.FILES_ONLY );
			fDlg.setFileFilter( new RoomFileFilter() );
			
			if ( fDlg.showOpenDialog( Main.f ) == JFileChooser.APPROVE_OPTION )
				path = fDlg.getSelectedFile();
		}
		
		// Did the user choose a file or did he cancel?
		if ( path != null ) {
			// Check path for validity:
			if ( !globalEditorModel.isInBasePath( path.getAbsolutePath() ) ) {
				Main.showNotInBasePathDialog( Main.f, globalEditorModel.getBasePath() );
				return false;
			}
			else {
				String newRoomFileName = Main.getCanonicalPath( path );
				Room newRoom = null;
				
				// Load the room:
				try {
					newRoom = RoomIO.readRoom( newRoomFileName, globalEditorModel );
				}
				catch ( IOException exc ) {
					String[] message = {
						"The file could not be read:",
						newRoomFileName };
					JOptionPane.showMessageDialog(
						Main.f,                      // parent dialog
						message,                     // message
						"Error",                     // title
						JOptionPane.ERROR_MESSAGE ); // message type
					return false;
				}
				catch ( Exception exc ) {
					String[] message = {
						"This file does not appear to be a valid Room,",
						"or its data is corrupted." };
					JOptionPane.showMessageDialog(
						Main.f,                      // parent dialog
						message,                     // message
						"Error",                     // title
						JOptionPane.ERROR_MESSAGE ); // message type
					return false;
				}
				
				// Check and load BGLayer images:
				for ( int layerInx = 0; layerInx < newRoom.getNumOfBGLayers(); layerInx++ ) {
					BGLayer bgLayer = newRoom.getBGLayer( layerInx );
					String sourcePath = globalEditorModel.prependBasePath( bgLayer.getImageFileName() );
					
					if ( !new File( sourcePath ).exists() ) {
						String[] message = {
							"The source image for layer " + layerInx + " could not be found in the base path:",
							" ",
							bgLayer.getImageFileName(),
							" ",
							"What would you like to do?" };
						String[] options = {
							"Choose a new image",
							"Delete this layer",
							"Cancel" };
						int option = JOptionPane.showOptionDialog(
							Main.f,                     // parent
							message,                    // message
							"New room",                 // title
							JOptionPane.DEFAULT_OPTION, // option type
							JOptionPane.ERROR_MESSAGE,  // message type
							null,                       // icon
							options,                    // options
							options[0] );               // initial value
						
						if ( option == 0 ) {
							// Get new sourcePath:
							// Invalidate the current source path, and show a
							// dialog to edit the layer:
							bgLayer.setImage( null, null );
							
							if ( !EditBGLayerDialog.editLayer( globalEditorModel, bgLayer ) )
								// User canceled:
								return false;
						}
						else if ( option == 1 ) {
							// Delete this layer:
							newRoom.removeBGLayer( layerInx );
							
							// Decrease layerInx, so we can move on to the next
							// layer:
							layerInx--;
						}
						else
							// User canceled:
							return false;
					}
				}
				
				// Done!
				globalEditorModel.setLoadedRoom( newRoom, newRoomFileName );
				return true;
			}
		}
		else
			// User canceled
			return false;
	}
	
}
