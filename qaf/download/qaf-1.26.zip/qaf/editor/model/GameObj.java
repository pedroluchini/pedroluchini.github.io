package model;

import java.util.Vector;

public class GameObj {
	
	public static interface Listener {
		public void idChanged ( GameObj src );
		public void positionChanged ( GameObj src );
		public void attributeChanged ( GameObj src, String attrKey );
	}
	
	private String id;
	private int x, y;
	private AttributeTable attributes = new AttributeTable();
	
	private Vector<Listener> listeners = new Vector<Listener>();
	
	
	
	
	public void addListener ( Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	
	
	
	public void removeListener ( Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	public GameObj ( String id, int x, int y ) {
		this.id = id;
		this.x = x;
		this.y = y;
	}
	
	
	
	
	public void setID ( String id ) {
		this.id = id;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).idChanged( this );
	}
	
	
	
	
	public String getID () {
		return id;
	}
	
	
	
	
	public void setPosition ( int x, int y ) {
		this.x = x;
		this.y = y;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).positionChanged( this );
	}
	
	
	
	
	public void setX ( int x ) {
		this.x = x;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).positionChanged( this );
	}
	
	
	
	
	public void setY ( int y ) {
		this.y = y;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).positionChanged( this );
	}
	
	
	
	
	public void move ( int dx, int dy ) {
		x += dx;
		y += dy;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).positionChanged( this );
	}
	
	
	
	
	public int getX () {
		return x;
	}
	
	
	
	
	public int getY () {
		return y;
	}
	
	
	
	
	public void setAttribute ( String key, String value ) {
		attributes.putPair( key, value );
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).attributeChanged( this, key );
	}
	
	
	
	
	public void setAttributeTable ( AttributeTable newAttributeTable ) {
		attributes.removeAll();
		
		for ( int i = 0; i < newAttributeTable.size(); i++ )
			setAttribute( newAttributeTable.getKey(i), newAttributeTable.getValue(i) );
	}
	
	
	
	
	public AttributeTable getAttributeTable () {
		AttributeTable clonedAttr = new AttributeTable();
		
		for ( int i = 0; i < this.attributes.size(); i++ )
			clonedAttr.putPair(
				this.attributes.getKey(i),
				this.attributes.getValue(i) );
		
		return clonedAttr;
	}
	
	
	
	
	public String getAttribute ( String key ) {
		return attributes.getValue( key ); 
	}
	
	
	
	
	public String[] getAttributeKeys () {
		String[] keys = new String[attributes.size()];
		for ( int i = 0; i < keys.length; i++ )
			keys[i] = attributes.getKey( i );
		return keys;
	}
	
	
	
	
	public String getAttributeKey ( int inx ) {
		return attributes.getKey( inx );
	}
	
	
	
	
	public String getAttributeValue ( int inx ) {
		return attributes.getValue( inx );
	}
	
	
	
	
	public int indexOfAttrKey ( String key ) {
		return attributes.indexOf( key );
	}
	
	
	
	
	public int getNumOfAttributes () {
		return attributes.size();
	}
	
	
	
	
	public GameObj clone () {
		GameObj clonedObj = new GameObj( this.id, this.x, this.y );
		for ( int i = 0; i < attributes.size(); i++ )
			clonedObj.setAttribute( attributes.getKey(i), attributes.getValue(i) );
		
		return clonedObj;
	}
	
}
