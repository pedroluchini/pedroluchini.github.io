package model;

import control.Main;

public class TileBrushMatrix implements AbstractTileMatrix {
	
	public final static int FREE_CELL = -2;
	
	
	
	private int[][] brushMatrix = null;
	private int origRow, origCol;
	
	
	
	
	public TileBrushMatrix ( int[][] brushMatrix, int origRow, int origCol ) {
		this.origCol = origCol;
		this.origRow = origRow;
		
		if ( brushMatrix != null ) {
			int rows = brushMatrix.length;
			int cols = brushMatrix[0].length;
			
			this.brushMatrix = new int[rows][cols];
			for ( int i = 0; i < rows; i++ )
				for ( int j = 0; j < cols; j++ )
					this.brushMatrix[i][j] = brushMatrix[i][j];
		}
	}
	
	
	
	
	public int getNumOfRows () {
		if ( brushMatrix == null )
			return 0;
		else
			return brushMatrix.length;
	}
	
	
	
	
	public int getNumOfCols () {
		if ( brushMatrix == null )
			return 0;
		else
			return brushMatrix[0].length;
	}
	
	
	
	
	public int getOrigRow () {
		return origRow;
	}
	
	
	
	
	public int getOrigCol () {
		return origCol;
	}
	
	
	
	
	public int getTileAtBrushCoords ( int row, int col ) {
		return brushMatrix[row][col];
	}
	
	
	
	
	public int getTileAtGlobalCoords ( int row, int col ) {
		// Displace coords. so they're relative to the brush:
		row -= origRow;
		col -= origCol;
		
		if ( row < 0 || row >= getNumOfRows() ||
		     col < 0 || col >= getNumOfCols() )
			return FREE_CELL;
		else
			return brushMatrix[row][col];
	}
	
	
	
	
	public void setTileAtGlobalCoords ( int row, int col, int tileID ) {
		// Unsetting a tile? 
		if ( tileID == FREE_CELL ) {
			unsetTileAtGlobalCoords( row, col );
			return;
		}
		
		// The brush is empty?
		if ( brushMatrix == null ) {
			// Create new matrix, and that's it.
			brushMatrix = new int[1][1];
			brushMatrix[0][0] = tileID;
			origRow = row;
			origCol = col;
			
			return;
		}
		
		// Brush needs to be extended?
		if ( row < origRow ) {
			// To the top...
			int[][] newBrushMatrix = new int[(origRow - row) + getNumOfRows()][getNumOfCols()];
			Main.fillMatrix( newBrushMatrix, FREE_CELL );
			
			Main.blitMatrix( newBrushMatrix, brushMatrix, (origRow - row), 0 );
			
			brushMatrix = newBrushMatrix;
			origRow = row;
		}
		else
		if ( row >= origRow + getNumOfRows() ) {
			// To the bottom...
			int[][] newBrushMatrix = new int[row - origRow + 1][getNumOfCols()];
			Main.fillMatrix( newBrushMatrix, FREE_CELL );
			
			Main.blitMatrix( newBrushMatrix, brushMatrix, 0, 0 );
			
			brushMatrix = newBrushMatrix;
		}
		
		if ( col < origCol ) {
			// To the left...
			int[][] newBrushMatrix = new int[getNumOfRows()][(origCol - col) + getNumOfCols()];
			Main.fillMatrix( newBrushMatrix, FREE_CELL );
			
			Main.blitMatrix( newBrushMatrix, brushMatrix, 0, (origCol - col) );
			
			brushMatrix = newBrushMatrix;
			origCol = col;
		}
		else
		if ( col >= origCol + getNumOfCols() ) {
			// To the right...
			int[][] newBrushMatrix = new int[getNumOfRows()][col - origCol + 1];
			Main.fillMatrix( newBrushMatrix, FREE_CELL );
			
			Main.blitMatrix( newBrushMatrix, brushMatrix, 0, 0 );
			
			brushMatrix = newBrushMatrix;
		}
		
		// Displace coords. so they're relative to the brush:
		row -= origRow;
		col -= origCol;
		
		brushMatrix[row][col] = tileID;
	}
	
	
	
	
	public void setTileAtBrushCoords ( int row, int col, int tileID ) {
		setTileAtGlobalCoords( row + origRow, col + origCol, tileID );
	}
	
	
	
	
	public void unsetTileAtGlobalCoords ( int row, int col ) {
		// Ignore if coordinates outside of matrix:
		if ( row < origRow || row >= origRow + getNumOfRows() ||
		     col < origCol || col >= origCol + getNumOfCols() )
			return;
		
		// Displace coords. so they're relative to the brush:
		row -= origRow;
		col -= origCol;
		
		brushMatrix[row][col] = FREE_CELL;
		
		// Was that the last tile in the brush?
		boolean lastTile = true;
		for (int i = 0; i < brushMatrix.length; i++) {
			for (int j = 0; j < brushMatrix[0].length; j++) {
				if (brushMatrix[i][j] != FREE_CELL) {
					lastTile = false;
					break;
				}
			}
		}
		
		if (lastTile) {
			// We now have an amepty brush:
			brushMatrix = null;
			return;
		}
		
		
		// Brush needs to be shrunk?
		boolean leftmost = (col == 0),
		        rightmost = (col == brushMatrix[0].length - 1),
		        topmost = (row == 0),
		        bottmost = (row == brushMatrix.length - 1);
		
		if (leftmost) {
			int i, j;
LEFTMOST_LABEL:
			for (j = 0; j < brushMatrix[0].length; j++)
				for (i = 0; i < brushMatrix.length; i++)
					if (brushMatrix[i][j] != FREE_CELL)
						break LEFTMOST_LABEL;
			
			int[][] newBrush =
			new int[brushMatrix.length][brushMatrix[0].length - j];
			Main.blitMatrix(newBrush, brushMatrix, 0, -j);
			brushMatrix = newBrush;
			origCol += j;
		}
		else if (rightmost) {
			int i, j;
RIGHTMOST_LABEL:
			for (j = brushMatrix[0].length - 1; j >= 0; j--)
				for (i = 0; i < brushMatrix.length; i++)
					if (brushMatrix[i][j] != FREE_CELL)
						break RIGHTMOST_LABEL;
			
			int[][] newBrush = new int[brushMatrix.length][j + 1];
			Main.blitMatrix(newBrush, brushMatrix, 0, 0);
			brushMatrix = newBrush;
		}
		
		if (topmost) {
			int i, j;
TOPMOST_LABEL:
			for (i = 0; i < brushMatrix.length; i++)
				for (j = 0; j < brushMatrix[0].length; j++)
					if (brushMatrix[i][j] != FREE_CELL)
						break TOPMOST_LABEL;
			
			int[][] newBrush =
				new int[brushMatrix.length - i][brushMatrix[0].length];
			Main.blitMatrix(newBrush, brushMatrix, -i, 0);
			brushMatrix = newBrush;
			origRow += i;
		}
		else if (bottmost) {
			int i, j;
BOTTMOST_LABEL:
			for (i = brushMatrix.length - 1; i >= 0; i--)
				for (j = 0; j < brushMatrix[0].length; j++)
					if (brushMatrix[i][j] != FREE_CELL)
						break BOTTMOST_LABEL;
			
			int[][] newBrush = new int[i + 1][brushMatrix[0].length];
			Main.blitMatrix(newBrush, brushMatrix, 0, 0);
			brushMatrix = newBrush;
		}
	}
	
	
	
	
	public void unsetTileAtBrushCoords ( int row, int col ) {
		unsetTileAtGlobalCoords( row + origRow, col + origCol );
	}
	
	
	
	
	public void clearBrush () {
		brushMatrix = null;
		origCol = origRow = 0;
	}
	
	
	
	
	public void flip ( boolean horizontally, boolean vertically ) {
		if ( brushMatrix == null )
			return;
		
		// Build brush with the same size:
		int[][] newBrushMatrix = new int[brushMatrix.length][brushMatrix[0].length];
		
		// Copy:
		for ( int i = 0; i < brushMatrix.length; i++ ) {
			for ( int j = 0; j < brushMatrix[i].length; j++ ) {
				int iInx = (vertically ? (brushMatrix.length    - i - 1) : i);
				int jInx = (horizontally ? (brushMatrix[i].length - j - 1) : j);
				
				int tileID = brushMatrix[iInx][jInx];
				
				// The tileID needs to be flipped?
				if ( tileID != -1 && tileID != FREE_CELL ) {
					if ( horizontally )
						tileID ^= Room.FLIPPED_TILE_X_MASK;
					
					if ( vertically )
						tileID ^= Room.FLIPPED_TILE_Y_MASK;
				}
				
				newBrushMatrix[i][j] = tileID;
			}
		}
		
		// Done!
		brushMatrix = newBrushMatrix;
	}
	
	
	
	
	public void setOrigin ( int origRow, int origCol ) {
		this.origRow = origRow;
		this.origCol = origCol;
	}
	
	
	
	
	public void setOrigRow ( int origRow ) {
		this.origRow = origRow;
	}
	
	
	
	
	public void setOrigCol ( int origCol ) {
		this.origCol = origCol;
	}
	
	
	
	
	public boolean isTileAtBrushCoordsSet ( int row, int col ) {
		return (getTileAtBrushCoords(row, col) != TileBrushMatrix.FREE_CELL);
	}
	
	public boolean isTileAtGlobalCoordsSet ( int row, int col ) {
		return (getTileAtGlobalCoords(row, col) != TileBrushMatrix.FREE_CELL);
	}
	
}