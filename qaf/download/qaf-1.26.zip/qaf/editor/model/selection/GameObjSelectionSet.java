/*
 * Created on Jun 12, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package model.selection;

import java.awt.Rectangle;
import java.util.Collection;
import java.util.Vector;

import model.GameObj;
import model.GlobalEditorModel;

public class GameObjSelectionSet implements SelectionSet {
	
	private Vector<GameObj> objs = new Vector<GameObj>();
	
	
	
	
	public GameObjSelectionSet () {}
	
	
	
	
	public GameObjSelectionSet ( GameObj[] objs ) {
		for ( int i = 0; i < objs.length; i++ )
			this.objs.add( objs[i] );
	}
	
	
	
	
	public GameObjSelectionSet ( Collection<GameObj> objs ) {
		for ( GameObj obj : objs )
			this.objs.add( obj );
	}
	
	
	
	
	public int getNumOfObjs () {
		return objs.size();
	}
	
	
	
	
	public GameObj getObj ( int i ) {
		return objs.get( i );
	}
	
	
	
	
	public int indexOfObj ( GameObj obj ) {
		return objs.indexOf( obj );
	}
	
	
	
	
	public boolean canPaste(GlobalEditorModel gem) {
		return true;
	}
	
	
	
	
	public void move(int horiz, int vert) {
		for ( int i = 0; i < objs.size(); i++ )
			objs.get( i ).move( horiz, vert );
	}
	
	
	
	
	public void flip(boolean horizontally, boolean vertically) {
		int leftmostX  = Integer.MAX_VALUE;
		int rightmostX = Integer.MIN_VALUE;
		int topmostY   = Integer.MAX_VALUE;
		int botmostY   = Integer.MIN_VALUE;
		
		for ( int i = 0; i < objs.size(); i++ ) {
			GameObj obj = objs.get( i );
			if ( obj.getX() < leftmostX )
				leftmostX = obj.getX();
			if ( obj.getX() > rightmostX )
				rightmostX = obj.getX();
			if ( obj.getY() < topmostY )
				topmostY = obj.getY();
			if ( obj.getY() > botmostY )
				botmostY = obj.getY();
		}
		
		for ( int i = 0; i < objs.size(); i++ ) {
			GameObj obj = objs.get( i );
			
			int x = (
				horizontally ?
					rightmostX - (obj.getX() - leftmostX) :
					obj.getX() );
			int y = (
				vertically ?
					botmostY - (obj.getY() - topmostY) :
					obj.getY() );
			
			obj.setPosition( x, y );
		}	
	}
	
	
	
	
	public Object makeBackUpOfState(GlobalEditorModel globalEditorModel, int layerInx) {
		/*
		Vector<GameObj> backUp = new Vector<GameObj>();
		
		Room room = globalEditorModel.getLoadedRoom();
		for ( int i = 0; i < room.getNumOfObjs(); i++ )
			backUp.add( room.getObj( i ) );
		
		return backUp;
		*/
		return null;
	}
	
	
	
	
	@SuppressWarnings("unchecked")
	public void restoreState(GlobalEditorModel globalEditorModel, int layerInx, Object _backUp) {
		/*
		Vector<GameObj> backUp = (Vector<GameObj>) _backUp;
		Room room = globalEditorModel.getLoadedRoom();
		
		// Remove all objects:
		while ( room.getNumOfObjs() > 0 )
			room.removeGameObj( 0 );
		
		// Add objects from the backup:
		for ( int i = 0; i < backUp.size(); i++ )
			room.addGameObj( (GameObj) backUp.get( i ) );
		*/
	}
	
	
	
	
	public void centerOnScreen(GlobalEditorModel globalEditorModel, int layerInx) {
		// Get the viewport's center:
		Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
		int centerPanelX = viewRect.x + viewRect.width/2;
		int centerPanelY = viewRect.y + viewRect.height/2;
		int centerRoomX = globalEditorModel.roomXFromPanelX( centerPanelX );
		int centerRoomY = globalEditorModel.roomYFromPanelY( centerPanelY );
		
		// Get selection set's center:
		int leftmostX  = Integer.MAX_VALUE;
		int rightmostX = Integer.MIN_VALUE;
		int topmostY   = Integer.MAX_VALUE;
		int botmostY   = Integer.MIN_VALUE;
		
		for ( int i = 0; i < objs.size(); i++ ) {
			GameObj obj = objs.get( i );
			if ( obj.getX() < leftmostX )
				leftmostX = obj.getX();
			if ( obj.getX() > rightmostX )
				rightmostX = obj.getX();
			if ( obj.getY() < topmostY )
				topmostY = obj.getY();
			if ( obj.getY() > botmostY )
				botmostY = obj.getY();
		}
		
		int centerSelX = (leftmostX + rightmostX)/2;
		int centerSelY = (topmostY + botmostY)/2;
		
		// Move to center:
		int dx = centerRoomX - centerSelX;
		int dy = centerRoomY - centerSelY;
		
		for ( int i = 0; i < objs.size(); i++ )
			objs.get( i ).move( dx, dy );
	}
	
	
	
	
	public SelectionSet clone () {
		return new GameObjSelectionSet( objs );
	}
	
	
	
	
	public boolean isFloatable () {
		return false;
	}
	
	
	
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof GameObjSelectionSet ) {
			GameObjSelectionSet that = (GameObjSelectionSet) obj;
			
			if ( this.objs.size() != that.objs.size() )
				return false;
			
			for ( int i = 0; i < this.objs.size(); i++ )
				if ( !that.objs.contains( this.objs.get( i ) ) )
					return false;
			
			return true;
		}
		else
			return false;
	}
	
	public boolean equals ( SelectionSet that ) {
		return equals( (Object) that );
	}
	
	
	
	
	public boolean survivesLayerChange ( GlobalEditorModel globalEditorModel, int fromLayerInx, int toLayerInx ) {
		return true;
	}
	
	
	
	
	public SelectionSet getPasteableClone () {
		GameObjSelectionSet pasteable = new GameObjSelectionSet();
		
		for ( GameObj obj : objs )
			pasteable.objs.add( obj.clone() );
		
		return pasteable;
	}

}
