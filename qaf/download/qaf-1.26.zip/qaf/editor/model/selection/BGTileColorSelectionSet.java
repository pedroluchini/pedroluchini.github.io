/*
 * Created on Jun 16, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package model.selection;

import java.awt.Color;
import java.awt.Rectangle;

import model.AbstractTileMatrix;
import model.BGLayer;
import model.ColorTile;
import model.ColorTileMatrix;
import model.GlobalEditorModel;
import model.Room;
import control.Main;

public class BGTileColorSelectionSet implements SelectionSet, AbstractTileMatrix {
	
	ColorTileMatrix tileMatrix = null;
	private int tileWidth, tileHeight;
	
	
	
	
	public BGTileColorSelectionSet ( int tileWidth, int tileHeight, ColorTileMatrix tileMatrix ) {
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		this.tileMatrix = tileMatrix.clone();
	}
	
	
	
	
	public BGTileColorSelectionSet ( int tileWidth, int tileHeight ) {
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		this.tileMatrix = new ColorTileMatrix( null, 0, 0 );
	}
	
	
	
	
	public int getTileWidth () {
		return tileWidth;
	}
	
	
	
	
	public int getTileHeight () {
		return tileHeight;
	}
	
	
	
	
	public int getOrigRow () {
		return tileMatrix.getOrigRow();
	}
	
	public int getOrigCol () {
		return tileMatrix.getOrigCol();
	}
	
	public int getNumOfRows () {
		return tileMatrix.getNumOfRows();
	}
	
	public int getNumOfCols () {
		return tileMatrix.getNumOfCols();
	}
	
	public ColorTile getTileAtBrushCoords ( int row, int col ) {
		return tileMatrix.getTileAtBrushCoords( row, col );
	}
	
	public ColorTile getTileAtGlobalCoords ( int row, int col ) {
		return tileMatrix.getTileAtGlobalCoords( row, col );
	}
	
	
	
	
	public boolean canPaste(GlobalEditorModel gem) {
		if ( gem.getWorkingLayer() == -1 )
			return false;
		
		BGLayer bgLayer = gem.getLoadedRoom().getBGLayer( gem.getWorkingLayer() );
		
		if (bgLayer.getTileWidth() != tileWidth)
			return false;
		if (bgLayer.getTileHeight() != tileHeight)
			return false;
		
		return true;
	}
	
	
	
	
	public void move ( int horiz, int vert ) {
		int origCol = tileMatrix.getOrigCol();
		int origRow = tileMatrix.getOrigRow();
		
		origCol += horiz;
		origRow += vert;
		
		tileMatrix.setOrigin( origRow, origCol );
	}
	
	
	
	
	public SelectionSet clone () {
		return new BGTileColorSelectionSet(this.tileWidth, this.tileHeight, this.tileMatrix);
	}
	
	
	
	
	public Object makeBackUpOfState ( GlobalEditorModel globalEditorModel, int layerInx ) {
		Room room = globalEditorModel.getLoadedRoom();
		ColorTile[][] backUp = Main.getLayerTileColorMatrix( room, layerInx );
		return backUp;
	}
	
	
	
	
	public void restoreState(GlobalEditorModel globalEditorModel, int layerInx, Object _backUp) {
		Room room = globalEditorModel.getLoadedRoom();
		ColorTile[][] backUp = (ColorTile[][]) _backUp;
		
		for ( int i = 0; i < room.getBGTileMatrixRows( layerInx ); i++ )
			for ( int j = 0; j < room.getBGTileMatrixCols( layerInx ); j++ )
				room.setBGTileColor( layerInx, i, j, backUp[i][j] );
	}
	
	
	
	
	public void centerOnScreen ( GlobalEditorModel globalEditorModel, int layerInx ) {
		// Get the viewport's center:
		Rectangle viewRect = globalEditorModel.getViewport().getViewRect();
		int centerPanelX = viewRect.x + viewRect.width/2;
		int centerPanelY = viewRect.y + viewRect.height/2;
		
		// Get the row/column of the screen's center:
		int centerRow = globalEditorModel.tileRowFromPanelY( centerPanelY, layerInx );
		int centerCol = globalEditorModel.tileColFromPanelX( centerPanelX, layerInx );
		
		// Calculate how much the selection needs to be displaced so it will
		// be centered on that row/col:
		int newOrigRow = centerRow - tileMatrix.getNumOfRows() + tileMatrix.getNumOfRows()/2;
		int newOrigCol = centerCol - tileMatrix.getNumOfCols() + tileMatrix.getNumOfCols()/2;
		
		// Center it:
		tileMatrix.setOrigin( newOrigRow, newOrigCol );
	}
	
	
	
	
	public boolean isFloatable () {
		return true;
	}
	
	
	
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof BGTileColorSelectionSet ) {
			BGTileColorSelectionSet that = (BGTileColorSelectionSet) obj;
			
			if ( this.tileHeight                     != that.tileHeight                     ||
			     this.tileWidth                      != that.tileWidth                      ||
			     this.tileMatrix.getOrigCol()        != that.tileMatrix.getOrigCol()        ||
			     this.tileMatrix.getOrigRow()        != that.tileMatrix.getOrigRow()        ||
			     this.tileMatrix.getNumOfCols() != that.tileMatrix.getNumOfCols() ||
			     this.tileMatrix.getNumOfRows() != that.tileMatrix.getNumOfRows() )
				return false;
			
			for ( int i = 0; i < tileMatrix.getNumOfRows(); i++ )
				for ( int j = 0; j < tileMatrix.getNumOfCols(); j++ )
					if ( this.tileMatrix.getTileAtBrushCoords(i, j) != that.tileMatrix.getTileAtBrushCoords(i, j) )
						return false;
			
			return true;
		}
		else
			return false;
	}
	
	public boolean equals ( SelectionSet that ) {
		return equals( (Object) that);
	}
	
	
	
	
	public boolean survivesLayerChange ( GlobalEditorModel globalEditorModel, int fromLayerInx, int toLayerInx ) {
		if ( toLayerInx == -1 )
			return false;
		
		BGLayer fromLayer = globalEditorModel.getLoadedRoom().getBGLayer( fromLayerInx );
		BGLayer toLayer   = globalEditorModel.getLoadedRoom().getBGLayer( toLayerInx );
		
		if ( fromLayer.getTranslationX() != toLayer.getTranslationX() )
			return false;
		if ( fromLayer.getTranslationY() != toLayer.getTranslationY() )
			return false;
		if ( fromLayer.getParallaxX() != toLayer.getParallaxX() )
			return false;
		if ( fromLayer.getParallaxY() != toLayer.getParallaxY() )
			return false;
		if ( fromLayer.getTileHeight() != toLayer.getTileHeight() )
			return false;
		if ( fromLayer.getTileWidth() != toLayer.getTileWidth() )
			return false;
		
		return false;
	}
	
	
	
	
	public SelectionSet getPasteableClone () {
		return this.clone();
	}
	
	
	
	
	public void flip ( boolean horizontally, boolean vertically ) {
		tileMatrix.flip( horizontally, vertically );
	}
	
	
	
	
	public ColorTileMatrix cloneMatrix () {
		return tileMatrix.clone();
	}
	
	
	
	
	public boolean isTileAtBrushCoordsSet ( int row, int col ) {
		return (tileMatrix.getTileAtBrushCoords(row, col) != null);
	}
	
	public boolean isTileAtGlobalCoordsSet ( int row, int col ) {
		return (tileMatrix.getTileAtGlobalCoords(row, col) != null);
	}
	
	
	
	
	public void setTileAtGlobalCoords ( int row, int col, ColorTile colorTile ) {
		tileMatrix.setTileAtGlobalCoords( row, col, colorTile );
	}
	
	public void unsetTileAtGlobalCoords ( int row, int col ) {
		tileMatrix.unsetTileAtGlobalCoords( row, col );
	}
	
	
	
	
	public ColorTile interpolateAtGlobalCoords ( int row, int col, ColorTile colorTile ) {
		int w = tileMatrix.getNumOfCols();
		int h = tileMatrix.getNumOfRows();
		row -= tileMatrix.getOrigRow();
		col -= tileMatrix.getOrigCol();
		
		int a0 = colorTile.getColor(0).getAlpha();
		int a1 = colorTile.getColor(1).getAlpha();
		int a2 = colorTile.getColor(2).getAlpha();
		int a3 = colorTile.getColor(3).getAlpha();
		int r0 = colorTile.getColor(0).getRed();
		int r1 = colorTile.getColor(1).getRed();
		int r2 = colorTile.getColor(2).getRed();
		int r3 = colorTile.getColor(3).getRed();
		int g0 = colorTile.getColor(0).getGreen();
		int g1 = colorTile.getColor(1).getGreen();
		int g2 = colorTile.getColor(2).getGreen();
		int g3 = colorTile.getColor(3).getGreen();
		int b0 = colorTile.getColor(0).getBlue();
		int b1 = colorTile.getColor(1).getBlue();
		int b2 = colorTile.getColor(2).getBlue();
		int b3 = colorTile.getColor(3).getBlue();
		
		int resA0 = interpolate( col, w, row, h, a0, a1, a2, a3 );
		int resR0 = interpolate( col, w, row, h, r0, r1, r2, r3 );
		int resG0 = interpolate( col, w, row, h, g0, g1, g2, g3 );
		int resB0 = interpolate( col, w, row, h, b0, b1, b2, b3 );
		int resA1 = interpolate( col + 1, w, row, h, a0, a1, a2, a3 );
		int resR1 = interpolate( col + 1, w, row, h, r0, r1, r2, r3 );
		int resG1 = interpolate( col + 1, w, row, h, g0, g1, g2, g3 );
		int resB1 = interpolate( col + 1, w, row, h, b0, b1, b2, b3 );
		int resA2 = interpolate( col + 1, w, row + 1, h, a0, a1, a2, a3 );
		int resR2 = interpolate( col + 1, w, row + 1, h, r0, r1, r2, r3 );
		int resG2 = interpolate( col + 1, w, row + 1, h, g0, g1, g2, g3 );
		int resB2 = interpolate( col + 1, w, row + 1, h, b0, b1, b2, b3 );
		int resA3 = interpolate( col, w, row + 1, h, a0, a1, a2, a3 );
		int resR3 = interpolate( col, w, row + 1, h, r0, r1, r2, r3 );
		int resG3 = interpolate( col, w, row + 1, h, g0, g1, g2, g3 );
		int resB3 = interpolate( col, w, row + 1, h, b0, b1, b2, b3 );
		
		return
			new ColorTile(
				colorTile.getBlend(),
				new Color(resR0, resG0, resB0, resA0),
				new Color(resR1, resG1, resB1, resA1),
				new Color(resR2, resG2, resB2, resA2),
				new Color(resR3, resG3, resB3, resA3) );
	}
	
	
	
	
	private static int interpolate ( int x, int w, int y, int h, int c0, int c1, int c2, int c3 ) {
		float horiz = (float) x / (float) w;
		float vert  = (float) y / (float) h;
		
		return (int) ((1 - vert) * ((1 - horiz) * c0 + horiz * c1) + vert * ((1 - horiz) * c3 + horiz * c2));
	}
	
}
