package model;

import java.awt.Image;
import java.util.Vector;

import control.Main;

public class BGLayer {
	
	public static interface Listener {
		public void imageChanged ( BGLayer src );
		public void tileSizeChanged ( BGLayer src );
		public void parallaxChanged ( BGLayer src );
		public void translationChanged ( BGLayer src );
	}
	
	
	
	
	private Image image;
	private String imageFileName;
	private int tileWidth, tileHeight;
	private float parallaxFactorX, parallaxFactorY;
	private int translateX, translateY;
	
	private Vector<Listener> listeners = new Vector<Listener>();
	
	
	
	
	public void addListener ( Listener listener ) {
		if ( !listeners.contains( listener ) )
			listeners.add( listener );
	}
	
	
	
	
	public void removeListener ( Listener listener ) {
		listeners.remove( listener );
	}
	
	
	
	
	public BGLayer ( Image image,
	                 String imageFileName,
	                 int tileWidth,
	                 int tileHeight,
	                 float parallaxFactorX,
	                 float parallaxFactorY,
	                 int translateX,
	                 int translateY ) {
		this.image = image;
		this.imageFileName = imageFileName;
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		this.parallaxFactorX = parallaxFactorX;
		this.parallaxFactorY = parallaxFactorY;
		this.translateX = translateX;
		this.translateY = translateY;
	}
	
	
	
	
	public void setImage ( Image image, String imageFileName ) {
		this.image = image;
		this.imageFileName = imageFileName;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).imageChanged( this );
	}
	
	
	
	
	public Image getImage () {
		return image;
	}
	
	
	
	
	public String getImageFileName () {
		return imageFileName;
	}
	
	
	
	
	public void setTileSize ( int tileWidth, int tileHeight ) {
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).tileSizeChanged( this );
	}
	
	
	
	
	public void setTileWidth ( int tileWidth ) {
		this.tileWidth = tileWidth;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).tileSizeChanged( this );
	}
	
	
	
	
	public void setTileHeight ( int tileHeight ) {
		this.tileHeight = tileHeight;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).tileSizeChanged( this );
	}
	
	
	
	
	public int getTileWidth () {
		return tileWidth;
	}
	
	
	
	
	public int getTileHeight () {
		return tileHeight;
	}
	
	
	
	
	public void setParallax ( float parallaxX, float parallaxY ) {
		this.parallaxFactorX = parallaxX;
		this.parallaxFactorY = parallaxY;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).parallaxChanged( this );
	}
	
	
	
	
	public void setParallaxX ( float parallaxX ) {
		this.parallaxFactorX = parallaxX;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).parallaxChanged( this );
	}
	
	
	
	
	public void setParallaxY ( float parallaxY ) {
		this.parallaxFactorY = parallaxY;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).parallaxChanged( this );
	}
	
	
	
	
	public float getParallaxX () {
		return parallaxFactorX;
	}
	
	
	
	
	public float getParallaxY () {
		return parallaxFactorY;
	}
	
	
	
	
	public void setTranslation ( int translateX, int translateY ) {
		this.translateX = translateX;
		this.translateY = translateY;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).translationChanged( this );
	}
	
	
	
	
	public void setTranslationX ( int translateX ) {
		this.translateX = translateX;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).translationChanged( this );
	}
	
	
	
	
	public void setTranslationY ( int translateY ) {
		this.translateY = translateY;
		
		for ( int i = 0; i < listeners.size(); i++ )
			listeners.get( i ).translationChanged( this );
	}
	
	
	
	
	public int getTranslationX () {
		return translateX;
	}
	
	
	
	
	public int getTranslationY () {
		return translateY;
	}
	
	
	
	
	/**
	 * Returns the rows in this BGLayer's source image, given its current
	 * tile height. 
	 */
	public int getNumOfRows() {
		return image.getHeight(Main.f) / tileHeight;
	}
	
	
	
	
	/**
	 * Returns the columns in this BGLayer's source image, given its current
	 * tile width.
	 */
	public int getNumOfCols() {
		return image.getWidth(Main.f) / tileWidth;
	}
		
}
