/*
 * Created on Jun 17, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package model;

public interface AbstractTileMatrix {
	public int getNumOfRows ();
	public int getNumOfCols ();
	public int getOrigRow ();
	public int getOrigCol ();
	public boolean isTileAtBrushCoordsSet ( int row, int col );
	public boolean isTileAtGlobalCoordsSet ( int row, int col );
}
