/*
 * Created on Jun 17, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package view;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;

import model.ColorTile;
import control.Main;

public class RenderableColoredTile {
	
	private Image sourceImage;
	private int x1, x2, y1, y2;
	private ColorTile colorTile;
	
	private BufferedImage resultImage;
	
	
	
	
	public RenderableColoredTile ( Image sourceImage, int x1, int x2, int y1, int y2, ColorTile colorTile ) {
		this.sourceImage = sourceImage;
		this.x1 = x1;
		this.x2 = x2;
		this.y1 = y1;
		this.y2 = y2;
		this.colorTile = colorTile;
		
		createResultImage();
	}
	
	
	
	
	public boolean equals ( Object obj ) {
		if ( obj instanceof RenderableColoredTile ) {
			RenderableColoredTile that = (RenderableColoredTile) obj;
			return equals( that.sourceImage, that.x1, that.x2, that.y1, that.y2, that.colorTile );
		}
		else
			return false;
	}
	
	
	
	
	public boolean equals ( Image sourceImage, int x1, int x2, int y1, int y2, ColorTile colorTile ) {
		if ( !this.sourceImage.equals( sourceImage ) )
			return false;
		if ( this.x1 != x1 )
			return false;
		if ( this.x2 != x2 )
			return false;
		if ( this.y1 != y1 )
			return false;
		if ( this.y2 != y2 )
			return false;
		if ( !this.colorTile.equals( colorTile ) )
			return false;
		
		return true;
	}
	
	
	
	
	public void render ( Graphics g, int dx1, int dy1, int dx2, int dy2 ) {
		g.drawImage(
			resultImage,
			dx1, dy1,
			dx2, dy2,
			0, 0,
			resultImage.getWidth(), resultImage.getHeight(),
			Main.f );
	}
	
	
	
	
	private void createResultImage () {
		int x      = Math.min( x1, x2 );
		int y      = Math.min( y1, y2 );
		int width  = Math.abs(x1 - x2);
		int height = Math.abs(y1 - y2);
		
		int a0 = colorTile.getColor(0).getAlpha();
		int a1 = colorTile.getColor(1).getAlpha();
		int a2 = colorTile.getColor(2).getAlpha();
		int a3 = colorTile.getColor(3).getAlpha();
		
		int r0 = colorTile.getColor(0).getRed();
		int r1 = colorTile.getColor(1).getRed();
		int r2 = colorTile.getColor(2).getRed();
		int r3 = colorTile.getColor(3).getRed();
		
		int g0 = colorTile.getColor(0).getGreen();
		int g1 = colorTile.getColor(1).getGreen();
		int g2 = colorTile.getColor(2).getGreen();
		int g3 = colorTile.getColor(3).getGreen();
		
		int b0 = colorTile.getColor(0).getBlue();
		int b1 = colorTile.getColor(1).getBlue();
		int b2 = colorTile.getColor(2).getBlue();
		int b3 = colorTile.getColor(3).getBlue();
		
		resultImage = new BufferedImage( width, height, BufferedImage.TYPE_INT_ARGB );
		
		int[] pixels = new int[resultImage.getWidth() * resultImage.getHeight()];
		PixelGrabber pg = new PixelGrabber(sourceImage, x, y, width, height, pixels, 0, width);
		try {
		    pg.grabPixels();
		} catch (InterruptedException e) {
		    System.err.println("interrupted waiting for pixels!");
		}
		if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
		    System.err.println("image fetch aborted or errored");
		}
		for (int dstI = 0; dstI < height; dstI++) {
		    for (int dstJ = 0; dstJ < width; dstJ++) {
		    	int srcJ = (x1 > x2 ? width - dstJ - 1 : dstJ);
		    	int srcI = (y1 > y2 ? height - dstI - 1 : dstI);
		    	
		    	int srcColor = pixels[srcI * width + srcJ];
		    	
		    	// Interpolate tile color:
		    	int tileA = interpolate( dstJ, width, dstI, height, a0, a1, a2, a3 );
		    	int tileR = interpolate( dstJ, width, dstI, height, r0, r1, r2, r3 );
		    	int tileG = interpolate( dstJ, width, dstI, height, g0, g1, g2, g3 );
		    	int tileB = interpolate( dstJ, width, dstI, height, b0, b1, b2, b3 );
		    	
		    	int dstColor = blend( colorTile.getBlend(), srcColor, ARGB(tileA, tileR, tileG, tileB) );
		    	
		    	resultImage.setRGB( dstJ, dstI, dstColor );
		    }
		}
	}
	
	
	
	
	private static int interpolate ( int x, int w, int y, int h, int c0, int c1, int c2, int c3 ) {
		float horiz = (float) x / (float) w;
		float vert  = (float) y / (float) h;
		
		return (int) ((1 - vert) * ((1 - horiz) * c0 + horiz * c1) + vert * ((1 - horiz) * c3 + horiz * c2));
	}
	
	
	
	
	private static int GETA ( int argb ) {
		return ((argb >> 24) & 0xFF);
	}
	
	private static int GETR ( int argb ) {
		return ((argb >> 16) & 0xFF);
	}
	
	private static int GETG ( int argb ) {
		return ((argb >>  8) & 0xFF);
	}
	
	private static int GETB ( int argb ) {
		return ((argb >>  0) & 0xFF);
	}
	
	private static int ARGB ( int a, int r, int g, int b ) {
		return ((a << 24) | (r << 16) | (g << 8) | (b));
	}
	
	
	
	
	private static int blend ( int blend, int pxColor, int tileColor ) {
		float pxA = GETA(pxColor);
		float pxR = GETR(pxColor);
		float pxG = GETG(pxColor);
		float pxB = GETB(pxColor);
		float tileA = GETA(tileColor);
		float tileR = GETR(tileColor);
		float tileG = GETG(tileColor);
		float tileB = GETB(tileColor);
		pxA /= 255;
		pxR /= 255;
		pxG /= 255;
		pxB /= 255;
		tileA /= 255;
		tileR /= 255;
		tileG /= 255;
		tileB /= 255;
		
		if ( blend == ColorTile.BLEND_COLORMUL ) {
			int a = (int) (255 * pxA * tileA);
			int r = (int) (255 * pxR * tileR);
			int g = (int) (255 * pxG * tileG);
			int b = (int) (255 * pxB * tileB);
			return ARGB(a, r, g, b);
		}
		else
		if ( blend == ColorTile.BLEND_COLORADD ) {
			int a = (int) (255 * pxA * tileA);
			int r = Math.min( 255, (int) (255 * (pxR + tileR)) );
			int g = Math.min( 255, (int) (255 * (pxG + tileG)) );
			int b = Math.min( 255, (int) (255 * (pxB + tileB)) );
			return ARGB(a, r, g, b);
		}
		else
			throw new IllegalArgumentException("Unknown blend mode: 0x" + Integer.toHexString(blend));
	}
	
}
