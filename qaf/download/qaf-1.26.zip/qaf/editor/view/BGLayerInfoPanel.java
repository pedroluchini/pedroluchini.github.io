package view;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;

import model.BGLayer;

public class BGLayerInfoPanel extends Box implements BGLayer.Listener {
	final static long serialVersionUID = 0;
	
	public void imageChanged(BGLayer src) {}
	
	public void parallaxChanged(BGLayer src) {
		parallaxLabel.setText( makeParallaxLabelText() );
	}

	public void tileSizeChanged(BGLayer src) {
		tileSizeLabel.setText( makeTileSizeLabelText() );
	}

	public void translationChanged(BGLayer src) {
		translationLabel.setText( makeTranslationLabelText() );
	}
	
	
	
	
	private BGLayer bgLayer;
	private JLabel tileSizeLabel    = new JLabel(),
	               parallaxLabel    = new JLabel(),
	               translationLabel = new JLabel();
	
	
	
	
	public BGLayerInfoPanel ( BGLayer bgLayer ) {
		super( BoxLayout.X_AXIS );
		
		this.bgLayer = bgLayer;
		bgLayer.addListener( this );
		
		setAlignmentX( 0 );
		setAlignmentY( 0 );
		
		// +----------------------------+
		// | Tile size:                 |
		// | Parallax:                  |
		// | Translation:               |
		// +----------------------------+
		
		add( Box.createHorizontalStrut( 5 ) );
		
		Box vBox = Box.createVerticalBox();
		vBox.setAlignmentX( 0 );
		vBox.setAlignmentY( 0 );
		{
			vBox.add( Box.createVerticalStrut( 5 ) );
			
			tileSizeLabel.setText( makeTileSizeLabelText() );
			tileSizeLabel.setAlignmentX( 0 );
			tileSizeLabel.setAlignmentY( 0 );
			vBox.add( tileSizeLabel );
			
			parallaxLabel.setText( makeParallaxLabelText() );
			parallaxLabel.setAlignmentX( 0 );
			parallaxLabel.setAlignmentY( 0 );
			vBox.add( parallaxLabel );
			
			translationLabel.setText( makeTranslationLabelText() );
			translationLabel.setAlignmentX( 0 );
			translationLabel.setAlignmentY( 0 );
			vBox.add( translationLabel );
			
			vBox.add( Box.createVerticalStrut( 5 ) );
		}
		add( vBox );
		
		add( Box.createHorizontalStrut( 5 ) );
		
	}
	
	
	
	
	private String makeTileSizeLabelText () {
		return "Tile size: " + bgLayer.getTileWidth() + " x " + bgLayer.getTileHeight();
	}
	
	
	
	
	private String makeParallaxLabelText () {
		return "Parallax factor: " + bgLayer.getParallaxX() + " X, " + bgLayer.getParallaxY() + " Y";
	}
	
	
	
	
	private String makeTranslationLabelText () {
		return "Translation: " + bgLayer.getTranslationX() + " X, " + bgLayer.getTranslationY() + " Y";
	}

}
