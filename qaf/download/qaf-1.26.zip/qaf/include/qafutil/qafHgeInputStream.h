/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#ifndef QAF_UTIL_HGEINPUTSTREAM_H
#define QAF_UTIL_HGEINPUTSTREAM_H

#include <stdio.h>

namespace qaf {

	/**
	 * Encapsulates reading from a file stored in an HGE resource pack.
	 */
	class HgeInputStream { 
		public:
			/**
			 * The constructor will load the resource through
			 * <tt>hge->Resource_Load()</tt>, preparing it for reading. Before
			 * accessing the stream with its reading methods, it is advisable
			 * to check if the operation was successful with <tt>canRead()</tt>.
			 */
			HgeInputStream ( const char * filename );
			
			/**
			 * @return true if the file has been successfully opened and/or there
			 *         are more bytes to be read from it.
			 */
			bool canRead ();
			
			/**
			 * @return The size of this resource, in bytes.
			 */
			int getSize ();
			
			/**
			 * Behaves in the same way as <tt>fseek</tt> from the standard I/O
			 * library.
			 * 
			 * @param offset Displacement, in bytes, to position the position
			 *               indicator relative to <tt>whence</tt>.
			 * @param whence Can be one of the constants:
			 *               - SEEK_SET: Displacement relative to the beginning
			 *                 of the stream;
			 *               - SEEK_END: Displacement relative to the end of
			 *                 of the stream;
			 *               - SEEK_CUR: Displacement relative to the position
			 *                 indicator's current position.
			 * @return On success, returns 0. Otherwise, returns -1.
			 */
			int seek ( long offset, int whence );
			
			/**
			 * @return The stream's current position indicator.
			 */
			long tell ();
			
			/**
			 * @return The next byte in the stream, or -1 if the end of the
			 *         stream has been reached.
			 */
			int getC ();
			
			/**
			 * Reads a block of data from the stream.
			 * 
			 * Read <tt>count</tt> number of items each one with a size of
			 * <tt>size</tt> bytes from the stream and stores it in the
			 * specified </tt>buffer<tt>.
			 * The stream's postion indicator is increased by the number of
			 * bytes read. Total amount of bytes read is
			 * (<tt>size x count</tt>).
			 * 
			 * @return The total number of items read.
			 */
			int read ( void * buffer, long itemSize, long itemCount );
			
			/**
			 * Skips all whitespace characters (' ', '\t', '\n', '\r') from
			 * the current position until either a non-whitespace character is
			 * found or the end of the file is reached.
			 * 
			 * @return The number of characters skipped.
			 */
			int skipWhiteSpace ();
			
			/**
			 * Destructor: If the resource has been loaded, it will be
			 * automatically freed before this object is destroyed.
			 */
			virtual ~HgeInputStream ();
			
			
		private:
			unsigned char * data;
			long size;
			long filePointer;
	};
	
}



#endif
