/* 
** Qaf Framework 1.2
** June 2006
** 
** Pedro Luchini de Moraes, Public Domain - Free Lunch Code
*/

#include <qafGameObj.h>

using namespace qaf;


void GameObj::initialize () {}
void GameObj::update     ( int objLayer, float dt ) {}
void GameObj::render     ( int objLayer, float scrollX, float scrollY ) {}
bool GameObj::isVolatile () { return true; }
CollisionStruct * GameObj::getCollisionStruct () { return NULL; }
GameObj::~GameObj () {}
