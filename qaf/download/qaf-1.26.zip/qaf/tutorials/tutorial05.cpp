#include <hge.h>
#include <hgeresource.h>
#include <qafEnvironment.h>
#include <qafobj/qafAnimParticleObj.h>

using namespace qaf;

HGE * hge = NULL;
hgeResourceManager * pResManager = NULL;
bool g_bDebugRender = false;

#define SHIP_ACCEL         800.0f
#define SHIP_TOPSPEED      200.0f
#define SHIP_ANGSPEED        2.0f
#define MISSILE_SPEED      400.0f
#define MISSILE_ANGSPEED     3.5f
#define MINE_ROTSPEED        2.0f


class SpaceMineObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Mine sprite
		Vector2D    m_pos;    // Mine position
		float       m_size;   // Mine scaling
		
		CollisionStruct::Circle m_circle; // Collision boundaries
		
	public:
		SpaceMineObj ( Vector2D pos, float size ) {
			m_pos = pos;
			m_size = size;
			m_sprite = pResManager->GetSprite( "sprMine" );
			
			// Initialize collision structure:
			m_circle.setXCenter( m_pos.x );
			m_circle.setYCenter( m_pos.y );
			m_circle.setRadius( m_size * m_sprite->GetWidth() / 2 );
		}
		
		CollisionStruct * getCollisionStruct () {
			return &m_circle;
		}
		
		Vector2D getPos () {
			return m_pos;
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Render the mine, slowly rotating...
			m_sprite->RenderEx(
				m_pos.x - scrollX, m_pos.y - scrollY,
				MINE_ROTSPEED * Environment::time,
				m_size, m_size );
			
			// Render collision structure if debug rendering is on:
			if ( g_bDebugRender )
				m_circle.render( scrollX, scrollY, 0xFF00FFFF );
		}
		
		float getSize () {
			return m_size;
		}
};



class MissileObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Missile sprite
		Vector2D    m_pos;    // Missile position
		Vector2D    m_vel;    // Missile velocity
		
		CollisionStruct::Polygon m_poly; // Collision boundaries
	
	public:
		// Constructor:
		MissileObj ( Vector2D pos, Vector2D vel ) {
			m_pos = pos;
			m_vel = vel;
			m_sprite = pResManager->GetSprite( "sprMissile" );
			
			// Create a polygonal collision structure we can rotate along with
			// the sprite:
			m_poly = CollisionStruct::Polygon( m_sprite );
			
			// Initialize the polygon's position and rotation:
			Vector2D vUp = Vector2D(0, -1);
			m_poly.setRotation( vUp.angle( m_vel ) );
			m_poly.setPosition( m_pos.x, m_pos.y );
		}
		
		CollisionStruct * getCollisionStruct () {
			return &m_poly;
		}
		
		Vector2D getPos () {
			return m_pos;
		}
		
		void update ( int objLayer, float dt ) {
			// Search the Environment for the closest space mine:
			SpaceMineObj * pTargetMine = NULL;
			float fTargetDist;
			
			ObjIterator<SpaceMineObj> it = Environment::makeObjIterator<SpaceMineObj>();
			while ( it.hasNext() ) {
				SpaceMineObj * pMine = it.next();
				
				// Calculate distance between the space mine and this missile:
				float fDist = (pMine->getPos() - m_pos).length();
				
				// Have we found a shorter distance?
				if ( pTargetMine == NULL || fDist < fTargetDist ) {
					pTargetMine = pMine;
					fTargetDist = fDist;
				}
			}
			
			// We've found our target mine!
			// ...Or maybe not. If there are no mines left in the playfield,
			// then there's nothing to target.
			if ( pTargetMine != NULL ) {
				// OK, we've got a target.
				Vector2D vMissileToMine = pTargetMine->getPos() - m_pos;
				
				// Rotate the missile's velocity so it will arc towards the mine.
				if ( m_vel.angle( vMissileToMine ) < 0 )
					// Counter-clockwise:
					m_vel = m_vel.rotate( -MISSILE_ANGSPEED * dt );
				else
					// Clockwise:
					m_vel = m_vel.rotate( MISSILE_ANGSPEED * dt );
			}
			
			// Move the missile:
			m_pos += m_vel * dt;
			
			// Update collision bounds:
			Vector2D vUp = Vector2D(0, -1);
			m_poly.setRotation( vUp.angle( m_vel ) );
			m_poly.setPosition( m_pos.x, m_pos.y );
			
			// Check if the missile has left the room's area.
			Room * pRoom = Environment::getLoadedRoom();
			if ( m_pos.x < 0 || m_pos.x > pRoom->getPixelWidth() ||
			     m_pos.y < 0 || m_pos.y > pRoom->getPixelHeight() ) {
				// The missile has left the room!
				// We can remove it from the game and delete it permanently.
				Environment::removeGameObj( this, true );
			}
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Since the missile sprite is pointing upwards, let's get the
			// relative angle between the velocity and a vector pointing up.
			Vector2D vUp = Vector2D(0, -1);
			float rot = vUp.angle( m_vel );
			
			// Render it:
			m_sprite->RenderEx( m_pos.x - scrollX, m_pos.y - scrollY, rot );
			
			// Render collision structure if debug rendering is on:
			if ( g_bDebugRender )
				m_poly.render( scrollX, scrollY, 0xFF00FFFF );
		}
};



class ShipObj : public GameObj {
	private:
		hgeSprite * m_sprite; // Ship sprite
		Vector2D    m_pos;    // Ship position
		Vector2D    m_vel;    // Ship velocity
		Vector2D    m_dir;    // Ship direction (unit vector)
	public:
		// Constructor:
		ShipObj ( Vector2D pos, Vector2D dir ) {
			m_pos = pos;
			m_vel = Vector2D(0, 0);
			m_dir = dir.unit(); // Make sure it's a unit vector!
			m_sprite = pResManager->GetSprite( "sprShip" );
		}
		
		Vector2D getPos () {
			return m_pos;
		}
		
		void update ( int objLayer, float dt ) {
			// Calculate acceleration:
			Vector2D accel = Vector2D(0, 0);
			
			if ( hge->Input_GetKeyState( HGEK_UP ) )
				accel += m_dir * SHIP_ACCEL;
			
			if ( hge->Input_GetKeyState( HGEK_DOWN ) )
				accel -= m_dir * SHIP_ACCEL;
			
			// Move:
			m_pos += m_vel * dt + 0.5f * accel * dt * dt;
			
			// Update velocity:
			m_vel += accel * dt;
			
			if ( m_vel.length() > SHIP_TOPSPEED )
				m_vel = m_vel.unit() * SHIP_TOPSPEED;
			
			// Rotate clockwise?
			if ( hge->Input_GetKeyState( HGEK_RIGHT ) ) {
				m_dir = m_dir.rotate( SHIP_ANGSPEED * dt );
				m_dir.normalize(); // Prevent floating-point precision errors
			}
			
			// Rotate counter-clockwise?
			if ( hge->Input_GetKeyState( HGEK_LEFT ) ) {
				m_dir = m_dir.rotate( -SHIP_ANGSPEED * dt );
				m_dir.normalize(); // Prevent floating-point precision errors
			}
			
			// Check if the ship has left the playfield.
			Room * pRoom = Environment::getLoadedRoom();
			if ( m_pos.x < 50 ) {
				m_pos.x = 50.0f;
				m_vel.x = 0;
			}
			
			if ( m_pos.x > pRoom->getPixelWidth() - 50 ) {
				m_pos.x = (float) (pRoom->getPixelWidth() - 50);
				m_vel.x = 0;
			}
			
			if ( m_pos.y < 50 ) {
				m_pos.y = 50.0f;
				m_vel.y = 0;
			}
			
			if ( m_pos.y > pRoom->getPixelHeight() - 50 ) {
				m_pos.y = (float) (pRoom->getPixelHeight() - 50);
				m_vel.y = 0;
			}
			
			// Force scrolling to follow the ship:
			Environment::centerScrollingPoint( (int) m_pos.x, (int) m_pos.y );
			
			// Shoot a missile?
			if ( hge->Input_GetKey() == HGEK_SPACE ) {
				// Create a new missile object and put it in the Environment.
				Environment::addGameObj( new MissileObj( m_pos, m_dir * MISSILE_SPEED ) );
			}
		}
		
		void render ( int objLayer, float scrollX, float scrollY ) {
			// Since the ship sprite is pointing upwards, let's get the
			// relative angle between the direction and a vector pointing up.
			Vector2D vUp = Vector2D(0, -1);
			float rot = vUp.angle( m_dir );
			
			// Render it:
			m_sprite->RenderEx( m_pos.x - scrollX, m_pos.y - scrollY, rot );
		}
};



// Game object factory implementation:
class GameObjFactoryImpl : public GameObjFactory {
	public:
		GameObj * createObject ( std::string & objID, int objX, int objY, AttributeTable & attributes ) {
			// Which object ID?
			if ( objID == "ShipObj" ) {
				// Create ship at (objX, objY) coordinates, facing up:
				return new ShipObj( Vector2D(objX, objY), Vector2D(0, -1) );
			}
			else
			if ( objID == "SpaceMineObj" ) {
				// Get "size" attribute, and convert it to a floating point
				// number:
				float fSize = (float) atof( attributes["size"].c_str() );
				
				// Could not convert?
				if ( fSize == 0.0f )
					fSize = 1.0f;
				
				// Create mine at (objX, objY), scaled by fSize:
				return new SpaceMineObj( Vector2D(objX, objY), fSize );
			}
			else
				// Unknown ID:
				return NULL;
		}
};



// The collision handler:
void handleCollision_Missile_SpaceMine ( MissileObj * pMissile, SpaceMineObj * pMine ) {
	// Create an explosion, by using one of Qaf's helper classes:
	Environment::addGameObj(
		new AnimParticleObj( 
			pResManager->GetAnimation( "aniExplosion" ), // anim
			pMine->getPos().x, pMine->getPos().y, 0,     // x, y, angle
			0, 0, 0,                                     // vx, vy, vr
			0, 0,                                        // ax, ay
			pMine->getSize(), pMine->getSize() ) );      // sizeX, sizeY
			
	
	// Remove both objects from the playfield and delete them:
	Environment::removeGameObj( pMine, true );
	Environment::removeGameObj( pMissile, true );
}



// The frame function:
bool frameFunction () {
	// Output text:
	Environment::cout << hge->Timer_GetFPS() << " FPS\n";
	Environment::cout << "Use UP, DOWN, LEFT, RIGHT to move the ship. Press SPACE to shoot.\n";
	Environment::cout << "Press D to toggle debug rendering.\n";
	Environment::cout << "Press R to reload the room.\n";
	
	// Perform Qaf's game loop:
	Environment::update( hge->Timer_GetDelta() );
	
	if ( hge->Input_GetKeyState( HGEK_ESCAPE ) )
		return true;
	
	// Toggle debug rendering?
	if ( hge->Input_GetKey() == HGEK_D )
		g_bDebugRender = !g_bDebugRender;
	
	// Reload the room?
	if ( hge->Input_GetKey() == HGEK_R )
		Environment::loadRoom( "tut05.qr" );
	
	return false;
}



// Application entry point:
int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow ) {
	
	// Set up HGE:
	hge = hgeCreate( HGE_VERSION );
	
	hge->System_SetState( HGE_FRAMEFUNC,     frameFunction );
	hge->System_SetState( HGE_FPS,           HGEFPS_UNLIMITED );
	hge->System_SetState( HGE_SCREENWIDTH,   640 );
	hge->System_SetState( HGE_SCREENHEIGHT,  480 );
	hge->System_SetState( HGE_WINDOWED,      true );
	hge->System_SetState( HGE_LOGFILE,       "tutorial05.log" );
	
	if ( !hge->System_Initiate() )
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	
	// Load resources:
	pResManager = new hgeResourceManager( "tut05sprites.txt" );
	
	// Set up the environment:
	Environment::initialize( false, true );
	
	// Load the room:
	Environment::loadRoom( "tut05.qr" );
	
	// "Hey, Qaf, this is what you should use to create game objects":
	Environment::setGameObjFactory( new GameObjFactoryImpl() );
	
	// "Hey, Qaf, this is what you should use to handle collisions between
	// Missiles and SpaceMines":
	Environment::registerCollisionHandler<MissileObj, SpaceMineObj>( handleCollision_Missile_SpaceMine );
	
	// Start the game loop:
	if ( !hge->System_Start() ) {
		MessageBox( NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL );
	}
	
	// Shutdown:
	Environment::shutdown();
	hge->System_Shutdown();
	hge->Release();
	
	return 0;
}



/**
@page tutorial05 Tutorial 5 - Iterators and Collision Handlers

In \ref tutorial04, we created lots of mines floating around the ship, but we
didn't do anything to make them collide. This tutorial will cover a few
techniques you can use to make objects interact with each other.

@section tut05s01 Homing Missiles

What if the missiles were smart enough to always target the closest mine? To do
that, a <tt>MissileObj</tt> will need to examine all the <tt>SpaceMineObj</tt>s
and pick the closest one to itself. This can be achieved by using an <i>object
iterator</i> in <tt>MissileObj::update()</tt>:

@code
#define MISSILE_ANGSPEED     3.5f
@endcode
@code
		void update ( int objLayer, float dt ) {
			// Search the Environment for the closest space mine:
			SpaceMineObj * pTargetMine = NULL;
			float fTargetDist;
			
			ObjIterator<SpaceMineObj> it = Environment::makeObjIterator<SpaceMineObj>();
			while ( it.hasNext() ) {
				SpaceMineObj * pMine = it.next();
				
				// Calculate distance between the space mine and this missile:
				float fDist = (pMine->getPos() - m_pos).length();
				
				// Have we found a shorter distance?
				if ( pTargetMine == NULL || fDist < fTargetDist ) {
					pTargetMine = pMine;
					fTargetDist = fDist;
				}
			}
			
			// We've found our target mine!
			// ...Or maybe not. If there are no mines left in the playfield,
			// then there's nothing to target.
			if ( pTargetMine != NULL ) {
				// OK, we've got a target.
				Vector2D vMissileToMine = pTargetMine->getPos() - m_pos;
				
				// Rotate the missile's velocity so it will arc towards the mine.
				if ( m_vel.angle( vMissileToMine ) < 0 )
					// Counter-clockwise:
					m_vel = m_vel.rotate( -MISSILE_ANGSPEED * dt );
				else
					// Clockwise:
					m_vel = m_vel.rotate( MISSILE_ANGSPEED * dt );
			}
			
			...
@endcode

With this code, missiles will always fly towards the mine that's closest to
them. However, we still need to make them actually explode and destroy each
other on contact.

@section tut05s02 Collision Structures

In order to detect object-to-object collisions, each object will be assigned
an instance of <tt>qaf::CollisionStruct</tt>. This is an abstract class; check
out its documentation for a list of collision structure subclasses you can use.
For this tutorial, we'll use <tt>qaf::CollisionStruct::Circle</tt> and 
<tt>qaf::CollisionStruct::Polygon</tt>.

Next, we need to associate collision structures with our objects. This is done
with another method inherited from <tt>qaf::GameObj</tt>:

@code
qaf::CollisionStruct * qaf::GameObj::getCollisionStruct ();
@endcode

By default, <tt>GameObj</tt>'s implementation of this method returns
<tt>NULL</tt> (which means "do not test this object for collisions"). To detect
object-to-object collision, we're going to override this behavior in our
classes and return a collision structure for each object.

<b><tt>SpaceMineObj</tt>:</b> \n
This one is simple enough: Just initialize a circle in the constructor, and
return it in <tt>getCollisionStruct()</tt>.

@code
class SpaceMineObj : public GameObj {
	private:
		...
		
		CollisionStruct::Circle m_circle; // Collision boundaries
		
	public:
		SpaceMineObj ( Vector2D pos, float size ) {
			...
			
			// Initialize collision structure:
			m_circle.setXCenter( m_pos.x );
			m_circle.setYCenter( m_pos.y );
			m_circle.setRadius( m_size * m_sprite->GetWidth() / 2 );
		}
		
		CollisionStruct * getCollisionStruct () {
			return &m_circle;
		}
		
		...
	};
@endcode

<b><tt>MissileObj</tt>:</b> \n
The missiles are constantly moving and rotating, so we can't simply initialize
a bounding box in the constructor! Since the collision structure needs to be
updated all the time, we'll add a bit of code to <tt>update()</tt>.

@code
class MissileObj : public GameObj {
	private:
		...
		
		CollisionStruct::Polygon m_poly; // Collision boundaries
	
	public:
		// Constructor:
		MissileObj ( Vector2D pos, Vector2D vel ) {
			...
			
			// Create a polygonal collision structure we can rotate along with
			// the sprite:
			m_poly = CollisionStruct::Polygon( m_sprite );
			
			// Initialize the polygon's position and rotation:
			Vector2D vUp = Vector2D(0, -1);
			m_poly.setRotation( vUp.angle( m_vel ) );
			m_poly.setPosition( m_pos.x, m_pos.y );
		}
		
		CollisionStruct * getCollisionStruct () {
			return &m_poly;
		}
		
		...
		
		void update ( int objLayer, float dt ) {
			...
			
			// Update collision bounds:
			Vector2D vUp = Vector2D(0, -1);
			m_poly.setRotation( vUp.angle( m_vel ) );
			m_poly.setPosition( m_pos.x, m_pos.y );
			
			...
		}
		
		...
};
@endcode

Almost there! Now that we've taken care of collision detection, it's time to
implement collision response.

@section tut05s03 The Collision Handler

This is just a callback function. It will be invoked when a collision occurs,
and the two colliding objects will be passed as arguments to the function.
We're interested in collisions between <tt>MissileObj</tt>s and
<tt>SpaceMineObj</tt>s, so the declaration looks like this:

@code
// The collision handler:
void handleCollision_Missile_SpaceMine ( MissileObj * pMissile, SpaceMineObj * pMine ) {
@endcode

I'm going to use a predefined class from the library
(<tt>qaf::AnimParticleObj</tt>) and an animation object (declared in
<b>tut05sprites.txt</b>) to create an explosion at the space mine's position.

@code
	// Create an explosion, by using one of Qaf's helper classes:
	Environment::addGameObj(
		new AnimParticleObj( 
			pResManager->GetAnimation( "aniExplosion" ), // anim
			pMine->getPos().x, pMine->getPos().y, 0,     // x, y, angle
			0, 0, 0,                                     // vx, vy, vr
			0, 0,                                        // ax, ay
			pMine->getSize(), pMine->getSize() ) );      // sizeX, sizeY
			
@endcode

The mine and the missile will obliterate each other, so let's remove them from
the playfield.

@code
	// Remove both objects from the playfield and delete them:
	Environment::removeGameObj( pMine, true );
	Environment::removeGameObj( pMissile, true );
}
@endcode

Finally, we <em>register</em> our handler. In <tt>WinMain</tt>:

@code
	// "Hey, Qaf, this is what you should use to handle collisions between
	// Missiles and SpaceMines":
	Environment::registerCollisionHandler<MissileObj, SpaceMineObj>( handleCollision_Missile_SpaceMine );	
@endcode

The syntax is a bit heavy there, so let's look at that line little by little.
 - <tt>qaf::Environment::registerCollisionHandler</tt> is a template method. It
    accepts two <em>type parameters</em>.
 - <b><tt><MissileObj, SpaceMineObj></tt></b> are the type parameters.
   Collision detection is class-based, so we actually tell Qaf the class, or
   <em>type</em>, of object that we want to handle.
 - <b><tt>handleCollision_Missile_SpaceMine</tt></b> is a pointer to the
   function that should be called when a collision between a
   <tt>MissileObj</tt> and a <tt>SpaceMineObj</tt> is detected.

That's it!

If you run the executable, you'll see a couple of extra touches:
 - I added an option to render the collision structs' outlines by pressing "D".
   This is done via <tt>qaf::CollisionStruct::render()</tt> in the objects'
   <tt>render()</tt> method.
 - You can reload the room by pressing "R". This is a simple call to
   <tt>qaf::Environment::loadRoom()</tt> in the frame function.

See the full source code for this tutorial in the file: <b>tutorials/tutorial05.cpp</b>

*/
